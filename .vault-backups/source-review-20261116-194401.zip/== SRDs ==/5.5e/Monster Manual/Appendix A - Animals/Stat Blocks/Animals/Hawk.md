---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Hawk
> *Tiny Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/Monster Manual/Artwork/mm-p364-hawk.png|320]]
> 
> 
> **AC** 13 **Initiative** +3 (13)  
> **HP** 1 (1d4 - 1)  
> **Speed** 10 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 5 | -3 | -3 | **Dex** | 16 | +3 | +3 | **Con** | 8 | -1 | -1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 14 | +2 | +2 | **Cha** | 6 | -2 | -2 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +6  
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 16  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> **Habitat** Arctic, Coastal, Forest, Grassland, Hill, Mountain  
> **Treasure** None  
> 
> ### Actions
> 
> ***Talons.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 1 Slashing damage.
