---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: dd373738-cacf-58b5-aa59-a87a3b2787d2
entity_type: character-option
source_ids: ["phb-2024"]
---

# Slow Fall

![[== SRDs ==/Attachments/Artwork/phb-p103-monk.png|320]]

You can take a Reaction when you fall to reduce any damage you take from the fall by an amount equal to five times your Monk level.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=104|Player’s Handbook (2024), PDF page 104]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
