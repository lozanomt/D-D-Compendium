---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Air Elemental
> 
> *Large Elemental, Neutral*
> 
> ![[mm-p015-air-elemental.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +5 (15)  
> **HP** 90 (12d10 + 24)  
> **Speed** 10 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 90 ft. (hover)  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 20 | +5 | +5 | **Con** | 14 | +2 | +2 |
> | **Int** | 6 | -2 | -2 | **Wis** | 10 | +0 | +0 | **Cha** | 6 | -2 | -2 |
> 
> **Resistances** Bludgeoning, Lightning, Piercing, Slashing  
> **Immunities** Poison, Thunder; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Petrified|Petrified]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Unconscious|Unconscious]]  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Primordial (Auran)  
> **CR** 5 (XP 1,800; PB +3)  
> 
> ### Traits
> 
> ***Air Form.*** The elemental can enter a creature's space and stop there. It can move through a space as narrow as 1 inch without expending extra movement to do so.
> 
> ### Actions
> 
> ***Multiattack.*** The elemental makes two Thunderous Slam attacks.
> 
> ***Thunderous Slam.*** *Melee Attack Roll:* +8, reach 10 ft. *Hit:* 14 (2d8 + 5) Thunder damage.
> 
> ***Whirlwind (Recharge 4-6).*** *Strength Saving Throw:* DC 13, one Medium or smaller creature in the elemental's space. *Failure:* 24 (4d10 + 2) Thunder damage, and the target is pushed up to 20 feet straight away from the elemental and has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition. *Success:* Half damage only.
