---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Studded Leather Armor, +2 [[Studded Leather Armor, +2 |(40,045 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Light/Studded Leather Armor]]), Very Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-studded-leather-armor.png|320]]


**Attunement** No

You have a +2 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Light/Studded Leather Armor|clean no-title]]
