---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: d0d7be44-4bd3-5fab-91dc-c652b300d6a0
entity_type: character-option
source_ids: ["phb-2024"]
---

# Arcane Recovery

![[== SRDs ==/Attachments/Artwork/phb-p167-wizard.png|320]]

You can regain some of your magical energy by studying your spellbook. When you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short Rest]], you can choose expended spell slots to recover. The spell slots can have a combined level equal to no more than half your Wizard level (round up), and none of the slots can be level 6 or higher. Once you use this feature, you can’t do so again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=168|Player’s Handbook (2024), PDF page 168]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
