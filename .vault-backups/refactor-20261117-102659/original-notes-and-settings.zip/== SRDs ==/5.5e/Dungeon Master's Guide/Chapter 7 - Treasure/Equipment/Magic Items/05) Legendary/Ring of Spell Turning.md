---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [298]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Ring of Spell Turning
*Ring, Legendary*

![[Placeholder.png|320]]

**Attunement:** Yes

While wearing the ring, you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on saving throws against [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Spells|spells]]. If you succeed on the save against a spell of level 7 or lower, that spell has no effect on you. If it targeted only you and did not create an area of effect, you can take a Reaction to deflect it back at its caster. The caster must save against the spell using their own spell save DC.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=298|p. 295 (PDF page 298)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
