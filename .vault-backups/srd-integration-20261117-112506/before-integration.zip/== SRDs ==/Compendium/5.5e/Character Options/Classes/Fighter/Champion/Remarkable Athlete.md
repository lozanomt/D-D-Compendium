---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 5f791af4-0ad7-53c9-ba87-4bd7dd3476d4
entity_type: character-option
source_ids: ["phb-2024"]
---

# Remarkable Athlete

![[== SRDs ==/Attachments/Artwork/phb-p099-champion.png|320]]

Thanks to your athleticism, you have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]] rolls and Strength ([[== SRDs ==/Compendium/5.5e/Rules/Skills/Athletics|Athletics]]) checks. In addition, immediately after you score a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Critical Hit|Critical Hit]], you can move up to half your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]] without provoking [[== SRDs ==/Compendium/5.5e/Rules/Actions/Opportunity Attacks|Opportunity Attacks]].

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=99|Player’s Handbook (2024), PDF page 99]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
