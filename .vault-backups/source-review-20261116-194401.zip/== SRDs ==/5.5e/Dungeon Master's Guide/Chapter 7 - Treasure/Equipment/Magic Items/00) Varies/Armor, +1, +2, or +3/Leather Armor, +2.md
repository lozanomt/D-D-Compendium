---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Leather Armor, +2 [[Leather Armor, +2 |(40,010 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Light/Leather Armor]]), Very Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-leather-armor.png|320]]


**Attunement** No

You have a +2 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Light/Leather Armor|clean no-title]]
