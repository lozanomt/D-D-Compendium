---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Mass Heal
*Level 9 Abjuration (Cleric)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** Instantaneous

A flood of healing energy flows from you into creatures around you. You restore up to 700 [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]], divided as you choose among any number of creatures that you can see within range. Creatures healed by this spell also have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded|Blinded]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Deafened|Deafened]], and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]] conditions removed from them.
