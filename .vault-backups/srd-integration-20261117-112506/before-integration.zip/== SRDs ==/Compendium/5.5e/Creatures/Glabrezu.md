---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 5f501a54-52d2-508e-b226-b8748e12d871
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Glabrezu
> 
> *Large Fiend (Demon), Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p140-glabrezu.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +6 (16)  
> **HP** 189 (18d10 + 90)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 20 | +5 | +9 | **Dex** | 15 | +2 | +2 | **Con** | 21 | +5 | +9 |
> | **Int** | 19 | +4 | +4 | **Wis** | 17 | +3 | +7 | **Cha** | 16 | +3 | +7 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Deception|Deception]] +7, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +7  
> **Resistances** Cold, Fire, Lightning  
> **Immunities** Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Truesight|Truesight]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 17  
> **Languages** Abyssal; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Telepathy|Telepathy]] 120 ft.  
> **CR** 9 (XP 5,000; PB +4)  
> 
> ### Traits
> 
> ***Demonic Restoration.*** If the glabrezu dies outside the Abyss, its body dissolves into ichor, and it gains a new body instantly, reviving with all its Hit Points somewhere in the Abyss.
> 
> ***Magic Resistance.*** The glabrezu has Advantage on saving throws against spells and other magical effects.
> 
> ### Actions
> 
> ***Multiattack.*** The glabrezu makes two Pincer attacks and uses Pummel or Spellcasting.
> 
> ***Pincer.*** *Melee Attack Roll:* +9, reach 10 ft. *Hit:* 16 (2d10 + 5) Slashing damage. If the target is a Medium or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 15) from one of two pincers.
> 
> ***Pummel.*** *Dexterity Saving Throw:* DC 17, one creature [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] by the glabrezu. *Failure:* 15 (3d6 + 5) Bludgeoning damage. *Success:* Half damage.
> 
> ***Spellcasting.*** The glabrezu casts one of the following spells, requiring no Material components and using Intelligence as the spellcasting ability (spell save DC 16):
> 
> - **At Will:** *Darkness*, *Detect Magic*, *Dispel Magic*
> - **1/Day Each:** *Confusion*, *Fly*, *Power Word Stun*

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
