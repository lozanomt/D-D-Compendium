---
cssclasses: [dnd-book, dnd-phb]
source_book: "Player's Handbook (2024)"
source_pages: [346, 359]
source_pdf_pages: [349, 362]
reviewed: 2026-11-17
---
# Appendix B - Creature Stat Blocks

This appendix provides stat blocks for creatures mentioned elsewhere in the book, particularly in the class, equipment, and spell chapters. See the [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix C - Rules Glossary/Appendix C - Rules Glossary|rules glossary]] for how to read a stat block, and see the Monster Manual for even more creatures.

The following stat blocks are presented in alphabetical order. When the Dungeon Master uses a stat block, the DM may change details in it.

These 51 entries follow the supplied Player’s Handbook PDF, printed pages 346–359. [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Shared-Creature-Index|Compare the corresponding Monster Manual entries]].

## Creature Index

| Creature | CR | Source page |
| --- | --- | --- |
| [[== SRDs ==/Compendium/5.5e/Creatures/Ape#Player's Handbook\|Ape]] | 1/2 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=349\|Player’s Handbook (2024), p. 346]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Badger#Player's Handbook\|Badger]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=349\|Player’s Handbook (2024), p. 346]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Bat#Player's Handbook\|Bat]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=349\|Player’s Handbook (2024), p. 346]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Black Bear#Player's Handbook\|Black Bear]] | 1/2 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=349\|Player’s Handbook (2024), p. 346]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Boar#Player's Handbook\|Boar]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=350\|Player’s Handbook (2024), p. 347]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Brown Bear#Player's Handbook\|Brown Bear]] | 1 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=350\|Player’s Handbook (2024), p. 347]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Camel#Player's Handbook\|Camel]] | 1/8 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=350\|Player’s Handbook (2024), p. 347]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Cat#Player's Handbook\|Cat]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=350\|Player’s Handbook (2024), p. 347]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Constrictor Snake#Player's Handbook\|Constrictor Snake]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=351\|Player’s Handbook (2024), p. 348]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Crab#Player's Handbook\|Crab]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=351\|Player’s Handbook (2024), p. 348]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Crocodile#Player's Handbook\|Crocodile]] | 1/2 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=351\|Player’s Handbook (2024), p. 348]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Dire Wolf#Player's Handbook\|Dire Wolf]] | 1 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=351\|Player’s Handbook (2024), p. 348]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Draft Horse#Player's Handbook\|Draft Horse]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=352\|Player’s Handbook (2024), p. 349]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Elephant#Player's Handbook\|Elephant]] | 4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=352\|Player’s Handbook (2024), p. 349]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Elk#Player's Handbook\|Elk]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=352\|Player’s Handbook (2024), p. 349]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Frog#Player's Handbook\|Frog]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=352\|Player’s Handbook (2024), p. 349]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Giant Badger#Player's Handbook\|Giant Badger]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=353\|Player’s Handbook (2024), p. 350]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Giant Crab#Player's Handbook\|Giant Crab]] | 1/8 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=353\|Player’s Handbook (2024), p. 350]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Giant Goat#Player's Handbook\|Giant Goat]] | 1/2 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=353\|Player’s Handbook (2024), p. 350]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Giant Seahorse#Player's Handbook\|Giant Seahorse]] | 1/2 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=353\|Player’s Handbook (2024), p. 350]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Giant Spider#Player's Handbook\|Giant Spider]] | 1 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=354\|Player’s Handbook (2024), p. 351]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Giant Weasel#Player's Handbook\|Giant Weasel]] | 1/8 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=354\|Player’s Handbook (2024), p. 351]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Goat#Player's Handbook\|Goat]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=354\|Player’s Handbook (2024), p. 351]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Hawk#Player's Handbook\|Hawk]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=355\|Player’s Handbook (2024), p. 352]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Imp#Player's Handbook\|Imp]] | 1 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=355\|Player’s Handbook (2024), p. 352]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Lion#Player's Handbook\|Lion]] | 1 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=355\|Player’s Handbook (2024), p. 352]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Lizard#Player's Handbook\|Lizard]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=356\|Player’s Handbook (2024), p. 353]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Mastiff#Player's Handbook\|Mastiff]] | 1/8 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=356\|Player’s Handbook (2024), p. 353]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Mule#Player's Handbook\|Mule]] | 1/8 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=356\|Player’s Handbook (2024), p. 353]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Octopus#Player's Handbook\|Octopus]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=356\|Player’s Handbook (2024), p. 353]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Owl#Player's Handbook\|Owl]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=357\|Player’s Handbook (2024), p. 354]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Panther#Player's Handbook\|Panther]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=357\|Player’s Handbook (2024), p. 354]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Pony#Player's Handbook\|Pony]] | 1/8 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=357\|Player’s Handbook (2024), p. 354]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Pseudodragon#Player's Handbook\|Pseudodragon]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=357\|Player’s Handbook (2024), p. 354]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Quasit#Player's Handbook\|Quasit]] | 1 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=358\|Player’s Handbook (2024), p. 355]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Rat#Player's Handbook\|Rat]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=358\|Player’s Handbook (2024), p. 355]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Raven#Player's Handbook\|Raven]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=358\|Player’s Handbook (2024), p. 355]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Reef Shark#Player's Handbook\|Reef Shark]] | 1/2 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=359\|Player’s Handbook (2024), p. 356]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Riding Horse#Player's Handbook\|Riding Horse]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=359\|Player’s Handbook (2024), p. 356]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Scorpion#Player's Handbook\|Scorpion]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=359\|Player’s Handbook (2024), p. 356]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Skeleton#Player's Handbook\|Skeleton]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=359\|Player’s Handbook (2024), p. 356]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Slaad Tadpole#Player's Handbook\|Slaad Tadpole]] | 1/8 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=360\|Player’s Handbook (2024), p. 357]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Sphinx of Wonder#Player's Handbook\|Sphinx of Wonder]] | 1 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=360\|Player’s Handbook (2024), p. 357]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Spider#Player's Handbook\|Spider]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=360\|Player’s Handbook (2024), p. 357]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Sprite#Player's Handbook\|Sprite]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=361\|Player’s Handbook (2024), p. 358]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Tiger#Player's Handbook\|Tiger]] | 1 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=361\|Player’s Handbook (2024), p. 358]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Venomous Snake#Player's Handbook\|Venomous Snake]] | 1/8 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=361\|Player’s Handbook (2024), p. 358]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Warhorse#Player's Handbook\|Warhorse]] | 1/2 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=362\|Player’s Handbook (2024), p. 359]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Weasel#Player's Handbook\|Weasel]] | 0 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=362\|Player’s Handbook (2024), p. 359]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Wolf#Player's Handbook\|Wolf]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=362\|Player’s Handbook (2024), p. 359]] |
| [[== SRDs ==/Compendium/5.5e/Creatures/Zombie#Player's Handbook\|Zombie]] | 1/4 | [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=362\|Player’s Handbook (2024), p. 359]] |

## Stat Blocks

[[== SRDs ==/Compendium/5.5e/Creatures/Ape#Player's Handbook|Ape]]

[[== SRDs ==/Compendium/5.5e/Creatures/Badger#Player's Handbook|Badger]]

[[== SRDs ==/Compendium/5.5e/Creatures/Bat#Player's Handbook|Bat]]

[[== SRDs ==/Compendium/5.5e/Creatures/Black Bear#Player's Handbook|Black Bear]]

[[== SRDs ==/Compendium/5.5e/Creatures/Boar#Player's Handbook|Boar]]

[[== SRDs ==/Compendium/5.5e/Creatures/Brown Bear#Player's Handbook|Brown Bear]]

[[== SRDs ==/Compendium/5.5e/Creatures/Camel#Player's Handbook|Camel]]

[[== SRDs ==/Compendium/5.5e/Creatures/Cat#Player's Handbook|Cat]]

[[== SRDs ==/Compendium/5.5e/Creatures/Constrictor Snake#Player's Handbook|Constrictor Snake]]

[[== SRDs ==/Compendium/5.5e/Creatures/Crab#Player's Handbook|Crab]]

[[== SRDs ==/Compendium/5.5e/Creatures/Crocodile#Player's Handbook|Crocodile]]

[[== SRDs ==/Compendium/5.5e/Creatures/Dire Wolf#Player's Handbook|Dire Wolf]]

[[== SRDs ==/Compendium/5.5e/Creatures/Draft Horse#Player's Handbook|Draft Horse]]

[[== SRDs ==/Compendium/5.5e/Creatures/Elephant#Player's Handbook|Elephant]]

[[== SRDs ==/Compendium/5.5e/Creatures/Elk#Player's Handbook|Elk]]

[[== SRDs ==/Compendium/5.5e/Creatures/Frog#Player's Handbook|Frog]]

[[== SRDs ==/Compendium/5.5e/Creatures/Giant Badger#Player's Handbook|Giant Badger]]

[[== SRDs ==/Compendium/5.5e/Creatures/Giant Crab#Player's Handbook|Giant Crab]]

[[== SRDs ==/Compendium/5.5e/Creatures/Giant Goat#Player's Handbook|Giant Goat]]

[[== SRDs ==/Compendium/5.5e/Creatures/Giant Seahorse#Player's Handbook|Giant Seahorse]]

[[== SRDs ==/Compendium/5.5e/Creatures/Giant Spider#Player's Handbook|Giant Spider]]

[[== SRDs ==/Compendium/5.5e/Creatures/Giant Weasel#Player's Handbook|Giant Weasel]]

[[== SRDs ==/Compendium/5.5e/Creatures/Goat#Player's Handbook|Goat]]

[[== SRDs ==/Compendium/5.5e/Creatures/Hawk#Player's Handbook|Hawk]]

[[== SRDs ==/Compendium/5.5e/Creatures/Imp#Player's Handbook|Imp]]

[[== SRDs ==/Compendium/5.5e/Creatures/Lion#Player's Handbook|Lion]]

[[== SRDs ==/Compendium/5.5e/Creatures/Lizard#Player's Handbook|Lizard]]

[[== SRDs ==/Compendium/5.5e/Creatures/Mastiff#Player's Handbook|Mastiff]]

[[== SRDs ==/Compendium/5.5e/Creatures/Mule#Player's Handbook|Mule]]

[[== SRDs ==/Compendium/5.5e/Creatures/Octopus#Player's Handbook|Octopus]]

[[== SRDs ==/Compendium/5.5e/Creatures/Owl#Player's Handbook|Owl]]

[[== SRDs ==/Compendium/5.5e/Creatures/Panther#Player's Handbook|Panther]]

[[== SRDs ==/Compendium/5.5e/Creatures/Pony#Player's Handbook|Pony]]

[[== SRDs ==/Compendium/5.5e/Creatures/Pseudodragon#Player's Handbook|Pseudodragon]]

[[== SRDs ==/Compendium/5.5e/Creatures/Quasit#Player's Handbook|Quasit]]

[[== SRDs ==/Compendium/5.5e/Creatures/Rat#Player's Handbook|Rat]]

[[== SRDs ==/Compendium/5.5e/Creatures/Raven#Player's Handbook|Raven]]

[[== SRDs ==/Compendium/5.5e/Creatures/Reef Shark#Player's Handbook|Reef Shark]]

[[== SRDs ==/Compendium/5.5e/Creatures/Riding Horse#Player's Handbook|Riding Horse]]

[[== SRDs ==/Compendium/5.5e/Creatures/Scorpion#Player's Handbook|Scorpion]]

[[== SRDs ==/Compendium/5.5e/Creatures/Skeleton#Player's Handbook|Skeleton]]

[[== SRDs ==/Compendium/5.5e/Creatures/Slaad Tadpole#Player's Handbook|Slaad Tadpole]]

[[== SRDs ==/Compendium/5.5e/Creatures/Sphinx of Wonder#Player's Handbook|Sphinx of Wonder]]

[[== SRDs ==/Compendium/5.5e/Creatures/Spider#Player's Handbook|Spider]]

[[== SRDs ==/Compendium/5.5e/Creatures/Sprite#Player's Handbook|Sprite]]

[[== SRDs ==/Compendium/5.5e/Creatures/Tiger#Player's Handbook|Tiger]]

[[== SRDs ==/Compendium/5.5e/Creatures/Venomous Snake#Player's Handbook|Venomous Snake]]

[[== SRDs ==/Compendium/5.5e/Creatures/Warhorse#Player's Handbook|Warhorse]]

[[== SRDs ==/Compendium/5.5e/Creatures/Weasel#Player's Handbook|Weasel]]

[[== SRDs ==/Compendium/5.5e/Creatures/Wolf#Player's Handbook|Wolf]]

[[== SRDs ==/Compendium/5.5e/Creatures/Zombie#Player's Handbook|Zombie]]
