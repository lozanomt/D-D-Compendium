---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Remove Curse
*Level 3 Abjuration (Cleric, Paladin, Warlock, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Touch
**Components:** V, S
**Duration:** Instantaneous

At your touch, all [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Rules/Common Terms/Curses|curses]] affecting one creature or object end. If the object is a cursed magic item, its curse remains, but the spell breaks its owner's [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Attunement|Attunement]] to the object so it can be removed or discarded.
