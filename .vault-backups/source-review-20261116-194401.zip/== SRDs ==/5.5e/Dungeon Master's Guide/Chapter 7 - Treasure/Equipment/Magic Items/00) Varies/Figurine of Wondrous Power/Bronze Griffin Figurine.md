---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Bronze Griffin Figurine

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


#### Bronze Griffon Figurine [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Figurine of Wondrous Power/Bronze Griffin Figurine|(4,000 GP)]]
*Wondrous Item, Rare*

**Attunement:** No

A *Figurine of Wondrous Power* is a statuette small enough to fit in a pocket. If you take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action to throw the figurine to a point on the ground within 60 feet of yourself, the figurine becomes a living creature specified in the figurine’s description below. If the space where the creature would appear is occupied by other creatures or objects, or if there isn’t enough space for the creature, the figurine doesn’t become a creature.

The creature is Friendly to you and your allies. It understands your languages, obeys your commands, and takes its turn immediately after you on your [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative]] count. If you issue no commands, the creature defends itself but takes no other actions.

The creature exists for a duration specific to each figurine. At the end of the duration, the creature reverts to its figurine form. It reverts to a figurine early if its creature form drops to 0 [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]] or if you take a Magic action while touching the creature to make it revert to figurine form. When the creature becomes a figurine again, its property can’t be used again until a certain amount of time has passed, as specified in the figurine’s description.

This bronze statuette is of a griffon rampant. It can become a [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Griffon]] for up to 6 hours. Once it has been used, it can’t be used again until 5 days have passed.

---
![[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Griffon|no-title clean]]
