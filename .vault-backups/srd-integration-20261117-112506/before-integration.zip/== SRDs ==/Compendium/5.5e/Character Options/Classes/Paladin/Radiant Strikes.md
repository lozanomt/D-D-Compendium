---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: fd8450b9-1f5e-519a-8104-780d1227f401
entity_type: character-option
source_ids: ["phb-2024"]
---

# Radiant Strikes

![[== SRDs ==/Attachments/Artwork/phb-p111-paladin.png|320]]

Your strikes now carry supernatural power. When you hit a target with an attack roll using a Melee weapon or an [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]], the target takes an extra 1d8 Radiant damage.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=112|Player’s Handbook (2024), PDF page 112]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
