---
tags:
  - weaponproperty
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Heavy

![[Placeholder.png|320]]


You have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on attack rolls with a Heavy weapon if it’s a Melee weapon and your Strength score isn’t at least 13 or if it’s a Ranged weapon and your Dexterity score isn’t at least 13.
