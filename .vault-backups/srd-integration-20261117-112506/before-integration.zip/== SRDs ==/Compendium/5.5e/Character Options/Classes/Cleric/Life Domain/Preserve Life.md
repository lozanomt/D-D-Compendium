---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 6cf312f2-9cab-5be4-bc83-638407b3fdee
entity_type: character-option
source_ids: ["phb-2024"]
---

# Preserve Life

![[== SRDs ==/Attachments/Artwork/phb-p076-life-domain.png|320]]

As a [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action, you present your [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Holy Symbol/Holy Symbol|Holy Symbol]] and expend a use of your [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Cleric/Channel Divinity|Channel Divinity]] to evoke healing energy that can restore a number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] equal to five times your Cleric level. Choose [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bloodied|Bloodied]] creatures within 30 feet of yourself (which can include you), and divide those Hit Points among them. This feature can restore a creature to no more than half its Hit Point maximum.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=76|Player’s Handbook (2024), PDF page 76]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=77|Player’s Handbook (2024), PDF page 77]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
