---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 109e22ec-f144-536c-961f-35e9517589d6
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [345]
---

> [!statblock]
> ## Baboon
> 
> *Small Beast, Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 3 (1d6)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 8 | -1 | -1 | **Dex** | 14 | +2 | +2 | **Con** | 11 | +0 | +0 |
> | **Int** | 4 | -3 | -3 | **Wis** | 12 | +1 | +1 | **Cha** | 6 | -2 | -2 |
> 
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Traits
> 
> ***Pack Tactics.*** The baboon has Advantage on an attack roll against a creature if at least one of the baboon's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +1, reach 5 ft. *Hit:* 1 (1d4 - 1) Piercing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=345|SRD 5.2.1, p. 345]] — matches the existing entry.
