---
tags:
  - weaponproperty
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Loading

![[Placeholder.png|320]]


You can fire only one piece of ammunition from a Loading weapon when you use an action, a Bonus Action, or a Reaction to fire it, regardless of the number of attacks you can normally make.
