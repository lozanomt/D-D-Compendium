---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 409d1f85-63f1-5e35-87b5-1df2bd9e4d31
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Earth Elemental
> 
> *Large Elemental, Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p110-earth-elemental.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** -1 (9)  
> **HP** 147 (14d10 + 70)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Burrowing|Burrow]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 20 | +5 | +5 | **Dex** | 8 | -1 | -1 | **Con** | 20 | +5 | +5 |
> | **Int** | 5 | -3 | -3 | **Wis** | 10 | +0 | +0 | **Cha** | 5 | -3 | -3 |
> 
> **Vulnerabilities** Thunder  
> **Immunities** Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Petrified|Petrified]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Tremorsense|Tremorsense]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Primordial (Terran)  
> **CR** 5 (XP 1,800; PB +3)  
> 
> ### Traits
> 
> ***Earth Glide.*** The elemental can burrow through nonmagical, unworked earth and stone. While doing so, the elemental doesn't disturb the material it moves through.
> 
> ***Siege Monster.*** The elemental deals double damage to objects and structures.
> 
> ### Actions
> 
> ***Multiattack.*** The elemental makes two attacks, using Slam or Rock Launch in any combination.
> 
> ***Slam.*** *Melee Attack Roll:* +8, reach 10 ft. *Hit:* 14 (2d8 + 5) Bludgeoning damage.
> 
> ***Rock Launch.*** *Ranged Attack Roll:* +8, range 60 ft. *Hit:* 8 (1d6 + 5) Bludgeoning damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]] condition.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
