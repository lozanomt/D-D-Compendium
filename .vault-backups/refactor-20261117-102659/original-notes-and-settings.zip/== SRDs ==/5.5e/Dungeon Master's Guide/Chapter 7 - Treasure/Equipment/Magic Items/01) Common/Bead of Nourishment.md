---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Bead of Nourishment [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/01) Common/Bead of Nourishment|(50 GP)]]
*Wondrous Item, Common*

![[Placeholder.png|320]]


**Attunement:** No

This flavorless, gelatinous bead dissolves on your tongue and provides as much nourishment as 1 day of [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Rations|Rations]].
