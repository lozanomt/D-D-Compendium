---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Painter's Supplies [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Artisan's Tools/Painter's Supplies|(10 GP)]]

![[Placeholder.png|320]]

**Ability:** Wisdom **Weight:** 5 lb.
[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]]: Paint a recognizable image of something you've seen (DC 10)
**Craft:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Druidic Focus/Druidic Focus|Druidic Focus]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Holy Symbol/Holy Symbol|Holy Symbol]]
