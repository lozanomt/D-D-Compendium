---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Remorhaz
> *Huge Monstrosity, Unaligned*
> 
> ![[mm-p260-remorhaz.png|320]]
> 
> 
> **AC** 17 **Initiative** +5 (15)  
> **HP** 195 (17d12 + 85)  
> **Speed** 40 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Burrowing|Burrow]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 24 | +7 | +7 | **Dex** | 13 | +1 | +1 | **Con** | 21 | +5 | +5 |
> | **Int** | 4 | -3 | -3 | **Wis** | 10 | +0 | +0 | **Cha** | 5 | -3 | -3 |
> 
> **Immunities** Cold, Fire  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Tremorsense|Tremorsense]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** None  
> **CR** 11 (XP 7,200; PB +4)  
> 
> **Habitat**Arctic  
> **Treasure** None  
> 
> ### Traits
> 
> ***Heat Aura.*** At the end of each of the remorhaz's turns, each creature in a 5-foot [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Emanation|Emanation]] originating from the remorhaz takes 16 (3d10) Fire damage.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +11, reach 10 ft. *Hit:* 18 (2d10 + 7) Piercing damage plus 14 (4d6) Fire damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] condition (escape DC 17), and it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] condition until the grapple ends.
> 
> ### Bonus Actions
> 
> ***Swallow.*** *Strength Saving Throw:* DC 19, one Large or smaller creature [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] by the remorhaz (it can have up to two creatures swallowed at a time). *Failure:* The target is swallowed by the remorhaz, and the Grappled condition ends. A swallowed creature has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded|Blinded]] and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] conditions, it has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Total Cover|Total Cover]] against attacks and other effects outside the remorhaz, and it takes 10 (3d6) Acid damage plus 10 (3d6) Fire damage at the start of each of the remorhaz's turns.
> 
> If the remorhaz takes 30 damage or more on a single turn from a creature inside it, the remorhaz must succeed on a DC 15 Constitution saving throw at the end of that turn or regurgitate all swallowed creatures, each of which falls in a space within 5 feet of the remorhaz and has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition. If the remorhaz dies, any swallowed creature no longer has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] condition and can escape from the corpse by using 15 feet of movement, exiting Prone.
