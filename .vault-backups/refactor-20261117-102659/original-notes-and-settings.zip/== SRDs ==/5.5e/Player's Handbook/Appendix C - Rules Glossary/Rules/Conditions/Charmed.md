---
tags:
  - condition
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Charmed

![[Placeholder.png|320]]


While you have the Charmed condition, you experience the following effects.

***Can't Harm the Charmer.*** You can't [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|attack]] the charmer or target the charmer with damaging abilities or magical effects.

***Social Advantage.*** The charmer has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on any ability check to interact with you socially.
