---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 52149548-9bae-5f7b-b5a9-04213298ccc5
entity_type: character-option
source_ids: ["phb-2024"]
---

# Tactical Master

![[== SRDs ==/Attachments/Artwork/phb-p093-fighter.png|320]]

When you attack with a weapon whose mastery property you can use, you can replace that property with the [[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Push|Push]], [[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Sap|Sap]], or [[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Slow|Slow]] property for that attack.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=94|Player’s Handbook (2024), PDF page 94]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
