---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Monk

![[phb-p103-monk.png|320]]


###### Core Monk Traits
|                                |                                                                                                                                                                                       |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Primary Ability**            | Dexterity and Wisdom                                                                                                                                                                  |
| **Hit Point Die**              | D8 per Monk level                                                                                                                                                                     |
| **Saving Throw Proficiencies** | Strength and Dexterity                                                                                                                                                                |
| **Skill Proficiencies**        | *Choose 2:* [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Acrobatics\|Acrobatics]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Athletics\|Athletics]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/History\|History]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Insight\|Insight]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Religion\|Religion]], or [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth\|Stealth]]                                                                                     |
| **Weapon Proficiencies**       | Simple weapons and Martial weapons that have the [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Light\|Light]] property                                                                                           |
| **Tool Proficiencies** | Choose one type of Artisan’s Tools or one [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Musical Instruments\|Musical Instrument]] |
| **Armor Training**             | None                                                                                                                                                                                  |
| **Starting Equipment**         | *Choose A or B:* (A) [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Simple Melee/Spear\|Spear]], 5 [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Simple Melee/Dagger\|Daggers]], Artisan's Tools or [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Musical Instruments\|Musical Instruments]] chosen for the tool proficiency above, [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Gear Packs/Explorer's Pack\|Explorer's Pack]], and 11 GP; or (B) 50 GP |
### Becoming a Monk...
#### As a Level 1 Character
- Gain all the traits Core Monk Traits table
- Gain the Monk's level 1 features, which are listed in the Monk Features table
#### As a Multiclass Character
- Gain the Hit Point Die trait from the Core Monk Traits table.
- Gain the Monk's level 1 features, which are listed in the Monk Features table.
## Monk Class Features
As a Monk, you gain the following class features when you reach the specified Monk levels. These features are listed in the Monk Features table.
###### Monk Features
| Level | Proficiency<br>Bonus | Class Features                                       | Martial Arts | Focus Points | Unarmored Movement |
| :---: | :------------------: | ---------------------------------------------------- | :----------: | :----------: | :----------------: |
|   1   |          +2          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Martial Arts\|Martial Arts]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Unarmored Defense\|Unarmored Defense]]                      |     1d6      |      -       |         -          |
|   2   |          +2          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Monk's Focus\|Monk's Focus]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Unarmored Movement\|Unarmored Movement]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Uncanny Metabolism\|Uncanny Metabolism]] |     1d6      |      2       |      +10 ft.       |
|   3   |          +2          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Deflect Attacks\|Deflect Attacks]], Monk Subclass                       |     1d6      |      3       |      +10 ft.       |
|   4   |          +2          | Ability Score Improvement, [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Slow Fall\|Slow Fall]]                 |     1d6      |      4       |      +10 ft.       |
|   5   |          +3          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Extra Attack\|Extra Attack]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Stunning Strike\|Stunning Strike]]                        |     1d8      |      5       |      +10 ft.       |
|   6   |          +3          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Empowered Strikes\|Empowered Strikes]], Subclass feature                  |     1d8      |      6       |      +15 ft.       |
|   7   |          +3          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Evasion\|Evasion]]                                              |     1d8      |      7       |      +15 ft.       |
|   8   |          +3          | Ability Score Improvement                            |     1d8      |      8       |      +15 ft.       |
|   9   |          +4          | Acrobatic Movement                                   |     1d8      |      9       |      +15 ft.       |
|  10   |          +4          | Heightened Focus, [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Self-Restoration\|Self-Restoration]]                   |     1d8      |      10      |      +20 ft.       |
|  11   |          +4          | Subclass feature                                     |     1d10     |      11      |      +20 ft.       |
|  12   |          +4          | Ability Score Improvement                            |     1d10     |      12      |      +20 ft.       |
|  13   |          +5          | Deflect Energy                                       |     1d10     |      13      |      +20 ft.       |
|  14   |          +5          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Disciplined Survivor\|Disciplined Survivor]]                                 |     1d10     |      14      |      +25 ft.       |
|  15   |          +5          | Perfect Focus                                        |     1d10     |      15      |      +25 ft.       |
|  16   |          +5          | Ability Score Improvement                            |     1d10     |      16      |      +25 ft.       |
|  17   |          +6          | Subclass feature                                     |     1d12     |      17      |      +25 ft.       |
|  18   |          +6          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Superior Defense\|Superior Defense]]                                     |     1d12     |      18      |      +30 ft.       |
|  19   |          +6          | Epic Boon                                            |     1d12     |      19      |      +30 ft.       |
|  20   |          +6          | Body and Mind                                        |     1d12     |      20      |      +30 ft.       |
#### Level 1: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Martial Arts|Martial Arts]]
Your practice of martial arts gives you mastery of combat styles that use your Unarmed Strike and Monk weapons, which are the following:
- Simple Melee weapons
- Martial Melee weapons that have the [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Light|Light]] property
You gain the following benefits while you are unarmed or wielding only Monk weapons and you aren’t wearing armor or wielding a [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Shield|Shield]].

***Bonus Unarmed Strike.*** You can make an [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Unarmed Strike|Unarmed Strike]] as a Bonus Action.

***Martial Arts Die.*** You can roll 1d6 in place of the normal damage of your Unarmed Strike or Monk weapons. This die changes as you gain Monk levels, as shown in the Martial Arts column of the Monk Features table.

***Dexterous Attacks.*** You can use your Dexterity modifier instead of your Strength modifier for the attack and damage rolls of your Unarmed Strikes and Monk weapons. In addition, when you use the Grapple or Shove option of your Unarmed Strike, you can use your Dexterity modifier instead of your Strength modifier to determine the save DC.
#### Level 1: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Unarmored Defense|Unarmored Defense]]
While you aren’t wearing armor or wielding a [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Shield|Shield]], your base Armor Class equals 10 plus your Dexterity and Wisdom modifiers.
#### Level 2: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Monk's Focus|Monk's Focus]]
Your focus and martial training allow you to harness a well of extraordinary energy within yourself. This energy is represented by Focus Points. Your Monk level determines the number of points you have, as shown in the Focus Points column of the Monk Features table.

You can expend these points to enhance or fuel certain Monk features. You start knowing three such features: Flurry of Blows, Patient Defense, and Step of the Wind, each of which is detailed below.

When you expend a Focus Point, it is unavailable until you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]], at the end of which you regain all your expended points.

Some features that use Focus Points require your target to make a saving throw. The save DC equals 8 plus your Wisdom modifier and Proficiency Bonus.

***Flurry of Blows.*** You can expend 1 Focus Point to make two [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Unarmed Strike|Unarmed Strikes]] as a Bonus Action.

***Patient Defense.*** You can take the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Disengage|Disengage]] action as a Bonus Action. Alternatively, you can expend 1 Focus Point to take both the Disengage and the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Dodge|Dodge]] actions as a Bonus Action.

***Step of the Wind.*** You can take the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Dash|Dash]] action as a Bonus Action. Alternatively, you can expend 1 Focus Point to take both the Disengage and Dash actions as a Bonus Action, and your jump distance is doubled for the turn.
#### Level 2: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Unarmored Movement|Unarmored Movement]]
Your speed increases by 10 feet while you aren’t wearing armor or wielding a [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Shield|Shield]]. This bonus increases when you reach certain Monk levels, as shown on the Monk Features table.
#### Level 2: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Uncanny Metabolism|Uncanny Metabolism]]
When you roll [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]], you can regain all expended Focus Points. When you do so, roll your Martial Arts die, and regain a number of [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]] equal to your Monk level plus the number rolled. Once you use this feature, you can’t use it again until you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].
#### Level 3: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Deflect Attacks|Deflect Attacks]]
When an attack roll hits you and its damage includes Bludgeoning, Piercing, or Slashing damage, you can take a Reaction to reduce the attack’s total damage against you. The reduction equals 1d10 plus your Dexterity modifier and Monk level.

If you reduce the damage to 0, you can expend 1 Focus Point to redirect some of the attack’s force. If you do so, choose a creature you can see within 5 feet of yourself if the attack was a melee attack or a creature you can see within 60 feet of yourself that isn’t behind [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Total Cover|Total Cover]] if the attack was a ranged attack. That creature must succeed on a Dexterity saving throw or take damage equal to two rolls of your Martial Arts die plus your Dexterity modifier. The damage is the same type dealt by the attack.
#### Level 3: Monk Subclass
You gain a Monk subclass of your choice. A subclass is a specialization that grants you features at certain Monk levels. For the rest of your career, you gain each of your subclass’s features that are of your Monk level or lower. The following subclasses are available for you to choose from:
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Warrior of Mercy/Warrior of Mercy|Warrior of Mercy]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Warrior of Shadow/Warrior of Shadow|Warrior of Shadow]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Warrior of the Elements/Warrior of the Elements|Warrior of the Elements]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Warrior of the Open Hand/Warrior of the Open Hand|Warrior of the Open Hand]]
#### Level 4: Ability Score Improvement
You gain the [[== SRDs ==/5.5e/Player's Handbook/Chapter 5 - Feats/Feats/02) General Feats/Ability Score Improvement|Ability Score Improvement]] feat or another feat of your choice for which you qualify. You gain this feature again at Monk levels 8, 12, and 16.
#### Level 4: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Slow Fall|Slow Fall]]
You can take a Reaction when you fall to reduce any damage you take from the fall by an amount equal to five times your Monk level.
#### Level 5: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Extra Attack|Extra Attack]]
You can attack twice instead of once whenever you take the Attack action on your turn.
#### Level 5: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Stunning Strike|Stunning Strike]]
Once per turn when you hit a creature with a Monk weapon or an [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Unarmed Strike|Unarmed Strike]], you can expend 1 Focus Point to attempt a stunning strike. The target must make a Constitution saving throw. On a failed save, the target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Stunned|Stunned]] condition until the start of your next turn. On a successful save, the target’s [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]] is halved until the start of your next turn, and the next attack roll made against the target before then has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]].
#### Level 6: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Empowered Strikes|Empowered Strikes]]
Whenever you deal damage with your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Unarmed Strike|Unarmed Strike]], it can deal your choice of Force damage or its normal damage type.
#### Level 7: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Evasion|Evasion]]
When you’re subjected to an effect that allows you to make a Dexterity saving throw to take only half damage, you instead take no damage if you succeed on the saving throw and only half damage if you fail. You don’t benefit from this feature if you have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition.
#### Level 9: Acrobatic Movement
While you aren’t wearing armor or wielding a Shield, you gain the ability to move along vertical surfaces and across liquids on your turn without falling during the movement.
#### Level 10: Heightened Focus
Your Flurry of Blows, Patient Defense, and Step of the Wind gain the following benefits.

***Flurry of Blows.*** You can expend 1 Focus Point to use Flurry of Blows and make three Unarmed Strikes with it instead of two.

***Patient Defense.*** When you expend a Focus Point to use Patient Defense, you gain a number of Temporary Hit Points equal to two rolls of your Martial Arts die.

***Step of the Wind.*** When you expend a Focus Point to use Step of the Wind, you can choose a willing creature within 5 feet of yourself that is Large or smaller. You move the creature with you until the end of your turn. The creature’s movement doesn’t provoke Opportunity Attacks.
#### Level 10: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Self-Restoration|Self-Restoration]]
Through sheer force of will, you can remove one of the following conditions from yourself at the end of each of your turns: [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Frightened|Frightened]], or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]]. In addition, forgoing food and drink doesn’t give you levels of [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]].
#### Level 13: Deflect Energy
You can now use your Deflect Attacks feature against attacks that deal any damage type, not just Bludgeoning, Piercing, or Slashing.
#### Level 14: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Disciplined Survivor|Disciplined Survivor]]
Your physical and mental discipline grant you proficiency in all saving throws. Additionally, whenever you make a saving throw and fail, you can expend 1 Focus Point to reroll it, and you must use the new roll.
#### Level 15: Perfect Focus
When you roll Initiative and don’t use Uncanny Metabolism, you regain expended Focus Points until you have 4 if you have 3 or fewer.
#### Level 18: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Superior Defense|Superior Defense]]
At the start of your turn, you can expend 3 Focus Points to bolster yourself against harm for 1 minute or until you have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition. During that time, you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to all damage except Force damage.
#### Level 19: Epic Boon
You gain an Epic Boon feat or another feat of your choice for which you qualify.
#### Level 20: Body and Mind
You have developed your body and mind to new heights. Your Dexterity and Wisdom scores increase by 4, to a maximum of 25.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=104|Player’s Handbook (2024), PDF page 104]]
