---
tags:
  - action
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Attack

![[Placeholder.png|320]]


When you take the Attack action, you can make one attack roll with a weapon or an [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Unarmed Strike|Unarmed Strike]].

***Equipping and Unequipping Weapons.*** You can either equip or unequip one weapon when you make an attack as part of this action. You do so either before or after the attack. If you equip a weapon before an attack, you don’t need to use it for that attack. Equipping a weapon includes drawing it from a sheath or picking it up. Unequipping a weapon includes sheathing, stowing, or dropping it.

***Moving between Attacks.*** If you move on your turn and have a feature, such as Extra Attack, that gives you more than one attack as part of the Attack action, you can use some or all of that movement to move between those attacks.
