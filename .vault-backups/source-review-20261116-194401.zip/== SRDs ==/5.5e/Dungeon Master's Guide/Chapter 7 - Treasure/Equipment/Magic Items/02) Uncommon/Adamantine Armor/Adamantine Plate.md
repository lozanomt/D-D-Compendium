---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Adamantine Plate [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Plate|(1,900 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Plate Armor]]), Uncommon*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

While you're wearing this armor, any [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Critical Hit]] against you becomes a normal hit.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Plate Armor|clean no-title]]
