---
type: spell-reference
coverage: source-reference
level: 5
school: Conjuration
rules_revision: "2024"
classes:
  - Ranger
  - Wizard
tags:
  - rules/spell-reference
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Steel Wind Strike

![[Placeholder.png|320]]


**Level 5 · Conjuration**

## Rules reference

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=173|Handbook class spell-list entry]]

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=242|Open the handbook’s spell descriptions]] and search for **Steel Wind Strike** for the complete casting time, range, components, duration, and effects. This note supplies a source reference, not a transcription of the spell.

## Class lists

[[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Ranger|Ranger]] · [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Wizard/Wizard|Wizard]]
