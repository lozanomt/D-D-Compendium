---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Arrows, +3 [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Ammunition, +1, +2, or +3/Arrows, +3|(20,001 GP)]]
*Weapon ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Ammunition/Arrows|Arrows]]), Very Rare*

![[Placeholder.png|320]]


**Attunement:** No

You have a +3 bonus to attack rolls and damage rolls made with this piece of magic ammunition. Once it hits a target, the ammunition is no longer magical.

---
![[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Ammunition/Arrows|clean no-title]]
