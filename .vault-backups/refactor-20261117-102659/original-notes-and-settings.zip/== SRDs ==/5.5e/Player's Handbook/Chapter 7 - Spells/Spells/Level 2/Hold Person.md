---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Hold Person
*Level 2 Enchantment (Bard, Cleric, Druid, Sorcerer, Warlock, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a straight piece of iron)
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 minute

Choose a Humanoid that you can see within range. The target must succeed on a Wisdom saving throw or have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Paralyzed|Paralyzed]] condition for the duration. At the end of each of its turns, the target repeats the save, ending the spell on itself on a success.

***Using a Higher-Level Spell Slot.*** You can target one additional Humanoid for each spell slot level above 2.
