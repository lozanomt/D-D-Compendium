---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Ice Storm
*Level 4 Evocation (Druid, Sorcerer, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 300 feet
**Components:** V, S, M (a mitten)
**Duration:** Instantaneous

Hail falls in a 20-foot-radius, 40-foot-high [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Cylinder|Cylinder]] centered on a point within range. Each creature in the Cylinder makes a Dexterity saving throw. A creature takes 2d10 Bludgeoning damage and 4d6 Cold damage on a failed save or half as much damage on a successful one.

Hailstones turn ground in the Cylinder into [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Difficult Terrain|Difficult Terrain]] until the end of your next turn.

***Using a Higher-Level Spell Slot.*** The Bludgeoning damage increases by 1d10 for each spell slot level above 4.
