---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 152cda35-5223-58be-bea3-b58bdc014307
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Awakened Tree
> *Huge Plant, Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p025-awakened-shrub.png|320]]
> 
> 
> **AC** 13 **Initiative** -2 (8)  
> **HP** 59 (7d12 + 14)  
> **Speed** 20 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 6 | -2 | -2 | **Con** | 15 | +2 | +2 |
> | **Int** | 10 | +0 | +0 | **Wis** | 10 | +0 | +0 | **Cha** | 7 | -2 | -2 |
> 
> **Vulnerabilities** Fire  
> **Resistances** Bludgeoning, Piercing  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Common plus one other language  
> **CR** 2 (XP 450; PB +2)  
> 
> **Habitat** Forest  
> **Treasure** None  
> 
> ### Actions
> ***Slam.*** *Melee Attack Roll:* +6, reach 10 ft. *Hit:* 13 (2d8 + 4) Bludgeoning damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
