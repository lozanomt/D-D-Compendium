---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 46b7a15a-4c52-5e91-9501-bf12febb4d74
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [320]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Roc

## Monster Manual


> [!statblock]
> ### Roc
>
> *Gargantuan Monstrosity, Unaligned*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p263-roc.png|320]]
>
> **AC:** 15 &emsp;  
> **Initiative:** +8 (18)  
> **HP:** 248 (16d20 + 80)  
> **Speed:** 20 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 120 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 28 | +9 | +9 | **Dex** | 10 | +0 | +4 | **Con** | 20 | +5 | +5 |
> | **Int** | 3 | -4 | -4 | **Wis** | 10 | +0 | +4 | **Cha** | 9 | -1 | -1 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +8  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 18  
> **Languages:** None  
> **CR:** 11 (XP 7,200; PB +4)  
>
> #### Actions
>
> ***Multiattack.*** The roc makes two Beak attacks. It can replace one attack with a Talons attack.
>
> ***Beak.*** *Melee Attack Roll:* +13, reach 10 ft. *Hit:* 28 (3d12 + 9) Piercing damage.
>
> ***Talons.*** *Melee Attack Roll:* +13, reach 5 ft. Hit: 23 (4d6 + 9) Slashing damage. If the target is a Huge or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 19) from both talons, and it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Restrained|Restrained]] condition until the grapple ends.
>
> #### Bonus Actions
>
> ***Swoop (Recharge 5-6).*** If the roc has a creature [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]], the roc flies up to half its Fly Speed without provoking Opportunity Attacks and drops that creature.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Roc
>
> *Gargantuan Monstrosity, Unaligned*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p263-roc.png|320]]
>
> **AC:** 15 &emsp;  
> **Initiative:** +8 (18)  
> **HP:** 248 (16d20 + 80)  
> **Speed:** 20 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 120 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 28 | +9 | +9 | **Dex** | 10 | +0 | +4 | **Con** | 20 | +5 | +5 |
> | **Int** | 3 | -4 | -4 | **Wis** | 10 | +0 | +4 | **Cha** | 9 | -1 | -1 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +8  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 18  
> **Languages:** None  
> **CR:** 11 (XP 7,200; PB +4)  
>
> #### Actions
>
> ***Multiattack.*** The roc makes two Beak attacks. It can replace one attack with a Talons attack.
>
> ***Beak.*** *Melee Attack Roll:* +13, reach 10 ft. *Hit:* 28 (3d12 + 9) Piercing damage.
>
> ***Talons.*** *Melee Attack Roll:* +13, reach 5 ft. Hit: 23 (4d6 + 9) Slashing damage. If the target is a Huge or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 19) from both talons, and it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Restrained|Restrained]] condition until the grapple ends.
>
> #### Bonus Actions
>
> ***Swoop (Recharge 5-6).*** If the roc has a creature [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]], the roc flies up to half its Fly Speed without provoking Opportunity Attacks and drops that creature.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=320|SRD 5.2.1, p. 320]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
