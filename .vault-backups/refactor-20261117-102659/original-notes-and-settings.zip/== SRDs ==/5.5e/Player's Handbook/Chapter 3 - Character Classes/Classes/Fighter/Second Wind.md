---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Second Wind

![[phb-p093-fighter.png|320]]

You have a limited well of physical and mental stamina that you can draw on. As a Bonus Action, you can use it to regain [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]] equal to 1d10 plus your Fighter level. You can use this feature twice. You regain one expended use when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short Rest]], and you regain all expended uses when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]]. When you reach certain Fighter levels, you gain more uses of this feature, as shown in the Second Wind column of the Fighter Features table.

***Tactical Mind.*** At Fighter level 2, you have a mind for tactics on and off the battlefield. When you fail an ability check, you can expend a use of your Second Wind to push yourself toward success. Rather than regaining [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]], you roll 1d10 and add the number rolled to the ability check, potentially turning it into a success. If the check still fails, this use of Second Wind isn’t expended.

***Tactical Shift.*** At Fighter level 5, whenever you activate your Second Wind with a Bonus Action, you can move up to half your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]] without provoking [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Opportunity Attacks|Opportunity Attacks]].

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=94|Player’s Handbook (2024), PDF page 94]]
