---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Extra Attack

![[Placeholder.png|320]]

You can attack twice instead of once whenever you take the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] action on your turn, when a class or subclass grants this feature.

- **Fighter:** three attacks at Fighter level 11, and four at Fighter level 20.
- **Warlock:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Thirsting Blade|Thirsting Blade]] grants Extra Attack for the pact weapon only. [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Devouring Blade|Devouring Blade]] requires Warlock level 12 and Thirsting Blade, and increases this to three pact-weapon attacks.
- **Multiclassing:** Extra Attack features from different classes do not add together. Thirsting Blade does not grant additional attacks on top of another source of Extra Attack. See [[== SRDs ==/5.5e/Player's Handbook/Chapter 2 - Creating a Character/Rules/Miscellaneous/Multiclassing|Multiclassing]].

Some subclasses permit replacing an attack with a cantrip. Follow the relevant subclass’s rule; this is not a general benefit of Extra Attack.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=95|Player’s Handbook (2024), PDF page 95]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=158|Player’s Handbook (2024), PDF page 158]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=160|Player’s Handbook (2024), PDF page 160]]
