---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Defensive Tactics

![[phb-p130-hunter.png|320]]


You gain one of the following feature options of your choice. Whenever you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]], you can replace the chosen option with the other one.

***Escape the Horde.*** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Opportunity Attacks|Opportunity Attacks]] have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] against you.

***Multiattack Defense.*** When a creature hits you with an attack roll, that creature has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on all other attack rolls against you this turn.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=130|Player’s Handbook (2024), PDF page 130]]
