---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Superior Hunter's Defense

![[phb-p130-hunter.png|320]]

When you take damage, you can take a Reaction to give yourself [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to that damage and any other damage of the same type until the end of the current turn.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=130|Player’s Handbook (2024), PDF page 130]]
