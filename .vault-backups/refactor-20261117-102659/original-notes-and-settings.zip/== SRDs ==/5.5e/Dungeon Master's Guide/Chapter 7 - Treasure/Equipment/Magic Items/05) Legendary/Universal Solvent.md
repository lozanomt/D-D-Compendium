---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [321]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Universal Solvent
*Wondrous Item, Legendary*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p321-universal-solvent.png|320]]

**Attunement:** No

A found tube contains 1d6 + 1 ounces. Take a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]] action to pour one or more ounces onto a surface within [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Reach|reach]]. Each ounce instantly dissolves up to 1 square foot of adhesive it touches, including [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/05) Legendary/Sovereign Glue|Sovereign Glue]].

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=321|p. 318 (PDF page 321)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
