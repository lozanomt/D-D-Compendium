---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [308]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Spellguard Shield
*Armor (Shield), Very Rare*

![[Placeholder.png|320]]

**Attunement:** Yes

While holding the Shield, you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on saving throws against [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Spells|spells]] and other magical effects. Spell [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|attack]] rolls have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] against you.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=308|p. 305 (PDF page 308)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
