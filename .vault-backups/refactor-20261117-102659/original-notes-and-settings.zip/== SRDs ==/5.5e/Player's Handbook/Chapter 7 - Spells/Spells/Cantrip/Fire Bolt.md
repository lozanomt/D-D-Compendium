---
source_pdf_pages: [277]
review_status: "rules-checked-against-page-image"
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Fire Bolt
*Evocation Cantrip (Sorcerer, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 120 feet
**Components:** V, S
**Duration:** Instantaneous

You hurl a mote of fire at a creature or an object within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 Fire damage. A flammable object hit by this spell starts [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Hazards/Burning|burning]] if it isn't being worn or carried.

***Cantrip Upgrade.*** The damage increases by 1d10 when you reach levels 5 (2d10), 11 (3d10), and 17 (4d10).

## Source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=277|Player's Handbook, p. 274 (PDF page 277)]]
