---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Jug [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Jug|(2 CP)]] 

![[Placeholder.png|320]]

A Jug holds up to 1 gallon.

**Weight:** 4 lb.
