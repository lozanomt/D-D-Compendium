---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Roc
> 
> *Gargantuan Monstrosity, Unaligned*
> 
> ![[mm-p263-roc.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +8 (18)  
> **HP** 248 (16d20 + 80)  
> **Speed** 20 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 120 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 28 | +9 | +9 | **Dex** | 10 | +0 | +4 | **Con** | 20 | +5 | +5 |
> | **Int** | 3 | -4 | -4 | **Wis** | 10 | +0 | +4 | **Cha** | 9 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +8  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 18  
> **Languages** None  
> **CR** 11 (XP 7,200; PB +4)  
> 
> ### Actions
> 
> ***Multiattack.*** The roc makes two Beak attacks. It can replace one attack with a Talons attack.
> 
> ***Beak.*** *Melee Attack Roll:* +13, reach 10 ft. *Hit:* 28 (3d12 + 9) Piercing damage.
> 
> ***Talons.*** *Melee Attack Roll:* +13, reach 5 ft. Hit: 23 (4d6 + 9) Slashing damage. If the target is a Huge or smaller creature, it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] condition (escape DC 19) from both talons, and it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] condition until the grapple ends.
> 
> ### Bonus Actions
> 
> ***Swoop (Recharge 5-6).*** If the roc has a creature [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]], the roc flies up to half its Fly Speed without provoking Opportunity Attacks and drops that creature.
