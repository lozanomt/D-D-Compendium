---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Hunter

*Protect Nature and People from Destruction*

![[phb-p130-hunter.png|320]]


You stalk prey in the wilds and elsewhere, using your abilities as a Hunter to protect nature and people everywhere from forces that would destroy them.
#### Level 3: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Hunter/Hunter's Lore|Hunter's Lore]]
You can call on the forces of nature to reveal certain strengths and weaknesses of your prey. While a creature is marked by your *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Hunter's Mark|Hunter's Mark]]*, you know whether that creature has any [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Immunity|Immunities]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistances]], or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Vulnerability|Vulnerabilities]], and if the creature has any, you know what they are.
#### Level 3: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Hunter/Hunter's Prey|Hunter's Prey]]
You gain one of the following feature options of your choice. Whenever you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]], you can replace the chosen option with the other one.

***Colossus Slayer.*** Your tenacity can wear down even the most resilient foes. When you hit a creature with a weapon, the weapon deals an extra 1d8 damage to the target if it’s missing any of its [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]]. You can deal this extra damage only once per turn.

***Horde Breaker.*** Once on each of your turns when you make an attack with a weapon, you can make another attack with the same weapon against a different creature that is within 5 feet of the original target, that is within the weapon’s range, and that you haven’t attacked this turn.
#### Level 7: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Hunter/Defensive Tactics|Defensive Tactics]]
You gain one of the following feature options of your choice. Whenever you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]], you can replace the chosen option with the other one.

***Escape the Horde.*** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Opportunity Attacks|Opportunity Attacks]] have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] against you.

***Multiattack Defense.*** When a creature hits you with an attack roll, that creature has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on all other attack rolls against you this turn.
#### Level 11: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Hunter/Superior Hunter's Prey|Superior Hunter's Prey]]
Once per turn when you deal damage to a creature marked by your *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Hunter's Mark|Hunter's Mark]]*, you can also deal that spell’s extra damage to a different creature that you can see within 30 feet of the first creature.
#### Level 15: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Hunter/Superior Hunter's Defense|Superior Hunter's Defense]]
When you take damage, you can take a Reaction to give yourself [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to that damage and any other damage of the same type until the end of the current turn.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=130|Player’s Handbook (2024), PDF page 130]]
