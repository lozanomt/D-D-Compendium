---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 3114bb95-4fc5-5562-9285-da8c51eda220
entity_type: creature
source_ids: ["mm-2025", "phb-2024"]
source_versions: ["Monster Manual", "Player's Handbook"]
---

# Sprite

One creature entry with separately labeled source versions. Each book’s chapter links to its own version.

## Monster Manual

> [!statblock]
> ### Sprite
> 
> *Tiny Fey, Neutral Good*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p300-sprite.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +4 (14)  
> **HP** 10 (4d4)  
> **Speed** 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 3 | -4 | -4 | **Dex** | 18 | +4 | +4 | **Con** | 10 | +0 | +0 |
> | **Int** | 14 | +2 | +2 | **Wis** | 13 | +1 | +1 | **Cha** | 11 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +3, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +8  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** Common, Elvish, Sylvan  
> **CR** 1/4 (XP 50; PB +2)  
> 
> #### Actions
> 
> ***Needle Sword.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 6 (1d4 + 4) Piercing damage.
> 
> ***Enchanting Bow.*** *Ranged Attack Roll:* +6, range 40/160 ft. *Hit:* 1 Piercing damage, and the target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]] condition until the start of the sprite's next turn.
> 
> ***Heart Sight.*** *Charisma Saving Throw:* DC 10, one creature within 5 feet the sprite can see (Celestials, Fiends, and Undead automatically fail the save). *Failure:* The sprite knows the target's emotions and alignment.
> 
> ***Invisibility.*** The sprite casts *Invisibility* on itself, requiring no spell components and using Charisma as the spellcasting ability.

## Player's Handbook

> [!statblock]
> ### Sprite
>
> *Tiny Fey, Neutral Good*
>
> **AC** 15 &emsp; **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]]** +4 (14)  
> **HP** 10 (4d4)  
> **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]** 10 ft., Fly 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 3 | -4 | -4 | **Dex** | 18 | +4 | +4 | **Con** | 10 | +0 | +0 |
> | **Int** | 14 | +2 | +2 | **Wis** | 13 | +1 | +1 | **Cha** | 11 | +0 | +0 |
>
> **Skills** Perception +3, Stealth +8  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** Common, Elvish, Sylvan  
> **CR** 1/4 (XP 50; PB +2)  
>
> #### Actions
>
> ***Needle Sword.*** *Melee [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack|Attack]] Roll:* +6, reach 5 ft. *Hit:* 6 (1d4 + 4) Piercing damage.
>
> ***Enchanting Bow.*** *Ranged [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack|Attack]] Roll:* +6, range 40/160 ft. *Hit:* 1 Piercing damage, and the target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]] condition until the start of the sprite's next turn.
>
> ***Heart Sight.*** *Charisma Saving Throw:* DC 10, one creature within 5 feet the sprite can see (Celestials, Fiends, and Undead automatically fail the save). *Failure:* The sprite knows the target's emotions and alignment.
>
> ***Invisibility.*** The sprite casts *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility|Invisibility]]* on itself, requiring no spell components and using Charisma as the spellcasting ability.

Source: [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=361|Player’s Handbook (2024), p. 358]].

[[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/Compendium/5.5e/Creatures/Sprite#Monster Manual|Monster Manual version]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Player's Handbook — Appendix B - Creature Stat Blocks]]
