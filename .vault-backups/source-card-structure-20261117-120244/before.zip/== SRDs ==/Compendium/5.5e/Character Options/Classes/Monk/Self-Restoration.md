---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: a4a7f0d6-9837-5d24-82a8-a72d0c24d5e2
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [52]
---

# Self-Restoration

![[== SRDs ==/Attachments/Artwork/phb-p103-monk.png|320]]

Through sheer force of will, you can remove one of the following conditions from yourself at the end of each of your turns: [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], or [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]. In addition, forgoing food and drink doesn’t give you levels of [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]].

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=104|Player’s Handbook (2024), PDF page 104]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

Through sheer force of will, you can remove one of the following conditions from yourself at the end of each of your turns: [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], or [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]].

In addition, forgoing food and drink doesn't give you levels of [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]].

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=52|SRD 5.2.1, p. 52]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=52|SRD 5.2.1, p. 52]]
