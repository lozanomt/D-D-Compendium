---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Ring Mail, +1 [[Ring Mail, +1 |(4,030 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Ring Mail]]), Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-ring-mail.png|320]]


**Attunement** No

You have a +1 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Ring Mail|clean no-title]]
