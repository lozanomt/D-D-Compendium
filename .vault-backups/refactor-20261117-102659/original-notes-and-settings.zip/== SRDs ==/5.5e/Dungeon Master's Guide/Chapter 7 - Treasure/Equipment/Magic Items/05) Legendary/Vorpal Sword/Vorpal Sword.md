---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Vorpal Sword [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/05) Legendary/Vorpal Sword/Vorpal Sword|(Varies)]]
*Weapon ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Glaive|Glaive]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Greatsword|Greatsword]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Longsword|Longsword]], or [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Scimitar|Scimitar]]), Legendary*

![[Placeholder.png|320]]


**Attunement:** Yes

You gain a +3 bonus to attack rolls and damage rolls made with this magic weapon. In addition, the weapon ignores [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to Slashing damage.

When you use this weapon to attack a creature that has at least one head and roll a 20 on the d20 for the attack roll, you cut off one of the creature's heads. The creature dies if it can't survive without the lost head. A creature is immune to this effect if it has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Immunity|Immunity]] to Slashing damage, if it doesn't have or need a head, or of the GM decides that the creature is too big for its head to be cut off with this weapon. Such a creature instead takes an extra 30 Slashing damage from the hit. If the creature has Legendary Resistance, it can expend one daily use of that trait to avoid losing its head, taking the extra damage instead.
