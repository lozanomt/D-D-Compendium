---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Trident of Fish Command [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Trident of Fish Command|(405 GP)]]
*Weapon ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Trident]], Uncommon*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** Yes

This magic weapon has 3 charges, and it regains 1d3 expended charges daily at dawn. While you carry it, you can expend 1 charge to cast *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Dominate Beast]]* (save DC 15) from it on a Beast that has a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] Speed.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Trident|clean no-title]]
