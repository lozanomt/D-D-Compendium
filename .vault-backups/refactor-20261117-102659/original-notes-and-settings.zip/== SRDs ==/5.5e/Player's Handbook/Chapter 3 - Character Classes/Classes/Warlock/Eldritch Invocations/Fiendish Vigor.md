---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Fiendish Vigor
*Prerequisite: Level 2+ Warlock*

![[phb-p155-warlock.png|320]]


You can cast *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/False Life|False Life]]* on yourself without expending a spell slot. When you cast the spell with this feature, you don’t roll the die for the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]]; you automatically get the highest number on the die.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=156|Player’s Handbook (2024), PDF page 156]]
