---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: f6d3f71f-3c92-561c-b0fa-5c4f1c0071a2
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [350, 351]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Giant Eagle

## Monster Manual


> [!statblock]
> ### Giant Eagle
>
> *Large Celestial, Neutral Good*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC:** 13 &emsp;  
> **Initiative:** +3 (13)  
> **HP:** 26 (4d10 + 4)  
> **Speed:** 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 80 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 16 | +3 | +3 | **Dex** | 17 | +3 | +3 | **Con** | 13 | +1 | +1 |
> | **Int** | 8 | -1 | -1 | **Wis** | 14 | +2 | +2 | **Cha** | 10 | +0 | +0 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +6  
> **Resistances:** Necrotic, Radiant  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages:** Celestial; understands Common and Primordial (Auran) but can't speak them  
> **CR:** 1 (XP 200; PB +2)  
>
> #### Actions
>
> ***Multiattack.*** The eagle makes two Rend attacks.
>
> ***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 5 (1d4 + 3) Slashing damage plus 3 (1d6) Radiant damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Giant Eagle
>
> *Large Celestial, Neutral Good*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC:** 13 &emsp;  
> **Initiative:** +3 (13)  
> **HP:** 26 (4d10 + 4)  
> **Speed:** 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 80 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 16 | +3 | +3 | **Dex** | 17 | +3 | +3 | **Con** | 13 | +1 | +1 |
> | **Int** | 8 | -1 | -1 | **Wis** | 14 | +2 | +2 | **Cha** | 10 | +0 | +0 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +6  
> **Resistances:** Necrotic, Radiant  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages:** Celestial; understands Common and Primordial (Auran) but can't speak them  
> **CR:** 1 (XP 200; PB +2)  
>
> #### Actions
>
> ***Multiattack.*** The eagle makes two Rend attacks.
>
> ***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 5 (1d4 + 3) Slashing damage plus 3 (1d6) Radiant damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=350|SRD 5.2.1, p. 350–351]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
