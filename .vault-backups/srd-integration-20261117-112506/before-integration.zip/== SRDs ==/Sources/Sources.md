# Sources

Books retain their PDFs, artwork, and chapter reference pages. Chapter links lead to the shared Compendium.

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Player's Handbook|Player's Handbook]]
- [[== SRDs ==/Sources/5.5e/Monster Manual/Monster Manual|Monster Manual]]
- [[== SRDs ==/Sources/5.5e/Dungeon Master's Guide/Dungeon Master's Guide|Dungeon Master's Guide]]
