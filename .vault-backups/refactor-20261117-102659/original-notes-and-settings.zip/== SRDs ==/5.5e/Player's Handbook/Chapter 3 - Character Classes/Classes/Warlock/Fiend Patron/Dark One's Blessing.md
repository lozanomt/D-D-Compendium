---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Dark One's Blessing

![[phb-p165-fiend-patron.png|320]]

When you reduce an enemy to 0 [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]], you gain [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to your Charisma modifier plus your Warlock level (minimum of 1 Temporary Hit Point). You also gain this benefit if someone else reduces an enemy within 10 feet of you to 0 Hit Points.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=164|Player’s Handbook (2024), PDF page 164]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=165|Player’s Handbook (2024), PDF page 165]]
