---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Assassin
> 
> *Medium or Small Humanoid, Neutral*
> 
> ![[mm-p024-assassin.png|320]]
> 
> 
> **AC** 16 &emsp; **Initiative** +10 (20)  
> **HP** 97 (15d8 + 30)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +0 | **Dex** | 18 | +4 | +7 | **Con** | 14 | +2 | +2 |
> | **Int** | 16 | +3 | +6 | **Wis** | 11 | +0 | +0 | **Cha** | 10 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Acrobatics|Acrobatics]] +7, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +6, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +10  
> **Resistances** Poison  
> **Gear** Light Crossbow, Shortsword, Studded Leather Armor  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages** Common, Thieves' Cant  
> **CR** 8 (XP 3,900; PB +3)  
> 
> ### Traits
> 
> ***Evasion.*** If the assassin is subjected to an effect that allows it to make a Dexterity saving throw to take only half damage, the assassin instead takes no damage if it succeeds on the save and only half damage if it fails. It can't use this trait if it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> 
> ### Actions
> 
> ***Multiattack.*** The assassin makes three attacks, using Shortsword or Light Crossbow in any combination.
> 
> ***Shortsword.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 7 (1d6 + 4) Piercing damage plus 17 (5d6) Poison damage, and the target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]] condition until the start of the assassin's next turn.
> 
> ***Light Crossbow.*** *Ranged Attack Roll:* +7, range 80/320 ft. *Hit:* 8 (1d8 + 4) Piercing damage plus 21 (6d6) Poison damage.
> 
> ### Bonus Actions
> 
> ***Cunning Action.*** The assassin takes the Dash, Disengage, or Hide action.
