---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 24b7c535-c1dc-5868-a289-7d430c41a0f2
entity_type: character-option
source_ids: ["phb-2024"]
---

# Divine Intervention

![[== SRDs ==/Attachments/Artwork/phb-p071-cleric.png|320]]

You can call on your deity or pantheon to intervene on your behalf. As a [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action, choose any Cleric spell of level 5 or lower that doesn’t require a Reaction to cast. As part of the same action, you cast that spell without expending a spell slot or needing Material [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Components|components]]. You can’t use this feature again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

At Cleric level 20, you can call on even more powerful divine intervention. When you use your [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Cleric/Divine Intervention|Divine Intervention]] feature, you can choose *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Wish|Wish]]* when you select a spell. If you do so, you can't use Divine Intervention again until you finish 2d4 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rests]].

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=72|Player’s Handbook (2024), PDF page 72]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
