---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 4edd0b4e-d2ac-5491-a7cd-6d90cff4f15e
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [284]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Ettin

## Monster Manual


> [!statblock]
> ### Ettin
>
> *Large Giant, Chaotic Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p118-ettin.png|320]]
>
> **AC:** 12 &emsp;  
> **Initiative:** -1 (9)  
> **HP:** 85 (10d10 + 30)  
> **Speed:** 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 21 | +5 | +5 | **Dex** | 8 | -1 | -1 | **Con** | 17 | +3 | +3 |
> | **Int** | 6 | -2 | -2 | **Wis** | 10 | +0 | +0 | **Cha** | 8 | -1 | -1 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4  
> **Immunities:** [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Blinded|Blinded]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Deafened|Deafened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Stunned|Stunned]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]]  
> **Gear:** Battleaxe, Morningstar  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages:** Giant  
> **CR:** 4 (XP 1,100; PB +2)  
>
> #### Actions
>
> ***Multiattack.*** The ettin makes one Battleaxe attack and one Morningstar attack.
>
> ***Battleaxe.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 14 (2d8 + 5) Slashing damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]] condition.
>
> ***Morningstar.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 14 (2d8 + 5) Piercing damage, and the target has Disadvantage on the next attack roll it makes before the end of its next turn.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Ettin
>
> *Large Giant, Chaotic Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p118-ettin.png|320]]
>
> **AC:** 12 &emsp;  
> **Initiative:** -1 (9)  
> **HP:** 85 (10d10 + 30)  
> **Speed:** 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 21 | +5 | +5 | **Dex** | 8 | -1 | -1 | **Con** | 17 | +3 | +3 |
> | **Int** | 6 | -2 | -2 | **Wis** | 10 | +0 | +0 | **Cha** | 8 | -1 | -1 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4  
> **Immunities:** [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Blinded|Blinded]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Deafened|Deafened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Stunned|Stunned]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]]  
> **Gear:** Battleaxe, Morningstar  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages:** Giant  
> **CR:** 4 (XP 1,100; PB +2)  
>
> #### Actions
>
> ***Multiattack.*** The ettin makes one Battleaxe attack and one Morningstar attack.
>
> ***Battleaxe.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 14 (2d8 + 5) Slashing damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]] condition.
>
> ***Morningstar.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 14 (2d8 + 5) Piercing damage, and the target has Disadvantage on the next attack roll it makes before the end of its next turn.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=284|SRD 5.2.1, p. 284]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
