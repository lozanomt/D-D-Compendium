---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Life Domain

*Soothe the Hurts of the World*

![[phb-p076-life-domain.png|320]]


The Life Domain focuses on the positive energy that helps sustain all life in the multiverse. Clerics who tap into this domain are masters of healing, using that life force to cure many hurts. Existence itself relies on the positive energy associated with this domain, so a Cleric of almost any religious tradition might choose it. This domain is particularly associated with agricultural deities, gods of healing or endurance, and gods of home and community. Religious orders of healing also seek the magic of this domain
#### Level 3: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Cleric/Life Domain/Disciple of Life|Disciple of Life]]
When a spell you cast with a spell slot restores [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]] to a creature, that creature regains additional Hit Points on the turn you cast the spell. The additional Hit Points equal 2 plus the spell slot’s level.
#### Level 3: Life Domain Spells
Your connection to this divine domain ensures you always have certain spells ready. When you reach a Cleric level specified in the Life Domain Spells table, you thereafter always have the listed spells prepared.
###### Life Domain Spells
| Cleric Level | Prepared Spells                                        |
| :----------: | ------------------------------------------------------ |
|      3       | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Aid\|Aid]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Bless\|Bless]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Cure Wounds\|Cure Wounds]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Lesser Restoration\|Lesser Restoration]]* |
|      5       | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Mass Healing Word\|Mass Healing Word]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Revivify\|Revivify]]*                |
|      7       | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Aura of Life\|Aura of Life]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Death Ward\|Death Ward]]*                   |
|      9       | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Greater Restoration\|Greater Restoration]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Mass Cure Wounds\|Mass Cure Wounds]]*      |
#### Level 3: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Cleric/Life Domain/Preserve Life|Preserve Life]]
As a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action, you present your [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Holy Symbol/Holy Symbol|Holy Symbol]] and expend a use of your [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Cleric/Channel Divinity|Channel Divinity]] to evoke healing energy that can restore a number of [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]] equal to five times your Cleric level. Choose [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Bloodied|Bloodied]] creatures within 30 feet of yourself (which can include you), and divide those Hit Points among them. This feature can restore a creature to no more than half its Hit Point maximum.
#### Level 6: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Cleric/Life Domain/Blessed Healer|Blessed Healer]]
The healing spells you cast on others heal you as well. Immediately after you cast a spell with a spell slot that restores [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]] to one or more creatures other than yourself, you regain Hit Points equal to 2 plus the spell slot’s level.
#### Level 17: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Cleric/Life Domain/Supreme Healing|Supreme Healing]]
When you would normally roll one or more dice to restore [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]] to a creature with a spell or [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Cleric/Channel Divinity|Channel Divinity]], don’t roll those dice for the healing; instead use the highest number possible for each die.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=76|Player’s Handbook (2024), PDF page 76]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=77|Player’s Handbook (2024), PDF page 77]]
