---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 5691d76d-bd43-507a-9538-dd58ea8acada
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Animated Armor
> 
> *Medium Construct, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p019-animated-armor.png|320]]
> 
> 
> **AC** 18 &emsp; **Initiative** +2 (12)  
> **HP** 33 (6d8 + 6)  
> **Speed** 25 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 11 | +0 | +0 | **Con** | 13 | +1 | +1 |
> | **Int** | 1 | -5 | -5 | **Wis** | 3 | -4 | -4 | **Cha** | 1 | -5 | -5 |
> 
> **Immunities** Poison, Psychic; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Deafened|Deafened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Petrified|Petrified]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 6  
> **Languages** None  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The armor makes two Slam attacks.
> 
> ***Slam.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Bludgeoning damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
