---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Steady Aim

![[phb-p131-rogue.png|320]]

As a Bonus Action, you give yourself [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on your next attack roll on the current turn. You can use this feature only if you haven’t moved during this turn, and after you use it, your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]] is 0 until the end of the current turn.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=132|Player’s Handbook (2024), PDF page 132]]
