---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 464f76a3-9a28-5dc5-a480-3702aabc5bf6
entity_type: character-option
source_ids: ["phb-2024"]
---

# Monk's Focus

![[== SRDs ==/Attachments/Artwork/phb-p103-monk.png|320]]

Your focus and martial training allow you to harness a well of extraordinary energy within yourself. This energy is represented by Focus Points. Your Monk level determines the number of points you have, as shown in the Focus Points column of the Monk Features table.

You can expend these points to enhance or fuel certain Monk features. You start knowing three such features: Flurry of Blows, Patient Defense, and Step of the Wind, each of which is detailed below.

When you expend a Focus Point, it is unavailable until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]], at the end of which you regain all your expended points.

Some features that use Focus Points require your target to make a saving throw. The save DC equals 8 plus your Wisdom modifier and Proficiency Bonus.

***Flurry of Blows.*** You can expend 1 Focus Point to make two [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strikes]] as a Bonus Action. At Monk level 10, you make three Unarmed Strikes instead.

***Patient Defense.*** You can take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Disengage|Disengage]] action as a Bonus Action. Alternatively, you can expend 1 Focus Point to take both the Disengage and the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Dodge|Dodge]] actions as a Bonus Action. At Monk level 10, when you expend a Focus Point to use Patient Defense, you gain a number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to two rolls of your Martial Arts die.

***Step of the Wind.*** You can take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Dash|Dash]] action as a Bonus Action. Alternatively, you can expend 1 Focus Point to take both the Disengage and Dash actions as a Bonus Action, and your jump distance is doubled for the turn. At Monk level 10, when you expend a Focus Point to use Step of the Wind, you can choose a willing creature within 5 feet of yourself that is Large or smaller. You move the creature with you until the end of your turn. The creature’s movement doesn’t provoke [[== SRDs ==/Compendium/5.5e/Rules/Actions/Opportunity Attacks|Opportunity Attacks]].

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=104|Player’s Handbook (2024), PDF page 104]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
