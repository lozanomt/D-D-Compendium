---
tags:
  - action
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Help

![[Placeholder.png|320]]


When you take the Help action, you do one of the following.

***Assist an Ability Check.*** Choose one of your skill or tool proficiencies and one ally who is near enough for you to assist verbally or physically when they make an ability check. That ally has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on the next ability check they make with the chosen skill or tool. This benefit expires if the ally doesn’t use it before the start of your next turn. The GM has final say on whether your assistance is possible.

***Assist an Attack Roll.*** You momentarily distract an enemy within 5 feet of you, giving [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] to the next attack roll by one of your allies against that enemy. This benefit expires at the start of your next turn.
