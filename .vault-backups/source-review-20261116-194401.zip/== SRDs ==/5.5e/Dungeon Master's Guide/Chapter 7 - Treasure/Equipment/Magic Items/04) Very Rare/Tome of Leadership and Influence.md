---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Name [[Magic Item|(# GP)]]
*Category, Rarity*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p320-tome-of-leadership-and-influence.png|320]]


**Attunement:**

Description
