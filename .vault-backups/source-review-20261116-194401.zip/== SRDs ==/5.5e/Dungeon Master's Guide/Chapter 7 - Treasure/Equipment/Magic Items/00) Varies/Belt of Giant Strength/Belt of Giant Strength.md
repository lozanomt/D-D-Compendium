---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Belt of Giant Strength

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p239-belt-of-giant-strength.png|320]]


#### Belt of Gaint Strength [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Belt of Giant Strength/Belt of Giant Strength|(Varies)]]
*Wondrous Item, Rarity Varies*

**Attunement:** Yes

While wearing this belt, your Strength changes to a score granted by the belt. The type of giant determines the score (see the table below). The item has no effect on you if your Strength without the belt is equal to or greater than the belt’s score.

| Belt                                                                     | Str, | Rarity    |
| ------------------------------------------------------------------------ | :----: | --------- |
| *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Belt of Giant Strength/Belt of Hill Giant Strength]]*                                        | 21   | Rare      |
| *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Belt of Giant Strength/Belt of Frost Giant Strength]]* or *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Belt of Giant Strength/Belt of Stone Giant Strength]]* | 23   | Very Rare |
| *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Belt of Giant Strength/Belt of Fire Giant Strength]]*                                        | 25   | Very Rare |
| *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Belt of Giant Strength/Belt of Cloud Giant Strength]]*                                       | 27   | Legendary |
| *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Belt of Giant Strength/Belt of Storm Giant Strength]]*                                       | 29   | Legendary |
