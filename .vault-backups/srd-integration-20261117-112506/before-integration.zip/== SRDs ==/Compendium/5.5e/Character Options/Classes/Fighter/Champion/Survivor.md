---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 546320ae-cb62-5e3c-8bc4-60dfc9ad6acd
entity_type: character-option
source_ids: ["phb-2024"]
---

# Survivor

![[== SRDs ==/Attachments/Artwork/phb-p099-champion.png|320]]

You attain the pinnacle of resilience in battle, giving you these benefits.

***Defy Death.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Death Saving Throw|Death Saving Throws]]. Moreover, when you roll 18-20 on a Death Saving Throw, you gain the benefit of rolling a 20 on it.

***Heroic Rally.*** At the start of each of your turns, you regain [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] equal to 5 plus your Constitution modifier if you are [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bloodied|Bloodied]] and have at least 1 Hit Point.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=99|Player’s Handbook (2024), PDF page 99]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
