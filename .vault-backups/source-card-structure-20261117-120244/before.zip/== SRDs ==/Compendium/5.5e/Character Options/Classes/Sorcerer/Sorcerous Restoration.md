---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 879cc32d-d6e9-57b1-b2f8-db1c8cb5ce0f
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [66]
---

# Sorcerous Restoration

![[== SRDs ==/Attachments/Artwork/phb-p141-sorcerer.png|320]]

When you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short Rest]], you can regain expended Sorcery Points, but no more than a number equal to half your Sorcerer level (round down). Once you use this feature, you can’t do so again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=142|Player’s Handbook (2024), PDF page 142]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

When you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short Rest]], you can regain expended Sorcery Points, but no more than a number equal to half your Sorcerer level (round down). Once you use this feature, you can't do so again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=66|SRD 5.2.1, p. 66]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=66|SRD 5.2.1, p. 66]]
