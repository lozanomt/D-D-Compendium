---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: a8f16be1-791d-579b-8d4e-323f049776b0
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Hill Giant
> 
> *Huge Giant, Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p170-hill-giant.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +2 (12)  
> **HP** 105 (10d12 + 40)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 21 | +5 | +5 | **Dex** | 8 | -1 | -1 | **Con** | 19 | +4 | +4 |
> | **Int** | 5 | -3 | -3 | **Wis** | 9 | -1 | -1 | **Cha** | 6 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** Giant  
> **CR** 5 (XP 1,800; PB +3)  
> 
> ### Actions
> 
> ***Multiattack.*** The giant makes two attacks, using Tree Club or Trash Lob in any combination.
> 
> ***Tree Club.*** *Melee Attack Roll:* +8, reach 10 ft. *Hit:* 18 (3d8 + 5) Bludgeoning damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]] condition.
> 
> ***Trash Lob.*** *Ranged Attack Roll:* +8, range 60/240 ft. *Hit:* 16 (2d10 + 5) Bludgeoning damage, and the target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]] condition until the end of its next turn.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
