---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Lesser Restoration
*Level 2 Abjuration (Bard, Cleric, Druid, Paladin, Ranger)*

![[Placeholder.png|320]]


**Casting Time:** Bonus Action
**Range:** Touch
**Components:** V, S
**Duration:** Instantaneous

You touch a creature and end one condition on it: [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded|Blinded]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Deafened|Deafened]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Paralyzed|Paralyzed]], or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]].
