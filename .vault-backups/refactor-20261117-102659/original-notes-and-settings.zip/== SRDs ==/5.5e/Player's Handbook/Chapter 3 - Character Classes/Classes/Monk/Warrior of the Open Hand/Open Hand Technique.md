---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Open Hand Technique

![[phb-p110-warrior-of-the-open-hand.png|320]]

Whenever you hit a creature with an attack granted by your Flurry of Blows, you can impose one of the following effects on that target.

***Addle.*** The target can’t make [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Opportunity Attacks|Opportunity Attacks]] until the start of its next turn.

***Push.*** The target must succeed on a Strength saving throw or be pushed up to 15 feet away from you.

***Topple.*** The target must succeed on a Dexterity saving throw or have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=110|Player’s Handbook (2024), PDF page 110]]
