---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Font of Magic

![[phb-p141-sorcerer.png|320]]

You can tap into the wellspring of magic within yourself. This wellspring is represented by Sorcery Points, which allow you to create a variety of magical effects.

You have 2 Sorcery Points, and you gain more as you reach higher levels, as shown in the Sorcery Points column of the Sorcerer Features table. You can’t have more Sorcery Points than the number shown in the table for your level. You regain all expended Sorcery Points when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

You can use your Sorcery Points to fuel the options below, along with other features, such as Metamagic, that use those points.

***Converting Spell Slots to Sorcery Points.*** You can expend a spell slot to gain a number of Sorcery Points equal to the slot’s level (no action required).

***Creating Spell Slots.*** As a Bonus Action, you can transform unexpended Sorcery Points into one spell slot. The Creating Spell Slots table shows the cost of creating a spell slot of a given level, and it lists the minimum Sorcerer level you must be to create a slot. You can create a spell slot no higher than level 5. Any spell slot you create with this feature vanishes when you finish a Long Rest.
###### Creating Spell Slots
| Spell Slot Level | Sorcery Point Cost | Min. Sorcerer Level |
| :----------------: | :------------------: | :-------------------: |
| 1                | 2                  | 2                   |
| 2                | 3                  | 3                   |
| 3                | 5                  | 5                   |
| 4                | 6                  | 7                   |
| 5                | 7                  | 9                   |

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=142|Player’s Handbook (2024), PDF page 142]]
