---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: f15ea862-1065-519a-b516-bdc09aec2aef
entity_type: character-option
source_ids: ["phb-2024"]
---

# Soldier

![[== SRDs ==/Attachments/Artwork/phb-p188-soldier.png|320]]

**Ability Scores:** Strength, Dexterity, Constitution
**Feat:** [[== SRDs ==/Compendium/5.5e/Character Options/Feats/01) Origin Feats/Savage Attacker|Savage Attacker]]
**Skill Proficiencies** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Athletics|Athletics]] and [[== SRDs ==/Compendium/5.5e/Rules/Skills/Intimidation|Intimidation]]
**Tool Proficiency:** *Choose one kind of [[== SRDs ==/Compendium/5.5e/Items/Tools/Gaming Sets/Gaming Sets|Gaming Set]]*
**Equipment:** *Choose A or B:* (A) [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Spear|Spear]], [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Ranged/Shortbow|Shortbow]], 20 [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Ammunition/Arrows|Arrows]], Gaming Set (same as above), [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Healer's Kit|Healer's Kit]], [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Quiver|Quiver]], [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Traveler's Clothes|Traveler's Clothes]], 14 GP; or (B) 50 GP

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Player's Handbook — Chapter 4 - Character Origins]]
