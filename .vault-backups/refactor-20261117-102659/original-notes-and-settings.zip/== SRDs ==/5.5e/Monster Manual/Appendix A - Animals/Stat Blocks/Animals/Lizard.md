---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Lizard
> 
> *Tiny Beast, Unaligned*
> 
> ![[Placeholder.png|320]]
> 
> 
> **AC** 10 &emsp; **Initiative** +0 (10)  
> **HP** 2 (1d4)  
> **Speed** 20 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 20 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 2 | -4 | -4 | **Dex** | 11 | +0 | +0 | **Con** | 10 | +0 | +0 |
> | **Int** | 1 | -5 | -5 | **Wis** | 8 | -1 | -1 | **Cha** | 3 | -4 | -4 |
> 
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 30 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Traits
> 
> ***Spider Climb.*** The lizard can climb difficult surfaces, including along ceilings, without needing to make an ability check.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +2, reach 5 ft. *Hit:* 1 Piercing damage.
