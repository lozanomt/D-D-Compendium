---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 68eb0ebc-a4d9-5ac7-836c-28589938cb50
entity_type: character-option
source_ids: ["phb-2024"]
---

# Uncanny Metabolism

![[== SRDs ==/Attachments/Artwork/phb-p103-monk.png|320]]

When you roll [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]], you can regain all expended Focus Points. When you do so, roll your Martial Arts die, and regain a number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] equal to your Monk level plus the number rolled. Once you use this feature, you can’t use it again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

***Perfect Focus.*** At Monk level 15, when you roll Initiative and don’t use Uncanny Metabolism, you regain expended Focus Points until you have 4 if you have 3 or fewer.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=104|Player’s Handbook (2024), PDF page 104]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
