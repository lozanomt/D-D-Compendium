---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 0c28b1ee-c5e1-5fc3-9f9e-bd5cf06629e8
entity_type: creature
source_ids: ["mm-2025", "phb-2024"]
source_versions: ["Monster Manual", "Player's Handbook"]
---

# Weasel

One creature entry with separately labeled source versions. Each book’s chapter links to its own version.

## Monster Manual

> [!statblock]
> ### Weasel
> 
> *Tiny Beast, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p362-weasel.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +3 (13)  
> **HP** 1 (1d4 - 1)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 3 | -4 | -4 | **Dex** | 16 | +3 | +3 | **Con** | 8 | -1 | -1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 3 | -4 | -4 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Acrobatics|Acrobatics]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +3, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +5  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> #### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 1 Piercing damage.

## Player's Handbook

> [!statblock]
> ### Weasel
>
> *Tiny Beast, Unaligned*
>
> **AC** 13 &emsp; **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]]** +3 (13)  
> **HP** 1 (1d4 - 1)  
> **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]** 30 ft., Climb 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 3 | -4 | -4 | **Dex** | 16 | +3 | +3 | **Con** | 8 | -1 | -1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 3 | -4 | -4 |
>
> **Skills** Acrobatics +5, Perception +3, Stealth +5  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
>
> #### Actions
>
> ***Bite.*** *Melee [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack|Attack]] Roll:* +5, reach 5 ft. *Hit:* 1 Piercing damage.

Source: [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=362|Player’s Handbook (2024), p. 359]].

[[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/Compendium/5.5e/Creatures/Weasel#Monster Manual|Monster Manual version]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Player's Handbook — Appendix B - Creature Stat Blocks]]
