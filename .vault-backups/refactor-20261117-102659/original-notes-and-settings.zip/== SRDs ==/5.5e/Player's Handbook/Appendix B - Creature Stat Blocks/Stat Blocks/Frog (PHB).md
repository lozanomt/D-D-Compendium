---
tags: [creature, phb]
cssclasses: [dnd-book, dnd-mm]
source_book: "Player's Handbook (2024)"
source_page: 349
source_pdf_page: 352
review_status: checked-against-page-image
reviewed: 2026-11-17
---

> [!statblock]
> ## Frog
>
> *Tiny Beast, Unaligned*
>
> **AC** 11 &emsp; **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]]** +1 (11)  
> **HP** 1 (1d4 - 1)  
> **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]]** 20 ft., Swim 20 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 1 | -5 | -5 | **Dex** | 13 | +1 | +1 | **Con** | 8 | -1 | -1 |
> | **Int** | 1 | -5 | -5 | **Wis** | 8 | -1 | -1 | **Cha** | 3 | -4 | -4 |
>
> **Skills** Perception +1, Stealth +3  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 30 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
>
> ### Traits
>
> ***Amphibious.*** The frog can breathe air and water.
>
> ***Standing Leap.*** The frog's Long Jump is up to 10 feet and its High Jump is up to 5 feet with or without a running start.
>
> ### Actions
>
> ***Bite.*** *Melee [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] Roll:* +3, reach 5 ft. *Hit:* 1 Piercing damage.

Source: [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=352|Player’s Handbook (2024), p. 349]].

[[== SRDs ==/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/5.5e/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Frog|Monster Manual version]]
