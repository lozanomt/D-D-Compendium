---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [315]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Staff of Withering
*Staff, Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p315-stone-of-controlling-earth-elementals.png|320]]

**Attunement:** Yes

The [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Arcane Focus/Staff|staff]] has 3 charges and regains 1d3 expended charges daily at dawn. Wield it as a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|magic]] [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Simple Melee/Quarterstaff|Quarterstaff]], dealing normal Quarterstaff damage on a hit. When you hit, you can expend 1 charge to deal an extra 2d10 Necrotic damage and force the target to make a DC 15 Constitution saving throw. On a failure, it has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on Strength and Constitution ability checks and saving throws for 1 hour.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=315|p. 312 (PDF page 315)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
