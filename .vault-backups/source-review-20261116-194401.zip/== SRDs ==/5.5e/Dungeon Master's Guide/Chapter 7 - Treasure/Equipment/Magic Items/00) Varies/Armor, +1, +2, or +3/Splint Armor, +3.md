---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Splint Armor, +3 [[Splint Armor, +3 |(200,200 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Splint Armor]]), Legendary*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-splint-armor.png|320]]


**Attunement** No

You have a +3 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Splint Armor|clean no-title]]
