---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Spider
> 
> *Large Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/Monster Manual/Artwork/phb-p354-giant-spider.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +3 (13)  
> **HP** 26 (4d10 + 4)  
> **Speed** 30 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 16 | +3 | +3 | **Con** | 12 | +1 | +1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 11 | +0 | +0 | **Cha** | 4 | -3 | -3 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +4, [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]] +7  
> **Senses** [[Darkvision]] 60 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 14  
> **Languages** None  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Traits
> 
> ***Spider Climb.*** The spider can climb difficult surfaces, including along ceilings, without needing to make an ability check.
> 
> ***Web Walker.*** The spider ignores movement restrictions caused by webs, and it knows the location of any other creature in contact with the same web.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Piercing damage plus 7 (2d6) Poison damage.
> 
> ***Web (Recharge 5-6).*** *Dexterity Saving Throw:* DC 13, one creature the spider can see within 60 feet. *Failure:* The target has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained]] condition until the web is destroyed (AC 10; HP 5; Vulnerability to Fire damage; Immunity to Poison and Psychic damage).
