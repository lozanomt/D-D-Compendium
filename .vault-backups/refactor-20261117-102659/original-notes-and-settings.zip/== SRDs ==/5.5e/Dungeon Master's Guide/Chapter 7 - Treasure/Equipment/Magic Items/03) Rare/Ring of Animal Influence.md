---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Name [[== SRDs ==/z. Load Bearing Folders/Templates/Magic Item|(# GP)]]
*Category, Rarity*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p295-ring-of-animal-influence.png|320]]


**Attunement:**

Description
