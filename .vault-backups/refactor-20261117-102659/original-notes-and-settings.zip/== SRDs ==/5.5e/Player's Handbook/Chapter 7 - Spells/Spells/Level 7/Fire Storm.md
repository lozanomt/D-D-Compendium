---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Fire Storm
*Level 7 Evocation (Cleric, Druid, Sorcerer)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S
**Duration:** Instantaneous

A storm of fire appears within range. The area of the storm consists of up to ten 10-foot [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Cube|Cubes]], which you arrange as you like. Each Cube must be contiguous with at least one other Cube. Each creature in the area makes a Dexterity saving throw, taking 7d10 Fire damage on a failed save or half as much damage on a successful one.

Flammable objects in the area that aren't being worn or carried start [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Hazards/Burning|burning]].
