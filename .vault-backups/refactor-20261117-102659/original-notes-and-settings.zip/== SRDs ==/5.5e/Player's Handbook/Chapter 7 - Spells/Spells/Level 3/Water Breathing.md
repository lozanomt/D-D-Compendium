---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Water Breathing
*Level 3 Transmutation (Druid, Ranger, Sorcerer, Wizard)*

![[phb-p343-water-breathing.png|320]]


**Casting Time:** Action or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Ritual|Ritual]]
**Range:** 30 feet
**Components:** V, S, M (a short reed)
**Duration:** 24 hours

This spell grants up to ten willing creatures of your choice within range the ability to breathe underwater until the spell ends. Affected creatures also retain their normal mode of respiration.
