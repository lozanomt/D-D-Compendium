---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Goblin Minion
> 
> *Small Fey (Goblinoid), Chaotic Neutral*
> 
> ![[mm-p145-goblin-boss.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 7 (2d6)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 8 | -1 | -1 | **Dex** | 15 | +2 | +2 | **Con** | 10 | +0 | +0 |
> | **Int** | 10 | +0 | +0 | **Wis** | 8 | -1 | -1 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +6  
> **Gear** Daggers (3)  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** Common, Goblin  
> **CR** 1/8 (XP 25; PB +2)  
> 
> ### Actions
> 
> ***Dagger.*** *Melee or Ranged Attack Roll:* +4, reach 5 ft. or range 20/60 ft. *Hit:* 4 (1d4 + 2) Piercing damage.
> 
> ### Bonus Actions
> 
> ***Nimble Escape.*** The goblin takes the Disengage or Hide action.
