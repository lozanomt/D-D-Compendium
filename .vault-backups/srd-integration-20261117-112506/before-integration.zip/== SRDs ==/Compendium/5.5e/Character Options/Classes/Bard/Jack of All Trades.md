---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: ddb52c59-f89b-5798-af4a-61852c3fbb61
entity_type: character-option
source_ids: ["phb-2024"]
---

# Jack of All Trades

![[== SRDs ==/Attachments/Artwork/phb-p061-bard.png|320]]

You can add half your Proficiency Bonus (round down) to any ability check you make that uses a skill proficiency you lack and that doesn’t otherwise use your Proficiency Bonus.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=62|Player’s Handbook (2024), PDF page 62]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
