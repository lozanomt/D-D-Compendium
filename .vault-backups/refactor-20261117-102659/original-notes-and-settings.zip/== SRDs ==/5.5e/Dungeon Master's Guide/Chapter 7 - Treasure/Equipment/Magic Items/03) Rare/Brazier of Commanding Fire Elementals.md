---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [244]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Brazier of Commanding Fire Elementals
*Wondrous Item, Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p244-bracers-of-defense.png|320]]

**Attunement:** No

While within 5 feet of the brazier, take a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action to summon a [[Fire Elemental|Fire Elemental]] in an unoccupied space as close to the brazier as possible. It understands your languages, obeys your commands, and takes its turn immediately after you on your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]] count. It disappears after 1 hour, when it dies, or when you dismiss it as a Bonus Action. The brazier can't summon another elemental until the next dawn.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=244|p. 241 (PDF page 244)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
