---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: c11e9d47-4f05-5cff-b0ef-55844fef7db7
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Troll
> 
> *Large Giant, Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p312-troll.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +1 (11)  
> **HP** 94 (9d10 + 45)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 13 | +1 | +1 | **Con** | 20 | +5 | +5 |
> | **Int** | 7 | -2 | -2 | **Wis** | 9 | -1 | -1 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** Giant  
> **CR** 5 (XP 1,800; PB +3)  
> 
> ### Traits
> 
> ***Loathsome Limbs (4/Day).*** If the troll ends any turn Bloodied and took 15+ Slashing damage during that turn, one of the troll's limbs is severed, falls into the troll's space, and becomes a **Troll Limb**. The limb acts immediately after the troll's turn. The troll has 1 [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]] level for each missing limb, and it grows replacement limbs the next time it regains Hit Points.
> 
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> 
> ***Regeneration.*** The troll regains 15 Hit Points at the start of each of its turns. If the troll takes Acid or Fire damage, this trait doesn't function on the troll's next turn. The troll dies only if it starts its turn with 0 Hit Points and doesn't regenerate.
> 
> ### Actions
> 
> ***Multiattack.*** The troll makes three Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +7, reach 10 ft. *Hit:* 11 (2d6 + 4) Slashing damage.
> 
> ### Bonus Actions
> 
> ***Charge.*** The troll moves up to half its Speed straight toward an enemy it can see.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
