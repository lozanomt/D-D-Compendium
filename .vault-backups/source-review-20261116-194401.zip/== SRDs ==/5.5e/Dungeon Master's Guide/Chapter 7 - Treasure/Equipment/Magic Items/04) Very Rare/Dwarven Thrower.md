---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Dwarven Thrower [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/04) Very Rare/Dwarven Thrower|(40,000 GP)]]
*Weapon ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Warhammer]]), Very Rare*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** Yes (by a Dwarf or a Creature Attuned to a [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/03) Rare/Belt of Dwarvenkind]])

You gain a +3 bonus to attack rolls and damage rolls made with this magic weapon. It has the [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Thrown]] property with a normal range of 20 feet and a long range of 60 feet. When you hit with a ranged attack using this weapon, it deals an extra 1d8 Force damage, or an extra 2d8 Force damage if the target is a Giant. Immediately after hitting or missing, the weapon flies back to your hand
