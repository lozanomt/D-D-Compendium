---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Divine Order

![[phb-p071-cleric.png|320]]

You have dedicated yourself to one of the following sacred roles of your choice.

***Protector.*** Trained for battle, you gain proficiency with Martial weapons and training with Heavy armor.

***Thaumaturge.*** You know one extra cantrip from the Cleric spell list. In addition, your mystical connection to the divine gives you a bonus to your Intelligence ([[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Arcana|Arcana]] or [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Religion|Religion]]) checks. The bonus equals your Wisdom modifier (minimum of +1).

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=72|Player’s Handbook (2024), PDF page 72]]
