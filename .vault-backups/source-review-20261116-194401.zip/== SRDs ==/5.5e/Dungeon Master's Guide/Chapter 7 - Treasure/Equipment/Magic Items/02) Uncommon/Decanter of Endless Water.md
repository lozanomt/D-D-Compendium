---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Decanter of Endless Water [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Decanter of Endless Water|(400 GP)]]
*Wondrous Item, Uncommon*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

This stoppered flask sloshes when shaken, as if it contains water. The decanter weighs 2 pounds.

You can take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action to remove the stopper and issue one of three command words, whereupon an amount of fresh water or salt water (your choice) pours out of the flask. The water stops pouring out at the start of your next turn. Choose from the following command words:

***Splash.*** The decanter produces 1 gallon of water.

***Fountain.*** The decanter produces 5 gallons of water.

***Geyser.*** The decanter produces 30 gallons of water that gushes forth in a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Line]] 30 feet long and 1 foot wide. If you’re holding the decanter, you can aim the geyser in one direction (no action required). One creature of your choice in the Line must succeed on a DC 13 Strength saving throw or take 1d4 Bludgeoning damage and have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone]] condition. Instead of a creature, you can target one object in the Line that isn’t being worn or carried and that weighs no more than 200 pounds. The object is knocked over by the geyser.
