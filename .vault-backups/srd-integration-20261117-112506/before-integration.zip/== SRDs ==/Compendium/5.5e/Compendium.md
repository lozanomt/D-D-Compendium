# Compendium

One note per entity, independent of the books that describe it. Book-specific differences appear as labeled sections within the same note.

- [[== SRDs ==/Compendium/5.5e/Character Options/Character Options|Character Options]]
- [[== SRDs ==/Compendium/5.5e/Creatures/Creatures|Creatures]]
- [[== SRDs ==/Compendium/5.5e/Items/Items|Items]]
- [[== SRDs ==/Compendium/5.5e/Lore/Lore|Lore]]
- [[== SRDs ==/Compendium/5.5e/Rules/Rules|Rules]]
- [[== SRDs ==/Compendium/5.5e/Spells/Spells|Spells]]

[[== SRDs ==/Sources/Sources|Browse by book]]
