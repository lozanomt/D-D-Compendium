---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: d099e98b-bab4-51a4-b401-7d682a86ca2d
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [333]
---

> [!statblock]
> ## Treant
> 
> *Huge Plant, Chaotic Good*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p310-treant.png|320]]
> 
> 
> **AC** 16 &emsp; **Initiative** +3 (13)  
> **HP** 138 (12d12 + 60)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 23 | +6 | +6 | **Dex** | 8 | -1 | -1 | **Con** | 21 | +5 | +5 |
> | **Int** | 12 | +1 | +1 | **Wis** | 16 | +3 | +3 | **Cha** | 12 | +1 | +1 |
> 
> **Vulnerabilities** Fire  
> **Resistances** Bludgeoning, Piercing  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** Common, Druidic, Elvish, Sylvan  
> **CR** 9 (XP 5,000; PB +4)  
> 
> ### Traits
> 
> ***Siege Monster.*** The treant deals double damage to objects and structures.
> 
> ### Actions
> 
> ***Multiattack.*** The treant makes two Slam attacks.
> 
> ***Slam.*** *Melee Attack Roll:* +10, reach 5 ft. *Hit:* 16 (3d6 + 6) Bludgeoning damage.
> 
> ***Hail of Bark.*** *Ranged Attack Roll:* +10, range 180 ft. *Hit:* 28 (4d10 + 6) Piercing damage.
> 
> ***Animate Trees (1/Day).*** The treant magically animates up to two trees it can see within 60 feet of itself. Each tree uses the **Treant** stat block, except it has Intelligence and Charisma scores of 1, it can't speak, and it lacks this action. The tree takes its turn immediately after the treant on the same Initiative count, and it obeys the treant. A tree remains animate for 1 day or until it dies, the treant dies, or it is more than 120 feet from the treant. The tree then takes root if possible.
> - [ ]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=333|SRD 5.2.1, p. 333]] — matches the existing entry.
