---
tags:
  - weaponproperty
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Push

![[Placeholder.png|320]]


If you hit a creature with this weapon, you can push the creature up to 10 feet straight away from yourself if it is Large or smaller.
