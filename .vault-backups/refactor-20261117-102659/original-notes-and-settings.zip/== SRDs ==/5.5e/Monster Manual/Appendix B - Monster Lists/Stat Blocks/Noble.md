---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Noble
> 
> *Medium or Small Humanoid, Neutral*
> 
> ![[mm-p229-noble.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +1 (11)  
> **HP** 9 (2d8)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +0 | **Dex** | 12 | +1 | +1 | **Con** | 11 | +0 | +0 |
> | **Int** | 12 | +1 | +1 | **Wis** | 14 | +2 | +2 | **Cha** | 16 | +3 | +3 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Deception|Deception]] +5, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Insight|Insight]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Persuasion|Persuasion]] +5  
> **Gear** Breastplate, Rapier  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** Common plus two other languages  
> **CR** 1/8 (XP 25; PB +2)  
> 
> ### Actions
> 
> ***Rapier.*** *Melee Attack Roll:* +3, reach 5 ft. *Hit:* 5 (1d8 + 1) Piercing damage.
> 
> ### Reactions
> 
> ***Parry.*** *Trigger:* The noble is hit by a melee attack roll while holding a weapon. *Response:* The noble adds 2 to its AC against that attack, possibly causing it to miss.
