---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Storm Giant
> 
> *Huge Giant, Chaotic Good*
> 
> ![[mm-p304-storm-giant.png|320]]
> 
> 
> **AC** 16 &emsp; **Initiative** +7 (17)  
> **HP** 230 (20d12 + 100)  
> **Speed** 50 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 25 ft. (hover), [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 50 ft. MOD SAVE MOD SAVE  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 29 | +9 | +14 | **Dex** | 14 | +2 | +2 | **Con** | 20 | +5 | +10 |
> | **Int** | 16 | +3 | +3 | **Wis** | 20 | +5 | +10 | **Cha** | 18 | +4 | +9 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Arcana|Arcana]] +8, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Athletics|Athletics]] +14, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/History|History]] +8, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +10 Resistances Cold Immunities Lightning, Thunder Senses [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 120 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Truesight|Truesight]] 30 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 20  
> **Languages** Common, Giant  
> **CR** 13 (XP 10,000; PB +5)  
> 
> ### Traits
> 
> ***Amphibious.*** The giant can breathe air and water.
> 
> ### Actions
> 
> ***Multiattack.*** The giant makes two attacks, using Storm Sword or Thunderbolt in any combination.
> 
> ***Storm Sword.*** *Melee Attack Roll:* +14, reach 10 ft. *Hit:* 23 (4d6 + 9) Slashing damage plus 13 (3d8) Lightning damage.
> 
> ***Thunderbolt.*** *Ranged Attack Roll:* +14, range 500 ft. *Hit:* 22 (2d12 + 9) Lightning damage, and the target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded|Blinded]] and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Deafened|Deafened]] conditions until the start of the giant's next turn.
> 
> ***Lightning Storm (Recharge 5-6).*** *Dexterity Saving Throw:* DC 18, each creature in a 10-foot-radius, 40-foot-high Cylinder originating from a point the giant can see within 500 feet. *Failure:* 55 (10d10) Lightning damage. *Success:* Half damage.
> 
> ***Spellcasting.*** The giant casts one of the following spells, requiring no Material components and using Wisdom as the spellcasting ability (spell save DC 18):
> 
> - **At Will:** *Detect Magic*, *Light*
> - **1/Day:** *Control Weather*
