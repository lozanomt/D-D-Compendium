---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: fb19985b-4e16-5cdf-9fb3-1dfb8cc3cf6a
entity_type: creature
source_ids: ["mm-2025", "phb-2024"]
source_versions: ["Monster Manual", "Player's Handbook"]
---

# Giant Weasel

One creature entry with separately labeled source versions. Each book’s chapter links to its own version.

## Monster Manual

> [!statblock]
> ### Giant Weasel
> 
> *Medium Beast, Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +3 (13)  
> **HP** 9 (2d8)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +0 | **Dex** | 17 | +3 | +3 | **Con** | 10 | +0 | +0 |
> | **Int** | 4 | -3 | -3 | **Wis** | 12 | +1 | +1 | **Cha** | 5 | -3 | -3 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Acrobatics|Acrobatics]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +3, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +5  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** None  
> **CR** 1/8 (XP 25; PB +2)  
> 
> #### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 5 (1d4 + 3) Piercing damage.

## Player's Handbook

> [!statblock]
> ### Giant Weasel
>
> *Medium Beast, Unaligned*
>
> **AC** 13 &emsp; **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]]** +3 (13)  
> **HP** 9 (2d8)  
> **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]** 40 ft., Climb 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +0 | **Dex** | 17 | +3 | +3 | **Con** | 10 | +0 | +0 |
> | **Int** | 4 | -3 | -3 | **Wis** | 12 | +1 | +1 | **Cha** | 5 | -3 | -3 |
>
> **Skills** Acrobatics +5, Perception +3, Stealth +5  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** None  
> **CR** 1/8 (XP 25; PB +2)  
>
> #### Actions
>
> ***Bite.*** *Melee [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack|Attack]] Roll:* +5, reach 5 ft. *Hit:* 5 (1d4 + 3) Piercing damage.

Source: [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=354|Player’s Handbook (2024), p. 351]].

[[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/Compendium/5.5e/Creatures/Giant Weasel#Monster Manual|Monster Manual version]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Player's Handbook — Appendix B - Creature Stat Blocks]]
