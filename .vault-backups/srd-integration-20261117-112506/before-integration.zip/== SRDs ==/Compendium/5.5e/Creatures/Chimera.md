---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: a721c047-7cf8-5c33-8db6-eb775d4758da
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Chimera
> 
> *Large Monstrosity, Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p072-chimera.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +0 (10)  
> **HP** 114 (12d10 + 48)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 11 | +0 | +0 | **Con** | 19 | +4 | +4 |
> | **Int** | 3 | -4 | -4 | **Wis** | 14 | +2 | +2 | **Cha** | 10 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +8  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 18  
> **Languages** Understands Draconic but can't speak  
> **CR** 6 (XP 2,300; PB +3)  
> 
> ### Actions
> 
> ***Multiattack.*** The chimera makes one Ram attack, one Bite attack, and one Claw attack. It can replace the Claw attack with a use of Fire Breath if available.
> 
> ***Bite.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 11 (2d6 + 4) Piercing damage, or 18 (4d6 + 4) Piercing damage if the chimera had Advantage on the attack roll.
> 
> ***Claw.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 7 (1d6 + 4) Slashing damage.
> 
> ***Ram.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 10 (1d12 + 4) Bludgeoning damage. If the target is a Medium or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]] condition.
> 
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 15, each creature in a 15-foot Cone. *Failure:* 31 (7d8) Fire damage. *Success:* Half damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
