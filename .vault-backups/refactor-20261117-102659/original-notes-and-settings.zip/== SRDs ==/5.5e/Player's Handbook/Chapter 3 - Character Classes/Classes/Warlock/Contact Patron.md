---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Contact Patron

![[phb-p155-warlock.png|320]]

In the past, you usually contacted your patron through intermediaries. Now you can communicate directly; you always have the *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Contact Other Plane|Contact Other Plane]]* spell prepared. With this feature, you can cast the spell without expending a spell slot to contact your patron, and you automatically succeed on the spell’s saving throw. Once you cast the spell with this feature, you can’t do so in this way again until you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=156|Player’s Handbook (2024), PDF page 156]]
