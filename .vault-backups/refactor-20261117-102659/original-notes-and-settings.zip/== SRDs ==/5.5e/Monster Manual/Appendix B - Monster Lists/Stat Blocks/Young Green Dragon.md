---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Young Green Dragon
> 
> *Large Dragon (Chromatic), Lawful Evil*
> 
> ![[mm-p154-green-dragon-wyrmling.png|320]]
> 
> 
> **AC** 18 &emsp; **Initiative** +4 (14)  
> **HP** 136 (16d10 + 48)  
> **Speed** 40 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 80 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 12 | +1 | +4 | **Con** | 17 | +3 | +3 |
> | **Int** | 16 | +3 | +3 | **Wis** | 13 | +1 | +4 | **Cha** | 15 | +2 | +2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Deception|Deception]] +5, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +7, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +4  
> **Immunities** Poison; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight|Blindsight]] 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 17  
> **Languages** Common, Draconic  
> **CR** 8 (XP 3,900; PB +3)  
> 
> ### Traits
> 
> ***Amphibious.*** The dragon can breathe air and water.
> 
> ***Multiattack.*** The dragon makes three Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +7, reach 10 ft. *Hit:* 11 (2d6 + 4) Slashing damage plus 7 (2d6) Poison damage.
> 
> ***Poison Breath (Recharge 5-6).*** *Constitution Saving Throw:* DC 14, each creature in a 30-foot Cone. *Failure:* 42 (12d6) Poison damage. *Success:* Half damage.
