---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Pike [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Pike|(5 GP)]]
*Martial Melee*

![[phb-p220-pike.png|320]]


**Mastery:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Mastery/Push|Push]] **Weight:** 18 lb.
**Damage:** 1d10 Piercing
**Properties:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Heavy|Heavy]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Reach|Reach]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Two-Handed|Two-Handed]]
