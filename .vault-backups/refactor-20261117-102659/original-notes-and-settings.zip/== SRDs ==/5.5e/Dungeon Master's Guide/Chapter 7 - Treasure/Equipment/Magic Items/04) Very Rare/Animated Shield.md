---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [232]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Animated Shield
*Armor (Shield), Very Rare*

![[Placeholder.png|320]]

**Attunement:** Yes

While holding the Shield, take a Bonus Action to animate it. It hovers in your space and protects you as if you were wielding it, leaving your hands free. It remains animated for 1 minute, until you end the effect with a Bonus Action, or until you die or have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition. It then falls to the ground or into a free hand.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=232|p. 229 (PDF page 232)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
