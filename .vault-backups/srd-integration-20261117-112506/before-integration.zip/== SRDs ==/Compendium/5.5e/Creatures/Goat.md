---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 62ac9dd2-1b0b-56c5-b317-c396ec1b6cc7
entity_type: creature
source_ids: ["mm-2025", "phb-2024"]
source_versions: ["Monster Manual", "Player's Handbook"]
---

# Goat

One creature entry with separately labeled source versions. Each book’s chapter links to its own version.

## Monster Manual

> [!statblock]
> ### Goat
> 
> *Medium Beast, Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 10 &emsp; **Initiative** +0 (10)  
> **HP** 4 (1d8)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +2 | **Dex** | 10 | +0 | +0 | **Con** | 11 | +0 | +0 |
> | **Int** | 2 | -4 | -4 | **Wis** | 10 | +0 | +0 | **Cha** | 5 | -3 | -3 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> #### Actions
> 
> ***Ram.*** *Melee Attack Roll:* +2, reach 5 ft. *Hit:* 1 Bludgeoning damage, or 2 (1d4) Bludgeoning damage if the goat moved 20+ feet straight toward the target immediately before the hit.

## Player's Handbook

> [!statblock]
> ### Goat
>
> *Medium Beast, Unaligned*
>
> **AC** 10 &emsp; **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]]** +0 (10)  
> **HP** 4 (1d8)  
> **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]** 40 ft., Climb 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +2 | **Dex** | 10 | +0 | +0 | **Con** | 11 | +0 | +0 |
> | **Int** | 2 | -4 | -4 | **Wis** | 10 | +0 | +0 | **Cha** | 5 | -3 | -3 |
>
> **Skills** Perception +2  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
>
> #### Actions
>
> ***Ram.*** *Melee [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack|Attack]] Roll:* +2, reach 5 ft. *Hit:* 1 Bludgeoning damage, or 2 (1d4) Bludgeoning damage if the goat moved 20+ feet straight toward the target immediately before the hit.

Source: [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=354|Player’s Handbook (2024), p. 351]].

[[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/Compendium/5.5e/Creatures/Goat#Monster Manual|Monster Manual version]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Player's Handbook — Appendix B - Creature Stat Blocks]]
