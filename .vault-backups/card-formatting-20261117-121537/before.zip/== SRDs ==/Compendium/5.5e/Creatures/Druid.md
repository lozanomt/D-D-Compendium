---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: fb3641a2-779a-5565-978b-0dca5bb0b74e
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [282]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Druid

## Monster Manual


> [!statblock]
> ### Druid
>
> *Medium or Small Humanoid (Druid), Neutral*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p108-druid.png|320]]
>
> **AC:** 13 &emsp;  
> **Initiative:** +1 (11)  
> **HP:** 44 (8d8 + 8)  
> **Speed:** 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 10 | +0 | +0 | **Dex** | 12 | +1 | +1 | **Con** | 13 | +1 | +1 |
> | **Int** | 12 | +1 | +1 | **Wis** | 16 | +3 | +3 | **Cha** | 11 | +0 | +0 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Medicine|Medicine]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Nature|Nature]] +3, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5  
> **Gear:** Studded Leather Armor  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages:** Common, Druidic, Sylvan  
> **CR:** 2 (XP 450; PB +2)  
>
> #### Actions
>
> ***Multiattack.*** The druid makes two attacks, using Vine Staff or Verdant Wisp in any combination.
>
> ***Vine Staff.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Bludgeoning damage plus 2 (1d4) Poison damage.
>
> ***Verdant Wisp.*** *Ranged Attack Roll:* +5, range 90 ft. *Hit:* 10 (3d6) Radiant damage.
>
> ***Spellcasting.*** The druid casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 13):
>
> - **At Will:** *Druidcraft*, *Speak with Animals*
> - **2/Day Each:** *Entangle*, *Thunderwave*
> - **1/Day Each:** *Animal Messenger*, *Longstrider*, *Moonbeam*
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Druid
>
> *Medium or Small Humanoid (Druid), Neutral*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p108-druid.png|320]]
>
> **AC:** 13 &emsp;  
> **Initiative:** +1 (11)  
> **HP:** 44 (8d8 + 8)  
> **Speed:** 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 10 | +0 | +0 | **Dex** | 12 | +1 | +1 | **Con** | 13 | +1 | +1 |
> | **Int** | 12 | +1 | +1 | **Wis** | 16 | +3 | +3 | **Cha** | 11 | +0 | +0 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Medicine|Medicine]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Nature|Nature]] +3, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5  
> **Gear:** Studded Leather Armor  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages:** Common, Druidic, Sylvan  
> **CR:** 2 (XP 450; PB +2)  
>
> #### Actions
>
> ***Multiattack.*** The druid makes two attacks, using Vine Staff or Verdant Wisp in any combination.
>
> ***Vine Staff.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Bludgeoning damage plus 2 (1d4) Poison damage.
>
> ***Verdant Wisp.*** *Ranged Attack Roll:* +5, range 90 ft. *Hit:* 10 (3d6) Radiant damage.
>
> ***Spellcasting.*** The druid casts one of the following spells, using Wisdom as the spellcasting ability (spell save DC 13):
>
> - **At Will:** *Druidcraft*, *Speak with Animals*
> - **2/Day Each:** *Entangle*, *Thunderwave*
> - **1/Day Each:** *Animal Messenger*, *Longstrider*, *Moonbeam*
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=282|SRD 5.2.1, p. 282]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
