---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Orb [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Arcane Focus/Orb|(20 GP)]] 
*Arcane Focus*

![[Placeholder.png|320]]


**Weight:** 3 lb.
