---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Staff of Healing [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/03) Rare/Staff of Healing|(4,000 GP)]]
*Staff, Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p312-staff-of-frost.png|320]]


**Attunement:** By a [[D&D 5e 2024 Rules/Player's Handbook/Chapter 3 - Character Classes/Classes/Bard/Bard]], [[D&D 5e 2024 Rules/Player's Handbook/Chapter 3 - Character Classes/Classes/Cleric/Cleric]], or [[D&D 5e 2024 Rules/Player's Handbook/Chapter 3 - Character Classes/Classes/Druid/Druid|Druid]]

This staff has 10 charges. While holding the staff, you can cast one of the spells on the following table from it, using your spellcasting ability modifier. The table indicates how many charges you must expend to cast the spell.

| Spell                    |                       Charge Cost                        |
| ------------------------ | :------------------------------------------------------: |
| *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Cure Wounds]]*        | 1 charge per spell level (maximum 4 for a level 4 spell) |
| *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Lesser Restoration]]* |                            2                             |
| *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Mass Cure Wounds]]*   |                            5                             |
***Regaining Charges.*** The staff regains 1d6 + 4 expended charges when you finish a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest]]. If you expend the last charge, roll 1d20. On a 1, the staff vanishes in a flash of light, lost forever.
