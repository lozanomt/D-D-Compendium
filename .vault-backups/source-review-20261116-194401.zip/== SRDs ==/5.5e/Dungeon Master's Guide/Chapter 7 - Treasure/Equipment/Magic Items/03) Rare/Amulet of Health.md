---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Amulet of Health [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/03) Rare/Amulet of Health|(4,000 GP)]]
*Wondrous Item, Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p231-amulet-of-health.png|320]]


**Attunement:** Yes

Your Constitution score is 19 while you wear this amulet. It has no effect on you if your Constitution is already 19 or higher without it.
