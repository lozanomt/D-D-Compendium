---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Chain Mail, +3 [[Chain Mail, +3 |(200,075 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Chain Mail]]), Legendary*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-chain-mail.png|320]]


**Attunement** No

You have a +3 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Chain Mail|clean no-title]]
