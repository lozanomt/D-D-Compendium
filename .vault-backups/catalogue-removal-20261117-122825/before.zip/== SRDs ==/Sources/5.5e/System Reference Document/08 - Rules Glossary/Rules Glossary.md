---
cssclasses: [dnd-book, dnd-phb]
source_id: srd-5.2.1
source_pages: [176, 191]
---

# Rules Glossary

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=176|SRD 5.2.1, p. 176]].

### Glossary Conventions

The glossary uses the following conventions:

Tags in Brackets. Some entries have a tag in brackets after the entry's name, as in "[[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack#SRD 5.2.1|Attack]] [ [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action#SRD 5.2.1|Action]] ]." A tag—[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action#SRD 5.2.1|Action]], Area of Effect, [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attitude#SRD 5.2.1|Attitude]], [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Condition#SRD 5.2.1|Condition]], or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hazard#SRD 5.2.1|Hazard]]—indicates that a rule is part of a family of rules. The tags also have glossary entries. "You." The game's rules—in this glossary and elsewhere—often talk about something happening to you in the game world. That "you" refers to the creature or object that the rule applies to in a particular moment of play. For example, the "you" in the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone#SRD 5.2.1|Prone]] condition is a creature that currently has that condition. "See Also." Some glossary entries include a See also section that points to other entries in the glossary, to other parts of this document, or both.

No Obsolete Terms. The glossary contains definitions of current rules terms only. If you're looking for a term from an earlier version of the fifth edition rules, consult the index.

Abbreviations.  The abbreviations listed below appear in this glossary and elsewhere in the rules.

AC [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Class#SRD 5.2.1|Armor Class]] C [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration#SRD 5.2.1|Concentration]] CE Chaotic Evil CG Chaotic Good

Cha. Charisma CN Chaotic Neutral

Con. Constitution CP Copper Piece(s)

CR [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating#SRD 5.2.1|Challenge Rating]] DC [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Difficulty Class#SRD 5.2.1|Difficulty Class]]

Dex. Dexterity EP Electrum Piece(s) GM Game Master GP Gold Piece(s)

HP Hit Point(s)

Int. Intelligence LE Lawful Evil LG Lawful Good LN Lawful Neutral M Material component N Neutral NE Neutral Evil NG Neutral Good NPC Nonplayer character PB [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus PP Platinum Piece(s) R [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual#SRD 5.2.1|Ritual]] S Somatic component SP Silver Piece(s)

Str. Strength V Verbal component

Wis. Wisdom XP Experience Point(s)

### Rules Definitions

Here are definitions of various rules.

### Ability Check

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ability Check#SRD 5.2.1|Ability Check]]

### Ability Score and Modifier

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ability Score and Modifier#SRD 5.2.1|Ability Score and Modifier]]

### Action

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action#SRD 5.2.1|Action]]

### Advantage

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage#SRD 5.2.1|Advantage]]

### Adventure

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Adventure#SRD 5.2.1|Adventure]]

### Alignment

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Alignment#SRD 5.2.1|Alignment]]

### Ally

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ally#SRD 5.2.1|Ally]]

### Area of Effect

[[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Areas of Effect#SRD 5.2.1|Areas of Effect]]

### Armor Class

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Class#SRD 5.2.1|Armor Class]]

### Armor Training

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Training#SRD 5.2.1|Armor Training]]

### Attack [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack#SRD 5.2.1|Attack]]

### Attack Roll

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attack Roll#SRD 5.2.1|Attack Roll]]

### Attitude

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attitude#SRD 5.2.1|Attitude]]

### Attunement

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]]

### Blinded [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Blinded#SRD 5.2.1|Blinded]]

### Blindsight

[[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight#SRD 5.2.1|Blindsight]]

### Bloodied

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bloodied#SRD 5.2.1|Bloodied]]

### Bonus Action

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bonus Action#SRD 5.2.1|Bonus Action]]

### Breaking Objects

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Breaking Objects#SRD 5.2.1|Breaking Objects]]

### Bright Light

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bright Light#SRD 5.2.1|Bright Light]]

### Burning [Hazard]

[[== SRDs ==/Compendium/5.5e/Rules/Hazards/Burning#SRD 5.2.1|Burning]]

### Burrow Speed

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Burrow Speed#SRD 5.2.1|Burrow Speed]]

### Campaign

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Campaign#SRD 5.2.1|Campaign]]

### Cantrip

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Cantrip#SRD 5.2.1|Cantrip]]

### Carrying Capacity

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Carrying Capacity#SRD 5.2.1|Carrying Capacity]]

### Challenge Rating

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating#SRD 5.2.1|Challenge Rating]]

### Character Sheet

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Character Sheet#SRD 5.2.1|Character Sheet]]

### Charmed [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed#SRD 5.2.1|Charmed]]

### Climbing

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing#SRD 5.2.1|Climbing]]

### Climb Speed

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climb Speed#SRD 5.2.1|Climb Speed]]

### Concentration

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration#SRD 5.2.1|Concentration]]

### Condition

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Condition#SRD 5.2.1|Condition]]

### Cone [Area of Effect]

[[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cone#SRD 5.2.1|Cone]]

### Cover

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Cover#SRD 5.2.1|Cover]]

### Crawling

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Crawling#SRD 5.2.1|Crawling]]

### Creature

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Creature#SRD 5.2.1|Creature]]

### Creature Type

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Creature Type#SRD 5.2.1|Creature Type]]

### Critical Hit

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Critical Hit#SRD 5.2.1|Critical Hit]]

### Cube [Area of Effect]

[[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cube#SRD 5.2.1|Cube]]

### Curses

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Curses#SRD 5.2.1|Curses]]

### Cylinder [Area of Effect]

[[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cylinder#SRD 5.2.1|Cylinder]]

### D20 Test

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/D20 Test#SRD 5.2.1|D20 Test]]

### Damage

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Damage#SRD 5.2.1|Damage]]

### Damage Roll

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Damage Roll#SRD 5.2.1|Damage Roll]]

### Damage Threshold

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Damage Threshold#SRD 5.2.1|Damage Threshold]]

### Damage Types

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Damage Types#SRD 5.2.1|Damage Types]]

### Darkness

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Darkness#SRD 5.2.1|Darkness]]

### Darkvision

[[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision#SRD 5.2.1|Darkvision]]

### Dash [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Dash#SRD 5.2.1|Dash]]

### Dead

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Dead#SRD 5.2.1|Dead]]

### Deafened [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Deafened#SRD 5.2.1|Deafened]]

### Death Saving Throw

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Death Saving Throw#SRD 5.2.1|Death Saving Throw]]

### Dehydration [Hazard]

[[== SRDs ==/Compendium/5.5e/Rules/Hazards/Dehydration#SRD 5.2.1|Dehydration]]

### Difficult Terrain

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Difficult Terrain#SRD 5.2.1|Difficult Terrain]]

### Difficulty Class

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Difficulty Class#SRD 5.2.1|Difficulty Class]]

### Dim Light

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Dim Light#SRD 5.2.1|Dim Light]]

### Disadvantage

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]]

### Disengage [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Disengage#SRD 5.2.1|Disengage]]

### Dodge [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Dodge#SRD 5.2.1|Dodge]]

### Emanation [Area of Effect]

[[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Emanation#SRD 5.2.1|Emanation]]

### Encounter

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Encounter#SRD 5.2.1|Encounter]]

### Enemy

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Enemy#SRD 5.2.1|Enemy]]

### Exhaustion [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion#SRD 5.2.1|Exhaustion]]

### Experience Points

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Experience Points#SRD 5.2.1|Experience Points]]

### Expertise

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Expertise#SRD 5.2.1|Expertise]]

### Falling [Hazard]

[[== SRDs ==/Compendium/5.5e/Rules/Hazards/Falling#SRD 5.2.1|Falling]]

### Flying

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying#SRD 5.2.1|Flying]]

### Fly Speed

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Fly Speed#SRD 5.2.1|Fly Speed]]

### Friendly [Attitude]

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Friendly#SRD 5.2.1|Friendly]]

### Frightened [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened#SRD 5.2.1|Frightened]]

### Grappled [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled#SRD 5.2.1|Grappled]]

### Grappling

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Grappling#SRD 5.2.1|Grappling]]

### Hazard

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hazard#SRD 5.2.1|Hazard]]

### Healing

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Healing#SRD 5.2.1|Healing]]

### Heavily Obscured

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Heavily Obscured#SRD 5.2.1|Heavily Obscured]]

### Help [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Help#SRD 5.2.1|Help]]

### Heroic Inspiration

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Heroic Inspiration#SRD 5.2.1|Heroic Inspiration]]

### Hide [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Hide#SRD 5.2.1|Hide]]

### High Jump

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/High Jump#SRD 5.2.1|High Jump]]

### Hit Point Dice

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Point Dice#SRD 5.2.1|Hit Point Dice]]

### Hit Points

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points#SRD 5.2.1|Hit Points]]

### Hostile [Attitude]

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hostile#SRD 5.2.1|Hostile]]

### Hover

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hover#SRD 5.2.1|Hover]]

### Illusions

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Illusions#SRD 5.2.1|Illusions]]

### Immunity

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Immunity#SRD 5.2.1|Immunity]]

### Improvised Weapons

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Improvised Weapons#SRD 5.2.1|Improvised Weapons]]

### Incapacitated [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated#SRD 5.2.1|Incapacitated]]

### Indifferent [Attitude]

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Indifferent#SRD 5.2.1|Indifferent]]

### Influence [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Influence#SRD 5.2.1|Influence]]

### Initiative

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]]

### Invisible [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Invisible#SRD 5.2.1|Invisible]]

### Jumping

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Jumping#SRD 5.2.1|Jumping]]

### Knocking Out a Creature

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Knocking Out a Creature#SRD 5.2.1|Knocking Out a Creature]]

### Lightly Obscured

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Lightly Obscured#SRD 5.2.1|Lightly Obscured]]

### Line [Area of Effect]

[[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Line#SRD 5.2.1|Line]]

### Long Jump

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Jump#SRD 5.2.1|Long Jump]]

### Long Rest

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]]

### Magic [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]]

### Magical Effect

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Magical Effect#SRD 5.2.1|Magical Effect]]

### Malnutrition [Hazard]

[[== SRDs ==/Compendium/5.5e/Rules/Hazards/Malnutrition#SRD 5.2.1|Malnutrition]]

### Monster

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Monster#SRD 5.2.1|Monster]]

### Nonplayer Character

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Nonplayer Character#SRD 5.2.1|Nonplayer Character]]

### Object

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Object#SRD 5.2.1|Object]]

### Occupied Space

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Occupied Space#SRD 5.2.1|Occupied Space]]

### Opportunity Attacks

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Opportunity Attacks#SRD 5.2.1|Opportunity Attacks]]

### Paralyzed [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed#SRD 5.2.1|Paralyzed]]

### Passive Perception

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception#SRD 5.2.1|Passive Perception]]

### Per Day

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Per Day#SRD 5.2.1|Per Day]]

### Petrified [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Petrified#SRD 5.2.1|Petrified]]

### Player Character

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Player Character#SRD 5.2.1|Player Character]]

### Poisoned [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned#SRD 5.2.1|Poisoned]]

### Possession

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Possession#SRD 5.2.1|Possession]]

### Proficiency

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]]

### Prone [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone#SRD 5.2.1|Prone]]

### Reach

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Reach#SRD 5.2.1|Reach]]

### Reaction

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Reaction#SRD 5.2.1|Reaction]]

### Ready [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Ready#SRD 5.2.1|Ready]]

### Resistance

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Resistance#SRD 5.2.1|Resistance]]

### Restrained [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Restrained#SRD 5.2.1|Restrained]]

### Ritual

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual#SRD 5.2.1|Ritual]]

### Round Down

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Round Down#SRD 5.2.1|Round Down]]

### Save

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Saving Throw#SRD 5.2.1|Saving Throw]]

### Saving Throw

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Saving Throw#SRD 5.2.1|Saving Throw]]

### Search [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Search#SRD 5.2.1|Search]]

### Shape-Shifting

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Shape-Shifting#SRD 5.2.1|Shape-Shifting]]

### Short Rest

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest#SRD 5.2.1|Short Rest]]

### Simultaneous Effects

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Simultaneous Effects#SRD 5.2.1|Simultaneous Effects]]

### Size

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Size#SRD 5.2.1|Size]]

### Skill

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Skill#SRD 5.2.1|Skill]]

### Speed

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed#SRD 5.2.1|Speed]]

### Spell

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]]

### Spell Attack

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell Attack#SRD 5.2.1|Spell Attack]]

### Spellcasting Focus

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spellcasting Focus#SRD 5.2.1|Spellcasting Focus]]

### Sphere [Area of Effect]

[[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Sphere#SRD 5.2.1|Sphere]]

### Stable

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Stable#SRD 5.2.1|Stable]]

### Stat Block

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Stat Block#SRD 5.2.1|Stat Block]]

### Study [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Study#SRD 5.2.1|Study]]

### Stunned [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Stunned#SRD 5.2.1|Stunned]]

### Suffocation [Hazard]

[[== SRDs ==/Compendium/5.5e/Rules/Hazards/Suffocation#SRD 5.2.1|Suffocation]]

### Surprise

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Surprise#SRD 5.2.1|Surprise]]

### Swimming

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming#SRD 5.2.1|Swimming]]

### Swim Speed

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swim Speed#SRD 5.2.1|Swim Speed]]

### Target

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Target#SRD 5.2.1|Target]]

### Telepathy

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Telepathy#SRD 5.2.1|Telepathy]]

### Teleportation

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Teleportation#SRD 5.2.1|Teleportation]]

### Temporary Hit Points

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points#SRD 5.2.1|Temporary Hit Points]]

### Tremorsense

[[== SRDs ==/Compendium/5.5e/Rules/Senses/Tremorsense#SRD 5.2.1|Tremorsense]]

### Truesight

[[== SRDs ==/Compendium/5.5e/Rules/Senses/Truesight#SRD 5.2.1|Truesight]]

### Unarmed Strike

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike#SRD 5.2.1|Unarmed Strike]]

### Unconscious [Condition]

[[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious#SRD 5.2.1|Unconscious]]

### Unoccupied Space

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unoccupied Space#SRD 5.2.1|Unoccupied Space]]

### Utilize [Action]

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Utilize#SRD 5.2.1|Utilize]]

### Vulnerability

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Vulnerability#SRD 5.2.1|Vulnerability]]

### Weapon

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Weapon#SRD 5.2.1|Weapon]]

### Weapon Attack

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Weapon Attack#SRD 5.2.1|Weapon Attack]]

## Tables and Boxed Reference Material

These extracts preserve the PDF’s table layout alongside the text above.

### Page 178 — srd-p178-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p178-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=178|Open source page 178]]

### Page 178 — srd-p178-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p178-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=178|Open source page 178]]

### Page 180 — srd-p180-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p180-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=180|Open source page 180]]

### Page 180 — srd-p180-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p180-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=180|Open source page 180]]

### Page 181 — srd-p181-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p181-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=181|Open source page 181]]

### Page 184 — srd-p184-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p184-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=184|Open source page 184]]

### Page 185 — srd-p185-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p185-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=185|Open source page 185]]

### Page 187 — srd-p187-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p187-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=187|Open source page 187]]

### Page 189 — srd-p189-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p189-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=189|Open source page 189]]
