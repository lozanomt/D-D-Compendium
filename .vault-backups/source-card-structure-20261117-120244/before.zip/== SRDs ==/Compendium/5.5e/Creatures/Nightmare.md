---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 02663d2a-a3da-527d-a631-4a2fee54cb4f
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [311]
---

> [!statblock]
> ## Nightmare
> 
> *Large Fiend, Neutral Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p228-nightmare.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +2 (12)  
> **HP** 68 (8d10 + 24)  
> **Speed** 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 90 ft. (hover)  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 15 | +2 | +2 | **Con** | 16 | +3 | +3 |
> | **Int** | 10 | +0 | +0 | **Wis** | 13 | +1 | +1 | **Cha** | 15 | +2 | +2 |
> 
> **Immunities** Fire  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** Understands Abyssal, Common, and Infernal but can't speak  
> **CR** 3 (XP 700; PB +2)  
> 
> ### Traits
> 
> ***Confer Fire Resistance.*** The nightmare can grant Resistance to Fire damage to a rider while it is on the nightmare.
> 
> ***Illumination.*** The nightmare sheds Bright Light in a 10 foot radius and Dim Light for an additional 10 feet.
> 
> ### Actions
> 
> ***Hooves.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 13 (2d8 + 4) Bludgeoning damage plus 10 (3d6) Fire damage.
> 
> ***Ethereal Stride.*** The nightmare and up to three willing creatures within 5 feet of it teleport to [[== SRDs ==/Compendium/5.5e/Lore/The Ethereal Plane|The Ethereal Plane]] from the Material Plane or vice versa.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=311|SRD 5.2.1, p. 311]] — matches the existing entry.
