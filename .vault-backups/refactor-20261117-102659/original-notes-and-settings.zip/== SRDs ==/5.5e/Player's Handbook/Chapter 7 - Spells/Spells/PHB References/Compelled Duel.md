---
type: spell-reference
coverage: source-reference
level: 1
school: Enchantment
rules_revision: "2024"
classes:
  - Paladin
tags:
  - rules/spell-reference
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Compelled Duel

![[Placeholder.png|320]]


**Level 1 · Enchantment**

## Rules reference

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=115|Handbook class spell-list entry]]

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=242|Open the handbook’s spell descriptions]] and search for **Compelled Duel** for the complete casting time, range, components, duration, and effects. This note supplies a source reference, not a transcription of the spell.

## Class lists

[[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Paladin/Paladin|Paladin]]
