---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 34a64923-71e6-5543-b44b-992480f84d27
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [269]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Ancient Brass Dragon

## Monster Manual


> [!statblock]
> ### Ancient Brass Dragon
>
> *Gargantuan Dragon (Metallic), Chaotic Good*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p059-ancient-brass-dragon.png|320]]
>
> **AC:** 20 &emsp;  
> **Initiative:** +12 (22)  
> **HP:** 332 (19d20 + 133)  
> **Speed:** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Burrowing|Burrow]] 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 80 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 27 | +8 | +8 | **Dex** | 10 | +0 | +6 | **Con** | 25 | +7 | +7 |
> | **Int** | 16 | +3 | +3 | **Wis** | 15 | +2 | +8 | **Cha** | 22 | +6 | +6 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]] +9, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +14, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Persuasion|Persuasion]] +12, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6  
> **Immunities:** Fire  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 24  
> **Languages:** Common, Draconic  
> **CR:** 20 (XP 25,000, or 33,000 in lair; PB +6)  
>
> #### Traits
>
> ***Legendary Resistance (4/Day, or 5/Day in Lair).*** If the dragon fails a saving throw, it can choose to succeed instead.
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> #### Actions
>
> ***Multiattack.*** The dragon makes three Rend attacks. It can replace one attack with a use of (A) Sleep Breath or (B) Spellcasting to cast *Scorching Ray* (level 3 version).
>
> ***Rend.*** *Melee Attack Roll:* +14, reach 15 ft. *Hit:* 19 (2d10 + 8) Slashing damage plus 7 (2d6) Fire damage.
>
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 21, each creature in a 90-foot-long, 5-footwide Line. *Failure:* 58 (13d8) Fire damage. *Success:* Half damage.
>
> ***Sleep Breath.*** *Constitution Saving Throw:* DC 21, each creature in a 90-foot Cone. *Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition until the end of its next turn, at which point it repeats the save. *Second Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]] condition for 10 minutes. This effect ends for the target if it takes damage or a creature within 5 feet of it takes an action to wake it.
>
> ***Spellcasting.*** The dragon casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 20):
>
> - **At Will:** *Detect Magic*, *Minor Illusion*, *Scorching Ray*  (level 3 version), *Shapechange* (Beast or Humanoid form only, no Temporary Hit Points gained from the spell, and no Concentration or Temporary Hit Points required to maintain the spell), *Speak with Animals*
> - **1/Day Each:** *Control Weather*, *Detect Thoughts*
>
> #### Legendary Actions
>
> *Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the dragon can expend a use to take one of the following actions. The dragon regains all expended uses at the start of each of its turns.*
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> ***Blazing Light.*** The dragon uses Spellcasting to cast *Scorching Ray* (level 3 version).
>
> ***Pounce.*** The dragon moves up to half its Speed, and it makes one Rend attack.
>
> ***Scorching Sands.*** *Dexterity Saving Throw:* DC 20, one creature the dragon can see within 120 feet. *Failure:* 36 (8d8) Fire damage, and the target's Speed is halved until the end of its next turn. *Failure or Success:* The dragon can't take this action again until the start of its next turn.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Ancient Brass Dragon
>
> *Gargantuan Dragon (Metallic), Chaotic Good*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p059-ancient-brass-dragon.png|320]]
>
> **AC:** 20 &emsp;  
> **Initiative:** +12 (22)  
> **HP:** 332 (19d20 + 133)  
> **Speed:** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Burrowing|Burrow]] 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 80 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 27 | +8 | +8 | **Dex** | 10 | +0 | +6 | **Con** | 25 | +7 | +7 |
> | **Int** | 16 | +3 | +3 | **Wis** | 15 | +2 | +8 | **Cha** | 22 | +6 | +6 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]] +9, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +14, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Persuasion|Persuasion]] +12, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6  
> **Immunities:** Fire  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 24  
> **Languages:** Common, Draconic  
> **CR:** 20 (XP 25,000, or 33,000 in lair; PB +6)  
>
> #### Traits
>
> ***Legendary Resistance (4/Day, or 5/Day in Lair).*** If the dragon fails a saving throw, it can choose to succeed instead.
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> #### Actions
>
> ***Multiattack.*** The dragon makes three Rend attacks. It can replace one attack with a use of (A) Sleep Breath or (B) Spellcasting to cast *Scorching Ray* (level 3 version).
>
> ***Rend.*** *Melee Attack Roll:* +14, reach 15 ft. *Hit:* 19 (2d10 + 8) Slashing damage plus 7 (2d6) Fire damage.
>
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 21, each creature in a 90-foot-long, 5-footwide Line. *Failure:* 58 (13d8) Fire damage. *Success:* Half damage.
>
> ***Sleep Breath.*** *Constitution Saving Throw:* DC 21, each creature in a 90-foot Cone. *Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition until the end of its next turn, at which point it repeats the save. *Second Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]] condition for 10 minutes. This effect ends for the target if it takes damage or a creature within 5 feet of it takes an action to wake it.
>
> ***Spellcasting.*** The dragon casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 20):
>
> - **At Will:** *Detect Magic*, *Minor Illusion*, *Scorching Ray*  (level 3 version), *Shapechange* (Beast or Humanoid form only, no Temporary Hit Points gained from the spell, and no Concentration or Temporary Hit Points required to maintain the spell), *Speak with Animals*
> - **1/Day Each:** *Control Weather*, *Detect Thoughts*
>
> #### Legendary Actions
>
> *Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the dragon can expend a use to take one of the following actions. The dragon regains all expended uses at the start of each of its turns.*
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> ***Blazing Light.*** The dragon uses Spellcasting to cast *Scorching Ray* (level 3 version).
>
> ***Pounce.*** The dragon moves up to half its Speed, and it makes one Rend attack.
>
> ***Scorching Sands.*** *Dexterity Saving Throw:* DC 20, one creature the dragon can see within 120 feet. *Failure:* 36 (8d8) Fire damage, and the target's Speed is halved until the end of its next turn. *Failure or Success:* The dragon can't take this action again until the start of its next turn.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=269|SRD 5.2.1, p. 269]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
