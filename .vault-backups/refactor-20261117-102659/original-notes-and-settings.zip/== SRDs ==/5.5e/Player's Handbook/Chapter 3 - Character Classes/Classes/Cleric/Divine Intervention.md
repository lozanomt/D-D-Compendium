---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Divine Intervention

![[phb-p071-cleric.png|320]]

You can call on your deity or pantheon to intervene on your behalf. As a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action, choose any Cleric spell of level 5 or lower that doesn’t require a Reaction to cast. As part of the same action, you cast that spell without expending a spell slot or needing Material [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Components|components]]. You can’t use this feature again until you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

At Cleric level 20, you can call on even more powerful divine intervention. When you use your [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Cleric/Divine Intervention|Divine Intervention]] feature, you can choose *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 9/Wish|Wish]]* when you select a spell. If you do so, you can't use Divine Intervention again until you finish 2d4 [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rests]].

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=72|Player’s Handbook (2024), PDF page 72]]
