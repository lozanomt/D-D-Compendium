---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 1d103e9b-4b70-5fea-967c-7ab897014af2
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [348]
---

> [!statblock]
> ## Eagle
> 
> *Small Beast, Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 4 (1d6 + 1)  
> **Speed** 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 6 | -2 | -2 | **Dex** | 15 | +2 | +2 | **Con** | 12 | +1 | +1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 14 | +2 | +2 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +6  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Actions
> 
> ***Talons.*** *Melee Attack Roll:* +4, reach 5 feet. *Hit:* 4 (1d4 + 2) Slashing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=348|SRD 5.2.1, p. 348]] — matches the existing entry.
