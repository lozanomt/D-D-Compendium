---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: bbedd94a-de16-5db7-98d9-f4c7aa354837
entity_type: creature
source_ids: ["mm-2025", "phb-2024", "srd-5.2.1"]
source_versions: ["Monster Manual", "Player's Handbook"]
srd_5_2_1_pages: [353]
---

# Giant Seahorse

One creature entry with separately labeled source versions. Each book’s chapter links to its own version.

## Monster Manual

> [!statblock]
> ### Giant Seahorse
> 
> *Large Beast, Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +1 (11)  
> **HP** 16 (3d10)  
> **Speed** 5 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 12 | +1 | +1 | **Con** | 11 | +0 | +0 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 5 | -3 | -3 |
> 
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** None  
> **CR** 1/2 (XP 100; PB +2)  
> 
> #### Traits
> 
> ***Water Breathing.*** The seahorse can breathe only underwater.
> 
> #### Actions
> 
> ***Ram.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 9 (2d6 + 2) Bludgeoning damage, or 11 (2d8 + 2) Bludgeoning damage if the seahorse moved 20+ feet straight toward the target immediately before the hit.
> 
> #### Bonus Actions
> 
> ***Bubble Dash.*** While underwater, the seahorse moves up to half its Swim Speed without provoking Opportunity Attacks.

## Player's Handbook

> [!statblock]
> ### Giant Seahorse
>
> *Large Beast, Unaligned*
>
> **AC** 14 &emsp; **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]]** +1 (11)  
> **HP** 16 (3d10)  
> **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]** 5 ft., Swim 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 12 | +1 | +1 | **Con** | 11 | +0 | +0 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 5 | -3 | -3 |
>
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** None  
> **CR** 1/2 (XP 100; PB +2)  
>
> #### Traits
>
> ***Water Breathing.*** The seahorse can breathe only underwater.
>
> #### Actions
>
> ***Ram.*** *Melee [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack|Attack]] Roll:* +4, reach 5 ft. *Hit:* 9 (2d6 + 2) Bludgeoning damage, or 11 (2d8 + 2) Bludgeoning damage if the seahorse moved 20+ feet straight toward the target immediately before the hit.
>
> #### Bonus Actions
>
> ***Bubble Dash.*** While underwater, the seahorse moves up to half its Swim [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]] without provoking [[== SRDs ==/Compendium/5.5e/Rules/Actions/Opportunity Attacks|Opportunity Attacks]].

Source: [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=353|Player’s Handbook (2024), p. 350]].

[[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/Compendium/5.5e/Creatures/Giant Seahorse#Monster Manual|Monster Manual version]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Player's Handbook — Appendix B - Creature Stat Blocks]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=353|SRD 5.2.1, p. 353]] — matches the Monster Manual section.
