---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Fiend Patron

*Make a Deal with the Lower Planes*

![[phb-p165-fiend-patron.png|320]]


Your pact draws on the Lower Planes, the realms of perdition. You might forge a bargain with a demon lord such as Demogorgon or Orcus; an archdevil such as Asmodeus; or a pit fiend, balor, yugoloth, or night hag that is especially mighty. That patron’s aims are evil - the corruption or destruction of all things, ultimately including you - and your path is defined by the extent to which you strive against those aims.
#### Level 3: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Fiend Patron/Dark One's Blessing|Dark One's Blessing]]
When you reduce an enemy to 0 [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]], you gain [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to your Charisma modifier plus your Warlock level (minimum of 1 Temporary Hit Point). You also gain this benefit if someone else reduces an enemy within 10 feet of you to 0 Hit Points.
#### Level 3: Fiend Spells
The magic of your patron ensures you always have certain spells ready; when you reach a Warlock level specified in the Fiend Spells table, you thereafter always have the listed spells prepared.
###### Fiend Spells
| Warlock Level | Prepared Spells                                                           |
| :-----------: | ------------------------------------------------------------------------- |
|       3       | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Burning Hands\|Burning Hands]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Command\|Command]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Scorching Ray\|Scorching Ray]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Suggestion\|Suggestion]]* |
|       5       | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Fireball\|Fireball]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Stinking Cloud\|Stinking Cloud]]*                                      |
|       7       | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Fire Shield\|Fire Shield]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Wall of Fire\|Wall of Fire]]*                                     |
|       9       | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Geas\|Geas]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Insect Plague\|Insect Plague]]*                                           |
#### Level 6: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Fiend Patron/Dark One's Own Luck|Dark One's Own Luck]]
You can call on your fiendish patron to alter fate in your favor. When you make an ability check or a saving throw, you can use this feature to add 1d10 to your roll. You can do so after seeing the roll but before any of the roll’s effects occur. You can use this feature a number of times equal to your Charisma modifier (minimum of once), but you can use it no more than once per roll. You regain all expended uses when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].
#### Level 10: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Fiend Patron/Fiendish Resilience|Fiendish Resilience]]
Choose one damage type, other than Force, whenever you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]]. You have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to that damage type until you choose a different one with this feature.
#### Level 14: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Fiend Patron/Hurl Through Hell|Hurl Through Hell]]
Once per turn when you hit a creature with an attack roll, you can try to instantly transport the target through the Lower Planes. The target must succeed on a Charisma saving throw against your spell save DC, or the target disappears and hurtles through a nightmare landscape. The target takes 8d10 Psychic damage if it isn’t a Fiend, and it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition until the end of your next turn, when it returns to the space it previously occupied or the nearest unoccupied space.

Once you use this feature, you can’t use it again until you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]] unless you expend a [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Pact Magic|Pact Magic]] spell slot (no action required) to restore your use of it.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=164|Player’s Handbook (2024), PDF page 164]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=165|Player’s Handbook (2024), PDF page 165]]
