---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Immunity

![[Placeholder.png|320]]


If you have Immunity to a damage type or a condition, it doesn’t affect you in any way.
