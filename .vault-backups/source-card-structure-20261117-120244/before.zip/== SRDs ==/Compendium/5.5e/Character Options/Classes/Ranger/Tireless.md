---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 446ac604-8ff5-525e-bc06-062bcf7ce0c5
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [59]
---

# Tireless

![[== SRDs ==/Attachments/Artwork/phb-p121-ranger.png|320]]

Primal forces now help fuel you on your journeys, granting you the following benefits.

***Temporary Hit Points.*** As a [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action, you can give yourself a number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to 1d8 plus your Wisdom modifier (minimum of 1). You can use this action a number of times equal to your Wisdom modifier (minimum of once), and you regain all expended uses when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

***Decrease Exhaustion.*** Whenever you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short Rest]], your [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]] level, if any, decreases by 1.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=122|Player’s Handbook (2024), PDF page 122]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

Primal forces now help fuel you on your journeys, granting you the following benefits.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]]. As a [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action, you can give yourself a number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to 1d8 plus your Wisdom modifier (minimum of 1). You can use this action a number of times equal to your Wisdom modifier (minimum of once), and you regain all expended uses when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

Decrease [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]]. Whenever you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short Rest]], your [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]] level, if any, decreases by 1.

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=59|SRD 5.2.1, p. 59]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=59|SRD 5.2.1, p. 59]]
