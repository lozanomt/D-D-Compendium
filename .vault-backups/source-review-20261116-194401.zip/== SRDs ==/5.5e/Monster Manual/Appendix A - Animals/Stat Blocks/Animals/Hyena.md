---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Hyena
> 
> *Medium Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]
> 
> 
> **AC** 11 &emsp; **Initiative** +1 (11)  
> **HP** 5 (1d8 + 1)  
> **Speed** 50 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +0 | **Dex** | 13 | +1 | +1 | **Con** | 12 | +1 | +1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 5 | -3 | -3 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +3  
> **Senses** [[Darkvision]] 60 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 13  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Traits
> 
> ***Pack Tactics.*** The hyena has Advantage on an attack roll against a creature if at least one of the hyena's allies is within 5 feet of the creature and the ally doesn't have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated]] condition.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +2, reach 5 ft. *Hit:* 3 (1d6) Piercing damage.
