---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Will-o'-Wisp
> 
> *Tiny Undead, Chaotic Evil*
> 
> ![[mm-p335-will-o-wisp.png|320]]
> 
> 
> **AC** 19 &emsp; **Initiative** +9 (19)  
> **HP** 27 (11d4)  
> **Speed** 5 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 50 ft. (hover)  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 1 | -5 | -5 | **Dex** | 28 | +9 | +9 | **Con** | 10 | +0 | +0 |
> | **Int** | 13 | +1 | +1 | **Wis** | 14 | +2 | +2 | **Cha** | 11 | +0 | +0 |
> 
> **Resistances** Acid, Bludgeoning, Cold, Fire, Necrotic, Piercing, Slashing  
> **Immunities** Lightning, Poison; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Petrified|Petrified]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Unconscious|Unconscious]]  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** Common plus one other language  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Ephemeral.*** The wisp can't wear or carry anything.
> 
> ***Illumination.*** The wisp sheds Bright Light in a 20-foot radius and Dim Light for an additional 20 feet.
> 
> ***Incorporeal Movement.*** The wisp can move through other creatures and objects as if they were Difficult Terrain. It takes 5 (1d10) Force damage if it ends its turn inside an object.
> 
> ### Actions
> 
> ***Shock.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 11 (2d8 + 2) Lightning damage.
> 
> ### Bonus Actions
> 
> ***Consume Life.*** *Constitution Saving Throw:* DC 10, one living creature the wisp can see within 5 feet that has 0 Hit Points. *Failure:* The target dies, and the wisp regains 10 (3d6) Hit Points.
> 
> ***Vanish.*** The wisp and its light have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Invisible|Invisible]] condition until the wisp's Concentration ends on this effect, which ends early immediately after the wisp makes an attack roll or uses Consume Life.
