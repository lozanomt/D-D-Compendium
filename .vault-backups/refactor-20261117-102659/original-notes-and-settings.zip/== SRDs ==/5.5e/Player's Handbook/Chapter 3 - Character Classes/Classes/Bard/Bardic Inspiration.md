---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Bardic Inspiration

![[phb-p061-bard.png|320]]

You can supernaturally inspire others through words, music, or dance. This inspiration is represented by your Bardic Inspiration die, which is a d6.

***Using Bardic Inspiration.*** As a Bonus Action, you can inspire another creature within 60 feet of yourself who can see or hear you. That creature gains one of your Bardic Inspiration dice. A creature can have only one Bardic Inspiration die at a time.

Once within the next hour when the creature fails a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/D20 Test|D20 Test]], the creature can roll the Bardic Inspiration die and add the number rolled to the d20, potentially turning the failure into a success. A Bardic Inspiration die is expended when it’s rolled.

***Number of Uses.*** You can confer a Bardic Inspiration die a number of times equal to your Charisma modifier (minimum of once), and you regain all expended uses when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

***At Higher Levels.*** Your Bardic Inspiration die changes when you reach certain Bard levels, as shown in the Bardic Die column of the Bard Features table. The die becomes a d8 at level 5, a d10 at level 10, and a d12 at level 15.

***Font of Inspiration.*** At Bard level 5, you now regain all your expended uses of Bardic Inspiration when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]]. In addition, you can expend a spell slot (no action required) to regain one expended use of Bardic Inspiration.

***Superior Inspiration.*** At Bard level 18, when you roll [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]], you regain expended uses of Bardic Inspiration until you have two if you have fewer than that.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=62|Player’s Handbook (2024), PDF page 62]]
