---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Ring Mail, +2 [[Ring Mail, +2 |(40,030 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Ring Mail]]), Very Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-ring-mail.png|320]]


**Attunement** No

You have a +2 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Ring Mail|clean no-title]]
