---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Resilient Sphere
*Level 4 Abjuration (Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a glass sphere)
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 minute

A shimmering sphere encloses a Large or smaller creature or object within range. An unwilling creature must succeed on a Dexterity saving throw or be enclosed for the duration.

Nothing - not physical objects, energy, or other spell effects - can pass through the barrier, in or out, though a creature in the sphere can breathe there. The sphere is immune to all damage, and a creature or object inside can't be damaged by attacks or effects originating from outside, nor can a creature inside the sphere damage anything outside it.

The sphere is weightless and just large enough to contain the creature or object inside. An enclosed creature can take an action to push against the sphere's walls and thus roll the sphere at up to half the creature's [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]]. Similarly, the globe can be picked up and moved by other creatures.

A *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 6/Disintegrate|Disintegrate]]* spell targeting the globe destroys it without harming anything inside.
