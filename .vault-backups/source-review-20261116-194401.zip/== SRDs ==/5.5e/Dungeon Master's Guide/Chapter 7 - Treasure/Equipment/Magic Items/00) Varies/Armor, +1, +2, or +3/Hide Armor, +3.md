---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Hide Armor, +3 [[Hide Armor, +3 |(200,010 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Hide Armor]]), Legendary*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-hide-armor.png|320]]


**Attunement** No

You have a +3 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Hide Armor|clean no-title]]
