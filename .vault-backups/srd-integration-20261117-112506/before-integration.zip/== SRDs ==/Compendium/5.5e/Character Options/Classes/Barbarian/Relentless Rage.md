---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 34fca379-1c16-5a87-af78-b2af82be45f3
entity_type: character-option
source_ids: ["phb-2024"]
---

# Relentless Rage

![[== SRDs ==/Attachments/Artwork/phb-p053-barbarian.png|320]]

Your Rage can keep you fighting despite grievous wounds. If you drop to 0 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] while your Rage is active and don’t die outright, you can make a DC 10 Constitution saving throw. If you succeed, your Hit Points instead change to a number equal to twice your Barbarian level.

Each time you use this feature after the first, the DC increases by 5. When you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]], the DC resets to 10.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=54|Player’s Handbook (2024), PDF page 54]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
