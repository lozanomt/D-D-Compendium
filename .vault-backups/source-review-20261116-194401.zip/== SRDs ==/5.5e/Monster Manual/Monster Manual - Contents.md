# Monster Manual — Contents

Existing vault entries grouped by the source’s chapters and appendices. Empty sections are ready for future additions; no missing book text was imported.

- [[D&D 5e 2024 Rules/Monster Manual/How to Use a Monster/How to Use a Monster|How to Use a Monster]] — 0 entries
- [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Monsters A to Z|Monsters A to Z]] — 236 entries
- [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Appendix A - Animals|Appendix A - Animals]] — 95 entries
- [[D&D 5e 2024 Rules/Monster Manual/Appendix B - Monster Lists/Appendix B - Monster Lists|Appendix B - Monster Lists]] — 0 entries

See [[D&D 5e 2024 Rules/Audits/Source-Reorganization-2026-11-16|source assignment and overlap report]] before removing a source.
