---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Heavy Precipitation

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


Everything within an area of heavy rain or heavy snowfall is [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Lightly Obscured]], and creatures in the area have [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage]] on all Wisdom ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]]) checks. Heavy rain also extinguishes open flames.
