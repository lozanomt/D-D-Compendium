---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: b5620cd5-f324-5802-985d-4cb3e750b3cc
entity_type: character-option
source_ids: ["phb-2024"]
---

# Elf

![[== SRDs ==/Attachments/Artwork/phb-p192-elf.png|320]]

**Creature Type:** Humanoid
**Size:** Medium (about 5 - 6 feet tall)
**[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]:** 30 feet

As an Elf, you have these special traits.

***Darkvision.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] with a range of 60 feet.

***Elven Lineage.*** You are part of a lineage that grants you supernatural abilities. Choose a lineage from the Elven Lineages table. You gain the level 1 benefit of that lineage.

When you reach character levels 3 and 5, you learn a higher-level spell, as shown on the table. You always have that spell prepared. You can cast it once without a spell slot, and you regain the ability to cast it in that way when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]]. You can also cast the spell using any spell slots you have of the appropriate level. Intelligence, Wisdom, or Charisma is your spellcasting ability for the spells you cast with this trait (choose the ability when you select the lineage).

***Fey Ancestry.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on saving throws you make to avoid or end the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]] condition.

***Keen Senses.*** You have proficiency in the [[== SRDs ==/Compendium/5.5e/Rules/Skills/Insight|Insight]], [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]], or [[== SRDs ==/Compendium/5.5e/Rules/Skills/Survival|Survival]] skill.

***Trance.*** You don’t need to sleep, and magic can’t put you to sleep. You can finish a Long Rest in 4 hours if you spend those hours in a trancelike meditation, during which you retain consciousness.

###### Elven Lineages
| Lineage  | Level 1                                                                                                                                                              | Level 3            | Level 5                  |
| -------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------ | ------------------------ |
| Drow     | The range of your [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision\|Darkvision]] increases to 120 feet. You also know the *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Dancing Lights\|Dancing Lights]]* cantrip.                                     | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Faerie Fire\|Faerie Fire]]*  | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkness\|Darkness]]*           |
| High Elf | You also know the *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Prestidigitation\|Prestidigitation]]* cantrip. Whenever you finish a Long Rest, you can replace that cantrip with a different cantrip from the Wizard spell list. | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic\|Detect Magic]]* | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Misty Step\|Misty Step]]*         |
| Wood Elf | Your Speed increases to 35 feet. You also know the *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Druidcraft\|Druidcraft]]* cantrip                                                                                          | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Longstrider\|Longstrider]]*  | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Pass without Trace\|Pass without Trace]]* |

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Player's Handbook — Chapter 4 - Character Origins]]
