---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [324]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Wand of Polymorph
*Wand, Very Rare*

![[Placeholder.png|320]]

**Attunement:** Yes, by a spellcaster

The [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Arcane Focus/Wand|wand]] has 7 charges. While holding it, expend 1 charge to cast [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Polymorph|Polymorph]] (save DC 15). It regains 1d6 + 1 expended charges daily at dawn. If you expend its last charge, roll 1d20; on a 1, the wand crumbles into ashes and is destroyed.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=324|p. 321 (PDF page 324)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
