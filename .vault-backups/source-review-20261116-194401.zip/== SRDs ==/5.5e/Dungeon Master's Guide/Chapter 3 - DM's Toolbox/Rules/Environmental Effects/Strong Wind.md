---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Strong Wind

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


Strong wind imposes [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage]] on ranged attack rolls with weapons. It also extinguishes open flames and disperses fog. A flying creature in a strong wind must land at the end of its turn or [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Hazards/Falling|fall]]. A strong wind in a desert can create a sandstorm that imposes Disadvantage on Wisdom ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]]) checks.
