---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Young Red Dragon
> 
> *Large Dragon (Chromatic), Chaotic Evil*
> 
> ![[mm-p256-red-dragon-wyrmling.png|320]]
> 
> 
> **AC** 18 &emsp; **Initiative** +4 (14)  
> **HP** 178 (17d10 + 85)  
> **Speed** 40 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 40 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 80 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 23 | +6 | +6 | **Dex** | 10 | +0 | +4 | **Con** | 21 | +5 | +5 |
> | **Int** | 14 | +2 | +2 | **Wis** | 11 | +0 | +4 | **Cha** | 19 | +4 | +4 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +8, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +4  
> **Immunities** Fire  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight|Blindsight]] 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 18  
> **Languages** Common, Draconic  
> **CR** 10 (XP 5,900; PB +4)  
> 
> ### Actions
> 
> ***Multiattack.*** The dragon makes three Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +10, reach 10 ft. *Hit:* 13 (2d6 + 6) Slashing damage plus 3 (1d6) Fire damage.
> 
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 17, each creature in a 30-foot Cone. *Failure:* 56 (16d6) Fire damage. *Success:* Half damage.
