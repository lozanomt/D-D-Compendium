---
type: spell-reference
coverage: source-reference
level: 0
school: Evocation
rules_revision: "2024"
classes:
  - Bard
  - Druid
  - Sorcerer
  - Warlock
  - Wizard
tags:
  - rules/spell-reference
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Thunderclap

![[Placeholder.png|320]]


**Cantrip · Evocation**

## Rules reference

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=171|Handbook class spell-list entry]]

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=242|Open the handbook’s spell descriptions]] and search for **Thunderclap** for the complete casting time, range, components, duration, and effects. This note supplies a source reference, not a transcription of the spell.

## Class lists

[[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Bard/Bard|Bard]] · [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Druid/Druid|Druid]] · [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Sorcerer/Sorcerer|Sorcerer]] · [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Warlock|Warlock]] · [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Wizard/Wizard|Wizard]]
