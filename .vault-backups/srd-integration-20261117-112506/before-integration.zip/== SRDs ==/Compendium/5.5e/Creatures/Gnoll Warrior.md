---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: dee317e3-9245-5ebc-a8d1-65aa480dfb6b
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Gnoll Warrior
> 
> *Medium Fiend, Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p143-gnoll-warrior.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +1 (11)  
> **HP** 27 (6d8)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 12 | +1 | +1 | **Con** | 11 | +0 | +0 |
> | **Int** | 6 | -2 | -2 | **Wis** | 10 | +0 | +0 | **Cha** | 7 | -2 | -2 |
> 
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Gnoll  
> **CR** 1/2 (XP 100; PB +2)  
> 
> ### Actions
> 
> ***Rend.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Piercing damage.
> 
> ***Bone Bow.*** *Ranged Attack Roll:* +3, range 150/600 ft. *Hit:* 6 (1d10 + 1) Piercing damage.
> 
> ### Bonus Actions
> 
> ***Rampage (1/Day).*** Immediately after dealing damage to a creature that is already Bloodied, the gnoll moves up to half its Speed, and it makes one Rend attack.
> - [ ]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
