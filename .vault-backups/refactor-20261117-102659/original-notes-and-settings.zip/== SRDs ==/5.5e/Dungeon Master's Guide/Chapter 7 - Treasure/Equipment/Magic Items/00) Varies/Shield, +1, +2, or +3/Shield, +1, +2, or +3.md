---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Shield, +1, +2, or +3 [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Shield, +1, +2, or +3/Shield, +1, +2, or +3|(Varies)]]
*Armor ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Shield|Shield]]), Varies*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p307-shield-of-missile-attraction.png|320]]


**Attunement:** No

While holding this Shield, you have a bonus to Armor Class determined by the Shield's rarity, in addition to the Shield's normal bonus to AC

| Rarity                                   | Bonus |
| ---------------------------------------- | :---: |
| *[[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Shield, +1, +2, or +3/Shield, +1\|Uncommon]]*  |  +1   |
| *[[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Shield, +1, +2, or +3/Shield, +2\|Rare]]*      |  +2   |
| *[[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Shield, +1, +2, or +3/Shield, +3\|Very Rare]]* |  +3   |

---
![[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Shield|clean no-title]]
