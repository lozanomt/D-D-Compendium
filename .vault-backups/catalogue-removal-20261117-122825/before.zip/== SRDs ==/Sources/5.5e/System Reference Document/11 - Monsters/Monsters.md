---
cssclasses: [dnd-book, dnd-phb]
source_id: srd-5.2.1
source_pages: [254, 257]
---

# Monsters

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=254|SRD 5.2.1, p. 254]].

### Stat Block Overview

A monster has a stat block that contains the rules necessary to use it in the game. Stat blocks are divided into the following parts:

Name and General Details. The name of the monster is followed by its size, creature type (along with any descriptive tags), and alignment.

Combat Highlights.  [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Class#SRD 5.2.1|Armor Class]], [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points#SRD 5.2.1|Hit Points]], [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed#SRD 5.2.1|Speed]], and [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]] are provided here.

Ability Scores.  A monster's ability scores, ability modifiers, and saving throws are listed here.

Other Details. The monster's Senses, Languages, and CR entries appear here. Additional details appear in some monsters, such as skill proficiencies,

Resistances, Immunities, and Gear. If a monster lacks those details, entries for them don't appear.

Traits.  [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Monster#SRD 5.2.1|Monster]] characteristics that are active at all times or during certain situations appear here.

Actions. The monster can take the actions here in addition to those in "Playing the Game."

Bonus Actions.  This section provides a monster's Bonus Actions, if any.

Reactions and Legendary Actions.  These sections provide Reactions and Legendary Actions, if any.

### Parts of a Stat Block

The rules for a stat block are detailed in "Rules Glossary"  and in this section.

#### Size

A monster is Tiny, Small, Medium, Large, Huge, or Gargantuan. If size options are presented, you choose the creature's size from those options. See "Playing the Game" for information on size.

#### Creature Type

Each monster has a tag that identifies the type of creature it is. Certain spells, magic items, class features, and other effects in the game interact in special ways with creatures of a particular type.

The game includes the following creature types, which have no rules of their own: Aberrations  are utterly alien beings, such as aboleths and cloakers.

Beasts are non-Humanoid natural creatures, like horses and wolves, as well as most giant animals.

Celestials are magical creatures, such as angels and pegasi, with ties to the Upper Planes.

Constructs  are magically created creatures such as homunculi and shield guardians.

Dragons are scaly beings of ancient origin, such as red dragons and wyverns.

Elementals are beings from the Elemental Planes, such as efreet and water elementals.

Fey are creatures tied to the Feywild or the forces of nature, such as dryads and goblins.

Fiends are creatures tied to terrifying Lower Planes, such as balors and hell hounds.

Giants are towering beings with humanlike shapes, like fire giants and trolls.

Humanoids are people defined by their roles and professions, such as mages, pirates, and warriors.

They include members of varied species.

Monstrosities  are unnatural creatures with strange origins, such as mimics and owlbears.

Oozes are gelatinous creatures, including black puddings and gelatinous cubes.

Plants are sentient vegetation and fungal monsters, such as shambling mounds and treants.

Undead are spirits and the reanimated dead, such as ghosts, vampires, and zombies.

#### Descriptive Tags

A monster might have one or more tags in parentheses following its type. Such tags provide additional categorization and have no rules of their own, but certain game effects might refer to them.

#### Alignment

The alignment specified in a monster's stat block is a default suggestion of how to roleplay the monster, inspired by its traditional role in the game or realworld folklore. Change a monster's alignment to suit your storytelling needs. The Neutral alignment, in particular, is an invitation for you to consider whether an individual leans toward one of the other alignments. "Character [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Creation#SRD 5.2.1|Creation]]"  describes the nine alignments and unaligned creatures.

#### Armor Class

A monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Class#SRD 5.2.1|Armor Class]] (AC) includes its natural armor, Dexterity, gear, and other defenses. See "Playing the Game" for information on [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Class#SRD 5.2.1|Armor Class]].

#### Initiative

The [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]] entry specifies the monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]] modifier followed by the monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]] score in parentheses. Use the modifier when you roll to determine a monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]]. A monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]] modifier is typically equal to its Dexterity modifier, but some monsters have additional modifiers, such as [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus, applied to that number.

If you don't want to roll a monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]], use the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]] score as the monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]] in combat. [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative#SRD 5.2.1|Initiative]] is further detailed in "Playing the Game." Running a MonsteR To ensure a monster acts in accordance with its [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating#SRD 5.2.1|Challenge Rating]], follow these rules during combat:

Special Abilities. If the monster has a special ability that deals a lot of damage but has a limited number of uses, such as a recharging breath weapon or a spell it can cast only once per day, have it use that special ability as quickly and as often as possible.

Multiattack. If the monster has Multiattack, have it use Multiattack on any of its turns in which it's not using one of its more powerful abilities.

Bonus Actions, Reactions, Legendary Actions. If the monster has Bonus Actions, Reactions, or Legendary Actions in its stat block, make sure it uses them as often as it can.

#### Hit Points

A monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points#SRD 5.2.1|Hit Points]] are presented as a number followed by parentheses, where the monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Point Dice#SRD 5.2.1|Hit Point Dice]] are provided, along with any contribution from its Constitution. Either use the number for the monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points#SRD 5.2.1|Hit Points]] or roll the die expression in parentheses to determine the monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points#SRD 5.2.1|Hit Points]] randomly; don't use both.

A monster's size typically determines the die used to calculate its [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points#SRD 5.2.1|Hit Points]], as shown in the Hit Dice by [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Size#SRD 5.2.1|Size]] table.

Hit Dice by [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Size#SRD 5.2.1|Size]] [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Monster#SRD 5.2.1|Monster]] [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Size#SRD 5.2.1|Size]] Hit Die Average HP per Die Tiny d4 21⁄2 Small d6 31⁄2 Medium d8 41⁄2 Large d10 51⁄2 Huge d12 61⁄2 Gargantuan d20 101⁄2 A monster's Constitution modifier is multiplied by the number of Hit Dice it possesses, and the result is added to its [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points#SRD 5.2.1|Hit Points]]. For example, if a monster has a Constitution of 12 (+1 modifier) and 2d8 Hit Dice, it has 2d8 + 2 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points#SRD 5.2.1|Hit Points]] (average 11).

For more on [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points#SRD 5.2.1|Hit Points]], see "Playing the Game ."

#### Speed

The [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed#SRD 5.2.1|Speed]] entry specifies a monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed#SRD 5.2.1|Speed]]. Some monsters have one or more of the following speeds:

Burrow, Climb, Fly, Swim. Rules for [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed#SRD 5.2.1|Speed]] and these specials speeds appear in "Rules Glossary ."

#### Ability Scores

Every monster has six ability scores along with corresponding ability score modifiers and saving throw modifiers. For more information on ability scores and saving throws, see "Playing the Game ."

#### Skills

The Skills entry specifies a monster's skill proficiencies, if any. For example, a monster that is very perceptive and stealthy might have bonuses to Wisdom (Perception) and Dexterity (Stealth) checks. A skill bonus is the sum of a monster's relevant ability modifier and its [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus. Other modifiers might apply.

#### Resistances and Vulnerabilities

These entries list a monster's Resistances and Vulnerabilities, if any. See "Playing the Game" for more information.

#### Immunities

This entry lists the monster's Immunities, if any. If the monster has damage and condition Immunities, the damage types are listed before the conditions.

See "Playing the Game" for details.

#### Gear

Monsters have proficiency with their equipment. If a monster has equipment that can be given away or retrieved, the items are listed in the Gear entry. The monster's stat block might include special flourishes that happen when the monster uses an item, and the stat block might ignore the rules in "Equipment" for that item. When used by someone else, a retrievable item uses its "Equipment" rules, ignoring any special flourishes in the stat block.

The Gear entry doesn't necessarily list all of a monster's equipment. For example, a monster that wears clothes is assumed to be dressed appropriately, and those clothes aren't in this entry.

Equipment mentioned outside the Gear entry is considered to be supernatural or highly specialized, and it is unusable when the monster is defeated.

#### Ammunition and Ranged Attacks

A monster that requires ammunition to make ranged attacks carries the necessary ammunition.

#### Equipping a Monster with Other Items

You may equip monsters with additional gear however you like, using the items in "Equipment" for inspiration. You decide how much of a monster's equipment is recoverable after the creature is slain and whether any of that equipment is still usable.

Beware of giving a monster combat-oriented magic items, since those might alter the monster's

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating#SRD 5.2.1|Challenge Rating]]. If you do give a monster a magic item, the monster can have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]] with magic items as noted in "Equipment." A monster with a class tag after its creature type is considered a member of that class for [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]] purposes.

#### Senses

The Senses entry specifies a monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception#SRD 5.2.1|Passive Perception]] score, as well as any special senses the monster possesses. [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception#SRD 5.2.1|Passive Perception]] and special senses are described in "Rules Glossary ."

#### Languages

This entry lists languages that the monster can use to communicate. Sometimes a monster can understand a language but can't communicate with it, which is noted in its entry. "None" indicates that a creature doesn't comprehend any language.

#### Telepathy

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Telepathy#SRD 5.2.1|Telepathy]] is a magical ability that allows a creature to communicate mentally with another creature within a specified range. See "Rules Glossary" for more information.

#### Challenge Rating

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating#SRD 5.2.1|Challenge Rating]] is defined in "Rules Glossary," while guidance on using CR to plan potential combat encounters is in "Gameplay Toolbox."

#### Experience Points

The number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Experience Points#SRD 5.2.1|Experience Points]] (XP) a monster is worth is based on its CR, as detailed in the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Experience Points#SRD 5.2.1|Experience Points]] by [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating#SRD 5.2.1|Challenge Rating]] table. XP is awarded for defeating the monster in combat or otherwise neutralizing it.

Unless a rule says otherwise, a monster summoned by a spell or another magical ability is worth the XP noted in its stat block.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Experience Points#SRD 5.2.1|Experience Points]] by [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating#SRD 5.2.1|Challenge Rating]]

CR XP CR XP 0 0 or 10 14 11, 50 0 1/8 25 15 13,000 1/4 50 16 15,000 1/2 100 17 18,000 1 200 18 20,000 2 450 19 22,000 3 700 20 25,000 4 1,100 21 33,000 5 1,800 22 41,000 6 2,300 23 50,000 7 2,900 24 62,000 8 3,900 25 75,000 9 5,000 26 90,000 10 5,900 27 105,000

CR XP CR XP 11 7,200 28 120,000 12 8,400 29 135,000 13 10,000 30 155,000

#### Proficiency Bonus

A monster's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus (PB) is determined by its CR, as shown in the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus by [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating#SRD 5.2.1|Challenge Rating]] table, and is reflected in saving throws, skills, and other statistics where the monster's exceptional aptitude is a factor.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus by [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating#SRD 5.2.1|Challenge Rating]]

CR PB CR PB 0–4 +2 17–20 +6 5–8 +3 21–24 +7 9–12 +4 25–28 +8 13–16 +5 29–30 +9

#### Traits

A monster's traits, if any, are features that are active at all times or in certain situations.

#### Actions

A monster can take the actions in this section or take one of the actions available to all creatures, as described in "Playing the Game."

#### Attack Notation

The entry for a monster's attack identifies whether the attack is a melee or a ranged attack and then provides the attack roll's bonus, its reach or range, and what happens on a hit. An attack is against one target unless its entry says otherwise. For details on different kinds of attacks, see "Playing the Game" and "Spells."

Hit. Any damage dealt or other effects that occur as a result of an attack hitting a target are described after the "Hit:" notation.

Miss. If an attack has an effect that occurs on a miss, that information follows the " Miss:" notation.

Hit or Miss. If an attack has an effect that occurs regardless of whether it hits or misses its target, that information follows the " Hit or Miss:" notation.

#### Saving Throw Effect Notation

If an effect forces a saving throw, the effect identifies the kind of save required and then provides the save's DC, a description of which creatures make the save, and an explanation of what happens on a failed or successful save. "Half damage only" on a successful save means the target takes half as much damage (round down) as targets that fail the save, while also ignoring all other parts of the effect.

#### Damage Notation

A stat block usually provides both a number and a die expression for each instance of damage. For example, an attack might deal 4 (1d4 + 2) damage on a hit. You decide whether to use the number or the die expression in parentheses; don't use both.

#### Multiattack

Some creatures can make more than one attack when they take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack#SRD 5.2.1|Attack]] action. Such creatures have the Multiattack entry in the "Actions" section of their stat block. This entry details the attacks a creature can make, as well as any additional abilities it can use, as part of the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack#SRD 5.2.1|Attack]] action.

#### Spellcasting

If a monster can cast any spells, its stat block lists the spells and provides the monster's spellcasting ability, spell save DC (if any spells require a saving throw), and spell attack bonus (if any spells require an attack roll). Unless noted otherwise, a spell of level 1 or higher is always cast at its lowest possible level and can't be cast at a higher level.

A monster's spell can have special rules or restrictions. For example, a green hag can cast the [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility#SRD 5.2.1|Invisibility]] spell, but the spell has a "self only" restriction, which means the spell affects only the hag.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Components. The Spellcasting trait notes whether the monster's spellcasting ignores the need for certain spell components. If any spell components are required, describe the monster's use of Verbal, Somatic, or Material components to signal to characters that it is casting a spell. A monster that requires Material components has them.

Casting Times of 1+ Minutes. If a spell has a casting time of 1 minute or more yet is listed in a spellcasting action, the monster doesn't cast the spell in just one action unless the action's description states otherwise; the monster must take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] action on each of its turns and maintain [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration#SRD 5.2.1|Concentration]] to cast the spell, as described in "Rules Glossary."

#### Bonus Action

If a monster has [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bonus Action#SRD 5.2.1|Bonus Action]] options, they are listed in this section. See "Playing the Game" for details on Bonus Actions.

#### Reactions

If the monster has [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Reaction#SRD 5.2.1|Reaction]] options, those are listed in this section along with their triggers. See "Playing the Game" for details on Reactions.

#### Legendary Actions

If the monster has Legendary [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action#SRD 5.2.1|Action]] options, those are listed in this section. A Legendary [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action#SRD 5.2.1|Action]] is an action that a monster can take immediately after another creature's turn. Only one of these actions can be taken at a time and only after another creature's turn ends. The monster can't take a Legendary [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action#SRD 5.2.1|Action]] if it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated#SRD 5.2.1|Incapacitated]] condition or is otherwise unable to take actions.

The monster has a limited number of Legendary [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action#SRD 5.2.1|Action]] uses, and that number is specified in the stat block. The monster expends one use whenever it takes a Legendary [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action#SRD 5.2.1|Action]], and it regains all expended uses at the start of each of its turns.

#### Limited Usage

Some parts of a stat block have restrictions on the number of times they can be used. Here are the most common ways that usage is limited:

X/Day. This notation means the stat block part can be used a certain number of times (represented by X) and that a monster must finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]] to regain expended uses. For example, a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Reaction#SRD 5.2.1|Reaction]] that includes "1/Day" means the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Reaction#SRD 5.2.1|Reaction]] can be taken once and that the monster must finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]] to take it again.

Recharge X–Y. This notation means a monster can use the stat block part once. At the start of each of the monster's turns, roll 1d6. If the roll is within the number range given in the notation (represented by X–Y), the monster regains the use of that part, which also recharges when the monster finishes a Short or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]]. For example, "Recharge 5–6" in an action means a monster can take the action once. Then, at the start of each of the monster's turns, it regains the use of that action if it rolls a 5 or 6 on 1d6.

Recharge after a Short or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]]. This notation means the monster can use the stat block part once and must then finish a Short or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]] to use it again.

## Tables and Boxed Reference Material

These extracts preserve the PDF’s table layout alongside the text above.

### Page 255 — srd-p255-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p255-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=255|Open source page 255]]

### Page 256 — srd-p256-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p256-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=256|Open source page 256]]

### Page 256 — srd-p256-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p256-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=256|Open source page 256]]
