---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 626f2e4c-843d-556e-a70a-38278876443f
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [290]
---

> [!statblock]
> ## Goblin Minion
> 
> *Small Fey (Goblinoid), Chaotic Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p145-goblin-boss.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 7 (2d6)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 8 | -1 | -1 | **Dex** | 15 | +2 | +2 | **Con** | 10 | +0 | +0 |
> | **Int** | 10 | +0 | +0 | **Wis** | 8 | -1 | -1 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6  
> **Gear** Daggers (3)  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** Common, Goblin  
> **CR** 1/8 (XP 25; PB +2)  
> 
> ### Actions
> 
> ***Dagger.*** *Melee or Ranged Attack Roll:* +4, reach 5 ft. or range 20/60 ft. *Hit:* 4 (1d4 + 2) Piercing damage.
> 
> ### Bonus Actions
> 
> ***Nimble Escape.*** The goblin takes the Disengage or Hide action.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=290|SRD 5.2.1, p. 290]] — matches the existing entry.
