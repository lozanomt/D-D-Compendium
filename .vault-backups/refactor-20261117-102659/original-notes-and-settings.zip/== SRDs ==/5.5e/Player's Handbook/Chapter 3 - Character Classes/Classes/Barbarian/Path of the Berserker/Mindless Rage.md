---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Mindless Rage

![[phb-p057-path-of-the-berserker.png|320]]

You have Immunity to the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Charmed|Charmed]] and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Frightened|Frightened]] conditions while your Rage is active. If you’re Charmed or Frightened when you enter your Rage, the condition ends on you.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=57|Player’s Handbook (2024), PDF page 57]]
