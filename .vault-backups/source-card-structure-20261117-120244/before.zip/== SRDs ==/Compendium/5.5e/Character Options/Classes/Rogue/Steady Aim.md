---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 11d857ff-3072-5d31-825f-afab364517db
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [62]
---

# Steady Aim

![[== SRDs ==/Attachments/Artwork/phb-p131-rogue.png|320]]

As a Bonus Action, you give yourself [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on your next attack roll on the current turn. You can use this feature only if you haven’t moved during this turn, and after you use it, your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]] is 0 until the end of the current turn.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=132|Player’s Handbook (2024), PDF page 132]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

As a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bonus Action|Bonus Action]], you give yourself [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on your next attack roll on the current turn. You can use this feature only if you haven't moved during this turn, and after you use it, your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]] is 0 until the end of the current turn.



![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p062-table-1.png]]



Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=62|SRD 5.2.1, p. 62]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=62|SRD 5.2.1, p. 62]]
