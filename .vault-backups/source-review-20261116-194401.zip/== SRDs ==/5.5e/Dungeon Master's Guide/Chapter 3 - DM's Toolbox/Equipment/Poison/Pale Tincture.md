---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Pale Tincture [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Equipment/Poison/Pale Tincture|(250 GP)]]
*[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Rules/Properties/Poison/Ingested]] Poison*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


A creature subjected to Pale Tincture must succeed on a DC 16 Constitution saving throw or take 3 (1d6) Poison damage and have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned]] condition. The Poisoned creature repeats the save every 24 hours, taking 3 (1d6) Poison damage on a failed save. The damage the poison deals can’t be healed by any means while the creature remains Poisoned. After seven successful saves against the poison, the creature is no longer Poisoned.
