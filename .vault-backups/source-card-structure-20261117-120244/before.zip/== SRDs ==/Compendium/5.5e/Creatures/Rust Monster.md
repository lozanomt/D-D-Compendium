---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 1e715300-1901-510a-87a6-f1d177a6bf21
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [320, 321]
---

> [!statblock]
> ## Rust Monster
> 
> *Medium Monstrosity, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p265-rust-monster.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +1 (11)  
> **HP** 33 (6d8 + 6)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 12 | +1 | +1 | **Con** | 13 | +1 | +1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 13 | +1 | +1 | **Cha** | 6 | -2 | -2 |
> 
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** None  
> **CR** 1/2 (XP 100; PB +2)  
> 
> ### Traits
> 
> ***Iron Scent.*** The rust monster can pinpoint the location of ferrous metal within 30 feet of itself.
> 
> ### Actions
> 
> ***Multiattack.*** The rust monster makes one Bite attack and uses Antennae twice.
> 
> ***Bite.*** *Melee Attack Roll:* +3, reach 5 ft. *Hit:* 5 (1d8 + 1) Piercing damage.
> 
> ***Antennae.*** The rust monster targets one nonmagical metal object — armor or a weapon — worn or carried by a creature within 5 feet of itself. *Dexterity Saving Throw:* DC 11, the creature with the object. *Failure:*  The object takes a -1 penalty to the AC it offers (armor) or to its attack rolls (weapon). Armor is destroyed if the penalty reduces its AC to 10, and a weapon is destroyed if its penalty reaches -5. The penalty can be removed by casting the *Mending* spell on the armor or weapon.
> 
> ***Destroy Metal.*** The rust monster touches a nonmagical metal object within 5 feet of itself that isn't being worn or carried. The touch destroys a 1-foot Cube of the object.
> 
> ### Reactions
> 
> ***Reflexive Antennae.*** *Trigger:* An attack roll hits the rust monster. *Response:* The rust monster uses Antennae.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=320|SRD 5.2.1, p. 320–321]] — matches the existing entry.
