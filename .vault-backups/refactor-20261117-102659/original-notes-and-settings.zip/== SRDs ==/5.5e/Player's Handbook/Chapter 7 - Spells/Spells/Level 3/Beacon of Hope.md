---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Beacon of Hope
*Level 3 Abjuration (Cleric)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 minute

Choose any number of creatures within range. For the duration, each target has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on Wisdom saving throws and[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Death Saving Throw|Death Saving Throws]] and regains the maximum number of Hit Points possible from any healing.
