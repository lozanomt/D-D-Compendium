---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Studded Leather Armor, +3 [[Studded Leather Armor, +3 |(200,045 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Light/Studded Leather Armor]]), Legendary*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-studded-leather-armor.png|320]]


**Attunement** No

You have a +3 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Light/Studded Leather Armor|clean no-title]]
