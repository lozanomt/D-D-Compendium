---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: c8f6becc-d625-5c7e-8705-4bee18db85c4
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Satyr
> 
> *Medium Fey, Chaotic Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p270-satyr.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +3 (13)  
> **HP** 31 (7d8)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 12 | +1 | +1 | **Dex** | 16 | +3 | +3 | **Con** | 11 | +0 | +0 |
> | **Int** | 12 | +1 | +1 | **Wis** | 10 | +0 | +0 | **Cha** | 14 | +2 | +2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Performance|Performance]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +5  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** Common, Elvish, Sylvan  
> **CR** 1/2 (XP 100; PB +2)  
> 
> ### Traits
> 
> ***Magic Resistance.*** The satyr has Advantage on saving throws against spells and other magical effects.
> 
> ### Actions
> 
> ***Hooves.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 5 (1d4 + 3) Bludgeoning damage. If the target is a Medium or smaller creature, the satyr pushes the target up to 10 feet straight away from itself.
> 
> ***Mockery.*** *Wisdom Saving Throw:* DC 12, one creature the satyr can see within 90 feet. *Failure:* 5 (1d6 + 2) Psychic damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
