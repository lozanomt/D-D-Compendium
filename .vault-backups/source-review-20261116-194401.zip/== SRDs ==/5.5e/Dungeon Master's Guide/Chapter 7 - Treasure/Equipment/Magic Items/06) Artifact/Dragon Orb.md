---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Dragon Orb [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/06) Artifact/Dragon Orb|(Priceless)]]
*Wondrous Item, Artifact*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** Yes

An orb is an etched crystal globe about 10 inches in diameter. When used, it grows to about 20 inches in diameter, and mist swirls inside it.

While attuned to an orb, you can take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action to peer into the orb’s depths. You must then make a DC 15 Charisma saving throw. On a successful save, you control the orb for as long as you remain attuned to it. On a failed save, the orb imposes the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Charmed]] condition on you for as long as you remain attuned to it.

While you are Charmed by the orb, you can’t voluntarily end your [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Attunement]] to it, and the orb casts *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Suggestion]]* on you at will (save DC 18), urging you to work toward the evil ends it desires. The dragon essence within the orb might want many things: the annihilation of a particular society or organization, freedom from the orb, to spread suffering in the world, to advance the worship of Tiamat, or something else the DM decides.

(The item is called the Orb of Dragonkind in the *Dungeon Master's Guide* which also includes additional information on using the Random Artifact Properties described in that book).

***Spells.*** The orb has 7 charges and regains 1d4 + 3 expended charges daily at dawn. If you control the orb, you can cast one of the spells on the following table from it. The table indicates how many charges you must expend to cast the spell.

| Spell                               | Charge Cost |
| ----------------------------------- | :---------: |
| *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Cure Wounds]]* (level 9 version) |      4      |
| *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Daylight]]*                      |      1      |
| *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Death Ward]]*                    |      2      |
| *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Detect Magic]]*                  |      0      |
| *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Scrying]]* (save DC 18)          |      3      |
***Call Dragons.*** While you control the orb, you can take a Magic action to cause the orb to issue a telepathic call that extends in all directions for 40 miles. Chromatic dragons in range feel compelled to come to the orb as soon as possible by the most direct route. Dragon deities such as Tiamat are unaffected by this call. Chromatic dragons drawn to the orb might be Hostile toward you for compelling them against their will. Once you have used this property, it can’t be used again for 1 hour.

***Destroying an Orb.*** A *Dragon Orb* has AC 20 and is destroyed if it takes damage from a *+3 Weapon* or a *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 6/Disintegrate]]* spell. Nothing else can harm it.
