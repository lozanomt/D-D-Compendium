---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Tactical Master

![[phb-p093-fighter.png|320]]

When you attack with a weapon whose mastery property you can use, you can replace that property with the [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Mastery/Push|Push]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Mastery/Sap|Sap]], or [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Mastery/Slow|Slow]] property for that attack.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=94|Player’s Handbook (2024), PDF page 94]]
