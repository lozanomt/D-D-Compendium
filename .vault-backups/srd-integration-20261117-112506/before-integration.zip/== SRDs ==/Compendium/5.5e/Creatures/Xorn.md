---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: e85c2bc8-e4f6-5647-9bca-0a2259233201
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Xorn
> 
> *Medium Elemental, Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p340-xorn.png|320]]
> 
> 
> **AC** 19 &emsp; **Initiative** +0 (10)  
> **HP** 84 (8d8 + 48)  
> **Speed** 20 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Burrowing|Burrow]] 20 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 10 | +0 | +0 | **Con** | 22 | +6 | +6 |
> | **Int** | 11 | +0 | +0 | **Wis** | 10 | +0 | +0 | **Cha** | 11 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6  
> **Immunities** Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Petrified|Petrified]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Tremorsense|Tremorsense]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages** Primordial (Terran)  
> **CR** 5 (XP 1,800; PB +3)  
> 
> ### Traits
> 
> ***Earth Glide.*** The xorn can burrow through nonmagical, unworked earth and stone. While doing so, the xorn doesn't disturb the material it moves through.
> 
> ***Treasure Sense.*** The xorn can pinpoint the location of precious metals and stones within 60 feet of itself.
> 
> ### Actions
> 
> ***Multiattack.*** The xorn makes one Bite attack and three Claw attacks.
> 
> ***Bite.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 17 (4d6 + 3) Piercing damage.
> 
> ***Claw.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 8 (1d10 + 3) Slashing damage.
> 
> ### Bonus Actions
> 
> ***Charge.*** The xorn moves up to its Speed or Burrow Speed straight toward an enemy it can sense.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
