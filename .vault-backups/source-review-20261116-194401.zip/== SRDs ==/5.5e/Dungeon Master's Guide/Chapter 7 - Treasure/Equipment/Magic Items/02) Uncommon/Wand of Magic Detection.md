---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Wand of Magic Detection [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Wand of Magic Detection|(400 GP)]]
*Wand, Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p323-wand-of-lightning-bolts.png|320]]


**Attunement:** No

This wand has 3 charges. While holding it, you can expend 1 charge to cast *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Detect Magic]]* from it. The wand regains 1d3 expended charges daily at dawn.
