---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 2c5a2094-d879-5645-8f32-9b20fbfd2b3e
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Guardian Naga
> 
> *Large Celestial, Lawful Good*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p163-guardian-naga.png|320]]
> 
> 
> **AC** 18 &emsp; **Initiative** +4 (14)  
> **HP** 136 (16d10 + 48)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 18 | +4 | +8 | **Con** | 16 | +3 | +7 |
> | **Int** | 16 | +3 | +7 | **Wis** | 19 | +4 | +8 | **Cha** | 18 | +4 | +8 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana|Arcana]] +11, [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]] +11, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Religion|Religion]] +11  
> **Immunities** Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Restrained|Restrained]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Celestial, Common  
> **CR** 10 (XP 5,900; PB +4)  
> 
> ### Traits
> 
> ***Celestial Restoration.*** If the naga dies, it returns to life in 1d6 days and regains all its Hit Points unless *Dispel Evil and Good* is cast on its remains.
> 
> ### Actions
> 
> ***Multiattack.*** The naga makes two Bite attacks. It can replace any attack with a use of Poisonous Spittle.
> 
> ***Bite.*** *Melee Attack Roll:* +8, reach 10 ft. *Hit:* 17 (2d12 + 4) Piercing damage plus 22 (4d10) Poison damage.
> 
> ***Poisonous Spittle.*** *Constitution Saving Throw:* DC 16, one creature the naga can see within 60 feet. *Failure:* 31 (7d8) Poison damage, and the target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Blinded|Blinded]] condition until the start of the naga's next turn. *Success:* Half damage only.
> 
> ***Spellcasting.*** The naga casts one of the following spells, requiring no Somatic or Material components and using Wisdom as the spellcasting ability (spell save DC 16):
> 
> - **At Will:** *Thaumaturgy*
> - **1/Day Each:** *Clairvoyance*, *Cure Wounds* (level 6 version), *Flame Strike* (level 6 version), *Geas*, *True Seeing*

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
