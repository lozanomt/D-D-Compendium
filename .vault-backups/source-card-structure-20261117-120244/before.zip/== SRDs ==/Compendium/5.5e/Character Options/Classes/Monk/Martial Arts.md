---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 4b8f7cf1-c528-5659-800c-001913068303
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [50]
---

# Martial Arts

![[== SRDs ==/Attachments/Artwork/phb-p103-monk.png|320]]

Your practice of martial arts gives you mastery of combat styles that use your Unarmed Strike and Monk weapons, which are the following:
- Simple Melee weapons
- Martial Melee weapons that have the [[== SRDs ==/Compendium/5.5e/Rules/Properties/Light|Light]] property
You gain the following benefits while you are unarmed or wielding only Monk weapons and you aren’t wearing armor or wielding a [[== SRDs ==/Compendium/5.5e/Items/Armor/Shield|Shield]].

***Bonus Unarmed Strike.*** You can make an [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]] as a Bonus Action.

***Martial Arts Die.*** You can roll 1d6 in place of the normal damage of your Unarmed Strike or Monk weapons. This die changes as you gain Monk levels, as shown in the Martial Arts column of the Monk Features table.

***Dexterous Attacks.*** You can use your Dexterity modifier instead of your Strength modifier for the attack and damage rolls of your Unarmed Strikes and Monk weapons. In addition, when you use the Grapple or Shove option of your Unarmed Strike, you can use your Dexterity modifier instead of your Strength modifier to determine the save DC.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=104|Player’s Handbook (2024), PDF page 104]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

Your practice of martial arts gives you mastery of combat styles that use your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]] and Monk weapons, which are the following:

• Simple Melee weapons

• Martial Melee weapons that have the Light property You gain the following benefits while you are unarmed or wielding only Monk weapons and you aren't wearing armor or wielding a [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield|Shield]].

Bonus [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]]. You can make an [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]] as a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bonus Action|Bonus Action]].

Martial Arts Die. You can roll 1d6 in place of the normal damage of your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]] or Monk weapons. This die changes as you gain Monk levels, as shown in the Martial Arts column of the Monk Features table.

Dexterous Attacks.  You can use your Dexterity modifier instead of your Strength modifier for the attack and damage rolls of your Unarmed Strikes and Monk weapons. In addition, when you use the Grapple or Shove option of your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]], you can use your Dexterity modifier instead of your Strength modifier to determine the save DC.

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=50|SRD 5.2.1, p. 50]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=50|SRD 5.2.1, p. 50]]
