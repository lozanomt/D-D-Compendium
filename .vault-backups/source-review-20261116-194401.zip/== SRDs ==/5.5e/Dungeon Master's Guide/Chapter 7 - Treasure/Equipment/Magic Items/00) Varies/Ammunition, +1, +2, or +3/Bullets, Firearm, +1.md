---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Bullets, Firearm, +1

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


#### Firearm Bullets, +1 [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Ammunition, +1, +2, or +3/Bullets, Firearm, +1|(210 GP)]]
*Weapon ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Ammunition/Bullets, Firearm|Firearm Bullets]]), Uncommon*

**Attunement:** No

You have a +1 bonus to attack rolls and damage rolls made with this piece of magic ammunition. Once it hits a target, the ammunition is no longer magical.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Ammunition/Bullets, Firearm|clean no-title]]
