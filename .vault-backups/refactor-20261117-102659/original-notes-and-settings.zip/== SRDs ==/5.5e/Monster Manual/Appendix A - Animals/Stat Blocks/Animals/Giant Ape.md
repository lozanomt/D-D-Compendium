---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Ape
> 
> *Huge Beast, Unaligned*
> 
> ![[mm-p356-giant-ape.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +5 (15)  
> **HP** 168 (16d12 + 64)  
> **Speed** 40 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 23 | +6 | +6 | **Dex** | 14 | +2 | +2 | **Con** | 18 | +4 | +4 |
> | **Int** | 5 | -3 | -3 | **Wis** | 12 | +1 | +1 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Athletics|Athletics]] +9, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Survival|Survival]] +4  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** None  
> **CR** 7 (XP 2,900; PB +3)  
> 
> ### Actions
> 
> ***Multiattack.*** The ape makes two Fist attacks.
> 
> ***Fist.*** *Melee Attack Roll:* +9, reach 10 ft. *Hit:* 22 (3d10 + 6) Bludgeoning damage.
> 
> ***Boulder Toss (Recharge 6).*** The ape hurls a boulder at a point it can see within 90 feet. *Dexterity Saving Throw:* DC 17, each creature in a 5-foot-radius Sphere centered on that point. *Failure:* 24 (7d6) Bludgeoning damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition. *Success:* Half damage only.
> 
> ### Bonus Actions
> 
> ***Leap.*** The ape jumps up to 30 feet by spending 10 feet of movement.
