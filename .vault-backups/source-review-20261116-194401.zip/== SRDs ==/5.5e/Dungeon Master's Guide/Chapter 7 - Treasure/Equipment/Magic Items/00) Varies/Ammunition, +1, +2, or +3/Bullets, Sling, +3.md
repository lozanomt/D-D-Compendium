---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Bullets, Sling, +3

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


#### Sling Bullets, +3 [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Ammunition, +1, +2, or +3/Bullets, Sling, +3|(200.04 GP)]]
*Weapon ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Ammunition/Bullets, Sling|Sling Bullets]]), Very Rare*

**Attunement:** No

You have a +3 bonus to attack rolls and damage rolls made with this piece of magic ammunition. Once it hits a target, the ammunition is no longer magical.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Ammunition/Bullets, Sling|clean no-title]]
