---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 63361669-25ad-5b36-bc74-39c79c09c854
entity_type: character-option
source_ids: ["phb-2024"]
---

# Mindless Rage

![[== SRDs ==/Attachments/Artwork/phb-p057-path-of-the-berserker.png|320]]

You have Immunity to the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]] and [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]] conditions while your Rage is active. If you’re Charmed or Frightened when you enter your Rage, the condition ends on you.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=57|Player’s Handbook (2024), PDF page 57]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
