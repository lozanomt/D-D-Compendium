---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Red Dragon Wyrmling
> 
> *Medium Dragon (Chromatic), Chaotic Evil*
> 
> ![[mm-p256-red-dragon-wyrmling.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +2 (12)  
> **HP** 75 (10d8 + 30)  
> **Speed** 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 10 | +0 | +2 | **Con** | 17 | +3 | +3 |
> | **Int** | 12 | +1 | +1 | **Wis** | 11 | +0 | +2 | **Cha** | 15 | +2 | +2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +2  
> **Immunities** Fire  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight|Blindsight]] 10 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Draconic  
> **CR** 4 (XP 1,100; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The dragon makes two Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 9 (1d10 + 4) Slashing damage plus 3 (1d6) Fire damage.
> 
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 13, each creature in a 15-foot Cone. *Failure:* 24 (7d6) Fire damage. *Success:* Half damage.
