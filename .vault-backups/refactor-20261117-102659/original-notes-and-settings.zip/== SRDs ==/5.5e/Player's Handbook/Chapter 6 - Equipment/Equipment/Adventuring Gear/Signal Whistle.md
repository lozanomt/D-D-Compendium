---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Signal Whistle [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Signal Whistle|(5 CP)]] 

![[Placeholder.png|320]]

When blown as a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]] action, a Signal Whistle produces a sound that can be heard up to 600 feet away.

**Weight:** -
