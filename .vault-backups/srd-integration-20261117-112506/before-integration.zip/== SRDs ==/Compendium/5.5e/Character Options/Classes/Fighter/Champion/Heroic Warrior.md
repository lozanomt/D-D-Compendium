---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: beacc705-1660-5897-8e4b-17f06fe79074
entity_type: character-option
source_ids: ["phb-2024"]
---

# Heroic Warrior

![[== SRDs ==/Attachments/Artwork/phb-p099-champion.png|320]]

The thrill of battle drives you toward victory. During combat, you can give yourself [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Heroic Inspiration|Heroic Inspiration]] whenever you start your turn without it.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=99|Player’s Handbook (2024), PDF page 99]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
