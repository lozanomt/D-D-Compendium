---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Falling Net
*Nuisance Trap (Levels 1 - 4)*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Trigger:** A creature crosses a trip wire
**Duration:** Instantaneous

A falling net trap uses a trip wire to release a weighted, 10-foot-square [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Net]] suspended from the ceiling. The trip wire is 3 inches off the ground and stretches between two columns or trees.

The first creature that crosses the trip wire causes the Net to fall on it. The target must succeed on a DC 10 Dexterity saving throw or have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained]] condition until it escapes. The target succeeds automatically if it’s Huge or larger. A creature can take an action to make a DC 10 Strength ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Athletics]]) check, freeing itself or another creature within its reach from the Net on a successful check.

***Detect and Disarm.*** As a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Search]] action, a creature can examine the trapped area and make a DC 11 Wisdom ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]]) check, detecting the trip wire and the suspended Net on a successful check. Once detected, the trip wire can be easily cut or avoided (no ability check required).

***Destroy the Net.*** Reducing the Net to 0 [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]] frees any creature trapped in it.

***Set the Trap.*** A creature that has [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Thieves' Tools]] and all the trap’s components (including a Net) can try to set a falling net trap, doing so with a successful DC 13 Dexterity ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Sleight of Hand]]) check. Each attempt to set this trap takes 10 minutes.

***At Higher Levels.*** You can scale the trap for higher levels by increasing the weight of the Net, which increases the save DC and the DC of the Strength (Athletics) check as follows: DC 12 at levels 5–10, DC
14 at levels 11–16, or DC 16 at levels 17–20.
