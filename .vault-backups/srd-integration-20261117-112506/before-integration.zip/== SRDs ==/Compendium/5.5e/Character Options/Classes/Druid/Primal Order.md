---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 01218ad6-b7df-5b3c-9a92-adcd86614265
entity_type: character-option
source_ids: ["phb-2024"]
---

# Primal Order

![[== SRDs ==/Attachments/Artwork/phb-p081-druid.png|320]]

You have dedicated yourself to one of the following sacred roles of your choice.

***Magician.*** You know one extra cantrip from the Druid spell list. In addition, your mystical connection to nature gives you a bonus to your Intelligence ([[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana|Arcana]] or [[== SRDs ==/Compendium/5.5e/Rules/Skills/Nature|Nature]]) checks. The bonus equals your Wisdom modifier (minimum bonus of +1).

***Warden.*** Trained for battle, you gain proficiency with Martial weapons and training with Medium armor.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=82|Player’s Handbook (2024), PDF page 82]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
