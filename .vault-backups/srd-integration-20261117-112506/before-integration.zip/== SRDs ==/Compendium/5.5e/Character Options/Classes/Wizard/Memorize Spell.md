---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 6ed47139-4f63-535a-91b0-9674b22b5f67
entity_type: character-option
source_ids: ["phb-2024"]
---

# Memorize Spell

![[== SRDs ==/Attachments/Artwork/phb-p167-wizard.png|320]]

Whenever you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short Rest]], you can study your spellbook and replace one of the level 1+ Wizard spells you have prepared for your Spellcasting feature with another level 1+ spell from the book.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=168|Player’s Handbook (2024), PDF page 168]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
