---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Scale Mail, +2 [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Armor, +1, +2, or +3/Scale Mail, +2|(40,050 GP)]]
*Armor ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Scale Mail|Scale Mail]]), Very Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/phb-p221-scale-mail.png|320]]


**Attunement** No

You have a +2 bonus to Armor Class while wearing this armor.

---
![[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Scale Mail|clean no-title]]
