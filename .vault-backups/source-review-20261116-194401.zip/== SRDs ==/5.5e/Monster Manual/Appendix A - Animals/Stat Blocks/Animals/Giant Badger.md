---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Badger
> 
> *Medium Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/Monster Manual/Artwork/phb-p353-giant-badger.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +0 (10)  
> **HP** 15 (2d8 + 6)  
> **Speed** 30 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Burrowing|Burrow]] 10 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 10 | +0 | +0 | **Con** | 17 | +3 | +3 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 5 | -3 | -3 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +3  
> **Resistances** Poison  
> **Senses** [[Darkvision]] 60 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 13  
> **Languages** None  
> **CR** 1/4 (XP 50; PB +2)  
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +3, reach 5 ft. *Hit:* 6 (2d4 + 1) Piercing damage.
