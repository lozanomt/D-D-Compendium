---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Helm of Comprehending Languages [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Helm of Comprehending Languages|(400 GP)]]
*Wondrous Item, Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p271-headband-of-intellect.png|320]]


**Attunement:** No

While wearing this helm, you can cast *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Comprehend Languages]]* from it.
