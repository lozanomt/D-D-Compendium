---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: cd4a5d00-da98-59b9-b62c-01617a370413
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Giant Vulture
> 
> *Large Monstrosity, Neutral Evil*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 10 &emsp; **Initiative** +0 (10)  
> **HP** 25 (3d10 + 9)  
> **Speed** 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 10 | +0 | +0 | **Con** | 16 | +3 | +3 |
> | **Int** | 6 | -2 | -2 | **Wis** | 12 | +1 | +1 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +3  
> **Resistances** Necrotic  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** Understands Common but can't speak  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Traits
> 
> ***Pack Tactics.*** The vulture has Advantage on an attack roll against a creature if at least one of the vulture's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> 
> ### Actions
> 
> ***Gouge.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 9 (2d6 + 2) Piercing damage, and the target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]] condition until the end of its next turn.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
