---
tags: [creature, phb]
cssclasses: [dnd-book, dnd-mm]
source_book: "Player's Handbook (2024)"
source_page: 348
source_pdf_page: 351
review_status: checked-against-page-image
reviewed: 2026-11-17
---

> [!statblock]
> ## Crab
>
> *Tiny Beast, Unaligned*
>
> **AC** 11 &emsp; **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]]** +0 (10)  
> **HP** 3 (1d4 + 1)  
> **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]]** 20 ft., Swim 20 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 6 | -2 | -2 | **Dex** | 11 | +0 | +0 | **Con** | 12 | +1 | +1 |
> | **Int** | 1 | -5 | -5 | **Wis** | 8 | -1 | -1 | **Cha** | 2 | -4 | -4 |
>
> **Skills** Stealth +2  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight|Blindsight]] 30 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
>
> ### Traits
>
> ***Amphibious.*** The crab can breathe air and water.
>
> ### Actions
>
> ***Claw.*** *Melee [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] Roll:* +2, reach 5 ft. *Hit:* 1 Bludgeoning damage.

Source: [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=351|Player’s Handbook (2024), p. 348]].

[[== SRDs ==/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/5.5e/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Crab|Monster Manual version]]
