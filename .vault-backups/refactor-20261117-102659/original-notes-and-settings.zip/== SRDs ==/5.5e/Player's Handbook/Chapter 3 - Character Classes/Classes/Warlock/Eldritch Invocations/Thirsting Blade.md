---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Thirsting Blade
*Prerequisite: Level 5+ Warlock, [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Pact of the Blade|Pact of the Blade]] Invocation*

![[phb-p155-warlock.png|320]]


You gain the [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Extra Attack|Extra Attack]] feature for your pact weapon only. With that feature, you can attack twice with the weapon instead of once when you take the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] action on your turn.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=156|Player’s Handbook (2024), PDF page 156]]
