---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: d46374fb-9d87-5fa8-8f49-1d667944bb04
entity_type: character-option
source_ids: ["phb-2024"]
---

# Primal Knowledge

![[== SRDs ==/Attachments/Artwork/phb-p053-barbarian.png|320]]

You gain proficiency in another skill of your choice from the skill list available to Barbarians at level 1.

In addition, while your Rage is active, you can channel primal power when you attempt certain tasks; whenever you make an ability check using one of the following skills, you can make it as a Strength check even if it normally uses a different ability: [[== SRDs ==/Compendium/5.5e/Rules/Skills/Acrobatics|Acrobatics]], [[== SRDs ==/Compendium/5.5e/Rules/Skills/Intimidation|Intimidation]], [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]], [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]], or [[== SRDs ==/Compendium/5.5e/Rules/Skills/Survival|Survival]]. When you use this ability, your Strength represents primal power coursing through you, honing your agility, bearing, and senses.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=54|Player’s Handbook (2024), PDF page 54]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
