---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Copper Dragon Wyrmling
> 
> *Medium Dragon (Metallic), Chaotic Good*
> 
> ![[mm-p080-copper-dragon-wyrmling.png|320]]
> 
> 
> **AC** 16 &emsp; **Initiative** +3 (13)  
> **HP** 22 (4d8 + 4)  
> **Speed** 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 12 | +1 | +3 | **Con** | 13 | +1 | +1 |
> | **Int** | 14 | +2 | +2 | **Wis** | 11 | +0 | +2 | **Cha** | 13 | +1 | +1 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +3  
> **Immunities** Acid  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight|Blindsight]] 10 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Draconic  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Actions
> 
> ***Rend.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (1d10 + 2) Slashing damage.
> 
> ***Acid Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 11, each creature in a 20-foot-long, 5-footwide Line. *Failure:* 18 (4d8) Acid damage. *Success:* Half damage.
> 
> ***Slowing Breath.*** *Constitution Saving Throw:* DC 11, each creature in a 15-foot Cone. *Failure:* The target can't take Reactions; its Speed is halved; and it can take either an action or a Bonus Action on its turn, not both. This effect lasts until the end of its next turn.
