---
tags:
  - lore
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 55713ee4-4ceb-52c9-899f-57b5532d4214
entity_type: lore
source_ids: ["dmg-2024"]
---

# The Ethereal Plane

![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]


Text

## Source References

- [[== SRDs ==/Sources/5.5e/Dungeon Master's Guide/Chapter 6 - Cosmology/Chapter 6 - Cosmology|Dungeon Master's Guide — Chapter 6 - Cosmology]]
