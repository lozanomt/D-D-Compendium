---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Passive Perception

![[Placeholder.png|320]]


Passive Perception is a score that reflects a creature’s general awareness of its surroundings. The DM uses this score when determining whether a creature notices something without consciously making a Wisdom ([[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]]) check.

A creature’s Passive Perception equals 10 plus the creature’s Wisdom (Perception) check bonus. If the creature has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on such checks, increase the score by 5. If the creature has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on them, decrease the score by 5. For example, a level 1 character with a Wisdom of 15 and proficiency in Perception has a Passive Perception of 14 (10 + 2 + 2). If that character has Advantage on Wisdom (Perception) checks, the score becomes 19.
