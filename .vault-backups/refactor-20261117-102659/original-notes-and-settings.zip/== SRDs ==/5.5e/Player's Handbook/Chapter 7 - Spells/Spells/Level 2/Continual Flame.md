---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Continual Flame
*Level 2 Evocation (Cleric, Druid, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (ruby dust worth 50+ GP, which the spell consumes)
**Duration:** Until dispelled

A flame springs from an object that you touch. The effect casts [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Bright Light|Bright Light]] in a 20-foot radius and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Dim Light|Dim Light]] for an additional 20 feet. It looks like a regular flame, but it creates no heat and consumes no fuel. The flame can be covered or hidden but not smothered or quenched.
