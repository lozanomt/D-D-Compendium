---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Chain Shirt [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Chain Shirt|(50 GP)]]
*Medium Armor (5 Minutes to Don and 1 Minute to Doff)*

![[== SRDs ==/Attachments/Artwork/phb-p221-chain-shirt.png|320]]


**Stealth:** - **Weight:** 20 lb.
**Armor Class (AC):** 13 + Dex modifier (Max 2)
**Strength:** -
