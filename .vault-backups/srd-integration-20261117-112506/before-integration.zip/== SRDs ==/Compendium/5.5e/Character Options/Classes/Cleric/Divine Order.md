---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 34c13d7a-9f41-5095-bef4-10e11654757b
entity_type: character-option
source_ids: ["phb-2024"]
---

# Divine Order

![[== SRDs ==/Attachments/Artwork/phb-p071-cleric.png|320]]

You have dedicated yourself to one of the following sacred roles of your choice.

***Protector.*** Trained for battle, you gain proficiency with Martial weapons and training with Heavy armor.

***Thaumaturge.*** You know one extra cantrip from the Cleric spell list. In addition, your mystical connection to the divine gives you a bonus to your Intelligence ([[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana|Arcana]] or [[== SRDs ==/Compendium/5.5e/Rules/Skills/Religion|Religion]]) checks. The bonus equals your Wisdom modifier (minimum of +1).

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=72|Player’s Handbook (2024), PDF page 72]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
