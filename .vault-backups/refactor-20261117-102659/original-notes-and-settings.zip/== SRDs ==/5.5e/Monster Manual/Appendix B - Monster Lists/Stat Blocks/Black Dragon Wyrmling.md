---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Black Dragon Wyrmling
> 
> *Medium Dragon (Chromatic), Chaotic Evil*
> 
> ![[mm-p040-black-dragon-wyrmling.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +4 (14)  
> **HP** 33 (6d8 + 6)  
> **Speed** 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 60 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 14 | +2 | +4 | **Con** | 13 | +1 | +1 |
> | **Int** | 10 | +0 | +0 | **Wis** | 11 | +0 | +2 | **Cha** | 13 | +1 | +1 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +4  
> **Immunities** Acid  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight|Blindsight]] 10 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Draconic  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Amphibious.*** The dragon can breathe air and water.
> 
> ### Actions
> 
> ***Multiattack.*** The dragon makes two Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Slashing damage plus 2 (1d4) Acid damage.
> 
> ***Acid Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 11, each creature in a 15-foot-long, 5-footwide Line. *Failure:* 22 (5d8) Acid damage. *Success:* Half damage.
