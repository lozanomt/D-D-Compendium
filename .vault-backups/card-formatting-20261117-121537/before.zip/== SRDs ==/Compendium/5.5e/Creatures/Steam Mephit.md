---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 43e9df3b-6222-5f7f-b138-9622106fae05
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [308]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Steam Mephit

## Monster Manual


> [!statblock]
> ### Steam Mephit
>
> *Small Elemental, Neutral Evil*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC:** 10 &emsp;  
> **Initiative:** +0 (10)  
> **HP:** 17 (5d6)  
> **Speed:** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 5 | -3 | -3 | **Dex** | 11 | +0 | +0 | **Con** | 10 | +0 | +0 |
> | **Int** | 11 | +0 | +0 | **Wis** | 10 | +0 | +0 | **Cha** | 12 | +1 | +1 |
>
> **Skills:**  
> **Stealth:** +2  
> **Immunities:** Fire, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages:** Primordial (Aquan, Ignan)  
> **CR:** 1/4 (XP 50; PB +2)  
>
> #### Traits
>
> ***Blurred Form.*** Attack rolls against the mephit are made with Disadvantage unless the mephit has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
>
> ***Death Burst.*** The mephit explodes when it dies. *Dexterity Saving Throw:* DC 10, each creature in a 5-foot Emanation originating from the mephit. *Failure:* 5 (2d4) Fire damage. *Success:* Half damage.
>
> #### Actions
>
> ***Claw.*** *Melee Attack Roll:* +2, reach 5 ft. *Hit:* 2 (1d4) Slashing damage plus 2 (1d4) Fire damage.
>
> ***Steam Breath (Recharge 6).*** *Constitution Saving Throw:* DC 10, each creature in a 15-foot Cone. *Failure:* 5 (2d4) Fire damage, and the target's Speed decreases by 10 feet until the end of the mephit's next turn. *Success:* Half damage only. *Failure or Success:* Being underwater doesn't grant Resistance to this Fire damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Steam Mephit
>
> *Small Elemental, Neutral Evil*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC:** 10 &emsp;  
> **Initiative:** +0 (10)  
> **HP:** 17 (5d6)  
> **Speed:** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 5 | -3 | -3 | **Dex** | 11 | +0 | +0 | **Con** | 10 | +0 | +0 |
> | **Int** | 11 | +0 | +0 | **Wis** | 10 | +0 | +0 | **Cha** | 12 | +1 | +1 |
>
> **Skills:**  
> **Stealth:** +2  
> **Immunities:** Fire, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages:** Primordial (Aquan, Ignan)  
> **CR:** 1/4 (XP 50; PB +2)  
>
> #### Traits
>
> ***Blurred Form.*** Attack rolls against the mephit are made with Disadvantage unless the mephit has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
>
> ***Death Burst.*** The mephit explodes when it dies. *Dexterity Saving Throw:* DC 10, each creature in a 5-foot Emanation originating from the mephit. *Failure:* 5 (2d4) Fire damage. *Success:* Half damage.
>
> #### Actions
>
> ***Claw.*** *Melee Attack Roll:* +2, reach 5 ft. *Hit:* 2 (1d4) Slashing damage plus 2 (1d4) Fire damage.
>
> ***Steam Breath (Recharge 6).*** *Constitution Saving Throw:* DC 10, each creature in a 15-foot Cone. *Failure:* 5 (2d4) Fire damage, and the target's Speed decreases by 10 feet until the end of the mephit's next turn. *Success:* Half damage only. *Failure or Success:* Being underwater doesn't grant Resistance to this Fire damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=308|SRD 5.2.1, p. 308]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
