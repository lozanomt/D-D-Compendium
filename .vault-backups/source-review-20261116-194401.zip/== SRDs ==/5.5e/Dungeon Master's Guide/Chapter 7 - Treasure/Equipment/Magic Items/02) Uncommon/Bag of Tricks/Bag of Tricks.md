---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Bag of Tricks [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Bag of Tricks/Bag of Tricks|(400 GP)]]
*Wondrous Item, Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p238-bag-of-tricks.png|320]]


**Attunement:** No

This bag made from gray, rust, or tan cloth appears empty. Reaching inside the bag, however, reveals the presence of a small, fuzzy object.

You can take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action to pull the fuzzy object from the bag and throw it up to 20 feet. When the object lands, it transforms into a creature you determine by rolling on the table that corresponds to the bag’s color. The creature vanishes at the next dawn or when it is reduced to 0 [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]].

The creature is Friendly to you and your allies, and it acts immediately after you on your [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative]] count. You can take a Bonus Action to command how the creature moves and what action it takes on its next turn, such as attacking an enemy. In the absence of such orders, the creature acts in a fashion appropriate to its nature.

Once three fuzzy objects have been pulled from the bag, the bag can’t be used again until the next dawn.
###### Bag of Tricks
| 1d8 | Gray             | Rust           | Tan              |
| :-: | ---------------- | -------------- | ---------------- |
|  1  | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Weasel]]       | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Rat]]        | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Jackal]]       |
|  2  | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Giant Rat]]    | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Owl]]        | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Ape]]          |
|  3  | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Badger]]       | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Mastiff]]    | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Baboon]]       |
|  4  | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Boar]]         | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Goat]]       | [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Axe Beak]]     |
|  5  | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Panther]]      | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Giant Goat]] | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Black Bear]]   |
|  6  | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Giant Badger]] | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Giant Boar]] | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Giant Weasel]] |
|  7  | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Dire Wolf]]    | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Lion]]       | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Giant Hyena]]  |
|  8  | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Giant Elk]]    | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Brown Bear]] | [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Tiger]]        |
