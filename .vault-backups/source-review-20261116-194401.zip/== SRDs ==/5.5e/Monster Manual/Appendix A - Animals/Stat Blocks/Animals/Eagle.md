---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Eagle
> 
> *Small Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 4 (1d6 + 1)  
> **Speed** 10 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 6 | -2 | -2 | **Dex** | 15 | +2 | +2 | **Con** | 12 | +1 | +1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 14 | +2 | +2 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +6  
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 16  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Actions
> 
> ***Talons.*** *Melee Attack Roll:* +4, reach 5 feet. *Hit:* 4 (1d4 + 2) Slashing damage.
