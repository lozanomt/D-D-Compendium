---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 9cba2fcf-1602-5b2b-bd42-eb02c91fd984
entity_type: character-option
source_ids: ["phb-2024"]
---

# Feral Instinct

![[== SRDs ==/Attachments/Artwork/phb-p053-barbarian.png|320]]

Your instincts are so honed that you have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]] rolls.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=54|Player’s Handbook (2024), PDF page 54]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
