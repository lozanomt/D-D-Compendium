---
tags:
  - condition
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Petrified

![[Placeholder.png|320]]


While you have the Petrified condition, you experience the following effects.

***Turned to Inanimate Substance.*** You are transformed, along with any nonmagical obejcts you are wearing and carrying, into a solid inanimate substance (usually stone). Your weight increases by a factor of ten, and you cease aging.

***Incapacitated.*** You have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition.

***Speed 0.*** Your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]] is 0 and can't increase.

***Attacks Affected.*** Attack rolls against you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]].

***Saving Throws Affected.*** You automatically fail Strength and Dexterity saving throws.

***Resist Damage.*** You have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to all damage.

***Poison Immunity.*** You have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Immunity|Immunity]] to the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]] condition.
