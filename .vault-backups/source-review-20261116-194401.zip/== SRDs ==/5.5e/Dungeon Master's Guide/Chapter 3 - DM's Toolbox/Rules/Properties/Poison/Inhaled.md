---
tags:
  - weaponproperty
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Inhaled

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


Poisonous powders and gases take effect when inhaled. Blowing the powder or releasing the gas subjects creatures in a 5-foot [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Cube]] to its effect. The resulting cloud dissipates immediately afterward. Holding one’s breath is ineffective against inhaled poisons, as they affect nasal membranes, tear ducts, and other parts of the body.
