---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Sight Rot
*Magical Contagion*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


Any Beast or Humanoid that drinks water tainted by Sight Rot must succeed on a DC 15 Constitution saving throw or have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded]] condition until the contagion ends.

***Fighting the Contagion.*** Magic such as a *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 6/Heal]]* or *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Lesser Restoration]]* spell ends the contagion immediately. A character who is proficient with an [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Herbalism Kit]] can use it to create one dose of nonmagical ointment, which takes 1 hour. When applied to the eyes of a creature suffering from Sight Rot, the ointment suppresses the contagion on that creature for 24 hours. If the contagion is suppressed in this way for a total of 72 hours (requiring three doses and applications of the ointment), the contagion ends on the creature.

***Spreading the Contagion.*** Any Humanoid that makes skin contact with a creature infected with Sight Rot must succeed on a DC 15 Constitution saving throw or also become infected with the contagion. On a successful save, the Humanoid can’t catch the contagion from that particular infected creature for the next 24 hours.
