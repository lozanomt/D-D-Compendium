---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 7db82384-493e-51fb-9c9b-1379696365d8
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [266]
---

> [!statblock]
> ## Blink Dog
> 
> *Medium Fey, Lawful Good*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p048-blink-dog.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +3 (13)  
> **HP** 22 (4d8 + 4)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 12 | +1 | +1 | **Dex** | 17 | +3 | +3 | **Con** | 12 | +1 | +1 |
> | **Int** | 10 | +0 | +0 | **Wis** | 13 | +1 | +1 | **Cha** | 11 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +5  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** Blink Dog; understands Elvish and Sylvan but can't speak them  
> **CR** 1/4 (XP 50; PB +2)  
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 5 (1d4 + 3) Piercing damage.
> 
> ### Bonus Actions
> 
> ***Teleport (Recharge 4-6).*** The dog teleports up to 40 feet to an unoccupied space it can see.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=266|SRD 5.2.1, p. 266]] — matches the existing entry.
