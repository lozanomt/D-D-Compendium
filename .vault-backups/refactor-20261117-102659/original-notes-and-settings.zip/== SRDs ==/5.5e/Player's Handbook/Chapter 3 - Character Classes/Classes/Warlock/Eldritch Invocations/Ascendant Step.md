---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Ascendant Step
*Prerequisite: Level 5+ Warlock*

![[phb-p155-warlock.png|320]]


You can cast *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Levitate|Levitate]]* on yourself without expending a spell slot.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=156|Player’s Handbook (2024), PDF page 156]]
