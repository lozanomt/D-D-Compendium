---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Dead

![[Placeholder.png|320]]


A dead creature has no [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]] and can’t regain them unless it is first revived by magic such as the *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Raise Dead|Raise Dead]]* or *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Revivify|Revivify]]* spell. When such a spell is cast, the spirit knows who is casting it and can refuse. The spirit of a dead creature has left the body and departed for the Outer Planes, and reviving the creature requires calling the spirit back.

If the creature returns to life, the revival effect determines the creature’s current Hit Points. Unless otherwise stated, the creature returns to life with any conditions, magical contagions, or [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Rules/Common Terms/Curses|curses]] that were affecting it at death if the durations of those effects are still ongoing. If the creature died with any [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]] levels, it returns with 1 fewer level. If the creature had [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Attunement|Attunement]] to one or more magic items, it is no longer attuned to them.
