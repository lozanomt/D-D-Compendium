---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Druidic Focus [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Druidic Focus/Druidic Focus|(Varies)]] 

![[Placeholder.png|320]]

**Class:** Druid, Ranger **Weight:** Varies
**Variants:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Druidic Focus/Sprig of Mistletoe|Sprig of Mistletoe]] (1 GP), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Druidic Focus/Wooden Staff|Wooden Staff]] (5 GP, 4 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Druidic Focus/Yew Wand|Yew Wand]] (10 GP, 1 lb.)
