---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [324]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Wand of Paralysis
*Wand, Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p323-wand-of-lightning-bolts.png|320]]

**Attunement:** Yes, by a spellcaster

The [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Arcane Focus/Wand|wand]] has 7 charges. While holding it, take a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action and expend 1 charge to target a creature you can see within 60 feet. The target must succeed on a DC 15 Constitution saving throw or have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Paralyzed|Paralyzed]] condition for 1 minute. It repeats the save at the end of each of its turns, ending the effect on itself on a success.

The wand regains 1d6 + 1 expended charges daily at dawn. If you expend its last charge, roll 1d20; on a 1, the wand crumbles into ashes and is destroyed.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=324|p. 321 (PDF page 324)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
