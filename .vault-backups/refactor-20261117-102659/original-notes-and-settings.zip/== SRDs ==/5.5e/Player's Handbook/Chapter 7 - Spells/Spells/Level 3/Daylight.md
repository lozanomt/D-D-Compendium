---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Daylight
*Level 3 Evocation (Cleric, Druid, Paladin, Ranger, Sorcerer)*

![[phb-p263-daylight.png|320]]


**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** 1 hour

For the duration, sunlight spreads from a point within range and fills a 60-foot-radius [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Sphere|Sphere]]. The sunlight's area is [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Bright Light|Bright Light]] and sheds [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Dim Light|Dim Light]] for an additional 60 feet.

Alternatively, you cast the spell on an object that isn't being worn or carried, causing the sunlight to fill a 60-foot [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Emanation|Emanation]] originating from that object. Covering that object with something opaque, such as a bowl or helm, blocks the sunlight.

If any of this spell's area overlaps with an area of [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Darkness|Darkness]] created by a spell of level 3 or lower, that other spell is dispelled.
