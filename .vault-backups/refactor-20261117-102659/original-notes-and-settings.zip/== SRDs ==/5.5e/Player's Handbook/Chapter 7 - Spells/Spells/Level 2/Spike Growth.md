---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Spike Growth
*Level 2 Transmutation (Druid, Ranger)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (seven thorns)
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 10 minutes

The ground in a 20-foot-radius [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Sphere|Sphere]] centered on a point within range sprouts hard spikes and thorns. The area becomes [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Difficult Terrain|Difficult Terrain]] for the duration. When a creature moves into or within the area, it takes 2d4 Piercing damage for every 5 feet it travels.

The transformation of the ground is camouflaged to look natural. Any creature that can't see the area when the spell is cast must take a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Search|Search]] action and succeed on a Wisdom ([[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] or [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Survival|Survival]]) check against your spell save DC to recognize the terrain as hazardous before entering it.
