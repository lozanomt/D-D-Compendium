---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Belt of Cloud Giant Strength [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Belt of Giant Strength/Belt of Cloud Giant Strength|(200,000 GP)]]
*Wondrous Item, Legendary*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p239-belt-of-giant-strength.png|320]]


**Attunement:** Yes

While wearing this belt, your Strength score changes to 27. The item has no effect on you if your Strength without the belt is equal to or greater than the belt’s score.
