---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Studied Attacks

![[phb-p093-fighter.png|320]]

You study your opponents and learn from each attack you make. If you make an attack roll against a creature and miss, you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on your next attack roll against that creature before the end of your next turn.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=94|Player’s Handbook (2024), PDF page 94]]
