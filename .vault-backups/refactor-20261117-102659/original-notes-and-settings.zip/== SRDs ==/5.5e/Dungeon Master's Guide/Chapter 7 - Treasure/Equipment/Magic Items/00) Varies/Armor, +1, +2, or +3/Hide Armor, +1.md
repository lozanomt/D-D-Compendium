---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Hide Armor, +1 [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Armor, +1, +2, or +3/Hide Armor, +1|(4,010 GP)]]
*Armor ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Hide Armor|Hide Armor]]), Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/phb-p221-hide-armor.png|320]]


**Attunement** No

You have a +1 bonus to Armor Class while wearing this armor.

---
![[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Hide Armor|clean no-title]]
