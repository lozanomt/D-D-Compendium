---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Lion
> 
> *Large Beast, Unaligned*
> 
> ![[mm-p366-lion.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 22 (4d10)  
> **Speed** 50 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 15 | +2 | +2 | **Con** | 11 | +0 | +0 |
> | **Int** | 3 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +3, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +4  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** None  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Traits
> 
> ***Pack Tactics.*** The lion has Advantage on an attack roll against a creature if at least one of the lion's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> 
> ***Running Leap.*** With a 10-foot running start, the lion can Long Jump up to 25 feet.
> 
> ### Actions
> 
> ***Multiattack.*** The lion makes two Rend attacks. It can replace one attack with a use of Roar.
> 
> ***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Slashing damage.
> 
> ***Roar.*** *Wisdom Saving Throw:* DC 11, one creature within 15 feet. *Failure:* The target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Frightened|Frightened]] condition until the start of the lion's next turn.
