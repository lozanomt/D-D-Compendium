---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Purify Food and Drink
*Level 1 Transmutation (Cleric, Druid, Paladin)*

![[Placeholder.png|320]]


**Casting Time:** Action or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Ritual|Ritual]]
**Range:** 10 feet
**Components:** V, S
**Duration:** Instantaneous

You remove poison and rot from nonmagical food and drink in a 5-foot-radius [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Sphere|Sphere]] centered on a point within range.
