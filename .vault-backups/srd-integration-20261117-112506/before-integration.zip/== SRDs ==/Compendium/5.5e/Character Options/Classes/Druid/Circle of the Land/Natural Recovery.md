---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 06c67fd7-8495-5317-bb65-148ad7bcaaab
entity_type: character-option
source_ids: ["phb-2024"]
---

# Natural Recovery

![[== SRDs ==/Attachments/Artwork/phb-p088-circle-of-the-land.png|320]]

You can cast one of the level 1+ spells that you have prepared from your Circle Spells feature without expending a spell slot, and you must finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]] before you do so again.

In addition, when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short Rest]], you can choose expended spell slots to recover. The spell slots can have a combined level that is equal to or less than half your Druid level (round up), and none of them can be level 6+. Once you recover spell slots with this feature, you can’t do so again until you finish a Long Rest.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=87|Player’s Handbook (2024), PDF page 87]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=88|Player’s Handbook (2024), PDF page 88]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=89|Player’s Handbook (2024), PDF page 89]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
