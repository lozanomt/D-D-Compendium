---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Faithful Steed

![[phb-p111-paladin.png|320]]

You can call on the aid of an otherworldly steed. You always have the *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Find Steed|Find Steed]]* spell prepared. You can also cast the spell once without expending a spell slot, and you regain the ability to do so when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=112|Player’s Handbook (2024), PDF page 112]]
