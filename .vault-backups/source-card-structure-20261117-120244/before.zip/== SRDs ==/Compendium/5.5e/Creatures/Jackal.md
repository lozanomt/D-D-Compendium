---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 266ad00d-4d21-5d20-b8d0-69ddc7696670
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [356]
---

> [!statblock]
> ## Jackal
> 
> *Small Beast, Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 3 (1d6)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 8 | -1 | -1 | **Dex** | 15 | +2 | +2 | **Con** | 11 | +0 | +0 |
> | **Int** | 3 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 6 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +4  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 90 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +1, reach 5 ft. *Hit:* 1 (1d4 - 1) Piercing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=356|SRD 5.2.1, p. 356]] — matches the existing entry.
