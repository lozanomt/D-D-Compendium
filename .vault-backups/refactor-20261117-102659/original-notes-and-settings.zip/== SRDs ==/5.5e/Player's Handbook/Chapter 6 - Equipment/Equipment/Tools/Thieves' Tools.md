---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Thieves' Tools [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Thieves' Tools|(25 GP)]]

![[Placeholder.png|320]]

**Ability:** Dexterity **Weight:** 1 lb.
[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]]: Pick a lock (DC 15), or disarm a trap (DC 15)
