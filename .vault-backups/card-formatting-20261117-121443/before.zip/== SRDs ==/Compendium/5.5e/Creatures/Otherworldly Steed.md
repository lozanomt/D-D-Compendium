---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: b93ceaf1-f329-5b4a-b702-7dc74239e3b2
entity_type: creature
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [131]
source_versions: ["Player's Handbook", "SRD 5.2.1"]
---

# Otherworldly Steed

## Player's Handbook

> [!statblock]
> ### Otherworldly Steed
> *Large Celestial, Fey, or Fiend (Your Choice), Neutral*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC** 10 + 1 per spell level  
> **HP** 5 + 10 per spell level (the steed has a number of Hit Dice (d10s) equal to the spell's level)  
> **Speed** 60 ft. [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft. (requires level 4+ spell)  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 12 | +1 | +1 | **Con** | 14 | +2 | +2 |
> | **Int** | 6 | -2 | -2 | **Wis** | 12 | +1 | +1 | **Cha** | 8 | -1 | -1 |
>
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** Telepathy 1 mile (works only with you)  
> **CR** None (XP 0; PB equals your Proficiency Bonus)  
>
> ### Traits
> ***Life Bond.*** When you regain Hit Points from a level 1+ spell, the steed regains the same number of Hit Points if you’re within 5 feet of it.
> ### Actions
> ***Otherworldly Slam.*** Melee Attack Roll: Bonus equals your spell attack modifier, reach 5 ft. Hit: 1d8 plus the spell’s level of Radiant (Celestial), Psychic (Fey), or Necrotic (Fiend) damage.
> ### Bonus Actions
> ***Fell Glare (Fiend Only; Recharges after a Long Rest).*** Wisdom Saving Throw: DC equals your spell save DC, one creature within 60 feet the steed can see. Failure: The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]] condition until the end of your next turn.
>
> ***Fey Step (Fey Only; Recharges after a Long Rest).*** The steed teleports, along with its rider, to an unoccupied space of your choice up to 60 feet away from itself.
>
> ***Healing Touch (Celestial Only; Recharges after a Long Rest).*** One creature within 5 feet of the steed regains a number of Hit Points equal to 2d8 plus the spell’s level.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf|Player's Handbook]]

## SRD 5.2.1

> [!statblock]
> ### Otherworldly Steed
> *Large Celestial, Fey, or Fiend (Your Choice), Neutral*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC** 10 + 1 per spell level  
> **HP** 5 + 10 per spell level (the steed has a number of Hit Dice (d10s) equal to the spell's level)  
> **Speed** 60 ft. [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft. (requires level 4+ spell)  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 12 | +1 | +1 | **Con** | 14 | +2 | +2 |
> | **Int** | 6 | -2 | -2 | **Wis** | 12 | +1 | +1 | **Cha** | 8 | -1 | -1 |
>
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** Telepathy 1 mile (works only with you)  
> **CR** None (XP 0; PB equals your Proficiency Bonus)  
>
> ### Traits
> ***Life Bond.*** When you regain Hit Points from a level 1+ spell, the steed regains the same number of Hit Points if you’re within 5 feet of it.
> ### Actions
> ***Otherworldly Slam.*** Melee Attack Roll: Bonus equals your spell attack modifier, reach 5 ft. Hit: 1d8 plus the spell’s level of Radiant (Celestial), Psychic (Fey), or Necrotic (Fiend) damage.
> ### Bonus Actions
> ***Fell Glare (Fiend Only; Recharges after a Long Rest).*** Wisdom Saving Throw: DC equals your spell save DC, one creature within 60 feet the steed can see. Failure: The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]] condition until the end of your next turn.
>
> ***Fey Step (Fey Only; Recharges after a Long Rest).*** The steed teleports, along with its rider, to an unoccupied space of your choice up to 60 feet away from itself.
>
> ***Healing Touch (Celestial Only; Recharges after a Long Rest).*** One creature within 5 feet of the steed regains a number of Hit Points equal to 2d8 plus the spell’s level.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=131|SRD 5.2.1, p. 131]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 7 - Spells/Chapter 7 - Spells|Player's Handbook — Chapter 7 - Spells]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=131|SRD 5.2.1, p. 131]]
