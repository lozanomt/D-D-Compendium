---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Ebony Fly Figurine [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Figurine of Wondrous Power/Ebony Fly Figurine|(4,000 GP)]]
*Wondrous Item, Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p265-ebony-fly-figurine.png|320]]


**Attunement:** No

A *Figurine of Wondrous Power* is a statuette small enough to fit in a pocket. If you take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action to throw the figurine to a point on the ground within 60 feet of yourself, the figurine becomes a living creature specified in the figurine’s description below. If the space where the creature would appear is occupied by other creatures or objects, or if there isn’t enough space for the creature, the figurine doesn’t become a creature.

The creature is Friendly to you and your allies. It understands your languages, obeys your commands, and takes its turn immediately after you on your [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative]] count. If you issue no commands, the creature defends itself but takes no other actions.

The creature exists for a duration specific to each figurine. At the end of the duration, the creature reverts to its figurine form. It reverts to a figurine early if its creature form drops to 0 [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]] or if you take a Magic action while touching the creature to make it revert to figurine form. When the creature becomes a figurine again, its property can’t be used again until a certain amount of time has passed, as specified in the figurine’s description.

This ebony statuette, carved in the likeness of a horsefly, can become a [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Stat Blocks/Item Summons/Giant Fly]] for up to 12 hours and can be ridden as a mount. Once it has been used, it can’t be used again until 2 days have passed.

---
![[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Stat Blocks/Item Summons/Giant Fly|no-title clean]]
