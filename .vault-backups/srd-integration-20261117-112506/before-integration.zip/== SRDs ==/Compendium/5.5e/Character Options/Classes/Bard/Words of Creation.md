---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 31ed0f2e-3687-5607-ad90-065c866f73f1
entity_type: character-option
source_ids: ["phb-2024"]
---

# Words of Creation

![[== SRDs ==/Attachments/Artwork/phb-p061-bard.png|320]]

You have mastered two of the Words of Creation: the words of life and death. You therefore always have the *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Heal|Power Word Heal]]* and *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Kill|Power Word Kill]]* spells prepared. When you cast either spell, you can target a second creature with it if that creature is within 10 feet of the first target.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=62|Player’s Handbook (2024), PDF page 62]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
