---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 82e15ad4-e896-5900-8429-a062cfb29271
entity_type: character-option
source_ids: ["phb-2024"]
---

# Danger Sense

![[== SRDs ==/Attachments/Artwork/phb-p053-barbarian.png|320]]

You gain an uncanny sense of when things aren’t as they should be, giving you an edge when you dodge perils. You have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on Dexterity saving throws unless you have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=54|Player’s Handbook (2024), PDF page 54]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
