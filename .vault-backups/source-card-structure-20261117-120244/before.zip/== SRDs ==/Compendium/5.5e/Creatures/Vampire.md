---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: dacf5e7a-12a5-5f3b-9fae-6c00b204a79b
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [335, 336]
---

> [!statblock]
> ## Vampire
> 
> *Medium or Small Undead, Lawful Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p316-vampire.png|320]]
> 
> 
> **AC** 16 &emsp; **Initiative** +14 (24)  
> **HP** 195 (23d8 + 92)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 18 | +4 | +9 | **Con** | 18 | +4 | +9 |
> | **Int** | 17 | +3 | +3 | **Wis** | 15 | +2 | +7 | **Cha** | 18 | +4 | +9 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +7, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +9  
> **Resistances** Necrotic  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 17  
> **Languages** Common plus two other languages  
> **CR** 13 (XP 10,000, or 11,500 in lair; PB +5)  
> 
> ### Traits
> 
> ***Legendary Resistance (3/Day, or 4/Day in Lair).*** If the vampire fails a saving throw, it can choose to succeed instead.
> 
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> 
> ***Misty Escape.*** If the vampire drops to 0 Hit Points outside its resting place, the vampire uses Shape-Shift to become mist (no action required). If it can't use Shape-Shift, it is destroyed.
> 
> While it has 0 Hit Points in mist form, it can't return to its vampire form, and it must reach its resting place within 2 hours or be destroyed. Once in its resting place, it returns to its vampire form and has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]] condition until it regains any Hit Points, and it regains 1 Hit Point after spending 1 hour there.
> 
> ***Spider Climb.*** The vampire can climb difficult surfaces, including along ceilings, without needing to make an ability check.
> 
> ***Vampire Weakness.*** The vampire has these weaknesses:
> 
> **Forbiddance.** The vampire can't enter a residence without an invitation from an occupant.  
> 
> **Running Water.** The vampire takes 20 Acid damage if it ends its turn in running water.  
> 
> **Stake to the Heart.** If a weapon that deals Piercing damage is driven into the vampire's heart while the vampire has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition in its resting place, the vampire has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]] condition until the weapon is removed.  
> 
> **Sunlight.** The vampire takes 20 Radiant damage if it starts its turn in sunlight. While in sunlight, it has Disadvantage on attack rolls and ability checks.  
> 
> ### Actions
> 
> ***Multiattack (Vampire Form Only).*** The vampire makes two Grave Strike attacks and uses Bite.
> 
> ***Grave Strike (Vampire Form Only).*** *Melee Attack Roll:* +9, reach 5 ft. *Hit:* 8 (1d8 + 4) Bludgeoning damage plus 7 (2d6) Necrotic damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 14) from one of two hands.
> 
> ***Bite (Bat or Vampire Form Only).*** *Constitution Saving Throw:* DC 17, one creature within 5 feet that is willing or that has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]], or [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Restrained|Restrained]] condition. *Failure:* 6 (1d4 + 4) Piercing damage plus 13 (3d8) Necrotic damage. The target's Hit Point maximum decreases by an amount equal to the Necrotic damage taken, and the vampire regains Hit Points equal to that amount. A Humanoid reduced to 0 Hit Points by this damage and then buried rises the following sunset as a **Vampire Spawn** under the vampire's control.
> 
> ### Bonus Actions
> 
> ***Charm (Recharge 5-6).*** The vampire casts *Charm Person*, requiring no spell components and using Charisma as the spellcasting ability (spell save DC 17), and the duration is 24 hours. The [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]] target is a willing recipient of the vampire's Bite, the damage of which doesn't end the spell. When the spell ends, the target is unaware it was Charmed by the vampire.
> 
> ***Shape-Shift.*** If the vampire isn't in sunlight or running water, it shape-shifts into a Tiny bat (Speed 5 ft., Fly Speed 30 ft.) or a Medium cloud of mist (Speed 5 ft., Fly Speed 20 ft. [hover]), or it returns to its vampire form. Anything it is wearing transforms with it.
> 
> While in bat form, the vampire can't speak. Its game statistics, other than its size and Speed, are unchanged.
> 
> While in mist form, the vampire can't take any actions, speak, or manipulate objects. It is weightless and can enter an enemy's space and stop there. If air can pass through a space, the mist can do so, but it can't pass through liquid. It has Resistance to all damage, except the damage it takes from sunlight.
> 
> ### Legendary Actions
> 
> *Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the vampire can expend a use to take one of the following actions. The vampire regains all expended uses at the start of each of its turns.*
> 
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> 
> ***Beguile.*** The vampire casts *Command*, requiring no spell components and using Charisma as the spellcasting ability (spell save DC 17). The vampire can't take this action again until the start of its next turn.
> 
> ***Deathless Strike.*** The vampire moves up to half its Speed, and it makes one Grave Strike attack.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=335|SRD 5.2.1, p. 335–336]] — matches the existing entry.
