---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Adamantine Armor [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Armor|(Varies)]]
*Armor (any Medium or Heavy, except [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Hide Armor|Hide Armor]]), Uncommon*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p230-adamantine-armor.png|320]]


**Attunement:** No

While you're wearing this armor, any [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Critical Hit|Critical Hit]] against you becomes a normal hit.
###### Applicable Armor
|               Name                |  Type  |            AC             |  Strength   |     Stealth      |
| ------------------------------- | :----: | :-----------------------: | :---------: | :--------------: |
| [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Chain Shirt\|Adamantine Chain Shirt]] | Medium | 13 + Dex modifier (max 2) |      -      |        -         |
| [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Scale Mail\|Adamantine Scale Mail]]  | Medium | 14 + Dex modifier (max 2) |      -      | [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage\|Disadvantage]] |
| [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Breastplate\|Adamantine Breastplate]] | Medium | 14 + Dex modifier (max 2) |      -      |        -         |
| [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Half Plate\|Adamantine Half Plate]]  | Medium | 15 + Dex modifier (max 2) |      -      | [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage\|Disadvantage]] |
|  [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Ring Mail\|Adamantine Ring Mail]]  | Heavy  |            14             |      -      | [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage\|Disadvantage]] |
| [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Chain Mail\|Adamantine Chain Mail]]  | Heavy  |            16             | Strength 13 | [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage\|Disadvantage]] |
|   [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Splint\|Adamantine Splint]]    | Heavy  |            17             | Strength 15 | [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage\|Disadvantage]] |
|    [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Plate\|Adamantine Plate]]    | Heavy  |            18             | Strength 15 | [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage\|Disadvantage]] |
