---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Draconic Resilience

![[phb-p151-draconic-sorcery.png|320]]

The magic in your body manifests physical traits of your draconic gift. Your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Point]] maximum increases by 3, and it increases by 1 whenever you gain another Sorcerer level. Parts of you are also covered by dragon-like scales. While you aren’t wearing armor, your base Armor Class equals 10 plus your Dexterity and Charisma modifiers.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=151|Player’s Handbook (2024), PDF page 151]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=152|Player’s Handbook (2024), PDF page 152]]
