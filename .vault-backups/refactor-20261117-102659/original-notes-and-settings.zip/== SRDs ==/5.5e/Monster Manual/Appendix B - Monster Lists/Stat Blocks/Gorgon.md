---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Gorgon
> 
> *Large Construct, Unaligned*
> 
> ![[mm-p151-gorgon.png|320]]
> 
> 
> **AC** 19 &emsp; **Initiative** +0 (10)  
> **HP** 114 (12d10 + 48)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 20 | +5 | +5 | **Dex** | 11 | +0 | +0 | **Con** | 18 | +4 | +4 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +7  
> **Immunities** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Petrified|Petrified]]  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 17  
> **Languages** None  
> **CR** 5 (XP 1,800; PB +3)  
> 
> ### Actions
> 
> ***Gore.*** *Melee Attack Roll:* +8, reach 5 ft. *Hit:* 18 (2d12 + 5) Piercing damage. If the target is a Large or smaller creature and the gorgon moved 20+ feet straight toward it immediately before the hit, the target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.
> 
> ***Petrifying Breath (Recharge 5-6).*** *Constitution Saving Throw:* DC 15, each creature in a 30-foot Cone. *First Failure:* The target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] condition and repeats the save at the end of its next turn if it is still Restrained, ending the effect on itself on a success. *Second Failure:* The target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Petrified|Petrified]] condition instead of the Restrained condition.
> 
> ### Bonus Actions
> 
> ***Trample.*** *Dexterity Saving Throw:* DC 16, one creature within 5 feet that has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition. *Failure:* 16 (2d10 + 5) Bludgeoning damage. *Success:* Half damage.
