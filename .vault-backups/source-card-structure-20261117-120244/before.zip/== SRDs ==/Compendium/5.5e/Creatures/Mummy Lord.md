---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 384c737a-0a69-5041-a287-7c24cfc3ec70
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [309, 310]
---

> [!statblock]
> ## Mummy Lord
> 
> *Medium or Small Undead (Cleric), Lawful Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p222-mummy-lord.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +10 (20)  
> **HP** 187 (25d8 + 75)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 10 | +0 | +0 | **Con** | 17 | +3 | +3 |
> | **Int** | 11 | +0 | +5 | **Wis** | 19 | +4 | +9 | **Cha** | 16 | +3 | +3 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +9, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Religion|Religion]] +5  
> **Vulnerabilities** Fire  
> **Immunities** Necrotic, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Truesight|Truesight]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 19  
> **Languages** Common plus three other languages  
> **CR** 15 (XP 13,000, or 15,000 in lair; PB +5)  
> 
> ### Traits
> 
> ***Legendary Resistance (3/Day, or 4/Day in Lair).*** If the mummy fails a saving throw, it can choose to succeed instead.
> 
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> 
> ***Magic Resistance.*** The mummy has Advantage on saving throws against spells and other magical effects.
> 
> ***Undead Restoration.*** If destroyed, the mummy gains a new body in 24 hours if its heart is intact, reviving with all its Hit Points. The new body appears in an unoccupied space within the mummy's lair. The heart is a Tiny object that has AC 17, HP 10, and Immunity to all damage except Fire.
> 
> ### Actions
> 
> ***Multiattack.*** The mummy makes one Rotting Fist or Channel Negative Energy attack, and it uses Dreadful Glare.
> 
> ***Rotting Fist.*** *Melee Attack Roll:* +9, reach 5 ft. *Hit:* 15 (2d10 + 4) Bludgeoning damage plus 10 (3d6) Necrotic damage. If the target is a creature, it is cursed. While cursed, the target can't regain Hit Points, it gains no benefit from finishing a Long Rest, and its Hit Point maximum decreases by 10 (3d6) every 24 hours that elapse. A creature dies and turns to dust if reduced to 0 Hit Points by this attack.
> 
> ***Channel Negative Energy.*** *Ranged Attack Roll:* +9, range 60 ft. *Hit:* 25 (6d6 + 4) Necrotic damage.
> 
> ***Dreadful Glare.*** *Wisdom Saving Throw:* DC 17, one creature the mummy can see within 60 feet. *Failure:* 25 (6d6 + 4) Psychic damage, and the target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]] condition until the end of the mummy's next turn.
> 
> ***Spellcasting.*** The mummy casts one of the following spells, requiring no Material components and using Wisdom as the spellcasting ability (spell save DC 17, +9 to hit with spell attacks):
> 
> - **At Will:** *Dispel Magic*, *Thaumaturgy*
> - **1/Day Each:** *Animate Dead*, *Harm*, *Insect Plague* (level 7 version)
> 
> ### Reactions
> 
> ***Whirlwind of Sand.*** *Trigger:* The mummy is hit by an attack roll. *Response:* The mummy adds 2 to its AC against the attack, possibly causing the attack to miss, and the mummy teleports up to 60 feet to an unoccupied space it can see. Each creature of its choice that it can see within 5 feet of its destination space has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Blinded|Blinded]] condition until the end of the mummy's next turn.
> 
> ### Legendary Actions
> 
> *Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the mummy can expend a use to take one of the following actions. The mummy regains all expended uses at the start of each of its turns.*
> 
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> 
> ***Dread Command.*** The mummy casts *Command* (level 2 version), using the same spellcasting ability as Spellcasting. The mummy can't take this action again until the start of its next turn.
> 
> ***Glare.*** The mummy uses Dreadful Glare. The mummy can't take this action again until the start of its next turn.
> 
> ***Necrotic Strike.*** The mummy makes one Rotting Fist or Channel Negative Energy attack.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=309|SRD 5.2.1, p. 309–310]] — matches the existing entry.
