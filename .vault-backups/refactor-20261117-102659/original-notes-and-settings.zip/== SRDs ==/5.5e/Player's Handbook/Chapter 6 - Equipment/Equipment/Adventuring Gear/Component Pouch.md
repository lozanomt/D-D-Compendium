---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Component Pouch [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Component Pouch|(25 GP)]] 

![[Placeholder.png|320]]

A Component Pouch is watertight and filled with compartments that hold all the free Material [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Components|components]] of your spells.

**Weight:** 2 lb.
