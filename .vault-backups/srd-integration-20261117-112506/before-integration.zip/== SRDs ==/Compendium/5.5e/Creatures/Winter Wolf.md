---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: b3bd13fc-9932-561c-b8f7-27b33a3e787d
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Winter Wolf
> 
> *Large Monstrosity, Neutral Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p336-winter-wolf.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +1 (11)  
> **HP** 75 (10d10 + 20)  
> **Speed** 50 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 13 | +1 | +1 | **Con** | 14 | +2 | +2 |
> | **Int** | 7 | -2 | -2 | **Wis** | 12 | +1 | +1 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +5  
> **Immunities** Cold  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** Common, Giant  
> **CR** 3 (XP 700; PB +2)  
> 
> ### Traits
> 
> ***Pack Tactics.*** The wolf has Advantage on an attack roll against a creature if at least one of the wolf's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 11 (2d6 + 4) Piercing damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]] condition.
> 
> ***Cold Breath (Recharge 5-6).*** *Constitution Saving Throw:* DC 12, each creature in a 15-foot Cone. *Failure:* 18 (4d8) Cold damage. *Success:* Half damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
