---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 2d2e39e3-f15e-5248-b839-d195521b6e1d
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Warrior Veteran
> 
> *Medium or Small Humanoid, Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p323-warrior-infantry.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +3 (13)  
> **HP** 65 (10d8 + 20)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 16 | +3 | +3 | **Dex** | 13 | +1 | +1 | **Con** | 14 | +2 | +2 |
> | **Int** | 10 | +0 | +0 | **Wis** | 11 | +0 | +0 | **Cha** | 10 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Athletics|Athletics]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2  
> **Gear** Greatsword, Heavy Crossbow, Splint Armor  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** Common plus one other language  
> **CR** 3 (XP 700; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The warrior makes two Greatsword or Heavy Crossbow attacks.
> 
> ***Greatsword.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 10 (2d6 + 3) Slashing damage.
> 
> ***Heavy Crossbow.*** *Ranged Attack Roll:* +3, range 100/400 ft. *Hit:* 12 (2d10 + 1) Piercing damage.
> 
> ### Reactions
> 
> ***Parry.*** *Trigger:* The warrior is hit by a melee attack roll while holding a weapon. *Response:* The warrior adds 2 to its AC against that attack, possibly causing it to miss.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
