---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 6729d28e-7bc6-5f30-9745-9929dafb3f28
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Adult Silver Dragon
> 
> *Huge Dragon (Metallic), Lawful Good*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p281-adult-silver-dragon.png|320]]
> 
> 
> **AC** 19 &emsp; **Initiative** +10 (20)  
> **HP** 216 (16d12 + 112)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 80 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 27 | +8 | +8 | **Dex** | 10 | +0 | +5 | **Con** | 25 | +7 | +7 |
> | **Int** | 16 | +3 | +3 | **Wis** | 13 | +1 | +6 | **Cha** | 22 | +6 | +6 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]] +8, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +11, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +5  
> **Immunities** Cold  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 21  
> **Languages** Common, Draconic  
> **CR** 16 (XP 15,000, or 18,000 in lair; PB +5)  
> 
> ### Traits
> 
> ***Legendary Resistance (3/Day, or 4/Day in Lair).*** If the dragon fails a saving throw, it can choose to succeed instead.
> 
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> 
> ### Actions
> 
> ***Multiattack.*** The dragon makes three Rend attacks. It can replace one attack with a use of (A) Paralyzing Breath or (B) Spellcasting to cast *Ice Knife*.
> 
> ***Rend.*** *Melee Attack Roll:* +13, reach 10 ft. *Hit:* 17 (2d8 + 8) Slashing damage plus 4 (1d8) Cold damage.
> 
> ***Cold Breath (Recharge 5-6).*** *Constitution Saving Throw:* DC 20, each creature in a 60-foot Cone. *Failure:* 54 (12d8) Cold damage. *Success:* Half damage.
> 
> ***Paralyzing Breath.*** *Constitution Saving Throw:* DC 20, each creature in a 60-foot Cone. *First Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition until the end of its next turn, when it repeats the save. *Second Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]] condition, and it repeats the save at the end of each of its turns, ending the effect on itself on a success. After 1 minute, it succeeds automatically.
> 
> ***Spellcasting.*** The dragon casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 19, +11 to hit with spell attacks):
> 
> - **At Will:** *Detect Magic*, *Hold Monster*, *Ice Knife*, *Shapechange* (Beast or Humanoid form only, no Temporary Hit Points gained from the spell, and no Concentration or Temporary Hit Points required to maintain the spell)
> - **1/Day Each:** *Ice Storm* (level 5 version), *Zone of Truth*
> 
> ### Legendary Actions
> 
> *Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the dragon can expend a use to take one of the following actions. The dragon regains all expended uses at the start of each of its turns.*
> 
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> 
> ***Chill.*** The dragon uses Spellcasting to cast *Hold Monster*. The dragon can't take this action again until the start of its next turn.
> 
> ***Cold Gale.*** *Dexterity Saving Throw:* DC 19, each creature in a 60-foot-long, 10-foot-wide Line. *Failure:* 14 (4d6) Cold damage, and the target is pushed up to 30 feet straight away from the dragon. *Success:* Half damage only. *Failure or Success:* The dragon can't take this action again until the start of its next turn.
> 
> ***Pounce.*** The dragon moves up to half its Speed, and it makes one Rend attack.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
