---
tags: [creature, phb]
cssclasses: [dnd-book, dnd-mm]
source_book: "Player's Handbook (2024)"
source_page: 347
source_pdf_page: 350
review_status: checked-against-page-image
reviewed: 2026-11-17
---

> [!statblock]
> ## Camel
>
> *Large Beast, Unaligned*
>
> **AC** 10 &emsp; **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]]** -1 (9)  
> **HP** 17 (2d10 + 6)  
> **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]]** 50 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 8 | -1 | -1 | **Con** | 17 | +3 | +5 |
> | **Int** | 2 | -4 | -4 | **Wis** | 11 | +0 | +0 | **Cha** | 5 | -3 | -3 |
>
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** None  
> **CR** 1/8 (XP 25; PB +2)  
>
> ### Actions
>
> ***Bite.*** *Melee [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] Roll:* +4, reach 5 ft. *Hit:* 4 (1d4 + 2) Bludgeoning damage.

Source: [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=350|Player’s Handbook (2024), p. 347]].

[[== SRDs ==/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/5.5e/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Camel|Monster Manual version]]
