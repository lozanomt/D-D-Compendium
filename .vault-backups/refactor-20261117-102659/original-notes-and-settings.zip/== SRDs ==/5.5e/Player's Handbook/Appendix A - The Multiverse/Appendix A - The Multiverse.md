---
tags:
  - lore
  - cosmology
cssclasses:
  - dnd-book
  - dnd-phb
source_book: "Player's Handbook (2024)"
source_pages: [344, 345]
source_pdf_pages: [347, 348]
review_status: "text-table-and-diagram-checked-against-page-images"
reviewed: 2026-11-17
---
# Appendix A - The Multiverse

This appendix provides an overview of the multiverse, the overarching reality that encompasses D&D's countless worlds and adventures. These realms are explored in greater detail in the [[== SRDs ==/5.5e/Dungeon Master's Guide/Dungeon Master’s Guide (2024)|Dungeon Master's Guide]], along with other planes like the [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 6 - Cosmology/Lore/Far Realm|Far Realm]], Negative Plane, and Positive Plane.

## The Material Realms

The philosophical and elemental forces of reality converge to create the following planes of existence:

**Material Plane.** Most D&D adventures take place on the Material Plane, which holds the worlds of settings like Dragonlance, Eberron, the Forgotten Realms, and Greyhawk. There's also room for any world your group creates. Magic and physical laws shape this plane's diverse worlds.

**Feywild.** This vibrant, idealized realm brims with life and emotion, which are most intense in the realm's Domains of Delight.

**Shadowfell.** This gloom-haunted realm holds grim wastelands, haunted ruins, and the infamous Domains of Dread.

## Transitive Planes

The transitive planes serve as paths between planes:

**Astral Plane.** This endless, silvery expanse links the [[#The Material Realms|Material Plane]] and the [[#The Outer Planes|Outer Planes]]. Whole civilizations have arisen in this glimmering vastness, while others navigate the magical cosmos in spelljamming vessels.

**[[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 6 - Cosmology/Lore/The Ethereal Plane|Ethereal Plane]].** This ghostly realm connects the [[#The Material Realms|Material Plane]] and the [[#The Inner Planes|Inner Planes]]. The region where the Ethereal Plane overlaps with other planes is called the Border Ethereal, a place where creatures can glimpse visions of planes beyond.

## The Inner Planes

Elemental forces and the building blocks of reality originate from these Inner Planes:

**Elemental Plane of Air.** Winds blow clouds and floating islands across this boundless sky.

**Elemental Plane of Earth.** This maze of caverns winds through stone and untold mineral riches.

**Elemental Plane of Fire.** An everlasting inferno, this realm blazes with life on volcanic islands.

**Elemental Plane of Water.** This bottomless ocean churns with mysterious sea life.

**Elemental Chaos.** Here on the fringes of the Inner Planes, elemental forces clash unpredictably.

**Para-Elemental Planes.** In these borderlands between the Elemental Planes, elemental forces combine into realms of ash, ice, magma, and ooze.

## The Outer Planes

Realms where ideas take form and spirits spend their afterlives, the Outer Planes are the homes of immortals. The following locations compose the Outer Planes:

**Sigil.** Sigil, the City of Doors, is a metropolis rather than a plane at the center of the Outer Planes. Here portals lead throughout the multiverse, and the enigmatic Lady of Pain maintains order.

**Outlands.** Influences from the other Outer Planes converge in the Outlands, where portals lead to those planes. At the Outlands' center rises the Spire, a pillar atop which floats Sigil.

**Other Outer Planes.** These planes are listed on the Outer Planes table. Some are paradises, some are nightmare realms, and some are more bizarre. Each is dominated by forces that embody one or more of the alignments described in [[== SRDs ==/5.5e/Player's Handbook/Chapter 2 - Creating a Character/Chapter 2 - Creating a Character|chapter 2]].

### Outer Planes

| Outer Plane | Alignment |
| --- | --- |
| [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 6 - Cosmology/Lore/Abyss\|Abyss]] | Chaotic Evil |
| Acheron | Lawful Evil, Lawful Neutral |
| Arborea | Chaotic Good |
| Arcadia | Lawful Good, Lawful Neutral |
| Beastlands | Chaotic Good, Neutral Good |
| Bytopia | Lawful Good, Neutral Good |
| Carceri | Chaotic Evil, Neutral Evil |
| Elysium | Neutral Good |
| Gehenna | Lawful Evil, Neutral Evil |
| Hades | Neutral Evil |
| Limbo | Chaotic Neutral |
| Mechanus | Lawful Neutral |
| Mount Celestia | Lawful Good |
| Nine Hells | Lawful Evil |
| Outlands | Neutral |
| Pandemonium | Chaotic Evil, Chaotic Neutral |
| Ysgard | Chaotic Good, Chaotic Neutral |

## Cosmology Diagram

![[== SRDs ==/5.5e/Player's Handbook/Artwork/phb-p345-multiverse.png]]

*The book's multiverse diagram, reproduced from page 345.*

## Source

- [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=347|Player's Handbook (2024), p. 344 — appendix text and Outer Planes table]]
- [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=348|Player's Handbook (2024), p. 345 — cosmology diagram]]
