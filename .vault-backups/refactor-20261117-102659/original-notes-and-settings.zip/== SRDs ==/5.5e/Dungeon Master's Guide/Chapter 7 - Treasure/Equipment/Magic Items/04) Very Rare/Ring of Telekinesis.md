---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [298]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Ring of Telekinesis
*Ring, Very Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p298-ring-of-telekinesis.png|320]]

**Attunement:** Yes

While wearing the ring, you can cast [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Telekinesis|Telekinesis]] from it.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=298|p. 295 (PDF page 298)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
