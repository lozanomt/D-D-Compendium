---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: ee7845ab-121b-5dac-a202-f33fe78097ac
entity_type: character-option
source_ids: ["phb-2024"]
---

# Studied Attacks

![[== SRDs ==/Attachments/Artwork/phb-p093-fighter.png|320]]

You study your opponents and learn from each attack you make. If you make an attack roll against a creature and miss, you have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on your next attack roll against that creature before the end of your next turn.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=94|Player’s Handbook (2024), PDF page 94]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
