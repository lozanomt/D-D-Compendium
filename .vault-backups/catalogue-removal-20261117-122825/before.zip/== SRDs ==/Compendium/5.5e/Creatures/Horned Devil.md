---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 593edbc7-379f-53d2-af8c-5099d808fd22
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [299, 300]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Horned Devil

## Monster Manual

> [!statblock]
> ### Horned Devil
>
> *Large Fiend (Devil), Lawful Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p176-horned-devil.png|320]]
>
> **AC:** 18  
> **Initiative:** +7 (17)  
> **HP:** 199 (19d10 + 95)  
> **Speed:** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 22 | +6 | +10 | **Dex** | 17 | +3 | +7 | **Con** | 21 | +5 | +5 |
> | **Int** | 12 | +1 | +1 | **Wis** | 16 | +3 | +7 | **Cha** | 18 | +4 | +8 |
>
> **Resistances:** Cold  
> **Immunities:** Fire, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 150 ft. (unimpeded by magical Darkness); [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages:** Infernal; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Telepathy|Telepathy]] 120 ft.  
> **CR:** 11 (XP 7,200; PB +4)  
>
> #### Traits
>
> ***Diabolical Restoration.*** If the devil dies outside the Nine Hells, its body disappears in sulfurous smoke, and it gains a new body instantly, reviving with all its Hit Points somewhere in the Nine Hells.
>
> ***Magic Resistance.*** The devil has Advantage on saving throws against spells and other magical effects.
>
> #### Actions
>
> ***Multiattack.*** The devil makes three attacks, using Searing Fork or Hurl Flame in any combination. It can replace one attack with a use of Infernal Tail.
>
> ***Searing Fork.*** *Melee Attack Roll:* +10, reach 10 ft. *Hit:*  15 (2d8 + 6) Piercing damage plus 9 (2d8) Fire damage.
>
> ***Hurl Flame.*** *Ranged Attack Roll:* +8, range 150 ft. *Hit:* 26 (5d8 + 4) Fire damage. If the target is a flammable object that isn't being worn or carried, it starts burning.
>
> ***Infernal Tail.*** *Dexterity Saving Throw:* DC 17, one creature the devil can see within 10 feet. *Failure:* 10 (1d8 + 6) Necrotic damage, and the target receives an infernal wound if it doesn't have one. While wounded, the target loses 10 (3d6) Hit Points at the start of each of its turns. The wound closes after 1 minute, after a spell restores Hit Points to the target, or after the target or a creature within 5 feet of it takes an action to stanch the wound, doing so by succeeding on a DC 17 Wisdom (Medicine) check.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1

> [!statblock]
> ### Horned Devil
>
> *Large Fiend (Devil), Lawful Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p176-horned-devil.png|320]]
>
> **AC:** 18  
> **Initiative:** +7 (17)  
> **HP:** 199 (19d10 + 95)  
> **Speed:** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 22 | +6 | +10 | **Dex** | 17 | +3 | +7 | **Con** | 21 | +5 | +5 |
> | **Int** | 12 | +1 | +1 | **Wis** | 16 | +3 | +7 | **Cha** | 18 | +4 | +8 |
>
> **Resistances:** Cold  
> **Immunities:** Fire, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 150 ft. (unimpeded by magical Darkness); [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages:** Infernal; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Telepathy|Telepathy]] 120 ft.  
> **CR:** 11 (XP 7,200; PB +4)  
>
> #### Traits
>
> ***Diabolical Restoration.*** If the devil dies outside the Nine Hells, its body disappears in sulfurous smoke, and it gains a new body instantly, reviving with all its Hit Points somewhere in the Nine Hells.
>
> ***Magic Resistance.*** The devil has Advantage on saving throws against spells and other magical effects.
>
> #### Actions
>
> ***Multiattack.*** The devil makes three attacks, using Searing Fork or Hurl Flame in any combination. It can replace one attack with a use of Infernal Tail.
>
> ***Searing Fork.*** *Melee Attack Roll:* +10, reach 10 ft. *Hit:*  15 (2d8 + 6) Piercing damage plus 9 (2d8) Fire damage.
>
> ***Hurl Flame.*** *Ranged Attack Roll:* +8, range 150 ft. *Hit:* 26 (5d8 + 4) Fire damage. If the target is a flammable object that isn't being worn or carried, it starts burning.
>
> ***Infernal Tail.*** *Dexterity Saving Throw:* DC 17, one creature the devil can see within 10 feet. *Failure:* 10 (1d8 + 6) Necrotic damage, and the target receives an infernal wound if it doesn't have one. While wounded, the target loses 10 (3d6) Hit Points at the start of each of its turns. The wound closes after 1 minute, after a spell restores Hit Points to the target, or after the target or a creature within 5 feet of it takes an action to stanch the wound, doing so by succeeding on a DC 17 Wisdom (Medicine) check.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=299|SRD 5.2.1, p. 299–300]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
