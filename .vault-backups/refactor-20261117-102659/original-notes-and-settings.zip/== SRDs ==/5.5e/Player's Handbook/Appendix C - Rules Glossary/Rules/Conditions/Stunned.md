---
tags:
  - condition
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Stunned

![[Placeholder.png|320]]


While you have the Stunned condition, you experience the following effects.

***Incapacitated.*** You have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition.

***Saving Throws Affected.*** You automatically fail Strength and Dexterity saving throws.

***Attacks Affected.*** Attack rolls against you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]].
