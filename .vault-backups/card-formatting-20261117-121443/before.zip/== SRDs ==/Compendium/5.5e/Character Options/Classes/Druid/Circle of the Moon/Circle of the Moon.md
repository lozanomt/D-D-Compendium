---
type: subclass
class: Druid
rules_revision: "2024"
reference_style: summary
tags:
  - rules/subclass
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 42f6e976-b45d-5f9b-9b75-e415c0629ec6
entity_type: character-option
source_ids: ["phb-2024"]
source_versions: ["Player's Handbook"]
---

# Circle of the Moon

## Player's Handbook

> [!info]
> ### Circle of the Moon
>
> ![[== SRDs ==/Attachments/Artwork/phb-p089-circle-of-the-moon.png|320]]
>
> **Class:** [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Druid/Druid|Druid]]
>
> A handbook reference summary. Use the linked PDF for complete wording, spell/resource tables, targeting restrictions, and exceptions.
>
> ### Features
>
> ### Level 3: Circle Forms
>
> Wild Shape can use Beasts up to CR equal to one-third your Druid level, rounded down, with the remaining Beast-form restrictions. Your form’s AC can be 13 + Wisdom modifier if higher, and you gain three times your Druid level in Temporary Hit Points.
>
> ### Level 3: Circle of the Moon Spells
>
> Always prepare the source’s circle spells and cast them while Wild Shaped: Cure Wounds, Moonbeam, Starry Wisp, Conjure Animals, Fount of Moonlight, and Mass Cure Wounds, unlocked at the listed levels.
>
> ### Level 6: Improved Circle Forms
>
> Wild Shape attacks can deal Radiant instead of their normal damage. While transformed, add Wisdom modifier to Constitution saving throws.
>
> ### Level 10: Moonlight Step
>
> As a Bonus Action, teleport 30 feet to a visible unoccupied space and gain Advantage on your next attack before the turn ends. Uses equal Wisdom modifier, minimum one, per Long Rest; level 2+ slots can restore uses.
>
> ### Level 14: Lunar Form
>
> Once per turn, a Wild Shape attack can deal 2d10 extra Radiant damage. Moonlight Step can also transport a willing creature near you to a space near your destination.
>
> ### Handbook
>
> [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=89|PDF page 89]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=90|PDF page 90]]
>
> **Source:** [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf|Player's Handbook]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
