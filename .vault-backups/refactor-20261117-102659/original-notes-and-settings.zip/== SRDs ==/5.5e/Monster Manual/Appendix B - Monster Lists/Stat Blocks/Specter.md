---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Specter
> 
> *Medium Undead, Chaotic Evil*
> 
> ![[mm-p292-specter.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 22 (5d8)  
> **Speed** 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 50 ft. (hover)  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 1 | -5 | -5 | **Dex** | 14 | +2 | +2 | **Con** | 11 | +0 | +0 |
> | **Int** | 10 | +0 | +0 | **Wis** | 10 | +0 | +0 | **Cha** | 11 | +0 | +0 |
> 
> **Resistances** Acid, Bludgeoning, Cold, Fire, Lightning, Piercing, Slashing, Thunder  
> **Immunities** Necrotic, Poison; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Petrified|Petrified]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Unconscious|Unconscious]]  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Understands Common plus one other language but can't speak  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Traits
> 
> ***Incorporeal Movement.*** The specter can move through other creatures and objects as if they were Difficult Terrain. It takes 5 (1d10) Force damage if it ends its turn inside an object.
> 
> ***Sunlight Sensitivity.*** While in sunlight, the specter has Disadvantage on ability checks and attack rolls.
> 
> ### Actions
> 
> ***Life Drain.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (2d6) Necrotic damage. If the target is a creature, its Hit Point maximum decreases by an amount equal to the damage taken.
