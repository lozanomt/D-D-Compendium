---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 091209d3-afd8-516c-bf7f-ede8d2330557
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [354]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Giant Venomous Snake

## Monster Manual


> [!statblock]
> ### Giant Venomous Snake
>
> *Medium Beast, Unaligned*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC:** 14 &emsp;  
> **Initiative:** +4 (14)  
> **HP:** 11 (2d8 + 2)  
> **Speed:** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 10 | +0 | +0 | **Dex** | 18 | +4 | +4 | **Con** | 13 | +1 | +1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 10 | +0 | +0 | **Cha** | 3 | -4 | -4 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 10 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages:** None  
> **CR:** 1/4 (XP 50; PB +2)  
>
> #### Actions
>
> ***Bite.*** *Melee Attack Roll:* +6, reach 10 ft. *Hit:* 6 (1d4 + 4) Piercing damage plus 4 (1d8) Poison damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Giant Venomous Snake
>
> *Medium Beast, Unaligned*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC:** 14 &emsp;  
> **Initiative:** +4 (14)  
> **HP:** 11 (2d8 + 2)  
> **Speed:** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 10 | +0 | +0 | **Dex** | 18 | +4 | +4 | **Con** | 13 | +1 | +1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 10 | +0 | +0 | **Cha** | 3 | -4 | -4 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 10 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages:** None  
> **CR:** 1/4 (XP 50; PB +2)  
>
> #### Actions
>
> ***Bite.*** *Melee Attack Roll:* +6, reach 10 ft. *Hit:* 6 (1d4 + 4) Piercing damage plus 4 (1d8) Poison damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=354|SRD 5.2.1, p. 354]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
