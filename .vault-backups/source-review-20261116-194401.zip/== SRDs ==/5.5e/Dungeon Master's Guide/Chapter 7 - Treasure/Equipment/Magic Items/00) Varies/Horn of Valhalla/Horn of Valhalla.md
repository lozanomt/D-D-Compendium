---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Horn of Valhalla [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Horn of Valhalla/Horn of Valhalla|(Varies)]]
*Wondrous Item, Varies*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p274-horn-of-blasting.png|320]]


**Attunement:** No

You can take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action to blow this horn. In response, warrior spirits from the plane of Ysgard appear in unoccupied spaces within 60 feet of you. Each spirit uses the [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Berserker]] stat block and returns to Ysgard after 1 hour or when it drops to 0 [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]]. The spirits look like living, breathing warriors, and they have [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Immunity]] to the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Charmed]] and [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Frightened]] conditions. Once you use the horn, it can’t be used again until 7 days have passed.

Four types of *Horn of Valhalla* are known to exist, each made of a different metal. The horn’s type determines how many spirits it summons, as well as the requirement for its use. The DM chooses the horn’s type or determines it randomly by rolling on the following table.

If you blow the horn without meeting its requirement, the summoned spirits attack you. If you meet the requirement, they are Friendly to you and your allies and follow your commands.


| 1d100   | Horn Type | Rarity    | Spirits | Requirement                          |
| :-------: | :---------: | :---------: | :-------: | ------------------------------------ |
| 01 - 40 | Silver    | Rare      | 2       | None                                 |
| 41 - 75 | Brass     | Rare      | 3       | Proficiency with all Simple weapons  |
| 76 - 90 | Bronze    | Very Rare | 4       | Training with all Medium armor       |
| 91 - 00 | Iron      | Legendary | 5       | Proficiency with all Martial weapons |
