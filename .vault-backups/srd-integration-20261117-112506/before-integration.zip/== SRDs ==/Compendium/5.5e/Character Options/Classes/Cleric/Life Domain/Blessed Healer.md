---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 81e38e40-7ace-5939-abd1-68bc99f7b9d0
entity_type: character-option
source_ids: ["phb-2024"]
---

# Blessed Healer

![[== SRDs ==/Attachments/Artwork/phb-p076-life-domain.png|320]]

The healing spells you cast on others heal you as well. Immediately after you cast a spell with a spell slot that restores [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] to one or more creatures other than yourself, you regain Hit Points equal to 2 plus the spell slot’s level.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=76|Player’s Handbook (2024), PDF page 76]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=77|Player’s Handbook (2024), PDF page 77]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
