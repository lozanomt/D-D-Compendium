---
tags:
  - skill
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Persuasion

![[Placeholder.png|320]]


Charisma (Persuasion) allows you to honestly and graciously convince someone of something.
