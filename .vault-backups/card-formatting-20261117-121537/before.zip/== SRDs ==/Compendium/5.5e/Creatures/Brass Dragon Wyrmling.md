---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 1a6a8ab8-48f0-5eee-9d6a-60ce3ba56153
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [268]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Brass Dragon Wyrmling

## Monster Manual


> [!statblock]
> ### Brass Dragon Wyrmling
>
> *Medium Dragon (Metallic), Chaotic Good*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p056-brass-dragon-wyrmling.png|320]]
>
> **AC:** 15 &emsp;  
> **Initiative:** +2 (12)  
> **HP:** 22 (4d8 + 4)  
> **Speed:** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Burrowing|Burrow]] 15 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 10 | +0 | +2 | **Con** | 13 | +1 | +1 |
> | **Int** | 10 | +0 | +0 | **Wis** | 11 | +0 | +2 | **Cha** | 13 | +1 | +1 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +2  
> **Immunities:** Fire  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages:** Draconic  
> **CR:** 1 (XP 200; PB +2)  
>
> #### Actions
>
> ***Rend.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (1d10 + 2) Slashing damage.
>
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 11, each creature in a 20-foot-long, 5-footwide Line. *Failure:* 14 (4d6) Fire damage. *Success:* Half damage.
>
> ***Sleep Breath.*** *Constitution Saving Throw:* DC 11, each creature in a 15-foot Cone. *Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition until the end of its next turn, at which point it repeats the save. *Second Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]] condition for 1 minute. This effect ends for the target if it takes damage or a creature within 5 feet of it takes an action to wake it.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Brass Dragon Wyrmling
>
> *Medium Dragon (Metallic), Chaotic Good*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p056-brass-dragon-wyrmling.png|320]]
>
> **AC:** 15 &emsp;  
> **Initiative:** +2 (12)  
> **HP:** 22 (4d8 + 4)  
> **Speed:** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Burrowing|Burrow]] 15 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 10 | +0 | +2 | **Con** | 13 | +1 | +1 |
> | **Int** | 10 | +0 | +0 | **Wis** | 11 | +0 | +2 | **Cha** | 13 | +1 | +1 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +2  
> **Immunities:** Fire  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages:** Draconic  
> **CR:** 1 (XP 200; PB +2)  
>
> #### Actions
>
> ***Rend.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (1d10 + 2) Slashing damage.
>
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 11, each creature in a 20-foot-long, 5-footwide Line. *Failure:* 14 (4d6) Fire damage. *Success:* Half damage.
>
> ***Sleep Breath.*** *Constitution Saving Throw:* DC 11, each creature in a 15-foot Cone. *Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition until the end of its next turn, at which point it repeats the save. *Second Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]] condition for 1 minute. This effect ends for the target if it takes damage or a creature within 5 feet of it takes an action to wake it.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=268|SRD 5.2.1, p. 268]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
