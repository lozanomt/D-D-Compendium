---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 494a8205-7146-573d-9417-95d91ef84f28
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [57]
---

# Smite of Protection

![[== SRDs ==/Attachments/Artwork/phb-p116-oath-of-devotion.png|320]]

Your magical smite now radiates protective energy. Whenever you cast *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Divine Smite|Divine Smite]]*, you and your allies have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Half Cover|Half Cover]] while in your [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Paladin/Aura of Protection|Aura of Protection]]. The aura has this benefit until the start of your next turn.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=116|Player’s Handbook (2024), PDF page 116]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=117|Player’s Handbook (2024), PDF page 117]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

Your magical smite now radiates protective energy.

Whenever you cast [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Divine Smite|Divine Smite]] , you and your allies have Half [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Cover|Cover]] while in your Aura of Protection.

The aura has this benefit until the start of your next turn.

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=57|SRD 5.2.1, p. 57]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=57|SRD 5.2.1, p. 57]]
