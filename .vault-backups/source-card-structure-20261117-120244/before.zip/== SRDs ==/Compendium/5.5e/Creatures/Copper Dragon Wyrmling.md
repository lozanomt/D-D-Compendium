---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 63ca5d69-25d7-591e-87a0-62425930505c
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [275, 276]
---

> [!statblock]
> ## Copper Dragon Wyrmling
> 
> *Medium Dragon (Metallic), Chaotic Good*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p080-copper-dragon-wyrmling.png|320]]
> 
> 
> **AC** 16 &emsp; **Initiative** +3 (13)  
> **HP** 22 (4d8 + 4)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 12 | +1 | +3 | **Con** | 13 | +1 | +1 |
> | **Int** | 14 | +2 | +2 | **Wis** | 11 | +0 | +2 | **Cha** | 13 | +1 | +1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +3  
> **Immunities** Acid  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Draconic  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Actions
> 
> ***Rend.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (1d10 + 2) Slashing damage.
> 
> ***Acid Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 11, each creature in a 20-foot-long, 5-footwide Line. *Failure:* 18 (4d8) Acid damage. *Success:* Half damage.
> 
> ***Slowing Breath.*** *Constitution Saving Throw:* DC 11, each creature in a 15-foot Cone. *Failure:* The target can't take Reactions; its Speed is halved; and it can take either an action or a Bonus Action on its turn, not both. This effect lasts until the end of its next turn.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=275|SRD 5.2.1, p. 275–276]] — matches the existing entry.
