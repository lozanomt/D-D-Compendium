---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: eeeb91d7-9d7d-55cc-9e8c-63757ab3359d
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Awakened Shrub
> *Small Plant, Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p025-awakened-shrub.png|320]]
> 
> 
> **AC** 9 **Initiative** -1 (9)  
> **HP** 10 (3d6)  
> **Speed** 20 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 3 | -4 | -4 | **Dex** | 8 | -1 | -1 | **Con** | 11 | +0 | +0 |
> | **Int** | 10 | +0 | +0 | **Wis** | 10 | +0 | +0 | **Cha** | 6 | -2 | -2 |
> 
> **Vulnerabilities** Fire  
> **Resistances** Piercing  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Common plus one other language  
> **CR** 0 (XP 10; PB +2)  
> 
> **Habitat** Forest  
> **Treasure** None  
> 
> ### Actions
> ***Rake.*** *Melee Attack Roll:* +1, reach 5 ft. *Hit:* 1 Slashing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
