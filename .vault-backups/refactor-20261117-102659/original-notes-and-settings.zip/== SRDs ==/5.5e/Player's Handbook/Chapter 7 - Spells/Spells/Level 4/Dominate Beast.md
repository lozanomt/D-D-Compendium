---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Dominate Beast
*Level 4 Enchantment (Druid, Ranger, Sorcerer)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 minute

One Beast you can see within range must succeed on a Wisdom saving throw or have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Charmed|Charmed]] condition for the duration. The target has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on the save if you or your allies are fighting it. Whenever the target takes damage, it repeats the save, ending the spell on itself on a success.

You have a telepathic link with the Charmed target while the two of you are on the same plane of existence. On your turn, you can use this link to issue commands to the target (no action required), such as "Attack that creature," "Move over there," or "Fetch that object." The target does its best to obey on its turn. If it completes an order and doesn't receive further direction from you, it acts and moves as it likes, focusing on protecting itself.

You can command the target to take a Reaction but must take your own Reaction to do so.

***Using a Higher-Level Spell Slot.*** Your Concentration can last longer with a spell slot of level 5 (up to 10 minutes), 6 (up to 1 hour), or 7+ (up to 8 hours).
