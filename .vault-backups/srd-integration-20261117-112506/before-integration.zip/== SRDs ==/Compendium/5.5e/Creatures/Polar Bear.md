---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 7853ec2e-3bd3-5f8c-9b91-046805089ab2
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Polar Bear
> 
> *Large Beast, Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 42 (5d10 + 15)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 20 | +5 | +5 | **Dex** | 14 | +2 | +2 | **Con** | 16 | +3 | +3 |
> | **Int** | 2 | -4 | -4 | **Wis** | 13 | +1 | +1 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +4  
> **Resistances** Cold  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** None  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The bear makes two Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 9 (1d8 + 5) Slashing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
