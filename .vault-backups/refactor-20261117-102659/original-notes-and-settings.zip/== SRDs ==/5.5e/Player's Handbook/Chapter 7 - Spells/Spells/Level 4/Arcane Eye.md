---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Arcane Eye
*Level 4 Divination (Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a bit of bat fur)
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 hour

You create an [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Invisible|Invisible]], invulnerable eye within range that hovers for the duration. You mentally receive visual information from the eye, which can see in every direction. It also has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] with a range of 30 feet.

As a Bonus Action, you can move the eye up to 30 feet in any direction. A solid barrier blocks the eye's movement, but the eye can pass through an opening as small as 1 inch in diameter.
