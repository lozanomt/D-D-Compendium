---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Freedom of Movement
*Level 4 Abjuration (Bard, Cleric, Druid, Ranger)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a leather strap)
**Duration:** 1 hour

You touch a willing creature. For the duration, the target's movement is unaffected by [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Difficult Terrain|Difficult Terrain]], and spells and other magical effects can neither reduce the target's Speed nor cause the target to have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Paralyzed|Paralyzed]] or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] conditions. The target also has a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] Speed equal to its Speed.

In addition, the target can spend 5 feet of movement to automatically escape from nonmagical restraints, such as manacles or a creature imposing the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] condition on it.

***Using a Higher-Level Spell Slot.*** You can target one additional creature for each spell slot level above 4.
