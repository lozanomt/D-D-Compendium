---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Costume [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Costume|(5 GP)]] 

![[Placeholder.png|320]]

While wearing a Costume, you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on any ability check you make to impersonate the person or type of person it represents.

**Weight:** 4 lb.
