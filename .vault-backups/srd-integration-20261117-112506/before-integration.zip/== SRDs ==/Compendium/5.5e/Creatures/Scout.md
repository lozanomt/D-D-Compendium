---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: ad598670-bd94-51f5-8099-5ad8d503a929
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Scout
> 
> *Medium or Small Humanoid, Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p272-scout.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +2 (12)  
> **HP** 16 (3d8 + 3)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +0 | **Dex** | 14 | +2 | +2 | **Con** | 12 | +1 | +1 |
> | **Int** | 11 | +0 | +0 | **Wis** | 13 | +1 | +1 | **Cha** | 11 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Nature|Nature]] +4, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Survival|Survival]] +5  
> **Gear** Leather Armor, Longbow, Shortsword  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** Common plus one other language  
> **CR** 1/2 (XP 100; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The scout makes two attacks, using Shortsword and Longbow in any combination.
> 
> ***Shortsword.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Piercing damage.
> 
> ***Longbow.*** *Ranged Attack Roll:* +4, range 150/600 ft. *Hit:* 6 (1d8 + 2) Piercing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
