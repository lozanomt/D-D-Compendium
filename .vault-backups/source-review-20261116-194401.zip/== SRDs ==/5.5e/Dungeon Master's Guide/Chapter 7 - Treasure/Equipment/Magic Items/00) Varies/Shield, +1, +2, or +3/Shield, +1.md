---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Shield, +1 [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Shield, +1, +2, or +3/Shield, +1|(410 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Shield|Shield]]), Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-shield.png|320]]


**Attunement:** No

While holding this Shield, you have a +1 bonus to Armor Class, in addition to the Shield's normal bonus to AC.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Shield|clean no-title]]
