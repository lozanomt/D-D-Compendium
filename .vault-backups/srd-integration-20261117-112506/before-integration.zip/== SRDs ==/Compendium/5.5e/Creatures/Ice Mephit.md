---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 5b67aced-22ab-5a16-bbb2-aae85eeb2f00
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Ice Mephit
> 
> *Small Elemental, Neutral Evil*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 11 &emsp; **Initiative** +1 (11)  
> **HP** 21 (6d6)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 7 | -2 | -2 | **Dex** | 13 | +1 | +1 | **Con** | 10 | +0 | +0 |
> | **Int** | 9 | -1 | -1 | **Wis** | 11 | +0 | +0 | **Cha** | 12 | +1 | +1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +3  
> **Vulnerabilities** Fire  
> **Immunities** Cold, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** Primordial (Aquan, Auran)  
> **CR** 1/2 (XP 100; PB +2)  
> 
> ### Traits
> 
> ***Death Burst.*** The mephit explodes when it dies. *Constitution Saving Throw:* DC 10, each creature in a 5-foot Emanation originating from the mephit. *Failure:* 5 (2d4) Cold damage. *Success:* Half damage.
> 
> ### Actions
> 
> ***Claw.*** *Melee Attack Roll:* +3, reach 5 ft. *Hit:* 3 (1d4 + 1) Slashing damage plus 2 (1d4) Cold damage.
> 
> ***Fog Cloud (1/Day).*** The mephit casts *Fog Cloud*, requiring no spell components and using Charisma as the spellcasting ability.
> 
> - [ ]
> 
> ***Frost Breath (Recharge 6).*** *Constitution Saving Throw:* DC 10, each creature in a 15-foot Cone. *Failure:* 7 (3d4) Cold damage. *Success:* Half damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
