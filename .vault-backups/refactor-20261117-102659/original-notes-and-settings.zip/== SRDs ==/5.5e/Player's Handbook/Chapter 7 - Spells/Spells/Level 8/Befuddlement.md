---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Befuddlement
*Level 8 Enchantment (Bard, Druid, Warlock, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (a key ring with no keys)
**Duration:** Instantaneous

You blast the mind of a creature that you can see within range. The target makes an Intelligence saving throw.

On a failed save, the target takes 10d12 Psychic damage and can't cast spells or take the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action. At the end of every 30 days, the target repeats the save, ending the effect on a success. The effect can also be ended by the *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Greater Restoration|Greater Restoration]]*, *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 6/Heal|Heal]]*, or *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 9/Wish|Wish]]* spell.

On a successful save, the target takes half as much damage only.
