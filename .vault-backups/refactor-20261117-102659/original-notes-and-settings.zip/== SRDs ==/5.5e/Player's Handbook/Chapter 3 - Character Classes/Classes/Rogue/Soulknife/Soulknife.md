---
type: subclass
class: Rogue
rules_revision: "2024"
reference_style: summary
tags:
  - rules/subclass
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Soulknife

![[phb-p138-soulknife.png|320]]


**Class:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Rogue/Rogue|Rogue]]

A handbook reference summary. Use the linked PDF for complete wording, spell/resource tables, targeting restrictions, and exceptions.

## Features

### Level 3: Psionic Power

Gain the source table’s Psionic Energy Dice, recovering one on a Short Rest and all on a Long Rest. Psi-Bolstered Knack improves failed proficient skill/tool checks, spending a die only on success. Psychic Whispers creates telepathic contact with up to Proficiency Bonus creatures for die-roll hours at one-mile range, with a free first use per Long Rest.

### Level 3: Psychic Blades

Manifest a blade in a free hand for Attack-action or Opportunity Attacks: 1d6 Psychic, Finesse, Thrown 60/120 feet, and Vex without using a mastery choice. After attacking with it on your turn, an eligible free other hand can make a 1d4 blade attack as a Bonus Action.

### Level 9: Soul Blades

Homing Strikes adds a Psionic Energy Die to a missed blade attack, spending it only if the attack then hits. Psychic Teleportation spends a die and a Bonus Action to teleport to a visible space up to ten times the roll in feet away.

### Level 13: Psychic Veil

A Magic action makes you Invisible for up to one hour, ending after you deal damage or force a save. One use per Long Rest; a Psionic Energy Die can restore it.

### Level 17: Rend Mind

A Psychic Blade Sneak Attack can force a Wisdom save against one minute of Stunned, with repeated end-of-turn saves. Once per Long Rest; spend three Psionic Energy Dice to restore it.

## Handbook

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=138|PDF page 138]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=139|PDF page 139]]
