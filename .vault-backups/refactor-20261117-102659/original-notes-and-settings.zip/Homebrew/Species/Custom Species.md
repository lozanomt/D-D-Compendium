---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Custom Species

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


#### Custom Ancestry
**Creature Type:** Humanoid
**Size:** Medium (about 4 - 8 feet tall) or Small (about 2 - 4 feet tall), chosen when you select this ancestry
**[[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed]]:** 30 feet

As a Custom Ancestry, you have these special traits.

***Additional Language.*** When you are selecting your Languages for character creation, you may choose three instead of two in addition to Common.

***Variable Trait.*** You gain one of the following options of your choice: (A) [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] with a range of 60 feet or (B) proficiency in one skill of your choice.

***Versatile.*** You gain an Origin feat of your choice.
