---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Killer Whale
> *Huge Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/Monster Manual/Artwork/mm-p365-hunter-shark.png|320]]
> 
> 
> **AC** 12 **Initiative** +2 (12)  
> **HP** 90 (12d12 + 12)  
> **Speed** 5 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 14 | +2 | +2 | **Con** | 13 | +1 | +1 |
> | **Int** | 3 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +3, [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]] +4  
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight]] 120 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 13  
> **Languages** None  
> **CR** 3 (XP 700; PB +2)  
> 
> **Habitat** Underwater  
> **Treasure** None  
> 
> ### Traits
> 
> ***Hold Breath.*** The whale can hold its breath for 30 minutes.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 21 (5d6 + 4) Piercing damage.
