---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: d3996e39-4ae2-53d5-92a7-d39dda629f05
entity_type: character-option
source_ids: ["phb-2024"]
---

# Instinctive Pounce

![[== SRDs ==/Attachments/Artwork/phb-p053-barbarian.png|320]]

As part of the Bonus Action you take to enter your Rage, you can move up to half your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]].

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=54|Player’s Handbook (2024), PDF page 54]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
