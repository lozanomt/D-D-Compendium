---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: bb880c41-02ef-5a48-9a88-60ce0f3d395d
entity_type: character-option
source_ids: ["phb-2024"]
---

# Magical Discoveries

![[== SRDs ==/Attachments/Artwork/phb-p069-college-of-lore.png|320]]

You learn two spells of your choice. These spells can come from the [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Cleric/Cleric|Cleric]], [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Druid/Druid|Druid]], or [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Wizard/Wizard|Wizard]] spell list or any combination thereof. A spell you choose must be a cantrip or a spell for which you have spell slots, as shown in the Bard Features table. You always have the chosen spells prepared, and whenever you gain a Bard level, you can replace one of the spells with another spell that meets these requirements.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=69|Player’s Handbook (2024), PDF page 69]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=70|Player’s Handbook (2024), PDF page 70]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
