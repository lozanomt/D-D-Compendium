---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: f6f4da66-d84a-56b6-ab56-65b60496c35d
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [353]
---

> [!statblock]
> ## Giant Scorpion
> 
> *Large Beast, Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 15 **Initiative** +1 (11)  
> **HP** 52 (7d10 + 14)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 16 | +3 | +3 | **Dex** | 13 | +1 | +1 | **Con** | 15 | +2 | +2 |
> | **Int** | 1 | -5 | -5 | **Wis** | 9 | -1 | -1 | **Cha** | 3 | -4 | -4 |
> 
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** None  
> **CR** 3 (XP 700; PB +2)  
> 
> **Habitat** Desert  
> **Treasure** None  
> 
> ### Actions
> 
> ***Multiattack.*** The scorpion makes two Claw attacks and one Sting attack.
> 
> ***Claw.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 6 (1d6 + 3) Bludgeoning damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 13) from one of two claws.
> 
> ***Sting.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Piercing damage plus 11 (2d10) Poison damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=353|SRD 5.2.1, p. 353]] — matches the existing entry.
