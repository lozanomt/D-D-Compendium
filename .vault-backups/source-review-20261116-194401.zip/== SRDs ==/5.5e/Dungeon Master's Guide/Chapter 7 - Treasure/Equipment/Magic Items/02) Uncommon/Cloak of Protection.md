---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Cloak of Protection [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Cloak of Protection|(400 GP)]]
*Wondrous Item, Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p248-cloak-of-elvenkind.png|320]]


**Attunement:** Yes

You gain a +1 bonus to Armor Class and saving throws while you wear this cloak.
