---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Essence of Ether [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Equipment/Poison/Essence of Ether|(300 GP)]]
*[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Rules/Properties/Poison/Inhaled]] Poison*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


A creature subjected to Essence of Ether must succeed on a DC 15 Constitution saving throw or have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned]] condition for 8 hours. The creature also has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Unconscious]] condition while Poisoned
in this way. The creature wakes up if it takes damage or if another creature takes an action to shake it awake.
