---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: f098b93d-ee49-5762-9f1d-eb36c168ffa2
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [297]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Hell Hound

## Monster Manual

> [!statblock]
> ### Hell Hound
> *Medium Fiend, Lawful Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p167-hell-hound.png|320]]
>
> **AC** 15 &emsp; **Initiative** +1 (11)  
> **HP** 58 (9d8 + 18)  
> **Speed** 50 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 12 | +1 | +1 | **Con** | 14 | +2 | +2 |
> | **Int** | 6 | -2 | -2 | **Wis** | 13 | +1 | +1 | **Cha** | 6 | -2 | -2 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5  
> **Immunities** Fire  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** Understands Infernal but can't speak  
> **CR** 3 (XP 700; PB +2)  
>
> **Habitat** Mountain, Planar (Hell), Underdark  
> **Treasure** None  
>
> ### Traits
> ***Pack Tactics.*** The hound has [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on an attack roll against a creature if at least one of the hound's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> ### Actions
> ***Multiattack.*** The hound makes two Bite attacks.
>
> ***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Piercing damage plus 3 (1d6) Fire damage.
>
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 12, each creature in a 15-foot [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cone|Cone]]. *Failure:* 17 (5d6) Fire damage. *Success:* Half damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1

> [!statblock]
> ### Hell Hound
> *Medium Fiend, Lawful Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p167-hell-hound.png|320]]
>
> **AC** 15 &emsp; **Initiative** +1 (11)  
> **HP** 58 (9d8 + 18)  
> **Speed** 50 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 12 | +1 | +1 | **Con** | 14 | +2 | +2 |
> | **Int** | 6 | -2 | -2 | **Wis** | 13 | +1 | +1 | **Cha** | 6 | -2 | -2 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5  
> **Immunities** Fire  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** Understands Infernal but can't speak  
> **CR** 3 (XP 700; PB +2)  
>
> **Habitat** Mountain, Planar (Hell), Underdark  
> **Treasure** None  
>
> ### Traits
> ***Pack Tactics.*** The hound has [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on an attack roll against a creature if at least one of the hound's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> ### Actions
> ***Multiattack.*** The hound makes two Bite attacks.
>
> ***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Piercing damage plus 3 (1d6) Fire damage.
>
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 12, each creature in a 15-foot [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cone|Cone]]. *Failure:* 17 (5d6) Fire damage. *Success:* Half damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=297|SRD 5.2.1, p. 297]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=297|SRD 5.2.1, p. 297]]
