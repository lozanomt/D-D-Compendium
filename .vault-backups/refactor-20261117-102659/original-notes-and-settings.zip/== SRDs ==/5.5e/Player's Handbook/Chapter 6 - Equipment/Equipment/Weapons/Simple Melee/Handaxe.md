---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Handaxe [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Simple Melee/Handaxe|(5 GP)]]
*Simple Melee*

![[phb-p219-handaxe.png|320]]


**Mastery:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Mastery/Vex|Vex]] **Weight:** 2 lb.
**Damage:** 1d6 Slashing
**Properties:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Light|Light]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Thrown|Thrown]] (Range 20/60)
