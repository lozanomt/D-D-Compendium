---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: b0a7b735-3dd3-5f1b-ad75-badfd5d346e2
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [51]
---

# Unarmored Movement

![[== SRDs ==/Attachments/Artwork/phb-p103-monk.png|320]]

Your speed increases by 10 feet while you aren’t wearing armor or wielding a [[== SRDs ==/Compendium/5.5e/Items/Armor/Shield|Shield]]. This bonus increases when you reach certain Monk levels, as shown on the Monk Features table.

***Acrobatic Movement.*** At Monk level 9, while you aren’t wearing armor or wielding a Shield, you gain the ability to move along vertical surfaces and across liquids on your turn without falling during the movement.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=104|Player’s Handbook (2024), PDF page 104]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

Your speed increases by 10 feet while you aren't wearing armor or wielding a [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield|Shield]]. This bonus increases when you reach certain Monk levels, as shown on the Monk Features table.

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=51|SRD 5.2.1, p. 51]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=51|SRD 5.2.1, p. 51]]
