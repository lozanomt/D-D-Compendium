---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 46ad9fc1-dd89-5a41-83e1-cc986a92d553
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [63]
---

# Uncanny Dodge

![[== SRDs ==/Attachments/Artwork/phb-p131-rogue.png|320]]

When an attacker that you can see hits you with an attack roll, you can take a Reaction to halve the attack’s damage against you (round down).

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=132|Player’s Handbook (2024), PDF page 132]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

When an attacker that you can see hits you with an attack roll, you can take a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Reaction|Reaction]] to halve the attack's damage against you (round down).

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=63|SRD 5.2.1, p. 63]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=63|SRD 5.2.1, p. 63]]
