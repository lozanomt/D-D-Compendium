---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Collapsing Roof
*Deadly Trap (Levels 1 - 4)*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Trigger:** A creature crosses a trip wire
**Duration:** Instantaneous

This trap uses a trip wire to collapse an unstable section of ceiling. The trip wire is 3 inches off the ground and stretches between two weak supports that topple when the trip wire is pulled.

The first creature that crosses the trip wire causes the supports to topple and the unstable section of ceiling to collapse. Each creature beneath the unstable section of ceiling must succeed on a DC 13 Dexterity saving throw, taking 11 (2d10) Bludgeoning damage on a failed save or half as much damage on a successful one. Rubble from the collapse turns the trapped area into [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Difficult Terrain]].

***Detect and Disarm.*** As a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Search]] action, a creature can examine the trapped area and make a DC 11 Wisdom ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]]) check, detecting the trip wire and the unstable section of ceiling on a successful check. Once detected, the trip wire can be easily cut or avoided (no ability check required).

***At Higher Levels.*** You can scale the trap for higher levels by increasing the damage and the save DC, as shown in the following table

| Levels  | Bludgeoning Damage | Save DC |
| :-----: | :----------------: | :-----: |
| 5 - 10  |     22 (4d10)      |   15    |
| 11 - 16 |     55 (10d10)     |   17    |
| 17 - 20 |     99 (18d10)     |   19    |
