---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Plant Growth
*Level 3 Transmutation (Bard, Druid, Ranger)*

![[Placeholder.png|320]]


**Casting Time:** Action (Overgrowth) or 8 hours (Enrichment)
**Range:** 150 feet
**Components:** V, S
**Duration:** Instantaneous

This spell channels vitality into plants. The casting time you use determines whether the spell has the Overgrowth or the Enrichment effect below.

***Overgrowth.*** Choose a point within range. All normal plants in a 100-foot-radius [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Sphere|Sphere]] centered on that point become thick and overgrown. A creature moving through that area must spend 4 feet of movement for every 1 foot it moves. You can exclude one or more areas of any size within the spell's area from being affected.

***Enrichment.*** All plants in a half-mile radius centered on a point within range become enriched for 420 days. The plants yield twice the normal amount of food when harvested. They can benefit from only one *Plant Growth* per year.
