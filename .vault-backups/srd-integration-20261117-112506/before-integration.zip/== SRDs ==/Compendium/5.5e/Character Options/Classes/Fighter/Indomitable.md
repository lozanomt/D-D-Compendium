---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: e5042920-d365-5aad-8f0a-c97b06460f62
entity_type: character-option
source_ids: ["phb-2024"]
---

# Indomitable

![[== SRDs ==/Attachments/Artwork/phb-p093-fighter.png|320]]

If you fail a saving throw, you can reroll it with a bonus equal to your Fighter level. You must use the new roll, and you can’t use this feature again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]]. You can use this feature twice before a Long Rest starting at level 13 and three times before a Long Rest starting at level 17.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=94|Player’s Handbook (2024), PDF page 94]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
