---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Wand of Web [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Wand of Web|(400 GP)]]
*Wand, Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p325-wand-of-secrets.png|320]]


**Attunement:** By a Spellcaster

This wand has 7 charges. While holding it, you can expend 1 charge to cast *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Web]]* (save DC 13) from it.

***Regaining Charges.*** The wand regains 1d6 + 1 expended charges daily at dawn. If you expend the wand’s last charge, roll 1d20. On a 1, the wand crumbles into ashes and is destroyed.
