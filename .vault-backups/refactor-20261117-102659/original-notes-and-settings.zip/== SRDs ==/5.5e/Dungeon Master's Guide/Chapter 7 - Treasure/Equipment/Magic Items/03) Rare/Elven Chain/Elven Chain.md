---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [260]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Elven Chain
*Armor (Chain Mail or Chain Shirt), Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p259-elven-chain.png|320]]

**Attunement:** No

While wearing the armor, you gain a +1 bonus to Armor Class. You are considered trained with this armor even if you lack training with Medium or [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Heavy|Heavy]] armor.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=260|p. 257 (PDF page 260)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
