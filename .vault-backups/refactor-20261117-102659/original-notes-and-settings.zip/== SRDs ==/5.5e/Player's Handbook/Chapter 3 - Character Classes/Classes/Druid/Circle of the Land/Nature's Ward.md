---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Nature's Ward

![[phb-p088-circle-of-the-land.png|320]]

You are immune to the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]] condition, and you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to a damage type associated with your current land choice in the Circle Spells feature, as shown in the Nature’s Ward table.
###### Nature's Ward
| Land Type | Resistance |
| --------- | ---------- |
| Arid      | Fire       |
| Polar     | Cold       |
| Temperate | Lightning  |
| Tropical  | Poison     |

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=87|Player’s Handbook (2024), PDF page 87]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=88|Player’s Handbook (2024), PDF page 88]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=89|Player’s Handbook (2024), PDF page 89]]
