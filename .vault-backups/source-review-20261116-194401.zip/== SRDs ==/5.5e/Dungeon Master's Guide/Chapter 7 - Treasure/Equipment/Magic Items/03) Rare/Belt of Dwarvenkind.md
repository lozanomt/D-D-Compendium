---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Belt of Dwarvenkind [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/03) Rare/Belt of Dwarvenkind|(4,000 GP)]]
*Wondrous Item, Rare*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** Yes

While wearing this belt, you gain the following benefits:

**Dwarvish.** You know Dwarvish.
**Friend of Dwarvenkind.** You have [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage]] on Charisma ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Persuasion]]) checks made to interact with dwarves and duergar.
**Toughness.** Your Constitution score increases by 2, to a maximum of 20.

In addition, while attuned to the belt, you have a 50 percent chance each day at dawn of growing a full beard if you can grow one, or a thicker beard if you already have one.

If you aren't a dwarf or duergar, you gain the following additional benefits while wearing the belt:

**Darkvision.** You have [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] with a range of 60 feet.
**Resilience.** You have [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to Poison damage. You also have Advantage on saving throws you make to avoid or end the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned]] condition.
