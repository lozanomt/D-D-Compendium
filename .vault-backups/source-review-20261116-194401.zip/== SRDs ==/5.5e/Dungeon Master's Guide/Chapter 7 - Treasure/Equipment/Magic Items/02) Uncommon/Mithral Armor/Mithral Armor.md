---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Mithral Armor [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Armor|(Varies)]]
*Armor (any Medium or Heavy, except [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Hide Armor]]), Uncommon*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

This armor weighs half as much as it normally would and can be worn under regular clothes. In addition, if the armor normally imposes [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage]] on Dexterity ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]]) checks or has a Strength requirement, the mithral version of the armor does not.
###### Applicable Armor
| Name                           |  Type  |            AC             | Strength | Stealth |
| ------------------------------ | :----: | :-----------------------: | :------: | :-----: |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Chain Mail]]  | Medium | 13 + Dex modifier (max 2) |    -     |    -    |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Scale Mail]]  | Medium | 14 + Dex modifier (max 2) |    -     |    -    |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Half Plate]]  | Medium | 14 + Dex modifier (max 2) |    -     |    -    |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Chain Shirt]] | Medium | 15 + Dex modifier (max 2) |    -     |    -    |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Ring Mail]]   | Heavy  |            14             |    -     |    -    |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Breastplate]] | Heavy  |            16             |    -     |    -    |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Splint]]      | Heavy  |            17             |    -     |    -    |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Plate]]       | Heavy  |            18             |    -     |    -    |
