---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: f85bb9d9-2a23-5e39-b802-97d7adb8fa4d
entity_type: character-option
source_ids: ["phb-2024"]
---

# Nature's Sanctuary

![[== SRDs ==/Attachments/Artwork/phb-p088-circle-of-the-land.png|320]]

As a [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action, you can expend a use of your [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Druid/Wild Shape|Wild Shape]] and cause spectral trees and vines to appear in a 15-foot [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cube|Cube]] on the ground within 120 feet of yourself. They last there for 1 minute or until you have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition or die. You and your allies have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Half Cover|Half Cover]] while in that area, and your allies gain the current [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Resistance|Resistance]] of your [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Druid/Circle of the Land/Nature's Ward|Nature's Ward]] while there. As a Bonus Action, you can move the Cube up to 60 feet to ground within 120 feet of yourself.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=87|Player’s Handbook (2024), PDF page 87]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=88|Player’s Handbook (2024), PDF page 88]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=89|Player’s Handbook (2024), PDF page 89]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
