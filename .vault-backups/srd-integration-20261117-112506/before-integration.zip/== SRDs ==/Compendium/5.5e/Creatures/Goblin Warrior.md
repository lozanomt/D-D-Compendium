---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 24f0827f-bab3-5612-be0f-1a54f4d20785
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Goblin Warrior
> 
> *Small Fey (Goblinoid), Chaotic Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p145-goblin-boss.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +2 (12)  
> **HP** 10 (3d6)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 8 | -1 | -1 | **Dex** | 15 | +2 | +2 | **Con** | 10 | +0 | +0 |
> | **Int** | 10 | +0 | +0 | **Wis** | 8 | -1 | -1 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6  
> **Gear** Leather Armor, Scimitar, Shield, Shortbow  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** Common, Goblin  
> **CR** 1/4 (XP 50; PB +2)  
> 
> ### Actions
> 
> ***Scimitar.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Slashing damage, plus 2 (1d4) Slashing damage if the attack roll had Advantage.
> 
> ***Shortbow.*** *Ranged Attack Roll:* +4, range 80/320 ft. *Hit:* 5 (1d6 + 2) Piercing damage, plus 2 (1d4) Piercing damage if the attack roll had Advantage.
> 
> ### Bonus Actions
> 
> ***Nimble Escape.*** The goblin takes the Disengage or Hide action.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
