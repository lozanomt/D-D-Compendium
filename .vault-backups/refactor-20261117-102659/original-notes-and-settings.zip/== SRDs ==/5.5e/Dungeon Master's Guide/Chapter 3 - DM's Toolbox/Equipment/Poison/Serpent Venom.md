---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Serpent Venom [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Equipment/Poison/Serpent Venom|(200 GP)]]
*[[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Rules/Properties/Poison/Injury|Injury]] Poison*

![[Placeholder.png|320]]


A creature subjected to Serpent Venom must succeed on a DC 11 Constitution saving throw, taking 10 (3d6) Poison damage on a failed save or half as much damage on a successful one.
