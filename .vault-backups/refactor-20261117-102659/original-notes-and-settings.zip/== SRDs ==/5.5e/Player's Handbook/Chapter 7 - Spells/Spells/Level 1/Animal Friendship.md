---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Animal Friendship
*Level 1 Enchantment (Bard, Druid, Ranger)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 30 feet
**Components:** V, S, M (a morsel of food)
**Duration:** 24 hours

Target a Beast that you can see within range. The target must succeed on a Wisdom saving throw or have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Charmed|Charmed]] condition for the duration. If you or one of your allies deals damage to the target, the spells ends.

***Using a Higher-Level Spell Slot.*** You can target one additional Beast for each spell slot level above 1.
