---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [321, 322]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Wand of Binding
*Wand, Rare*

![[Placeholder.png|320]]

**Attunement:** Yes

The [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Arcane Focus/Wand|wand]] has 7 charges. While holding it, expend 2 charges to cast [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Hold Person|Hold Person]] or 5 charges to cast [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Hold Monster|Hold Monster]] (save DC 17). It regains 1d6 + 1 expended charges daily at dawn. If you expend its last charge, roll 1d20; on a 1, the wand crumbles into ashes and is destroyed.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=321|p. 318 (PDF page 321)]]; [[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=322|p. 319 (PDF page 322)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
