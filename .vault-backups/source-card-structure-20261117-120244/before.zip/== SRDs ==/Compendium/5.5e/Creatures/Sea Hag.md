---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 8eab625c-5ecd-5648-845b-5027972fe3e7
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [322]
---

> [!statblock]
> ## Sea Hag
> 
> *Medium Fey, Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p273-sea-hag.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +1 (11)  
> **HP** 52 (7d8 + 21)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 16 | +3 | +3 | **Dex** | 13 | +1 | +1 | **Con** | 16 | +3 | +3 |
> | **Int** | 12 | +1 | +1 | **Wis** | 12 | +1 | +1 | **Cha** | 13 | +1 | +1 |
> 
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** Common, Giant, Primordial (Aquan)  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Amphibious.*** The hag can breathe air and water.
> 
> ***Coven Magic.*** While within 30 feet of at least two hag allies, the hag can cast one of the following spells, requiring no Material components, using the spell's normal casting time, and using Intelligence as the spellcasting ability (spell save DC 11): *Augury*, *Find Familiar*, *Identify*, *Locate Object*, *Scrying*, or *Unseen Servant*. The hag must finish a Long Rest before using this trait to cast that spell again.
> 
> ***Vile Appearance.*** *Wisdom Saving Throw:* DC 11, any Beast or Humanoid that starts its turn within 30 feet of the hag and can see the hag's true form. *Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]] condition until the start of its next turn. *Success:* The target is immune to this hag's Vile Appearance for 24 hours.
> 
> ### Actions
> 
> ***Claw.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 10 (2d6 + 3) Slashing damage.
> 
> ***Death Glare (Recharge 5-6).*** *Wisdom Saving Throw:* DC 11, one [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]] creature the hag can see within 30 feet. *Failure:* If the target has 20 Hit Points or fewer, it drops to 0 Hit Points. Otherwise, the target takes 13 (3d8) Psychic damage.
> 
> ***Illusory Appearance.*** The hag casts *Disguise Self*, using Constitution as the spellcasting ability (spell save DC 13). The spell's duration is 24 hours.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=322|SRD 5.2.1, p. 322]] — matches the existing entry.
