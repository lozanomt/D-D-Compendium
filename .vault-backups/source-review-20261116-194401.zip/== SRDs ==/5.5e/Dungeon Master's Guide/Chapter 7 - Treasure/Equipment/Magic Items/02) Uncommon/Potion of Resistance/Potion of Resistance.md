---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Potion of Resistance [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Potion of Resistance/Potion of Resistance|(200 GP)]]
*Potion, Uncommon*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

When you drink this potion, you have [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to one type of damage for 1 hour. The DM chooses the type or determines it randomly by rolling on the following table.

| 1d10 | Damage Type |
| :--: | ----------- |
|  1   | Acid        |
|  2   | Cold        |
|  3   | Fire        |
|  4   | Force       |
|  5   | Lightning   |
|  6   | Necrotic    |
|  7   | Poison      |
|  8   | Psychic     |
|  9   | Radiant     |
|  10  | Thunder     |
