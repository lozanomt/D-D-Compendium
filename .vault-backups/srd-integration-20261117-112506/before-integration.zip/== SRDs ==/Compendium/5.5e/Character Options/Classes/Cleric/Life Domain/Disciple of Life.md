---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 413c9bad-748e-5330-8543-5c3803cf78e3
entity_type: character-option
source_ids: ["phb-2024"]
---

# Disciple of Life

![[== SRDs ==/Attachments/Artwork/phb-p076-life-domain.png|320]]

When a spell you cast with a spell slot restores [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] to a creature, that creature regains additional Hit Points on the turn you cast the spell. The additional Hit Points equal 2 plus the spell slot’s level.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=76|Player’s Handbook (2024), PDF page 76]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=77|Player’s Handbook (2024), PDF page 77]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
