---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Superior Defense

![[phb-p103-monk.png|320]]

At the start of your turn, you can expend 3 Focus Points to bolster yourself against harm for 1 minute or until you have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition. During that time, you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to all damage except Force damage.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=104|Player’s Handbook (2024), PDF page 104]]
