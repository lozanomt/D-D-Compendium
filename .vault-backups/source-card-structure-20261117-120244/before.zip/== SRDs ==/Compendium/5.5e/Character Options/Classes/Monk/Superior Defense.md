---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 96f0a392-86ff-5746-8d3c-2f6c90922c08
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [52]
---

# Superior Defense

![[== SRDs ==/Attachments/Artwork/phb-p103-monk.png|320]]

At the start of your turn, you can expend 3 Focus Points to bolster yourself against harm for 1 minute or until you have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition. During that time, you have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Resistance|Resistance]] to all damage except Force damage.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=104|Player’s Handbook (2024), PDF page 104]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

At the start of your turn, you can expend 3 Focus Points to bolster yourself against harm for 1 minute or until you have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.

During that time, you have Resistance to all damage except Force damage.

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=52|SRD 5.2.1, p. 52]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=52|SRD 5.2.1, p. 52]]
