---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Rolling Stone
*Deadly Trap (Levels 11 - 16) or Nuisance Trap (Levels 17 - 20)*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Trigger:** A creature moves onto a pressure plate
**Duration:** Until the stone stops rolling

When a creature moves onto a hidden pressure plate, a 5-foot-radius orb of solid stone is released from a secret compartment and begins to roll. The stone and all creatures nearby roll [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative]]; the stone gets a +8 bonus on its Initiative roll.

On its turn, the stone moves 60 feet in one direction, changing course if redirected by an obstacle. The stone can move through creatures’ spaces, and creatures can move through the stone’s space, treating it as [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Difficult Terrain]]. Whenever the stone enters a creature’s space for the first time on a turn or a creature enters the stone’s space while the stone is rolling, that creature must succeed on a DC 15 Dexterity saving throw or take 55 (10d10) Bludgeoning damage and have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone]] condition.

The stone stops when it hits a wall or similar barrier. It can’t go around corners, but creative dungeon builders incorporate curving turns into nearby passages that allow the stone to keep moving.

***Detect and Disarm.*** As a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Study]] action, a creature can examine the section of floor that forms the pressure plate and make a DC 15 Intelligence ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Investigation]]) check, deducing the pressure plate’s function on a successful check. Wedging an [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Iron Spikes|Iron Spike]] or a similar object under the pressure plate prevents the trap from triggering.

***Destroy the Stone.*** The stone is a Large object that has AC 17, HP 100, a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Damage Threshold]] of 10, and [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Immunity]] to Poison and Psychic damage.

***Slow the Stone.*** As an action, a creature can try to slow down the stone with a DC 20 Strength ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Athletics]]) check. If the check is successful, the distance the stone moves on its turn is reduced by 15 feet. If that distance drops to 0, it stops moving and is no longer a threat.
