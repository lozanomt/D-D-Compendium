---
type: spell-reference
coverage: source-reference
level: 3
school: Conjuration
rules_revision: "2024"
classes:
  - Druid
  - Ranger
  - Warlock
  - Wizard
tags:
  - rules/spell-reference
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Summon Fey

![[Placeholder.png|320]]


**Level 3 · Conjuration**

## Rules reference

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=172|Handbook class spell-list entry]]

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=242|Open the handbook’s spell descriptions]] and search for **Summon Fey** for the complete casting time, range, components, duration, and effects. This note supplies a source reference, not a transcription of the spell.

## Class lists

[[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Druid/Druid|Druid]] · [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Ranger|Ranger]] · [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Warlock|Warlock]] · [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Wizard/Wizard|Wizard]]
