---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Adamantine Armor [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Armor|(Varies)]]
*Armor (any Medium or Heavy, except [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Hide Armor]]), Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p230-adamantine-armor.png|320]]


**Attunement:** No

While you're wearing this armor, any [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Critical Hit]] against you becomes a normal hit.
###### Applicable Armor
|               Name                |  Type  |            AC             |  Strength   |     Stealth      |
| ------------------------------- | :----: | :-----------------------: | :---------: | :--------------: |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Chain Shirt]] | Medium | 13 + Dex modifier (max 2) |      -      |        -         |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Scale Mail]]  | Medium | 14 + Dex modifier (max 2) |      -      | [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage]] |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Breastplate]] | Medium | 14 + Dex modifier (max 2) |      -      |        -         |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Half Plate]]  | Medium | 15 + Dex modifier (max 2) |      -      | [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage]] |
|  [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Ring Mail]]  | Heavy  |            14             |      -      | [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage]] |
| [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Chain Mail]]  | Heavy  |            16             | Strength 13 | [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage]] |
|   [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Splint]]    | Heavy  |            17             | Strength 15 | [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage]] |
|    [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Plate]]    | Heavy  |            18             | Strength 15 | [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage]] |
