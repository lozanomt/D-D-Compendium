---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: cf4adc08-0dd7-51cf-b083-81de0189e1fd
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Piranha
> 
> *Tiny Beast, Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +3 (13)  
> **HP** 1 (1d4 - 1)  
> **Speed** 5 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 2 | -4 | -4 | **Dex** | 16 | +3 | +3 | **Con** | 9 | -1 | -1 |
> | **Int** | 1 | -5 | -5 | **Wis** | 7 | -2 | -2 | **Cha** | 2 | -4 | -4 |
> 
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 8  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Traits
> 
> ***Water Breathing.*** The piranha can breathe only underwater.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5 (with Advantage if the target doesn't have all its Hit Points), reach 5 ft. *Hit:* 1 Piercing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
