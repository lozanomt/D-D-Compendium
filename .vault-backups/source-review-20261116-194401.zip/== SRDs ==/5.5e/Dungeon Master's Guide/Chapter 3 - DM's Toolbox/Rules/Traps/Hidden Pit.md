---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Hidden Pit
*Nuisance Trap (Levels 1 - 4)*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Trigger:** A creature moves onto the pit's lid
**Duration:** Instantaneous

This 10-foot-deep pit has a hinged lid constructed from material identical to the surrounding floor. When a creature moves onto the lid, it swings open like a trapdoor, causing the creature to fall into the
pit. The lid remains open thereafter. A creature that falls into the pit takes 3 (1d6) Bludgeoning damage from the fall.

***Detect and Disarm.*** As a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Study]] action, a creature can examine the section of floor that forms the pit’s lid and make a DC 15 Intelligence ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Investigation]]) check, detecting the pit on a successful check. Once the pit is detected, an [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Iron Spikes|Iron Spike]] or a similar object can be wedged between the pit’s lid and the surrounding floor to prevent the lid from opening, thereby making it safe to cross. The cover can also be held shut using *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Arcane Lock]]* or similar magic.

***Escape.*** A creature needs a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb Speed]], climbing gear, or magic such as *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Spider Climb]]* to scale the pit’s smooth walls. You can make the pit easier to escape by adding cracks in the walls big enough to serve as handholds and footholds.

***At Higher Levels.*** You can scale the trap for higher levels by increasing the pit’s depth and damage, as shown in the following table.

| Levels  | Pit Depth | Bludgeoning Damage |
| :-----: | :-------: | :----------------: |
| 5 - 10  |  30 feet  |      10 (3d6)      |
| 11 - 16 |  60 feet  |      21 (6d6)      |
| 17 - 20 | 120 feet  |     42 (12d6)      |
