---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Quickened Spell

![[phb-p141-sorcerer.png|320]]

*Cost:* 2 Sorcery Points

When you cast a spell that has a casting time of an action, you can spend 2 Sorcery Points to change the casting time to a Bonus Action for this casting. You can’t modify a spell in this way if you’ve already cast a level 1+ spell on the current turn, nor can you cast a level 1+ spell on this turn after modifying a spell in this way.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=142|Player’s Handbook (2024), PDF page 142]]
