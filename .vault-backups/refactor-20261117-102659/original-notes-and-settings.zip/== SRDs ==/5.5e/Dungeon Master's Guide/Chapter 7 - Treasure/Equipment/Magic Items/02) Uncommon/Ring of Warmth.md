---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [299]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Ring of Warmth
*Ring, Uncommon*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p299-ring-of-warmth.png|320]]

**Attunement:** Yes

Whenever you take Cold damage while wearing the ring, reduce that damage by 2d8. In addition, you and everything you wear and carry are unharmed by temperatures of 0 degrees Fahrenheit or lower.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=299|p. 296 (PDF page 299)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
