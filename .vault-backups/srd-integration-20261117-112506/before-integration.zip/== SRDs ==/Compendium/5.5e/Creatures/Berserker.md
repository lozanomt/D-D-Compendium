---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 0e0eb778-23c4-5780-8989-53dd6fa5b418
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Berserker
> 
> *Medium or Small Humanoid, Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p039-berserker.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +1 (11)  
> **HP** 67 (9d8 + 27)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 16 | +3 | +3 | **Dex** | 12 | +1 | +1 | **Con** | 17 | +3 | +3 |
> | **Int** | 9 | -1 | -1 | **Wis** | 11 | +0 | +0 | **Cha** | 9 | -1 | -1 |
> 
> **Gear** Greataxe, Hide Armor  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Common  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Bloodied Frenzy.*** While Bloodied, the berserker has Advantage on attack rolls and saving throws.
> 
> ### Actions
> 
> ***Greataxe.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 9 (1d12 + 3) Slashing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
