---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Antilife Shell
*Level 5 Abjuration (Druid)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Self
**Components:** V, S
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 hour

An aura extends from you in a 10-foot [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Emanation|Emanation]] for the duration. The aura prevents creatures other than Constructs and Undead from passing or reaching through it. An affected creature can cast spells or make attacks with Ranged or [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Reach|Reach]] weapons through the barrier.

If you move so that an affected creature is forced to pass through the barrier, the spell ends.
