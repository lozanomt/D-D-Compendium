---
source_pdf_pages: [277]
review_status: "rules-checked-against-page-image"
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Fire Shield
*Level 4 Evocation (Druid, Sorcerer, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a bit of phosphorus or a firefly)
**Duration:** 10 minutes

Wispy flames wreathe your body for the duration, shedding [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Bright Light|Bright Light]] in a 10-foot radius and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Dim Light|Dim Light]] for an additional 10 feet.

The flames provide you with a warm shield or a chill shield, as you choose. The warm shield grants you [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to Cold damage, and the chill shield grants you Resistance to Fire damage.

In addition, whenever a creature within 5 feet of you hits you with a melee attack roll, the shield erupts with flame. The attacker takes 2d8 Fire damage from a warm shield or 2d8 Cold damage from a chill shield.

## Source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=277|Player's Handbook, p. 274 (PDF page 277)]]
