---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [299]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Ring of X-ray Vision
*Ring, Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p300-ring-of-x-ray-vision.png|320]]

**Attunement:** Yes

While wearing the ring, take a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action to gain X-ray vision with a 30-foot [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Range|range]] for 1 minute. Solid objects in that radius appear transparent to you and don't block [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Light|light]] from passing through them. You can see through 1 foot of stone, 1 inch of common metal, or up to 3 feet of wood or dirt. Thicker substances and thin sheets of lead block the vision.

Each time you use this property again before taking a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]], make a DC 15 Constitution saving throw or gain 1 [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]] level.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=299|p. 296 (PDF page 299)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
