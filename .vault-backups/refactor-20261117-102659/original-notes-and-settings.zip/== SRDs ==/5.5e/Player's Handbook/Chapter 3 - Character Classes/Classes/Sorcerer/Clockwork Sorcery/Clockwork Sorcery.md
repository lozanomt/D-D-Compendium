---
type: subclass
class: Sorcerer
rules_revision: "2024"
reference_style: summary
tags:
  - rules/subclass
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Clockwork Sorcery

![[phb-p150-clockwork-sorcery.png|320]]


**Class:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Sorcerer/Sorcerer|Sorcerer]]

A handbook reference summary. Use the linked PDF for complete wording, spell/resource tables, targeting restrictions, and exceptions.

## Features

### Level 3: Clockwork Spells

Always prepare the source table’s spells as you reach their levels, including Aid, Alarm, Lesser Restoration, Protection from Evil and Good, Dispel Magic, Protection from Energy, Freedom of Movement, Summon Construct, Greater Restoration, and Wall of Force.

### Level 3: Restore Balance

React before a visible creature within 60 feet rolls with Advantage or Disadvantage to prevent either from affecting that roll. Uses equal Charisma modifier, minimum one; recover on a Long Rest.

### Level 6: Bastion of Law

A Magic action spends 1–5 Sorcery Points to ward you or a visible creature within 30 feet with that many d8s. The recipient spends the dice to reduce damage. Lasts until your Long Rest or reuse.

### Level 14: Trance of Order

A Bonus Action grants one minute in which attacks against you cannot benefit from Advantage and your D20 Tests treat 9 or lower as 10. Refresh on a Long Rest; 5 Sorcery Points restore it.

### Level 18: Clockwork Cavalcade

A Magic action summons spirits in a 30-foot Cube: distribute up to 100 healing, repair damaged objects, and end level-6-or-lower spells on chosen creatures and objects. Refresh on a Long Rest; 7 Sorcery Points restore it.

## Handbook

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=149|PDF page 149]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=150|PDF page 150]]
