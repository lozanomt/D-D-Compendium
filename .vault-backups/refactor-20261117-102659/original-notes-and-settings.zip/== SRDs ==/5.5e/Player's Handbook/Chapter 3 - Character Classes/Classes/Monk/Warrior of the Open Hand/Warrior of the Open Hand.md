---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Warrior of the Open Hand

*Master Unarmed Combat Techniques*

![[phb-p110-warrior-of-the-open-hand.png|320]]


Warriors of the Open Hand are masters of unarmed combat. They learn techniques to push and trip their opponents and manipulate their own energy to protect themselves from harm.

#### Level 3: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Warrior of the Open Hand/Open Hand Technique|Open Hand Technique]]
Whenever you hit a creature with an attack granted by your Flurry of Blows, you can impose one of the following effects on that target.

***Addle.*** The target can’t make [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Opportunity Attacks|Opportunity Attacks]] until the start of its next turn.

***Push.*** The target must succeed on a Strength saving throw or be pushed up to 15 feet away from you.

***Topple.*** The target must succeed on a Dexterity saving throw or have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.
#### Level 6: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Warrior of the Open Hand/Wholeness of Body|Wholeness of Body]]
You gain the ability to heal yourself. As a Bonus Action, you can roll your Martial Arts die. You regain a number of [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]] equal to the number rolled plus your Wisdom modifier (minimum of 1 Hit Point regained). You can use this feature a number of times equal to your Wisdom modifier (minimum of once), and you regain all expended uses when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].
#### Level 11: Fleet Step
When you take a Bonus Action other than Step of the Wind, you can also use Step of the Wind immediately after that Bonus Action.
#### Level 17: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Monk/Warrior of the Open Hand/Quivering Palm|Quivering Palm]]
You gain the ability to set up lethal vibrations in someone’s body. When you hit a creature with an [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Unarmed Strike|Unarmed Strike]], you can expend 4 Focus Points to start these imperceptible vibrations, which last for a number of days equal to your Monk level. The vibrations are harmless unless you take an action to end them. Alternatively, when you take the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] action on your turn, you can forgo one of the attacks to end the vibrations. To end them, you and the target must be on the same plane of existence. When you end them, the target must make a Constitution saving throw, taking 10d12 Force damage on a failed save or half as much damage on a successful one.

You can have only one creature under the effect of this feature at a time. You can end the vibrations harmlessly (no action required).

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=110|Player’s Handbook (2024), PDF page 110]]
