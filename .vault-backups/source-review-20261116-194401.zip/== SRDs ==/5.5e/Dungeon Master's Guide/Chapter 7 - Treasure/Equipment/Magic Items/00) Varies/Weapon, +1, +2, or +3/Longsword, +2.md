---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Longsword, +2 [[Longsword, +2 |(4,015 GP)]]
*Weapon ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Longsword]]), Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p220-longsword.png|320]]


**Attunement** No

You have a +2 bonus to attack rolls and damage rolls made with this magic weapon.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Longsword|clean no-title]]
