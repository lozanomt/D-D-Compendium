---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Darkness

![[Placeholder.png|320]]


An area of Darkness is [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Heavily Obscured|Heavily Obscured]].
