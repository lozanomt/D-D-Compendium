---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Wind Fan [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Wind Fan|(400 GP)]]
*Wondrous Item, Uncommon*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p328-weapon-of-warning.png|320]]


**Attunement:** No

While holding this fan, you can cast *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Gust of Wind|Gust of Wind]]* (save DC 13) from it. Each subsequent time the fan is used before the next dawn, it has a cumulative 20 percent chance of not working; if the fan fails to work, it tears into useless, nonmagical tatters.
