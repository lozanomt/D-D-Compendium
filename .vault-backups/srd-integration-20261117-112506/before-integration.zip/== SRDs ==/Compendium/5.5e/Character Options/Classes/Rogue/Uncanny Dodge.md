---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 46ad9fc1-dd89-5a41-83e1-cc986a92d553
entity_type: character-option
source_ids: ["phb-2024"]
---

# Uncanny Dodge

![[== SRDs ==/Attachments/Artwork/phb-p131-rogue.png|320]]

When an attacker that you can see hits you with an attack roll, you can take a Reaction to halve the attack’s damage against you (round down).

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=132|Player’s Handbook (2024), PDF page 132]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
