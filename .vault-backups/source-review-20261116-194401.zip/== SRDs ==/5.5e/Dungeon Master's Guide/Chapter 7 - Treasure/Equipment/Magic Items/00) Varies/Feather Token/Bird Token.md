---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Bird Token [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Feather Token/Bird Token|(2,000 GP)]]
*Wondrous Item, Rare*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

This object looks like a feather. You can take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action to toss the token 5 feet into the air. The token disappears and an enormous, multicolored bird takes its place. The bird has the statistics of a [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Roc]], but it can’t attack. It obeys your simple commands and can carry up to 500 pounds while flying at its maximum speed (16 miles per hour for a maximum of 144 miles per day, with a 1-hour rest for every 3 hours of flying) or 1,000 pounds at half that speed. The bird disappears after flying its maximum distance for a day or if it drops to 0 [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]]. You can dismiss the bird as a Magic action.

---
![[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Roc|no-title clean]]
