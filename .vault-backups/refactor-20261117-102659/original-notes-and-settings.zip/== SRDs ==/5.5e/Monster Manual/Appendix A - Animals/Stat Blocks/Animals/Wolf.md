---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Wolf
> 
> *Medium Beast, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/phb-p362-wolf.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 11 (2d8 + 2)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 15 | +2 | +2 | **Con** | 12 | +1 | +1 |
> | **Int** | 3 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 6 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +4  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** None  
> **CR** 1/4 (XP 50; PB +2)  
> 
> ### Traits
> 
> ***Pack Tactics.*** The wolf has Advantage on attack rolls against a creature if at least one of the wolf's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Piercing damage. If the target is a Medium or smaller creature, it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.
