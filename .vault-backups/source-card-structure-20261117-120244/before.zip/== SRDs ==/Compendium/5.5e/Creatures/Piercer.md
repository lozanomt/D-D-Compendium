---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 4c936a6f-b4a2-50ba-9406-3c35a3fe3554
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Piercer
> *Size Type (Tag), Alignment*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p242-piercer.png|320]]
> 
> 
> **AC** # **Initiative** +# (#)  
> **HP** # (#d# + #)  
> **Speed** # ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Burrowing|Burrow]] # ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] # ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] # ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] # ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | # | +# | +# | **Dex** | # | +# | +# | **Con** | # | +# | +# |
> | **Int** | # | +# | +# | **Wis** | # | +# | +# | **Cha** | # | +# | +# |
> 
> **Skills** Skill +#, Skill +#  
> **Vulnerabilities** Damage, Damage  
> **Resistances** Damage, Damage  
> **Immunities** Damage; Condition  
> **Gear** Item, Item  
> **Senses** Sense # ft., Sense # ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] #  
> **Languages** Language, Telepathy # ft.  
> **CR** # (XP #, or # in lair; PB +#)  
> 
> Details for this creature can be found in the *Monster Manual*.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
