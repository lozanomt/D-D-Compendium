---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Battleaxe [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Battleaxe|(10 GP)]]
*Martial Melee*

![[phb-p220-battleaxe.png|320]]


**Mastery:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Mastery/Topple|Topple]] **Weight:** 4 lb.
**Damage:** 1d8 Slashing
**Properties:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Versatile|Versatile]] (1d10)
