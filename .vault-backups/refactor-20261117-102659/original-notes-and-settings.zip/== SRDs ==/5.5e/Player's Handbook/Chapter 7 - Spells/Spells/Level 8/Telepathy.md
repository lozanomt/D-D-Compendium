---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Telepathy

![[Placeholder.png|320]]

The details for this spell can be found in the *Player's Handbook*.
