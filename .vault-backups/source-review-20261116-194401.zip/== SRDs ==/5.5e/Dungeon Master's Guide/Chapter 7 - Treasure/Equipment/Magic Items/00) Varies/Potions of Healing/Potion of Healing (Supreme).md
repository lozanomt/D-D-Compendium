---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Potion of Healing (Supreme) [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Potions of Healing/Potion of Healing (Supreme)|(20,000 GP)]]
*Potion, Very Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p292-potion-of-healing.png|320]]


**Attunement:** No **Weight:** 0.5 lb

As a Bonus Action, you can drink it or administer it to another creature within 5 feet of yourself. The creature that drinks the magical red fluid in this vial regains 10d4 + 20 [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]]. The potion's red liquid glimmers when agitated.
