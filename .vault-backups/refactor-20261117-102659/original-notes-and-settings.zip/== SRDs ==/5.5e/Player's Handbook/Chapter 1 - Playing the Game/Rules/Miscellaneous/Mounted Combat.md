---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Mounted Combat

![[Placeholder.png|320]]


A willing creature that is at least one size larger than a rider and that has an appropriate anatomy can serve as a mount, using the following rules.

#### Mounting and Dismounting
During your move, you can mount a creature that is within 5 feet of you or dismount. Doing so costs an amount of movement equal to half your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]] (round down). For example, if your Speed is 30 feet, you spend 15 feet of movement to mount a horse.

#### Controlling a Mount
You can control a mount only if it has been trained to accept a rider. Domesticated horses, mules, and similar creatures have such training.

The [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]] of a controlled mount changes to match yours when you mount it. It moves on your turn as you direct it, and it has only three action options during that turn: [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Dash|Dash]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Disengage|Disengage]], and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Dodge|Dodge]]. A controlled mount can move and act even on the turn that you mount it.

In contrast, an independent mount - one that lets you ride but ignores your control - retains its place in the Initiative order and moves and acts as it likes.

#### Falling Off
If an effect is about to move your mount against its will while you’re on it, you must succeed on a DC 10 Dexterity saving throw or fall off, landing with the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition in an unoccupied space within 5 feet of the mount.

While mounted, you must make the same save if you’re knocked Prone or the mount is.
