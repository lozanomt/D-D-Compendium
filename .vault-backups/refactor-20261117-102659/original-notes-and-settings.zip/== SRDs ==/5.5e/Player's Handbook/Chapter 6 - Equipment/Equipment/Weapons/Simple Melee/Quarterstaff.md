---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Quarterstaff [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Simple Melee/Quarterstaff|(2 SP)]]
*Simple Melee*

![[phb-p219-quarterstaff.png|320]]


**Mastery:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Mastery/Topple|Topple]] **Weight:** 4 lb.
**Damage:** 1d6 Bludgeoning
**Properties:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Versatile|Versatile]] (1d8)
