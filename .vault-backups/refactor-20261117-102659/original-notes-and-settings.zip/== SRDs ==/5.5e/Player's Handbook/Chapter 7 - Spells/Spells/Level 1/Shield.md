---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Shield
*Level 1 Abjuration (Sorcerer, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Reaction, which you take when you are hit by an attack roll or targeted by the *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Magic Missile|Magic Missile]]* spell
**Range:** Self
**Components:** V, S
**Duration:** 1 round

An imperceptible barrier of magical force protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from *Magic Missile*.
