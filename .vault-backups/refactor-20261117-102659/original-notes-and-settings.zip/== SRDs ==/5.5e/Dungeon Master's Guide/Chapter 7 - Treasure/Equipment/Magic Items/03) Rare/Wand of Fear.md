---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [322]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Wand of Fear
*Wand, Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p322-wand-of-enemy-detection.png|320]]

**Attunement:** Yes

The [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Arcane Focus/Wand|wand]] has 7 charges. While holding it, expend 1 charge to cast [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Command|Command]] (only the flee or grovel options) or 3 charges to cast [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Fear|Fear]] with a 60-foot [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Cone|Cone]] (save DC 15). It regains 1d6 + 1 expended charges daily at dawn. If you expend its last charge, roll 1d20; on a 1, the wand crumbles into ashes and is destroyed.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=322|p. 319 (PDF page 322)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
