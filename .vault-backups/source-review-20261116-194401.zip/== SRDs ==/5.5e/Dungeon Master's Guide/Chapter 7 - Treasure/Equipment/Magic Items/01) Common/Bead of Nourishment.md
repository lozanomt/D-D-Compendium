---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Bead of Nourishment [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/01) Common/Bead of Nourishment|(50 GP)]]
*Wondrous Item, Common*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

This flavorless, gelatinous bead dissolves on your tongue and provides as much nourishment as 1 day of [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Rations]].
