---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Wolf Spider
> 
> *Medium Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/Monster Manual/Artwork/mm-p364-giant-wolf-spider.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +3 (13)  
> **HP** 11 (2d8 + 2)  
> **Speed** 40 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 12 | +1 | +1 | **Dex** | 16 | +3 | +3 | **Con** | 13 | +1 | +1 |
> | **Int** | 3 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 4 | -3 | -3 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +3, [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]] +7  
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight]] 10 ft., [[Darkvision]] 60 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 13  
> **Languages** None  
> **CR** 1/4 (XP 50; PB +2)  
> 
> ### Traits
> 
> ***Spider Climb.*** The spider can climb difficult surfaces, including along ceilings, without needing to make an ability check.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 5 (1d4 + 3) Piercing damage plus 5 (2d4) Poison damage.
