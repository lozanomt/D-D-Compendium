---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Prayer of Healing
*Level 2 Abjuration (Cleric, Paladin)*

![[Placeholder.png|320]]


**Casting Time:** 10 minutes
**Range:** 30 feet
**Components:** V
**Duration:** Instantaneous

Up to five creatures of your choice who remain within range for the spell's entire casting gain the benefits of a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short Rest]] and also regain 2d8 Hit Points. A creature can't be affected by this spell again until that creature finishes a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

***Using a Higher-Level Spell Slot.*** The healing increases by 1d8 for each spell slot level above 2.
