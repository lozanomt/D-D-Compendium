---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Scale Mail, +3 [[Scale Mail, +3 |(200,050 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Scale Mail]]), Legendary*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-scale-mail.png|320]]


**Attunement** No

You have a +3 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Scale Mail|clean no-title]]
