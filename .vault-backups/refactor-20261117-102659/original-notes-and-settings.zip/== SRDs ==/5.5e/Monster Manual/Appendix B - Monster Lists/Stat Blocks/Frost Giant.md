---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Frost Giant
> 
> *Huge Giant, Neutral Evil*
> 
> ![[mm-p126-frost-giant.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +2 (12)  
> **HP** 149 (13d12 + 65)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 23 | +6 | +6 | **Dex** | 9 | -1 | -1 | **Con** | 21 | +5 | +8 |
> | **Int** | 9 | -1 | -1 | **Wis** | 10 | +0 | +3 | **Cha** | 12 | +1 | +4 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Athletics|Athletics]] +9, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +3  
> **Immunities** Cold  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** Giant  
> **CR** 8 (XP 3,900; PB +3)  
> 
> ### Actions
> 
> ***Multiattack.*** The giant makes two attacks, using Frost Axe or Great Bow in any combination.
> 
> ***Frost Axe.*** *Melee Attack Roll:* +9, reach 10 ft. *Hit:* 19 (2d12 + 6) Slashing damage plus 9 (2d8) Cold damage.
> 
> ***Great Bow.*** *Ranged Attack Roll:* +9, range 150/600 ft. *Hit:* 17 (2d10 + 6) Piercing damage plus 7 (2d6) Cold damage, and the target's Speed decreases by 10 feet until the end of its next turn.
> 
> ### Bonus Actions
> 
> ***War Cry (Recharge 5-6).*** The giant or one creature of its choice that can see or hear it gains 16 (2d10 + 5) Temporary Hit Points and has Advantage on attack rolls until the start of the giant's next turn.
