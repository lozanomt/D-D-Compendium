---
tags:
  - condition
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Poisoned

![[Placeholder.png|320]]


While you have the Poisoned condition, you experience the following effect.

***Ability Checks and Attacks Affected.*** You have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on ability checks and attack rolls.
