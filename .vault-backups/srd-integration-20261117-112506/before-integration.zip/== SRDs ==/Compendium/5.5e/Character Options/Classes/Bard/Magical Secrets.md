---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 7cc886f8-68e0-5220-9ade-31eea6d7b973
entity_type: character-option
source_ids: ["phb-2024"]
---

# Magical Secrets

![[== SRDs ==/Attachments/Artwork/phb-p061-bard.png|320]]

You’ve learned secrets from various magical traditions. Whenever you reach a Bard level (including this level) and the Prepared Spells number in the Bard Features table increases, you can choose any of your new prepared spells from the [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Bard/Bard|Bard]], [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Cleric/Cleric|Cleric]], [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Druid/Druid|Druid]], and [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Wizard/Wizard|Wizard]] spell lists, and the chosen spells count as Bard spells for you. In addition, whenever you replace a spell prepared for this class, you can replace it with a spell from those lists.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=62|Player’s Handbook (2024), PDF page 62]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
