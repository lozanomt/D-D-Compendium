---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Centipede
> 
> *Small Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +2 (12)  
> **HP** 9 (2d6 + 2)  
> **Speed** 30 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 5 | -3 | -3 | **Dex** | 14 | +2 | +2 | **Con** | 12 | +1 | +1 |
> | **Int** | 1 | -5 | -5 | **Wis** | 7 | -2 | -2 | **Cha** | 3 | -4 | -4 |
> 
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight]] 30 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 8  
> **Languages** None  
> **CR** 1/4 (XP 50; PB +2)  
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 4 (1d4 + 2) Piercing damage, and the target has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned]] condition until the start of the centipede's next turn.
