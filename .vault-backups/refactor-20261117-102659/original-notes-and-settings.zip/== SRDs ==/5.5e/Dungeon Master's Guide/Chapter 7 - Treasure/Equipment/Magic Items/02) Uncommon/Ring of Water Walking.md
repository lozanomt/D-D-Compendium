---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [299]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Ring of Water Walking
*Ring, Uncommon*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p299-ring-of-water-walking.png|320]]

**Attunement:** No

While wearing the ring, you can cast [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Water Walk|Water Walk]] from it, targeting only yourself.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=299|p. 296 (PDF page 299)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
