---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: e0a1b4da-6f04-5d85-a46a-a2e856eec63d
entity_type: character-option
source_ids: ["phb-2024"]
---

# Sage

![[== SRDs ==/Attachments/Artwork/phb-p186-sage.png|320]]

**Ability Scores:** Constitution, Intelligence, Wisdom
**Feat:** [[== SRDs ==/Compendium/5.5e/Character Options/Feats/01) Origin Feats/Magic Initiate|Magic Initiate]] (Wizard)
**Skill Proficiencies** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana|Arcana]] and [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]]
**Tool Proficiency:** [[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Calligrapher's Supplies|Calligrapher's Supplies]]
**Equipment:** *Choose A or B:* (A) [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Quarterstaff|Quarterstaff]], [[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Calligrapher's Supplies|Calligrapher's Supplies]], [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Book|Book]] (history), [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Parchment|Parchment]] (8 sheets), [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Robe|Robe]], 8 GP; or (B) 50 GP

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Player's Handbook — Chapter 4 - Character Origins]]
