---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 4d480b38-8e47-5e4b-b65a-d276bb78365c
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [304]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Lich

## Monster Manual

> [!statblock]
> ### Lich
>
> *Medium Undead (Wizard), Neutral Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p197-lich.png|320]]
>
> **AC:** 20  
> **Initiative:** +17 (27)  
> **HP:** 315 (42d8 + 126)  
> **Speed:** 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +0 | **Dex** | 16 | +3 | +10 | **Con** | 16 | +3 | +10 |
> | **Int** | 21 | +5 | +12 | **Wis** | 14 | +2 | +9 | **Cha** | 16 | +3 | +3 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana|Arcana]] +19, [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]] +12, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Insight|Insight]] +9, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +9  
> **Resistances:** Cold, Lightning  
> **Immunities:** Necrotic, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Gear:** Component Pouch  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Truesight|Truesight]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 19  
> **Languages:** All  
> **CR:** 21 (XP 33,000, or 41,000 in lair; PB +7)  
>
> #### Traits
>
> ***Legendary Resistance (4/Day, or 5/Day in Lair).*** If the lich fails a saving throw, it can choose to succeed instead.
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> ***Spirit Jar.*** If destroyed, the lich reforms in 1d10 days if it has a spirit jar, reviving with all its Hit Points. The new body appears in an unoccupied space within the lich's lair.
>
> #### Actions
>
> ***Multiattack.*** The lich makes three attacks, using Eldritch Burst or Paralyzing Touch in any combination.
>
> ***Eldritch Burst.*** *Melee or Ranged Attack Roll:* +12, reach 5 ft. or range 120 ft. *Hit:* 31 (4d12 + 5) Force damage.
>
> ***Paralyzing Touch.*** *Melee Attack Roll:* +12, reach 5 ft. *Hit:* 15 (3d6 + 5) Cold damage, and the target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]] condition until the start of the lich's next turn.
>
> ***Spellcasting.*** The lich casts one of the following spells, using Intelligence as the spellcasting ability (spell save DC 20):
>
> - **At Will:** *Detect Magic*, *Detect Thoughts*, *Dispel Magic*, *Fireball* (level 5 version), *Invisibility*, *Lightning Bolt*  (level 5 version), *Mage Hand*, *Prestidigitation*
> - **2/Day Each:** *Animate Dead*, *Dimension Door*, *Plane Shift*
> - **1/Day Each:** *Chain Lightning*, *Finger of Death*, *Power Word Kill*, *Scrying*
>
> #### Reactions
>
> ***Protective Magic.*** The lich casts *Counterspell* or *Shield* in response to the spell's trigger, using the same spellcasting ability as Spellcasting.
>
> #### Legendary Actions
>
> *Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the lich can expend a use to take one of the following actions. The lich regains all expended uses at the start of each of its turns.*
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> ***Deathly Teleport.*** The lich teleports up to 60 feet to an unoccupied space it can see, and each creature within 10 feet of the space it left takes 11 (2d10) Necrotic damage.
>
> ***Disrupt Life.*** *Constitution Saving Throw:* DC 20, each creature that isn't an Undead in a 20-foot Emanation originating from the lich. *Failure:* 31 (9d6) Necrotic damage. *Success:* Half damage. *Failure or Success:* The lich can't take this action again until the start of its next turn.
>
> ***Frightening Gaze.*** The lich casts *Fear*, using the same spellcasting ability as Spellcasting. The lich can't take this action again until the start of its next turn.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1

> [!statblock]
> ### Lich
>
> *Medium Undead (Wizard), Neutral Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p197-lich.png|320]]
>
> **AC:** 20  
> **Initiative:** +17 (27)  
> **HP:** 315 (42d8 + 126)  
> **Speed:** 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +0 | **Dex** | 16 | +3 | +10 | **Con** | 16 | +3 | +10 |
> | **Int** | 21 | +5 | +12 | **Wis** | 14 | +2 | +9 | **Cha** | 16 | +3 | +3 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana|Arcana]] +19, [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]] +12, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Insight|Insight]] +9, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +9  
> **Resistances:** Cold, Lightning  
> **Immunities:** Necrotic, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Gear:** Component Pouch  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Truesight|Truesight]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 19  
> **Languages:** All  
> **CR:** 21 (XP 33,000, or 41,000 in lair; PB +7)  
>
> #### Traits
>
> ***Legendary Resistance (4/Day, or 5/Day in Lair).*** If the lich fails a saving throw, it can choose to succeed instead.
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> ***Spirit Jar.*** If destroyed, the lich reforms in 1d10 days if it has a spirit jar, reviving with all its Hit Points. The new body appears in an unoccupied space within the lich's lair.
>
> #### Actions
>
> ***Multiattack.*** The lich makes three attacks, using Eldritch Burst or Paralyzing Touch in any combination.
>
> ***Eldritch Burst.*** *Melee or Ranged Attack Roll:* +12, reach 5 ft. or range 120 ft. *Hit:* 31 (4d12 + 5) Force damage.
>
> ***Paralyzing Touch.*** *Melee Attack Roll:* +12, reach 5 ft. *Hit:* 15 (3d6 + 5) Cold damage, and the target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]] condition until the start of the lich's next turn.
>
> ***Spellcasting.*** The lich casts one of the following spells, using Intelligence as the spellcasting ability (spell save DC 20):
>
> - **At Will:** *Detect Magic*, *Detect Thoughts*, *Dispel Magic*, *Fireball* (level 5 version), *Invisibility*, *Lightning Bolt*  (level 5 version), *Mage Hand*, *Prestidigitation*
> - **2/Day Each:** *Animate Dead*, *Dimension Door*, *Plane Shift*
> - **1/Day Each:** *Chain Lightning*, *Finger of Death*, *Power Word Kill*, *Scrying*
>
> #### Reactions
>
> ***Protective Magic.*** The lich casts *Counterspell* or *Shield* in response to the spell's trigger, using the same spellcasting ability as Spellcasting.
>
> #### Legendary Actions
>
> *Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the lich can expend a use to take one of the following actions. The lich regains all expended uses at the start of each of its turns.*
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> ***Deathly Teleport.*** The lich teleports up to 60 feet to an unoccupied space it can see, and each creature within 10 feet of the space it left takes 11 (2d10) Necrotic damage.
>
> ***Disrupt Life.*** *Constitution Saving Throw:* DC 20, each creature that isn't an Undead in a 20-foot Emanation originating from the lich. *Failure:* 31 (9d6) Necrotic damage. *Success:* Half damage. *Failure or Success:* The lich can't take this action again until the start of its next turn.
>
> ***Frightening Gaze.*** The lich casts *Fear*, using the same spellcasting ability as Spellcasting. The lich can't take this action again until the start of its next turn.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=304|SRD 5.2.1, p. 304]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
