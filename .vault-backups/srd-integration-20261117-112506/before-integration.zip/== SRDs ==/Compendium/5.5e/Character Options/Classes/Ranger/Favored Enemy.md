---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: cd6ea123-71e9-5e5b-86d6-3037420ba64b
entity_type: character-option
source_ids: ["phb-2024"]
---

# Favored Enemy

![[== SRDs ==/Attachments/Artwork/phb-p121-ranger.png|320]]

You always have the *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hunter's Mark|Hunter's Mark]]* spell prepared. You can cast it twice without expending a spell slot, and you regain all expended uses of this ability when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

The number of times you can cast the spell without a spell slot increases when you reach certain Ranger levels.

***Relentless Hunter.*** At Ranger level 13, taking damage can't break your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration|Concentration]] on *Hunter's Mark*.

***Precise Hunter.*** At Ranger level 17, you have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on attack rolls against the creature currently marked by your *Hunter's Mark*.

***Foe Slayer.*** At Ranger level 20, the damage die of your *Hunter's Mark* is a d10 rather than a d6

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=122|Player’s Handbook (2024), PDF page 122]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
