---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [291]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Potion of Growth
*Potion, Uncommon*

![[Placeholder.png|320]]

**Attunement:** No

Drinking the potion gives you the enlarge effect of [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Enlarge + Reduce|Enlarge/Reduce]] for 10 minutes, without requiring [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]].

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=291|p. 288 (PDF page 291)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
