---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Hit Point Dice

![[Placeholder.png|320]]


Hit Point Dice, or Hit Dice for short, help determine a player character’s [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Point]] maximum. Most monsters also have Hit Dice. A creature can spend Hit Dice during a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short Rest]] to regain Hit Points.
