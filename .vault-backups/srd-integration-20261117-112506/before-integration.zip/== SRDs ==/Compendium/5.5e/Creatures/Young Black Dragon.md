---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 421d4484-daeb-5f0e-8b0f-8b32e60c9234
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Young Black Dragon
> 
> *Large Dragon (Chromatic), Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p040-black-dragon-wyrmling.png|320]]
> 
> 
> **AC** 18 &emsp; **Initiative** +5 (15)  
> **HP** 127 (15d10 + 45)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 80 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 14 | +2 | +5 | **Con** | 17 | +3 | +3 |
> | **Int** | 12 | +1 | +1 | **Wis** | 11 | +0 | +3 | **Cha** | 15 | +2 | +2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +5  
> **Immunities** Acid  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages** Common, Draconic  
> **CR** 7 (XP 2,900; PB +3)  
> 
> ### Traits
> 
> ***Amphibious.*** The dragon can breathe air and water.
> 
> ### Actions
> 
> ***Multiattack.*** The dragon makes three Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +7, reach 10 ft. *Hit:* 9 (2d4 + 4) Slashing damage plus 3 (1d6) Acid damage.
> 
> ***Acid Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 14, each creature in a 30-foot-long, 5-footwide Line. *Failure:* 49 (14d6) Acid damage. *Success:* Half damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
