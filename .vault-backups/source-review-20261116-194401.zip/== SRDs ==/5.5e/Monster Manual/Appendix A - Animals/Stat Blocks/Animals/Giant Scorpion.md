---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Scorpion
> 
> *Large Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]
> 
> 
> **AC** 15 **Initiative** +1 (11)  
> **HP** 52 (7d10 + 14)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 16 | +3 | +3 | **Dex** | 13 | +1 | +1 | **Con** | 15 | +2 | +2 |
> | **Int** | 1 | -5 | -5 | **Wis** | 9 | -1 | -1 | **Cha** | 3 | -4 | -4 |
> 
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight]] 60 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 9  
> **Languages** None  
> **CR** 3 (XP 700; PB +2)  
> 
> **Habitat** Desert  
> **Treasure** None  
> 
> ### Actions
> 
> ***Multiattack.*** The scorpion makes two Claw attacks and one Sting attack.
> 
> ***Claw.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 6 (1d6 + 3) Bludgeoning damage. If the target is a Large or smaller creature, it has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled]] condition (escape DC 13) from one of two claws.
> 
> ***Sting.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Piercing damage plus 11 (2d10) Poison damage.
