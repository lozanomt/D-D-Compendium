---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Stroke of Luck

![[phb-p131-rogue.png|320]]

You have a marvelous knack for succeeding when you need to. If you fail a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/D20 Test|D20 Test]], you can turn the roll into a 20.

Once you use this feature, you can’t use it again until you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short]] or[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=132|Player’s Handbook (2024), PDF page 132]]
