---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Dim Light

![[Placeholder.png|320]]


An area with Dim Light is [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Lightly Obscured|Lightly Obscured]].
