---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: f85d86cf-f132-57bc-8d79-5801ad0cfdff
entity_type: creature
source_ids: ["mm-2025", "phb-2024", "srd-5.2.1"]
source_versions: ["Monster Manual", "Player's Handbook"]
srd_5_2_1_pages: [350]
---

# Giant Crab

One creature entry with separately labeled source versions. Each book’s chapter links to its own version.

## Monster Manual

> [!statblock]
> ### Giant Crab
> 
> *Medium Beast, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p358-giant-crab.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +1 (11)  
> **HP** 13 (3d8)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 13 | +1 | +1 | **Con** | 11 | +0 | +0 |
> | **Int** | 1 | -5 | -5 | **Wis** | 9 | -1 | -1 | **Cha** | 3 | -4 | -4 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +3  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 30 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** None  
> **CR** 1/8 (XP 25; PB +2)  
> 
> #### Traits
> 
> ***Amphibious.*** The crab can breathe air and water.
> 
> #### Actions
> 
> ***Claw.*** *Melee Attack Roll:* +3, reach 5 ft. *Hit:* 4 (1d6 + 1) Bludgeoning damage. If the target is a Medium or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 11) from one of two claws.

## Player's Handbook

> [!statblock]
> ### Giant Crab
>
> *Medium Beast, Unaligned*
>
> **AC** 15 &emsp; **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]]** +1 (11)  
> **HP** 13 (3d8)  
> **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]** 30 ft., Swim 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 13 | +1 | +1 | **Con** | 11 | +0 | +0 |
> | **Int** | 1 | -5 | -5 | **Wis** | 9 | -1 | -1 | **Cha** | 3 | -4 | -4 |
>
> **Skills** Stealth +3  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 30 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** None  
> **CR** 1/8 (XP 25; PB +2)  
>
> #### Traits
>
> ***Amphibious.*** The crab can breathe air and water.
>
> #### Actions
>
> ***Claw.*** *Melee [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack|Attack]] Roll:* +3, reach 5 ft. *Hit:* 4 (1d6 + 1) Bludgeoning damage. If the target is a Medium or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 11). The crab has two claws, each of which can grapple one target.

Source: [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=353|Player’s Handbook (2024), p. 350]].

[[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/Compendium/5.5e/Creatures/Giant Crab#Monster Manual|Monster Manual version]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Player's Handbook — Appendix B - Creature Stat Blocks]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=350|SRD 5.2.1, p. 350]] — matches the Monster Manual section.
