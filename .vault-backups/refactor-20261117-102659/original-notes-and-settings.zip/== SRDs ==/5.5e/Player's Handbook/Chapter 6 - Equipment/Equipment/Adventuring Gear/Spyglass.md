---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Spyglass [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Spyglass|(1,000 GP)]] 

![[Placeholder.png|320]]

Objects viewed through a Spyglass are magnified to twice their size.

**Weight:** 1 lb.
