---
tags:
  - condition
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Exhaustion

![[Placeholder.png|320]]


While you have the Exhaustion condition, you experience the following effects.

***Exhaustion Levels.*** This condition is cumulative. Each time you receive it, you gain 1 Exhaustion level. You die if your Exhaustion level is 6.

***D20 Tests Affected.*** When you make a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/D20 Test|D20 Test]], the roll is reduced by 2 times your Exhaustion level.

***Speed Reduced.*** Your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]] is reduced by a number of feet equal to 5 times your Exhaustion level.

***Removing Exhaustion Levels.*** Finishing a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]] removes 1 of your Exhaustion levels. When your Exhaustion level reaches 0, the condition ends.
