---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Poisoned Darts
*Deadly Trap (Levels 1 - 4)*

![[Placeholder.png|320]]


**Trigger:** A creature moves onto a pressure plate
**Duration:** Instantaneous, and the trap resets at the start of the next turn if it has activated fewer than three times

When a creature moves onto this trap’s pressure plate for the first time on a turn, poisoned darts shoot from tubes embedded in the surrounding walls. The holes that house these tubes are obscured by dust and cobwebs or skillfully hidden amid bas-reliefs, murals, or frescoes. Each creature in the darts’ path must succeed on a DC 13 Dexterity saving throw or be struck by 1d3 darts, taking 3 (1d6) Poison damage per dart.

***Detect and Disarm.*** As a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Search|Search]] action, a creature can examine the walls and make a DC 15 Wisdom ([[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]]) check, detecting the holes on a successful check. Plugging all the holes with wax, cloth, or detritus prevents the darts from firing.

As a Search action, a creature can examine the section of floor that forms the pressure plate and make a DC 15 Wisdom (Perception) check, detecting the pressure plate on a successful check. Wedging an [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Iron Spikes|Iron Spike]] or a similar object under the pressure plate prevents the trap from triggering.

***At Higher Levels.*** You can scale the trap for higher levels by increasing each dart’s Poison damage as follows: 7 (2d6) at levels 5–10, 14 (4d6) at levels 11–16, or 24 (7d6) at levels 17–20.
