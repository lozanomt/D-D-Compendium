---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: f66e0565-4d4f-5736-b880-0975a3f66c58
entity_type: character-option
source_ids: ["phb-2024"]
---

# Human

![[== SRDs ==/Attachments/Artwork/phb-p197-human.png|320]]

**Creature Type:** Humanoid
**Size:** Medium (about 4 - 7 feet tall) or Small (about 2 - 4 feet tall), chosen when you select this ancestry
**[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]:** 30 feet

As a Human, you have these special traits.

***Resourceful.*** You gain [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Heroic Inspiration|Heroic Inspiration]] whenever you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

***Skillful.*** You gain proficiency in one skill of your choice

***Versatile.*** You gain an Origin feat of your choice.

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Player's Handbook — Chapter 4 - Character Origins]]
