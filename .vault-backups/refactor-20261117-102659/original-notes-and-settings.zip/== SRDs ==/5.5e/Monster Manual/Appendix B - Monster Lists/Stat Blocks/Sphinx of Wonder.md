---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Sphinx of Wonder
> 
> *Tiny Celestial, Lawful Good*
> 
> ![[mm-p293-sphinx-of-wonder.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +3 (13)  
> **HP** 24 (7d4 + 7)  
> **Speed** 20 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 6 | -2 | -2 | **Dex** | 17 | +3 | +3 | **Con** | 13 | +1 | +1 |
> | **Int** | 15 | +2 | +2 | **Wis** | 12 | +1 | +1 | **Cha** | 11 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Arcana|Arcana]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Religion|Religion]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +5  
> **Resistances** Necrotic, Psychic, Radiant  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** Celestial, Common  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Traits
> 
> ***Magic Resistance.*** The sphinx has Advantage on saving throws against spells and other magical effects.
> 
> ### Actions
> 
> ***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 5 (1d4 + 3) Slashing damage plus 7 (2d6) Radiant damage.
> 
> ### Reactions
> 
> ***Burst of Ingenuity (2/Day).*** *Trigger:* The sphinx or another creature within 30 feet makes an ability check or a saving throw. *Response:* The sphinx adds 2 to the roll.
> - [ ]
> - [ ]
