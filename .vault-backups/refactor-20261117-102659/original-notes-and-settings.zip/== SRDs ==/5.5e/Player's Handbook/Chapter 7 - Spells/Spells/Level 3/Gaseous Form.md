---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Gaseous Form
*Level 3 Transmutation (Sorcerer, Warlock, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a bit of gauze)
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 hour

A willing creature you touch [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Shape-Shifting|shape-shifts]], along with everything it's wearing and carrying, into a misty cloud for the duration. The spell ends on the target if it drops to 0 [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]] or if it takes a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action to end the spell on itself.

While in this form, the target's only method of movement is a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] Speed of 10 feet, and it can hover. The target can enter and occupy the space of another creature. The target has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to Bludgeoning, Piercing, and Slashing damage; it has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Immunity|Immunity]] to the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition; and it has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on Strength, Dexterity, and Constitution saving throws. The target can pass through narrow openings, but it treats liquids as though they were solid surfaces.

The target can't talk or manipulate objects, and any objects it was carrying or holding can't be dropped, used, or otherwise interacted with. Finally, the target can't attack or cast spells.

***Using a Higher-Level Spell Slot.*** You can target one additional creature for each spell slot level above 3.
