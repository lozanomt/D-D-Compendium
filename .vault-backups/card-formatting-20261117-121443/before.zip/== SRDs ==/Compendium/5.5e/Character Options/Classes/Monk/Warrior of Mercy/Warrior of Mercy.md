---
type: subclass
class: Monk
rules_revision: "2024"
reference_style: summary
tags:
  - rules/subclass
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 8c161120-c1dd-5ab4-abcf-5d7db86c0c87
entity_type: character-option
source_ids: ["phb-2024"]
source_versions: ["Player's Handbook"]
---

# Warrior of Mercy

## Player's Handbook

> [!info]
> ### Warrior of Mercy
>
> ![[== SRDs ==/Attachments/Artwork/phb-p107-warrior-of-mercy.png|320]]
>
> **Class:** [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Monk/Monk|Monk]]
>
> A handbook reference summary. Use the linked PDF for complete wording, spell/resource tables, targeting restrictions, and exceptions.
>
> ### Features
>
> ### Level 3: Hand of Harm
>
> Once per turn after damaging a creature with an Unarmed Strike, spend 1 Focus Point for extra Necrotic damage equal to a Martial Arts die + Wisdom modifier.
>
> ### Level 3: Hand of Healing
>
> A Magic action and 1 Focus Point heal a touched creature by a Martial Arts die + Wisdom modifier. During Flurry of Blows, replace one strike with this healing without its additional Focus cost.
>
> ### Level 3: Implements of Mercy
>
> Gain Insight, Medicine, and Herbalism Kit proficiency.
>
> ### Level 6: Physician’s Touch
>
> Hand of Harm can also Poison until your next turn ends. Hand of Healing can end one condition: Blinded, Deafened, Paralyzed, Poisoned, or Stunned.
>
> ### Level 11: Flurry of Healing and Harm
>
> During Flurry of Blows, replace each strike with Hand of Healing, and apply Hand of Harm to a damaging Flurry strike, without their additional Focus costs. Hand of Harm remains once per turn. This enhanced benefit has Wisdom-modifier uses (minimum one) per Long Rest.
>
> ### Level 17: Hand of Ultimate Mercy
>
> A Magic action and 5 Focus Points revive a creature dead no longer than 24 hours with 4d10 + Wisdom modifier Hit Points, removing the listed conditions. Once per Long Rest.
>
> ### Handbook
>
> [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=107|PDF page 107]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=108|PDF page 108]]
>
> **Source:** [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf|Player's Handbook]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
