---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Flask [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Flask|(2 CP)]] 

![[Placeholder.png|320]]

A Flask holds up to 1 pint.

**Weight:**  1 lb.
