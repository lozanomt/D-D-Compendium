---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: e8ca488e-f906-5f38-97b7-9a5cfcb70726
entity_type: character-option
source_ids: ["phb-2024"]
---

# Ritual Adept

![[== SRDs ==/Attachments/Artwork/phb-p167-wizard.png|320]]

You can cast any spell as a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual|Ritual]] if that spell has the Ritual tag and the spell is in your spellbook. You needn’t have the spell prepared, but you must read from the book to cast a spell in this way.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=168|Player’s Handbook (2024), PDF page 168]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
