---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Explorer's Pack [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Gear Packs/Explorer's Pack|10 GP]]

![[Placeholder.png|320]]

An Explorer's Pack contains the following items:
[[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Backpack|Backpack]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Bedroll|Bedroll]], 2 flasks of [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Oil|Oil]], 10 days of [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Rations|Rations]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Rope|Rope]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Tinderbox|Tinderbox]], 10 [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Torch|Torches]], and [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Waterskin|Waterskin]].
