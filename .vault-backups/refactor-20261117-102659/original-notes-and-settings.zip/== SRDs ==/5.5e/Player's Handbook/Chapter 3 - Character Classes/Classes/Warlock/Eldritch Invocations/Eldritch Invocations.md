---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Eldritch Invocations

![[phb-p155-warlock.png|320]]

You have unearthed Eldritch Invocations, pieces of forbidden knowledge that imbue you with an abiding magical ability or other lessons. You gain one invocation of your choice.

***Prerequisites.*** If an invocation has a prerequisite, you must meet it to learn that invocation.

***Replacing and Gaining Invocations.*** Whenever you gain a Warlock level, you can replace one of your invocations with another one for which you qualify. You can’t replace an invocation if it’s a prerequisite for another invocation that you have.

When you gain certain Warlock levels, you gain more invocations of your choice, as shown in the Invocations column of the Warlock Features table. You can’t pick the same invocation more than once unless its description says otherwise.
###### Eldritch Invocation Options
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Agonizing Blast|Agonizing Blast]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Armor of Shadows|Armor of Shadows]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Ascendant Step|Ascendant Step]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Devil's Sight|Devil's Sight]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Devouring Blade|Devouring Blade]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Eldritch Mind|Eldritch Mind]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Eldritch Smite|Eldritch Smite]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Eldritch Spear|Eldritch Spear]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Fiendish Vigor|Fiendish Vigor]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Gaze of Two Minds|Gaze of Two Minds]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Gift of the Depths|Gift of the Depths]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Gift of the Protectors|Gift of the Protectors]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Investment of the Chain Master|Investment of the Chain Master]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Lessons of the First Ones|Lessons of the First Ones]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Lifedrinker|Lifedrinker]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Mask of Many Faces|Mask of Many Faces]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Master of Myriad Forms|Master of Myriad Forms]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Misty Visions|Misty Visions]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/One with Shadows|One with Shadows]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Otherworldly Leap|Otherworldly Leap]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Pact of the Blade|Pact of the Blade]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Pact of the Chain|Pact of the Chain]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Pact of the Tome|Pact of the Tome]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Repelling Blast|Repelling Blast]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Thirsting Blade|Thirsting Blade]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Visions of Distant Realms|Visions of Distant Realms]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Whispers of the Grave|Whispers of the Grave]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Eldritch Invocations/Witch Sight|Witch Sight]]

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=156|Player’s Handbook (2024), PDF page 156]]
