---
cssclasses: [dnd-book, dnd-phb]
source_id: srd-5.2.1
source_pages: [104, 175]
---

# Spells

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=104|SRD 5.2.1, p. 104]].

### Gaining Spells

Before you can cast a spell, you must have the spell prepared in your mind or have access to the spell from a magic item, such as a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scroll . Your features specify which spells you have access to, if any; whether you always have certain spells prepared; and whether you can change the list of spells you have prepared.

#### Preparing Spells

If you have a list of level 1+ spells you prepare, your spellcasting feature specifies when you can change the list and the number of spells you can change, as summarized in the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Preparation by Class table.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Preparation by Class Class Change When You ...

Number of Spells Bard Gain a level One Cleric Finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]] Any Druid Finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]] Any Paladin Finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]] One Ranger Finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]] One Sorcerer Gain a level One Warlock Gain a level One Wizard Finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]] Any Most spellcasting monsters don't change their lists of prepared spells, but the GM is free to alter them.

#### Always-Prepared Spells

Certain features might give you a spell that you always have prepared. If you also have a list of prepared spells that you can change, a spell that you always have prepared doesn't count against the number of spells on that list.

### Casting Spells

Each spell description has a series of entries that provide the details needed to cast the spell. The following sections explain each of those entries, which follow a spell's name.

#### Spell Level

Every spell has a level from 0 to 9, which is indicated in a spell's description. A spell's level is an indicator of how powerful it is. Cantrips—simple spells that can be cast almost by rote—are level 0.

The rules for each spellcasting class say when its members gain access to spells of certain levels.

#### Spell Slots

Spellcasting is taxing, so a spellcaster can cast only a limited number of level 1+ spells before resting.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] slots are the main way a spellcaster's magical potential is represented. Each spellcasting class gives its members a limited number of spell slots of certain spell levels. For example, a level 3 Wizard has four level 1 spell slots and two level 2 slots.

When you cast a spell, you expend a slot of that spell's level or higher, effectively "filling" a slot with the spell. Imagine a spell slot is a groove of a certain size—small for a level 1 slot and larger for a higher-level spell. A level 1 spell fits into a slot of any size, but a level 2 spell fits only into a slot that's at least level 2. So when a level 3 Wizard casts [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Magic Missile#SRD 5.2.1|Magic Missile]], a level 1 spell, that Wizard spends one of four level 1 slots and has three remaining.

Finishing a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest#SRD 5.2.1|Long Rest]] restores any expended spell slots.

#### Casting without Slots

There are several ways to cast a spell without expending a spell slot:

Cantrips.  A cantrip is cast without a spell slot.

Rituals . Certain spells have the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual#SRD 5.2.1|Ritual]] tag in the

Casting Time entry. Such a spell can be cast following the normal rules for spellcasting, or it can be cast as a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual#SRD 5.2.1|Ritual]]. The [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual#SRD 5.2.1|Ritual]] version of a spell takes 10 minutes longer to cast than normal, but it doesn't expend a spell slot. To cast a spell as a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual#SRD 5.2.1|Ritual]], a spellcaster must have it prepared.

Special Abilities. Some characters and monsters have special abilities that allow them to cast specific spells without a spell slot. This casting is usually limited in another way, such as being able to cast the spell a limited number of times per day.

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Items.  [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scrolls and some other magic items contain spells that can be cast without a spell slot. The description of such an item specifies how many times a spell can be cast from it.

#### Using a Higher-Level Spell Slot

When a spellcaster casts a spell using a slot that is of a higher level than the spell, the spell takes on the higher level for that casting. For instance, if a Wizard casts [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Magic Missile#SRD 5.2.1|Magic Missile]]  using a level 2 slot, that

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Magic Missile#SRD 5.2.1|Magic Missile]] is level 2. Effectively, the spell expands to fill the slot it is put into.

Some spells, such as [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Magic Missile#SRD 5.2.1|Magic Missile]]  and [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Cure Wounds#SRD 5.2.1|Cure Wounds]], have more powerful effects when cast at a higher level, as detailed in a spell's description.

#### School of Magic

Each spell belongs to a school of magic. The schools are listed in the Schools of [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] table. These categories help describe spells but have no rules of their own, although some other rules refer to them.

Schools of [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] School Typical Effects Abjuration Prevents or reverses harmful effects Conjuration Transports creatures or objects [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Divination#SRD 5.2.1|Divination]] Reveals information Enchantment Influences minds Evocation Channels energy to create effects that are often destructive Illusion Deceives the mind or senses Necromancy Manipulates life and death Transmutation Transforms creatures or objects

#### Class Spell Lists

If a spell is on a class's spell list, the class's name appears in parentheses after the spell's school of magic. Some features add a spell to a character's spell list even if the character isn't a member of a class in the parentheses.

#### Casting Time

Most spells require the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] action to cast, but some spells require a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bonus Action#SRD 5.2.1|Bonus Action]], a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Reaction#SRD 5.2.1|Reaction]], or 1 minute or more. A spell's Casting Time entry specifies which of those is required.

#### One Spell with a Spell Slot per Turn

On a turn, you can expend only one spell slot to cast a spell. This rule means you can't, for example, cast a spell with a spell slot using the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] action and another one using a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bonus Action#SRD 5.2.1|Bonus Action]] on the same turn.

#### Reaction and Bonus Action Triggers

A spell that has a casting time of a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Reaction#SRD 5.2.1|Reaction]] is cast in response to a trigger that is defined in the spell's

Casting Time entry. Some spells that have a casting time of a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bonus Action#SRD 5.2.1|Bonus Action]] are also cast in response to a trigger defined in the spell.

#### Longer Casting Times

Certain spells—including a spell cast as a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual#SRD 5.2.1|Ritual]]—require more time to cast: minutes or even hours. While you cast a spell with a casting time of 1 minute or more, you must take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] action on each of your turns, and you must maintain [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration#SRD 5.2.1|Concentration]] (see "Rules Glossary") while you do so. If your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration#SRD 5.2.1|Concentration]] is broken, the spell fails, but you don't expend a spell slot. To cast the spell again, you must start over.

#### Range

A spell's range indicates how far from the spellcaster the spell's effect can originate, and the spell's description specifies which part of the effect is limited by the range.

A range usually takes one of the following forms:

Distance.  The range is expressed in feet.

Touch. The spell's effect originates on something, as defined by the spell, that the spellcaster must touch within their reach.

Self. The spell is cast on the spellcaster or emanates from them, as specified in the spell.

If a spell has movable effects, they aren't restricted by its range unless the spell's description says otherwise.

#### Components

A spell's components are physical requirements the spellcaster must meet to cast the spell. Each spell's description indicates whether it requires Verbal (V), Somatic (S), or Material (M) components. If the spellcaster can't provide one or more of a spell's components, the spellcaster can't cast the spell.

#### Verbal (V)

A Verbal component is the chanting of esoteric words that sound like nonsense to the uninitiated.

The words must be uttered in a normal speaking voice. The words themselves aren't the source of the spell's power; rather, the particular combination of sounds, with specific pitch and resonance, sets the threads of magic in motion. Thus, a creature who is gagged or in an area of magical silence can't cast a spell with a Verbal component.

#### Somatic (S)

A Somatic component is a forceful gesticulation or an intricate set of gestures. A spellcaster must use at least one of their hands to perform these movements.

#### Material (M)

A Material component is a particular material used in a spell's casting, as specified in parentheses in the Components entry. These materials aren't consumed by the spell unless the spell's description states otherwise. The spellcaster must have a hand free to access them, but it can be the same hand used to perform Somatic components, if any.

If a spell doesn't consume its materials and doesn't specify a cost for them, a spellcaster can use a Component Pouch (see "Equipment") instead of providing the materials specified in the spell, or the idEntiFyinG an onGoinG spEll You can try to identify a non-instantaneous spell by its observable effects if its duration is ongoing. To identify it, you must take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Study#SRD 5.2.1|Study]] action and succeed on a DC 15 Intelligence (Arcana) check. spellcaster can substitute a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spellcasting Focus#SRD 5.2.1|Spellcasting Focus]] if the caster has a feature that allows that substitution. To use a Component Pouch, you must have a hand free to reach into it, and to use a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spellcasting Focus#SRD 5.2.1|Spellcasting Focus]], you must hold it unless its description says otherwise (see "Equipment" for descriptions).

#### Duration

A spell's duration is the length of time the spell persists after it is cast. A duration typically takes one of the following forms:

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration#SRD 5.2.1|Concentration]].  A duration that requires [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration#SRD 5.2.1|Concentration]] follows the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration#SRD 5.2.1|Concentration]] rules (see "Rules Glossary").

Instantaneous.  An instantaneous duration means the spell's magic appears only for a moment and then disappears.

Time Span. A duration that provides a time span specifies how long the spell lasts in rounds, minutes, hours, or the like. For example, a Duration entry might say "1 minute," meaning the spell ends after 1 minute has passed. While a time-span spell that you cast is ongoing, you can dismiss it (no action required) if you don't have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated#SRD 5.2.1|Incapacitated]] condition.

#### Effects

The effects of a spell are detailed after its duration entry. Those details present exactly what the spell does, which ignores mundane physical laws; any outcomes beyond those effects are under the

GM's purview. Whatever the effects, they typically deal with targets, saving throws, attack rolls, or all three, each of which is detailed below.

#### Targets

A typical spell requires the caster to pick one or more targets to be affected by the spell's magic. A spell's description says whether the spell targets creatures, objects, or something else.

A Clear Path to the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Target#SRD 5.2.1|Target]]. To target something with a spell, a caster must have a clear path to it, so it can't be behind Total [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Cover#SRD 5.2.1|Cover]].

Targeting Yourself. If a spell targets a creature of your choice, you can choose yourself unless the creature must be [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hostile#SRD 5.2.1|Hostile]] or specifically a creature other than you.

[[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Areas of Effect#SRD 5.2.1|Areas of Effect]]. Some spells, such as [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Thunderwave#SRD 5.2.1|Thunderwave]], cover an area called an area of effect, which is defined in "Rules Glossary." The area determines what the spell targets. The description of a spell specifies whether it has an area of effect, which is typically one of these shapes: [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cone#SRD 5.2.1|Cone]], [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cube#SRD 5.2.1|Cube]], [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cylinder#SRD 5.2.1|Cylinder]], [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Emanation#SRD 5.2.1|Emanation]], [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Line#SRD 5.2.1|Line]], or [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Sphere#SRD 5.2.1|Sphere]].

Awareness of Being Targeted. Unless a spell has a perceptible effect, a creature doesn't know it was targeted by the spell. An effect like lightning is obvious, but a more subtle effect, such as an attempt to read thoughts, goes unnoticed unless a spell's description says otherwise.

Invalid Targets. If you cast a spell on someone or something that can't be affected by it, nothing happens to that target, but if you used a spell slot to cast the spell, the slot is still expended.

If the spell normally has no effect on a target that succeeds on a saving throw, the invalid target appears to have succeeded on its saving throw, even though it didn't attempt one (giving no hint that the creature is an invalid target). Otherwise, you perceive that the spell did nothing to the target.

#### Saving Throws

Many spells specify that a target makes a saving throw to avoid some or all of a spell's effects. The spell specifies the ability that the target uses for the save and what happens on a success or failure.

Here's how to calculate the DC for your spells: [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] save DC = 8 + your spellcasting ability modifier + your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus

#### Attack Rolls

Some spells require the caster to make an attack roll to determine whether the spell hits a target.

Here's how to calculate the attack modifier for your spells: [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] attack modifier = your spellcasting ability modifier + your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus

#### Combining Spell Effects

The effects of different spells add together while their durations overlap. In contrast, the effects of the same spell cast multiple times don't combine.

Instead, the most potent effect—such as the highest bonus—from those castings applies while their durations overlap. The most recent effect applies if the castings are equally potent and their durations overlap. For example, if two Clerics cast [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bless#SRD 5.2.1|Bless]] on the same target, that target gains the spell's benefit only once; the target doesn't receive two bonus dice.

But if the durations of the spells overlap, the effect continues until the duration of the second [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bless#SRD 5.2.1|Bless]] ends.

### Spell Descriptions

### Acid Arrow

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Acid Arrow#SRD 5.2.1|Acid Arrow]]

### Acid Splash

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Acid Splash#SRD 5.2.1|Acid Splash]]

### Aid

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Aid#SRD 5.2.1|Aid]]

### Alarm

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Alarm#SRD 5.2.1|Alarm]]

### Alter Self

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Alter Self#SRD 5.2.1|Alter Self]]

### Animal Friendship

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Animal Friendship#SRD 5.2.1|Animal Friendship]]

### Animal Messenger

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Animal Messenger#SRD 5.2.1|Animal Messenger]]

### Animal Shapes

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Animal Shapes#SRD 5.2.1|Animal Shapes]]

### Animate Dead

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Animate Dead#SRD 5.2.1|Animate Dead]]

### Animate Objects

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Animate Objects#SRD 5.2.1|Animate Objects]]

### Antimagic Field

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Antimagic Field#SRD 5.2.1|Antimagic Field]]

### Antipathy/Sympathy

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Antipathy + Sympathy#SRD 5.2.1|Antipathy + Sympathy]]

### Antilife Shell

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Antilife Shell#SRD 5.2.1|Antilife Shell]]

### Arcane Eye

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Arcane Eye#SRD 5.2.1|Arcane Eye]]

### Arcane Hand

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Arcane Hand#SRD 5.2.1|Arcane Hand]]

### Arcane Lock

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Arcane Lock#SRD 5.2.1|Arcane Lock]]

### Arcane Sword

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Arcane Sword#SRD 5.2.1|Arcane Sword]]

### Arcanist's Magic Aura

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Arcanist's Magic Aura#SRD 5.2.1|Arcanist's Magic Aura]]

### Astral Projection

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Astral Projection#SRD 5.2.1|Astral Projection]]

### Augury

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Augury#SRD 5.2.1|Augury]]

### Aura of Life

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Aura of Life#SRD 5.2.1|Aura of Life]]

### Awaken

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Awaken#SRD 5.2.1|Awaken]]

### Bane

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bane#SRD 5.2.1|Bane]]

### Banishment

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Banishment#SRD 5.2.1|Banishment]]

### Barkskin

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Barkskin#SRD 5.2.1|Barkskin]]

### Beacon of Hope

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Beacon of Hope#SRD 5.2.1|Beacon of Hope]]

### Befuddlement

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Befuddlement#SRD 5.2.1|Befuddlement]]

### Bestow Curse

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Bestow Curse#SRD 5.2.1|Bestow Curse]]

### Black Tentacles

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Black Tentacles#SRD 5.2.1|Black Tentacles]]

### Blade Barrier

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Blade Barrier#SRD 5.2.1|Blade Barrier]]

### Bless

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bless#SRD 5.2.1|Bless]]

### Blight

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Blight#SRD 5.2.1|Blight]]

### Blindness/Deafness

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blindness + Deafness#SRD 5.2.1|Blindness + Deafness]]

### Blink

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Blink#SRD 5.2.1|Blink]]

### Blur

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blur#SRD 5.2.1|Blur]]

### Burning Hands

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Burning Hands#SRD 5.2.1|Burning Hands]]

### Call Lightning

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Call Lightning#SRD 5.2.1|Call Lightning]]

### Calm Emotions

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Calm Emotions#SRD 5.2.1|Calm Emotions]]

### Chain Lightning

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Chain Lightning#SRD 5.2.1|Chain Lightning]]

### Charm Monster

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Charm Monster#SRD 5.2.1|Charm Monster]]

### Charm Person

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Charm Person#SRD 5.2.1|Charm Person]]

### Chill Touch

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Chill Touch#SRD 5.2.1|Chill Touch]]

### Chromatic Orb

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Chromatic Orb#SRD 5.2.1|Chromatic Orb]]

### Circle of Death

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Circle of Death#SRD 5.2.1|Circle of Death]]

### Clairvoyance

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Clairvoyance#SRD 5.2.1|Clairvoyance]]

### Clone

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Clone#SRD 5.2.1|Clone]]

### Cloudkill

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Cloudkill#SRD 5.2.1|Cloudkill]]

### Color Spray

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Color Spray#SRD 5.2.1|Color Spray]]

### Command

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Command#SRD 5.2.1|Command]]

### Commune

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Commune#SRD 5.2.1|Commune]]

### Commune with Nature

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Commune with Nature#SRD 5.2.1|Commune with Nature]]

### Comprehend Languages

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Comprehend Languages#SRD 5.2.1|Comprehend Languages]]

### Compulsion

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Compulsion#SRD 5.2.1|Compulsion]]

### Cone of Cold

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Cone of Cold#SRD 5.2.1|Cone of Cold]]

### Confusion

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Confusion#SRD 5.2.1|Confusion]]

### Conjure Animals

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Conjure Animals#SRD 5.2.1|Conjure Animals]]

### Conjure Celestial

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Conjure Celestial#SRD 5.2.1|Conjure Celestial]]

### Conjure Elemental

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Conjure Elemental#SRD 5.2.1|Conjure Elemental]]

### Conjure Fey

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Conjure Fey#SRD 5.2.1|Conjure Fey]]

### Conjure Minor Elementals

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Conjure Minor Elementals#SRD 5.2.1|Conjure Minor Elementals]]

### Conjure Woodland Beings

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Conjure Woodland Beings#SRD 5.2.1|Conjure Woodland Beings]]

### Contact Other Plane

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Contact Other Plane#SRD 5.2.1|Contact Other Plane]]

### Contagion

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Contagion#SRD 5.2.1|Contagion]]

### Contingency

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Contingency#SRD 5.2.1|Contingency]]

### Continual Flame

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Continual Flame#SRD 5.2.1|Continual Flame]]

### Control Water

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Control Water#SRD 5.2.1|Control Water]]

### Control Weather

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Control Weather#SRD 5.2.1|Control Weather]]

### Counterspell

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Counterspell#SRD 5.2.1|Counterspell]]

### Create Food and Water

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Create Food and Water#SRD 5.2.1|Create Food and Water]]

### Create or Destroy Water

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Create or Destroy Water#SRD 5.2.1|Create or Destroy Water]]

### Create Undead

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Create Undead#SRD 5.2.1|Create Undead]]

### Creation

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Creation#SRD 5.2.1|Creation]]

### Cure Wounds

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Cure Wounds#SRD 5.2.1|Cure Wounds]]

### Dancing Lights

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Dancing Lights#SRD 5.2.1|Dancing Lights]]

### Darkness

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkness#SRD 5.2.1|Darkness]]

### Darkvision

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkvision#SRD 5.2.1|Darkvision]]

### Daylight

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Daylight#SRD 5.2.1|Daylight]]

### Death Ward

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Death Ward#SRD 5.2.1|Death Ward]]

### Delayed Blast Fireball

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Delayed Blast Fireball#SRD 5.2.1|Delayed Blast Fireball]]

### Demiplane

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Demiplane#SRD 5.2.1|Demiplane]]

### Detect Evil and Good

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Evil and Good#SRD 5.2.1|Detect Evil and Good]]

### Detect Magic

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic#SRD 5.2.1|Detect Magic]]

### Detect Poison and Disease

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Poison and Disease#SRD 5.2.1|Detect Poison and Disease]]

### Detect Thoughts

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Detect Thoughts#SRD 5.2.1|Detect Thoughts]]

### Dimension Door

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dimension Door#SRD 5.2.1|Dimension Door]]

### Disguise Self

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Disguise Self#SRD 5.2.1|Disguise Self]]

### Disintegrate

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Disintegrate#SRD 5.2.1|Disintegrate]]

### Dispel Evil and Good

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dispel Evil and Good#SRD 5.2.1|Dispel Evil and Good]]

### Dispel Magic

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic#SRD 5.2.1|Dispel Magic]]

### Dissonant Whispers

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Dissonant Whispers#SRD 5.2.1|Dissonant Whispers]]

### Divination

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Divination#SRD 5.2.1|Divination]]

### Divine Favor

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Divine Favor#SRD 5.2.1|Divine Favor]]

### Divine Smite

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Divine Smite#SRD 5.2.1|Divine Smite]]

### Divine Word

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Divine Word#SRD 5.2.1|Divine Word]]

### Dominate Beast

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dominate Beast#SRD 5.2.1|Dominate Beast]]

### Dominate Monster

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Dominate Monster#SRD 5.2.1|Dominate Monster]]

### Dominate Person

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dominate Person#SRD 5.2.1|Dominate Person]]

### Dragon's Breath

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Dragon's Breath#SRD 5.2.1|Dragon's Breath]]

### Dream

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dream#SRD 5.2.1|Dream]]

### Druidcraft

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Druidcraft#SRD 5.2.1|Druidcraft]]

### Earthquake

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Earthquake#SRD 5.2.1|Earthquake]]

### Eldritch Blast

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Eldritch Blast#SRD 5.2.1|Eldritch Blast]]

### Elementalism

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Elementalism#SRD 5.2.1|Elementalism]]

### Enhance Ability

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enhance Ability#SRD 5.2.1|Enhance Ability]]

### Enlarge/Reduce

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enlarge + Reduce#SRD 5.2.1|Enlarge + Reduce]]

### Ensnaring Strike

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ensnaring Strike#SRD 5.2.1|Ensnaring Strike]]

### Entangle

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Entangle#SRD 5.2.1|Entangle]]

### Enthrall

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enthrall#SRD 5.2.1|Enthrall]]

### Etherealness

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Etherealness#SRD 5.2.1|Etherealness]]

### Expeditious Retreat

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Expeditious Retreat#SRD 5.2.1|Expeditious Retreat]]

### Eyebite

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Eyebite#SRD 5.2.1|Eyebite]]

### Fabricate

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Fabricate#SRD 5.2.1|Fabricate]]

### Faerie Fire

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Faerie Fire#SRD 5.2.1|Faerie Fire]]

### Faithful Hound

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Faithful Hound#SRD 5.2.1|Faithful Hound]]

### False Life

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/False Life#SRD 5.2.1|False Life]]

### Fear

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fear#SRD 5.2.1|Fear]]

### Feather Fall

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Feather Fall#SRD 5.2.1|Feather Fall]]

### Find Familiar

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Find Familiar#SRD 5.2.1|Find Familiar]]

### Find Steed

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Find Steed#SRD 5.2.1|Find Steed]]

### Find Traps

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Find Traps#SRD 5.2.1|Find Traps]]

### Finger of Death

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Finger of Death#SRD 5.2.1|Finger of Death]]

### Fireball

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fireball#SRD 5.2.1|Fireball]]

### Find the Path

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Find the Path#SRD 5.2.1|Find the Path]]

### Fire Bolt

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Fire Bolt#SRD 5.2.1|Fire Bolt]]

### Fire Shield

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Fire Shield#SRD 5.2.1|Fire Shield]]

### Fire Storm

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Fire Storm#SRD 5.2.1|Fire Storm]]

### Flame Blade

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Flame Blade#SRD 5.2.1|Flame Blade]]

### Flame Strike

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Flame Strike#SRD 5.2.1|Flame Strike]]

### Flaming Sphere

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Flaming Sphere#SRD 5.2.1|Flaming Sphere]]

### Flesh to Stone

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Flesh to Stone#SRD 5.2.1|Flesh to Stone]]

### Floating Disk

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Floating Disk#SRD 5.2.1|Floating Disk]]

### Fly

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fly#SRD 5.2.1|Fly]]

### Fog Cloud

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Fog Cloud#SRD 5.2.1|Fog Cloud]]

### Forbiddance

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Forbiddance#SRD 5.2.1|Forbiddance]]

### Forcecage

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Forcecage#SRD 5.2.1|Forcecage]]

### Foresight

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Foresight#SRD 5.2.1|Foresight]]

### Freedom of Movement

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Freedom of Movement#SRD 5.2.1|Freedom of Movement]]

### Freezing Sphere

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Freezing Sphere#SRD 5.2.1|Freezing Sphere]]

### Gaseous Form

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Gaseous Form#SRD 5.2.1|Gaseous Form]]

### Gate

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Gate#SRD 5.2.1|Gate]]

### Geas

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Geas#SRD 5.2.1|Geas]]

### Gentle Repose

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gentle Repose#SRD 5.2.1|Gentle Repose]]

### Giant Insect

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Giant Insect#SRD 5.2.1|Giant Insect]]

### Glibness

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Glibness#SRD 5.2.1|Glibness]]

### Globe of Invulnerability

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Globe of Invulnerability#SRD 5.2.1|Globe of Invulnerability]]

### Glyph of Warding

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Glyph of Warding#SRD 5.2.1|Glyph of Warding]]

### Goodberry

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Goodberry#SRD 5.2.1|Goodberry]]

### Grease

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Grease#SRD 5.2.1|Grease]]

### Greater Invisibility

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Greater Invisibility#SRD 5.2.1|Greater Invisibility]]

### Greater Restoration

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Greater Restoration#SRD 5.2.1|Greater Restoration]]

### Guardian of Faith

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Guardian of Faith#SRD 5.2.1|Guardian of Faith]]

### Guards and Wards

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Guards and Wards#SRD 5.2.1|Guards and Wards]]

### Guidance

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Guidance#SRD 5.2.1|Guidance]]

### Guiding Bolt

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Guiding Bolt#SRD 5.2.1|Guiding Bolt]]

### Gust of Wind

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gust of Wind#SRD 5.2.1|Gust of Wind]]

### Hallow

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Hallow#SRD 5.2.1|Hallow]]

### Hallucinatory Terrain

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Hallucinatory Terrain#SRD 5.2.1|Hallucinatory Terrain]]

### Harm

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Harm#SRD 5.2.1|Harm]]

### Haste

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Haste#SRD 5.2.1|Haste]]

### Heal

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Heal#SRD 5.2.1|Heal]]

### Healing Word

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Healing Word#SRD 5.2.1|Healing Word]]

### Heat Metal

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Heat Metal#SRD 5.2.1|Heat Metal]]

### Hellish Rebuke

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hellish Rebuke#SRD 5.2.1|Hellish Rebuke]]

### Heroes' Feast

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Heroes' Feast#SRD 5.2.1|Heroes' Feast]]

### Heroism

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Heroism#SRD 5.2.1|Heroism]]

### Hex

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hex#SRD 5.2.1|Hex]]

### Hideous Laughter

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hideous Laughter#SRD 5.2.1|Hideous Laughter]]

### Hold Monster

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Hold Monster#SRD 5.2.1|Hold Monster]]

### Hold Person

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Hold Person#SRD 5.2.1|Hold Person]]

### Holy Aura

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Holy Aura#SRD 5.2.1|Holy Aura]]

### Hunter's Mark

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hunter's Mark#SRD 5.2.1|Hunter's Mark]]

### Hypnotic Pattern

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Hypnotic Pattern#SRD 5.2.1|Hypnotic Pattern]]

### Ice Knife

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ice Knife#SRD 5.2.1|Ice Knife]]

### Ice Storm

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Ice Storm#SRD 5.2.1|Ice Storm]]

### Identify

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Identify#SRD 5.2.1|Identify]]

### Illusory Script

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Illusory Script#SRD 5.2.1|Illusory Script]]

### Imprisonment

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Imprisonment#SRD 5.2.1|Imprisonment]]

### Incendiary Cloud

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Incendiary Cloud#SRD 5.2.1|Incendiary Cloud]]

### Inflict Wounds

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Inflict Wounds#SRD 5.2.1|Inflict Wounds]]

### Insect Plague

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Insect Plague#SRD 5.2.1|Insect Plague]]

### Instant Summons

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Instant Summons#SRD 5.2.1|Instant Summons]]

### Irresistible Dance

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Irresistible Dance#SRD 5.2.1|Irresistible Dance]]

### Invisibility

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility#SRD 5.2.1|Invisibility]]

### Jump

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Jump#SRD 5.2.1|Jump]]

### Knock

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Knock#SRD 5.2.1|Knock]]

### Legend Lore

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Legend Lore#SRD 5.2.1|Legend Lore]]

### Lesser Restoration

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Lesser Restoration#SRD 5.2.1|Lesser Restoration]]

### Levitate

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Levitate#SRD 5.2.1|Levitate]]

### Light

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Light#SRD 5.2.1|Light]]

### Lightning Bolt

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Lightning Bolt#SRD 5.2.1|Lightning Bolt]]

### Locate Animals or Plants

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Animals or Plants#SRD 5.2.1|Locate Animals or Plants]]

### Locate Creature

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Locate Creature#SRD 5.2.1|Locate Creature]]

### Locate Object

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Object#SRD 5.2.1|Locate Object]]

### Longstrider

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Longstrider#SRD 5.2.1|Longstrider]]

### Mage Armor

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Mage Armor#SRD 5.2.1|Mage Armor]]

### Mage Hand

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mage Hand#SRD 5.2.1|Mage Hand]]

### Magic Circle

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Magic Circle#SRD 5.2.1|Magic Circle]]

### Magic Jar

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Magic Jar#SRD 5.2.1|Magic Jar]]

### Magic Missile

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Magic Missile#SRD 5.2.1|Magic Missile]]

### Magic Mouth

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Mouth#SRD 5.2.1|Magic Mouth]]

### Magic Weapon

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Weapon#SRD 5.2.1|Magic Weapon]]

### Magnificent Mansion

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Magnificent Mansion#SRD 5.2.1|Magnificent Mansion]]

### Major Image

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Major Image#SRD 5.2.1|Major Image]]

### Mass Cure Wounds

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mass Cure Wounds#SRD 5.2.1|Mass Cure Wounds]]

### Mass Heal

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Mass Heal#SRD 5.2.1|Mass Heal]]

### Mass Healing Word

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Mass Healing Word#SRD 5.2.1|Mass Healing Word]]

### Mass Suggestion

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Mass Suggestion#SRD 5.2.1|Mass Suggestion]]

### Maze

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Maze#SRD 5.2.1|Maze]]

### Meld into Stone

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Meld into Stone#SRD 5.2.1|Meld into Stone]]

### Mending

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mending#SRD 5.2.1|Mending]]

### Message

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Message#SRD 5.2.1|Message]]

### Meteor Swarm

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Meteor Swarm#SRD 5.2.1|Meteor Swarm]]

### Mind Blank

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Mind Blank#SRD 5.2.1|Mind Blank]]

### Mind Spike

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mind Spike#SRD 5.2.1|Mind Spike]]

### Minor Illusion

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Minor Illusion#SRD 5.2.1|Minor Illusion]]

### Mirage Arcane

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Mirage Arcane#SRD 5.2.1|Mirage Arcane]]

### Mirror Image

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mirror Image#SRD 5.2.1|Mirror Image]]

### Mislead

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mislead#SRD 5.2.1|Mislead]]

### Misty Step

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Misty Step#SRD 5.2.1|Misty Step]]

### Modify Memory

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Modify Memory#SRD 5.2.1|Modify Memory]]

### Moonbeam

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Moonbeam#SRD 5.2.1|Moonbeam]]

### Move Earth

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Move Earth#SRD 5.2.1|Move Earth]]

### Nondetection

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Nondetection#SRD 5.2.1|Nondetection]]

### Passwall

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Passwall#SRD 5.2.1|Passwall]]

### Pass without Trace

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Pass without Trace#SRD 5.2.1|Pass without Trace]]

### Phantasmal Force

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Phantasmal Force#SRD 5.2.1|Phantasmal Force]]

### Phantasmal Killer

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Phantasmal Killer#SRD 5.2.1|Phantasmal Killer]]

### Phantom Steed

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Phantom Steed#SRD 5.2.1|Phantom Steed]]

### Planar Ally

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Planar Ally#SRD 5.2.1|Planar Ally]]

### Planar Binding

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Planar Binding#SRD 5.2.1|Planar Binding]]

### Plane Shift

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Plane Shift#SRD 5.2.1|Plane Shift]]

### Plant Growth

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Plant Growth#SRD 5.2.1|Plant Growth]]

### Poison Spray

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Poison Spray#SRD 5.2.1|Poison Spray]]

### Polymorph

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Polymorph#SRD 5.2.1|Polymorph]]

### Power Word Heal

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Heal#SRD 5.2.1|Power Word Heal]]

### Power Word Kill

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Kill#SRD 5.2.1|Power Word Kill]]

### Power Word Stun

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Power Word Stun#SRD 5.2.1|Power Word Stun]]

### Prayer of Healing

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Prayer of Healing#SRD 5.2.1|Prayer of Healing]]

### Prestidigitation

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Prestidigitation#SRD 5.2.1|Prestidigitation]]

### Prismatic Spray

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Prismatic Spray#SRD 5.2.1|Prismatic Spray]]

### Prismatic Wall

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Prismatic Wall#SRD 5.2.1|Prismatic Wall]]

### Private Sanctum

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Private Sanctum#SRD 5.2.1|Private Sanctum]]

### Produce Flame

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Produce Flame#SRD 5.2.1|Produce Flame]]

### Programmed Illusion

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Programmed Illusion#SRD 5.2.1|Programmed Illusion]]

### Project Image

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Project Image#SRD 5.2.1|Project Image]]

### Protection from Energy

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Protection from Energy#SRD 5.2.1|Protection from Energy]]

### Protection from Evil and Good

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Protection from Evil and Good#SRD 5.2.1|Protection from Evil and Good]]

### Protection from Poison

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Protection from Poison#SRD 5.2.1|Protection from Poison]]

### Purify Food and Drink

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Purify Food and Drink#SRD 5.2.1|Purify Food and Drink]]

### Raise Dead

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Raise Dead#SRD 5.2.1|Raise Dead]]

### Ray of Enfeeblement

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Ray of Enfeeblement#SRD 5.2.1|Ray of Enfeeblement]]

### Ray of Frost

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Ray of Frost#SRD 5.2.1|Ray of Frost]]

### Regenerate

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Regenerate#SRD 5.2.1|Regenerate]]

### Ray of Sickness

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ray of Sickness#SRD 5.2.1|Ray of Sickness]]

### Reincarnate

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Reincarnate#SRD 5.2.1|Reincarnate]]

### Remove Curse

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Remove Curse#SRD 5.2.1|Remove Curse]]

### Resilient Sphere

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Resilient Sphere#SRD 5.2.1|Resilient Sphere]]

### Resistance

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Resistance#SRD 5.2.1|Resistance]]

### Resurrection

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Resurrection#SRD 5.2.1|Resurrection]]

### Reverse Gravity

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Reverse Gravity#SRD 5.2.1|Reverse Gravity]]

### Revivify

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Revivify#SRD 5.2.1|Revivify]]

### Rope Trick

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Rope Trick#SRD 5.2.1|Rope Trick]]

### Sacred Flame

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Sacred Flame#SRD 5.2.1|Sacred Flame]]

### Sanctuary

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Sanctuary#SRD 5.2.1|Sanctuary]]

### Scorching Ray

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Scorching Ray#SRD 5.2.1|Scorching Ray]]

### Scrying

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Scrying#SRD 5.2.1|Scrying]]

### Searing Smite

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Searing Smite#SRD 5.2.1|Searing Smite]]

### Secret Chest

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Secret Chest#SRD 5.2.1|Secret Chest]]

### See Invisibility

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/See Invisibility#SRD 5.2.1|See Invisibility]]

### Seeming

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Seeming#SRD 5.2.1|Seeming]]

### Sending

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sending#SRD 5.2.1|Sending]]

### Sequester

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Sequester#SRD 5.2.1|Sequester]]

### Shapechange

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Shapechange#SRD 5.2.1|Shapechange]]

### Shatter

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Shatter#SRD 5.2.1|Shatter]]

### Shield

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]]

### Shield of Faith

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield of Faith#SRD 5.2.1|Shield of Faith]]

### Shillelagh

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Shillelagh#SRD 5.2.1|Shillelagh]]

### Shining Smite

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Shining Smite#SRD 5.2.1|Shining Smite]]

### Shocking Grasp

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Shocking Grasp#SRD 5.2.1|Shocking Grasp]]

### Silence

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Silence#SRD 5.2.1|Silence]]

### Silent Image

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Silent Image#SRD 5.2.1|Silent Image]]

### Simulacrum

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Simulacrum#SRD 5.2.1|Simulacrum]]

### Sleep

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Sleep#SRD 5.2.1|Sleep]]

### Sleet Storm

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sleet Storm#SRD 5.2.1|Sleet Storm]]

### Slow

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Slow#SRD 5.2.1|Slow]]

### Sorcerous Burst

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Sorcerous Burst#SRD 5.2.1|Sorcerous Burst]]

### Spare the Dying

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Spare the Dying#SRD 5.2.1|Spare the Dying]]

### Speak with Animals

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Speak with Animals#SRD 5.2.1|Speak with Animals]]

### Speak with Dead

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Dead#SRD 5.2.1|Speak with Dead]]

### Speak with Plants

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Plants#SRD 5.2.1|Speak with Plants]]

### Spider Climb

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spider Climb#SRD 5.2.1|Spider Climb]]

### Spike Growth

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spike Growth#SRD 5.2.1|Spike Growth]]

### Spirit Guardians

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Spirit Guardians#SRD 5.2.1|Spirit Guardians]]

### Spiritual Weapon

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spiritual Weapon#SRD 5.2.1|Spiritual Weapon]]

### Starry Wisp

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Starry Wisp#SRD 5.2.1|Starry Wisp]]

### Stinking Cloud

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Stinking Cloud#SRD 5.2.1|Stinking Cloud]]

### Stone Shape

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stone Shape#SRD 5.2.1|Stone Shape]]

### Stoneskin

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stoneskin#SRD 5.2.1|Stoneskin]]

### Storm of Vengeance

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Storm of Vengeance#SRD 5.2.1|Storm of Vengeance]]

### Suggestion

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Suggestion#SRD 5.2.1|Suggestion]]

### Summon Dragon

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Summon Dragon#SRD 5.2.1|Summon Dragon]]

### Sunbeam

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Sunbeam#SRD 5.2.1|Sunbeam]]

### Sunburst

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Sunburst#SRD 5.2.1|Sunburst]]

### Symbol

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Symbol#SRD 5.2.1|Symbol]]

### Telekinesis

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Telekinesis#SRD 5.2.1|Telekinesis]]

### Telepathic Bond

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Telepathic Bond#SRD 5.2.1|Telepathic Bond]]

### Teleport

[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Teleport#SRD 5.2.1|Teleport]]

### Teleportation Circle

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Teleportation Circle#SRD 5.2.1|Teleportation Circle]]

### Thaumaturgy

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Thaumaturgy#SRD 5.2.1|Thaumaturgy]]

### Thunderwave

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Thunderwave#SRD 5.2.1|Thunderwave]]

### Time Stop

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Time Stop#SRD 5.2.1|Time Stop]]

### Tiny Hut

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tiny Hut#SRD 5.2.1|Tiny Hut]]

### Tongues

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tongues#SRD 5.2.1|Tongues]]

### Transport via Plants

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Transport via Plants#SRD 5.2.1|Transport via Plants]]

### Tree Stride

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Tree Stride#SRD 5.2.1|Tree Stride]]

### True Polymorph

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/True Polymorph#SRD 5.2.1|True Polymorph]]

### True Resurrection

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/True Resurrection#SRD 5.2.1|True Resurrection]]

### True Seeing

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/True Seeing#SRD 5.2.1|True Seeing]]

### True Strike

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/True Strike#SRD 5.2.1|True Strike]]

### Tsunami

[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Tsunami#SRD 5.2.1|Tsunami]]

### Unseen Servant

[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Unseen Servant#SRD 5.2.1|Unseen Servant]]

### Vampiric Touch

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Vampiric Touch#SRD 5.2.1|Vampiric Touch]]

### Vicious Mockery

[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Vicious Mockery#SRD 5.2.1|Vicious Mockery]]

### Vitriolic Sphere

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Vitriolic Sphere#SRD 5.2.1|Vitriolic Sphere]]

### Wall of Fire

[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Wall of Fire#SRD 5.2.1|Wall of Fire]]

### Wall of Force

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Wall of Force#SRD 5.2.1|Wall of Force]]

### Wall of Ice

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Wall of Ice#SRD 5.2.1|Wall of Ice]]

### Wall of Stone

[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Wall of Stone#SRD 5.2.1|Wall of Stone]]

### Wall of Thorns

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Wall of Thorns#SRD 5.2.1|Wall of Thorns]]

### Warding Bond

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Warding Bond#SRD 5.2.1|Warding Bond]]

### Water Breathing

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Breathing#SRD 5.2.1|Water Breathing]]

### Water Walk

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Walk#SRD 5.2.1|Water Walk]]

### Web

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Web#SRD 5.2.1|Web]]

### Weird

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Weird#SRD 5.2.1|Weird]]

### Wind Walk

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Wind Walk#SRD 5.2.1|Wind Walk]]

### Wind Wall

[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Wind Wall#SRD 5.2.1|Wind Wall]]

### Wish

[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Wish#SRD 5.2.1|Wish]]

### Word of Recall

[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Word of Recall#SRD 5.2.1|Word of Recall]]

### Zone of Truth

[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Zone of Truth#SRD 5.2.1|Zone of Truth]]

## Tables and Boxed Reference Material

These extracts preserve the PDF’s table layout alongside the text above.

### Page 104 — srd-p104-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p104-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=104|Open source page 104]]

### Page 105 — srd-p105-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p105-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=105|Open source page 105]]

### Page 107 — srd-p107-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p107-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=107|Open source page 107]]

### Page 108 — srd-p108-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p108-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=108|Open source page 108]]

### Page 109 — srd-p109-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p109-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=109|Open source page 109]]

### Page 110 — srd-p110-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p110-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=110|Open source page 110]]

### Page 110 — srd-p110-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p110-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=110|Open source page 110]]

### Page 110 — srd-p110-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p110-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=110|Open source page 110]]

### Page 110 — srd-p110-table-4.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p110-table-4.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=110|Open source page 110]]

### Page 111 — srd-p111-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p111-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=111|Open source page 111]]

### Page 111 — srd-p111-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p111-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=111|Open source page 111]]

### Page 111 — srd-p111-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p111-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=111|Open source page 111]]

### Page 112 — srd-p112-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p112-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=112|Open source page 112]]

### Page 113 — srd-p113-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p113-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=113|Open source page 113]]

### Page 113 — srd-p113-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p113-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=113|Open source page 113]]

### Page 114 — srd-p114-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p114-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=114|Open source page 114]]

### Page 115 — srd-p115-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p115-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=115|Open source page 115]]

### Page 115 — srd-p115-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p115-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=115|Open source page 115]]

### Page 115 — srd-p115-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p115-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=115|Open source page 115]]

### Page 117 — srd-p117-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p117-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=117|Open source page 117]]

### Page 118 — srd-p118-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p118-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=118|Open source page 118]]

### Page 119 — srd-p119-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p119-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=119|Open source page 119]]

### Page 119 — srd-p119-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p119-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=119|Open source page 119]]

### Page 119 — srd-p119-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p119-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=119|Open source page 119]]

### Page 120 — srd-p120-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p120-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=120|Open source page 120]]

### Page 120 — srd-p120-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p120-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=120|Open source page 120]]

### Page 120 — srd-p120-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p120-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=120|Open source page 120]]

### Page 120 — srd-p120-table-4.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p120-table-4.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=120|Open source page 120]]

### Page 121 — srd-p121-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p121-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=121|Open source page 121]]

### Page 121 — srd-p121-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p121-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=121|Open source page 121]]

### Page 121 — srd-p121-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p121-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=121|Open source page 121]]

### Page 122 — srd-p122-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p122-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=122|Open source page 122]]

### Page 122 — srd-p122-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p122-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=122|Open source page 122]]

### Page 123 — srd-p123-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p123-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=123|Open source page 123]]

### Page 125 — srd-p125-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p125-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=125|Open source page 125]]

### Page 125 — srd-p125-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p125-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=125|Open source page 125]]

### Page 125 — srd-p125-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p125-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=125|Open source page 125]]

### Page 125 — srd-p125-table-4.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p125-table-4.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=125|Open source page 125]]

### Page 127 — srd-p127-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p127-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=127|Open source page 127]]

### Page 127 — srd-p127-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p127-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=127|Open source page 127]]

### Page 128 — srd-p128-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p128-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=128|Open source page 128]]

### Page 129 — srd-p129-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p129-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=129|Open source page 129]]

### Page 130 — srd-p130-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p130-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=130|Open source page 130]]

### Page 130 — srd-p130-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p130-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=130|Open source page 130]]

### Page 131 — srd-p131-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p131-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=131|Open source page 131]]

### Page 132 — srd-p132-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p132-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=132|Open source page 132]]

### Page 132 — srd-p132-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p132-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=132|Open source page 132]]

### Page 133 — srd-p133-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p133-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=133|Open source page 133]]

### Page 134 — srd-p134-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p134-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=134|Open source page 134]]

### Page 134 — srd-p134-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p134-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=134|Open source page 134]]

### Page 135 — srd-p135-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p135-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=135|Open source page 135]]

### Page 136 — srd-p136-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p136-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=136|Open source page 136]]

### Page 137 — srd-p137-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p137-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=137|Open source page 137]]

### Page 137 — srd-p137-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p137-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=137|Open source page 137]]

### Page 137 — srd-p137-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p137-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=137|Open source page 137]]

### Page 138 — srd-p138-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p138-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=138|Open source page 138]]

### Page 139 — srd-p139-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p139-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=139|Open source page 139]]

### Page 139 — srd-p139-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p139-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=139|Open source page 139]]

### Page 139 — srd-p139-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p139-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=139|Open source page 139]]

### Page 140 — srd-p140-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p140-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=140|Open source page 140]]

### Page 140 — srd-p140-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p140-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=140|Open source page 140]]

### Page 140 — srd-p140-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p140-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=140|Open source page 140]]

### Page 141 — srd-p141-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p141-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=141|Open source page 141]]

### Page 141 — srd-p141-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p141-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=141|Open source page 141]]

### Page 141 — srd-p141-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p141-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=141|Open source page 141]]

### Page 142 — srd-p142-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p142-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=142|Open source page 142]]

### Page 142 — srd-p142-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p142-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=142|Open source page 142]]

### Page 143 — srd-p143-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p143-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=143|Open source page 143]]

### Page 143 — srd-p143-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p143-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=143|Open source page 143]]

### Page 143 — srd-p143-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p143-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=143|Open source page 143]]

### Page 144 — srd-p144-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p144-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=144|Open source page 144]]

### Page 144 — srd-p144-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p144-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=144|Open source page 144]]

### Page 145 — srd-p145-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p145-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=145|Open source page 145]]

### Page 145 — srd-p145-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p145-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=145|Open source page 145]]

### Page 146 — srd-p146-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p146-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=146|Open source page 146]]

### Page 146 — srd-p146-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p146-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=146|Open source page 146]]

### Page 147 — srd-p147-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p147-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=147|Open source page 147]]

### Page 147 — srd-p147-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p147-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=147|Open source page 147]]

### Page 148 — srd-p148-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p148-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=148|Open source page 148]]

### Page 149 — srd-p149-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p149-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=149|Open source page 149]]

### Page 150 — srd-p150-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p150-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=150|Open source page 150]]

### Page 151 — srd-p151-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p151-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=151|Open source page 151]]

### Page 152 — srd-p152-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p152-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=152|Open source page 152]]

### Page 153 — srd-p153-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p153-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=153|Open source page 153]]

### Page 154 — srd-p154-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p154-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=154|Open source page 154]]

### Page 154 — srd-p154-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p154-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=154|Open source page 154]]

### Page 154 — srd-p154-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p154-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=154|Open source page 154]]

### Page 155 — srd-p155-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p155-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=155|Open source page 155]]

### Page 156 — srd-p156-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p156-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=156|Open source page 156]]

### Page 156 — srd-p156-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p156-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=156|Open source page 156]]

### Page 157 — srd-p157-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p157-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=157|Open source page 157]]

### Page 157 — srd-p157-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p157-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=157|Open source page 157]]

### Page 158 — srd-p158-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p158-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=158|Open source page 158]]

### Page 158 — srd-p158-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p158-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=158|Open source page 158]]

### Page 158 — srd-p158-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p158-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=158|Open source page 158]]

### Page 158 — srd-p158-table-4.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p158-table-4.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=158|Open source page 158]]

### Page 158 — srd-p158-table-5.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p158-table-5.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=158|Open source page 158]]

### Page 159 — srd-p159-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p159-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=159|Open source page 159]]

### Page 159 — srd-p159-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p159-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=159|Open source page 159]]

### Page 159 — srd-p159-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p159-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=159|Open source page 159]]

### Page 160 — srd-p160-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p160-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=160|Open source page 160]]

### Page 160 — srd-p160-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p160-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=160|Open source page 160]]

### Page 160 — srd-p160-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p160-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=160|Open source page 160]]

### Page 160 — srd-p160-table-4.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p160-table-4.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=160|Open source page 160]]

### Page 161 — srd-p161-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p161-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=161|Open source page 161]]

### Page 161 — srd-p161-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p161-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=161|Open source page 161]]

### Page 161 — srd-p161-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p161-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=161|Open source page 161]]

### Page 162 — srd-p162-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p162-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=162|Open source page 162]]

### Page 162 — srd-p162-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p162-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=162|Open source page 162]]

### Page 162 — srd-p162-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p162-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=162|Open source page 162]]

### Page 162 — srd-p162-table-4.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p162-table-4.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=162|Open source page 162]]

### Page 163 — srd-p163-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p163-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=163|Open source page 163]]

### Page 163 — srd-p163-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p163-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=163|Open source page 163]]

### Page 163 — srd-p163-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p163-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=163|Open source page 163]]

### Page 164 — srd-p164-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p164-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=164|Open source page 164]]

### Page 164 — srd-p164-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p164-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=164|Open source page 164]]

### Page 165 — srd-p165-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p165-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=165|Open source page 165]]

### Page 165 — srd-p165-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p165-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=165|Open source page 165]]

### Page 166 — srd-p166-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p166-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=166|Open source page 166]]

### Page 167 — srd-p167-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p167-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=167|Open source page 167]]

### Page 168 — srd-p168-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p168-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=168|Open source page 168]]

### Page 170 — srd-p170-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p170-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=170|Open source page 170]]

### Page 171 — srd-p171-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p171-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=171|Open source page 171]]

### Page 171 — srd-p171-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p171-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=171|Open source page 171]]

### Page 171 — srd-p171-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p171-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=171|Open source page 171]]

### Page 172 — srd-p172-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p172-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=172|Open source page 172]]

### Page 172 — srd-p172-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p172-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=172|Open source page 172]]

### Page 173 — srd-p173-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p173-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=173|Open source page 173]]

### Page 173 — srd-p173-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p173-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=173|Open source page 173]]

### Page 173 — srd-p173-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p173-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=173|Open source page 173]]

### Page 174 — srd-p174-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p174-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=174|Open source page 174]]

### Page 174 — srd-p174-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p174-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=174|Open source page 174]]
