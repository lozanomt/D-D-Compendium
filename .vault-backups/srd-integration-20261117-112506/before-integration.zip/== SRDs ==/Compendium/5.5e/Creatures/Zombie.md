---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 4b6ac031-7fda-5fa3-a936-22f48f363dff
entity_type: creature
source_ids: ["mm-2025", "phb-2024"]
source_versions: ["Monster Manual", "Player's Handbook"]
---

# Zombie

One creature entry with separately labeled source versions. Each book’s chapter links to its own version.

## Monster Manual

> [!statblock]
> ### Zombie
> *Medium Undead, Neutral Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p349-zombie.png|320]]
> 
> 
> **AC** 8 **Initiative** -2 (8)  
> **HP** 15 (2d8 + 6)  
> **Speed** 20 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 6 | -2 | -2 | **Con** | 16 | +3 | +3 |
> | **Int** | 3 | -4 | -4 | **Wis** | 6 | -2 | +0 | **Cha** | 5 | -3 | -3 |
> 
> **Immunities** Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 8  
> **Languages** Understands Common plus one other language but can't speak  
> **CR** 1/4 (XP 50; PB +2)  
> 
> **Habitat** Planar (Shadowfell), Underdark, Urban  
> **Treasure** None  
> 
> #### Traits
> ***Undead Fortitude.*** If damage reduces the zombie to 0 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]], it makes a Constitution saving throw (DC 5 plus the damage taken) unless the damage is Radiant or from a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Critical Hit|Critical Hit]]. On a successful save, the zombie drops to 1 Hit Point instead.
> #### Actions
> ***Slam.*** *Melee Attack Roll:* +3, reach 5 ft. *Hit:* 5 (1d8 + 1) Bludgeoning damage.

## Player's Handbook

> [!statblock]
> ### Zombie
> *Medium Undead, Neutral Evil*
>
> **AC** 8 **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]]** -2 (8)  
> **HP** 15 (2d8 + 6)  
> **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]** 20 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 6 | -2 | -2 | **Con** | 16 | +3 | +3 |
> | **Int** | 3 | -4 | -4 | **Wis** | 6 | -2 | +0 | **Cha** | 5 | -3 | -3 |
>
> **Immunities** Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 8  
> **Languages** Understands the languages it knew in life but can’t speak  
> **CR** 1/4 (XP 50; PB +2)  
>
> #### Traits
> ***Undead Fortitude.*** If damage reduces the zombie to 0 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]], it makes a Constitution saving throw (DC 5 plus the damage taken) unless the damage is Radiant or from a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Critical Hit|Critical Hit]]. On a successful save, the zombie drops to 1 Hit Point instead.
> #### Actions
> ***Slam.*** *Melee [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack|Attack]] Roll:* +3, reach 5 ft. *Hit:* 4 (1d6 + 1) Bludgeoning damage.

Source: [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=362|Player’s Handbook (2024), p. 359]].

[[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/Compendium/5.5e/Creatures/Zombie#Monster Manual|Monster Manual version]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Player's Handbook — Appendix B - Creature Stat Blocks]]
