---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 0f970668-8ee2-58e7-a75b-2eed8d473683
entity_type: character-option
source_ids: ["phb-2024"]
---

# Primal Champion

![[== SRDs ==/Attachments/Artwork/phb-p053-barbarian.png|320]]

You embody primal power. Your Strength and Constitution scores increase by 4, to a maximum of 25.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=54|Player’s Handbook (2024), PDF page 54]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
