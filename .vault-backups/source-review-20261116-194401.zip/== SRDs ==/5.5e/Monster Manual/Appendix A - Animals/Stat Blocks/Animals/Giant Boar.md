---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Boar
> 
> *Large Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/Monster Manual/Artwork/mm-p357-giant-boar.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +0 (10)  
> **HP** 42 (5d10 + 15)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +5 | **Dex** | 10 | +0 | +0 | **Con** | 16 | +3 | +3 |
> | **Int** | 2 | -4 | -4 | **Wis** | 7 | -2 | -2 | **Cha** | 5 | -3 | -3 |
> 
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 8  
> **Languages** None  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Bloodied Fury.*** The boar has Advantage on melee attack rolls while it is Bloodied.
> 
> ### Actions
> 
> ***Gore.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 10 (2d6 + 3) Piercing damage. If the target is a Large or smaller creature and the boar moved 20+ feet straight toward it immediately before the hit, the target takes an extra 7 (2d6) Piercing damage and has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone]] condition.
