---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Locate Creature
*Level 4 Divination (Bard, Cleric, Druid, Paladin, Ranger, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (fur from a bloodhound)
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 hour

Describe or name a creature that is familiar to you. You sense the direction to the creature's location if that creature is within 1,000 feet of you. If the creature is moving, you know the direction of its movement.

The spell can locate a specific creature known to you or the nearest creature of a specific kind (such as a human or a unicorn) if you have seen such a creature up close - within 30 feet - at least once. If the creature you described or named is in a different form, such as under the effects of a *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 6/Flesh to Stone|Flesh to Stone]]* or *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Polymorph|Polymorph]]* spell, this spell doesn't locate the creature.

This spell can't locate a creature if any thickness of lead blocks a direct path between you and the creature.
