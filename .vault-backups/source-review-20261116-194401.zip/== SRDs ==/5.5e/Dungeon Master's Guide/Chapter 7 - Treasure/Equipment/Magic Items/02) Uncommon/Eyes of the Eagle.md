---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Eyes of the Eagle [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Eyes of the Eagle|(400 GP)]]
*Wondrous Item, Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p264-eyes-of-charming.png|320]]


**Attunement:** No

These crystal lenses fit over the eyes. While wearing them, you have [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage]] on Wisdom ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]]) checks that rely on sight. In conditions of clear visibility, you can make out details of even extremely distant creatures and objects as small as 2 feet across.
