---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Glass Bottle [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Glass Bottle|(2 GP)]] 

![[Placeholder.png|320]]

A Glass Bottle holds up to 1.5 pints.

**Weight:** 2 lb.
