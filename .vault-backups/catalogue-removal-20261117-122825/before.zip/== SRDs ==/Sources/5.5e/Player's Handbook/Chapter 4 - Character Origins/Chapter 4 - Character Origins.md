# Chapter 4 - Character Origins

13 existing entries.

- [[== SRDs ==/Compendium/5.5e/Character Options/Backgrounds/Acolyte#Player's Handbook|Acolyte]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Backgrounds/Criminal#Player's Handbook|Criminal]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Backgrounds/Sage#Player's Handbook|Sage]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Backgrounds/Soldier#Player's Handbook|Soldier]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Species/Dragonborn#Player's Handbook|Dragonborn]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Species/Dwarf#Player's Handbook|Dwarf]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Species/Elf#Player's Handbook|Elf]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Species/Gnome#Player's Handbook|Gnome]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Species/Goliath#Player's Handbook|Goliath]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Species/Halfling#Player's Handbook|Halfling]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Species/Human#Player's Handbook|Human]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Species/Orc#Player's Handbook|Orc]]
- [[== SRDs ==/Compendium/5.5e/Character Options/Species/Tiefling#Player's Handbook|Tiefling]]
