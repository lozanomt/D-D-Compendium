---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [308, 309]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Level 8 Spell Scroll
*Scroll, Very Rare*

![[Placeholder.png|320]]

**Attunement:** No

**Spell level:** 8  
**Spell save DC:** 18  
**Spell [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|attack]] bonus:** +10

A [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/Spell Scroll/Spell Scroll|Spell Scroll]] holds one spell in a mystical cipher. If the spell is on your spell list, you can read and cast it without Material [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Components|components]]; otherwise the scroll is unintelligible. Use the spell's normal casting time. The scroll crumbles to dust when the spell is cast; interrupting the casting does not destroy it.

If the spell is on your list but is a higher level than you can normally cast, make an ability check using your [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Spellcasting|spellcasting]] ability, with DC 10 + the spell's level. On a failure, the spell disappears from the scroll without effect.

See Spell Scroll for the full rarity and level table.

**Copying into a [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Spellbook|Spellbook]].** A [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Wizard/Wizard|Wizard]] spell on a scroll can be copied into a spellbook. The copier makes an Intelligence ([[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Arcana|Arcana]]) check with DC 10 + the spell's level. A success copies the spell. The scroll is destroyed whether the check succeeds or fails.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=308|p. 305 (PDF page 308)]]; [[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=309|p. 306 (PDF page 309)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
