---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Sunburst
*Level 8 Evocation (Cleric, Druid, Sorcerer, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 150 feet
**Components:** V, S, M (a piece of sunstone)
**Duration:** Instantaneous

Brilliant sunlight flashes in a 60-foot-radius [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Sphere|Sphere]] centered on a point you choose within range. Each creature in the Sphere makes a Constitution saving throw. On a failed save, a creature takes 12d6 Radiant damage and has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded|Blinded]] condition for 1 minute. On a successful save, it takes half as much damage only.

A creature Blinded by this spell makes another Constitution saving throw at the end of each of its turns, ending the effect on itself on a success.

This spell dispels [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Darkness|Darkness]] in its area that was created by any spell.
