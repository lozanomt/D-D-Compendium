---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Mithral Splint [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Mithral Armor/Mithral Splint|(600 GP)]]
*Armor ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Splint Armor|Splint Armor]]), Uncommon*

![[Placeholder.png|320]]


**Attunement:** No

This armor weighs half as much as it normally would and can be worn under regular clothes. In addition, if the armor normally imposes [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on Dexterity ([[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]]) checks or has a Strength requirement, the mithral version of the armor does not.

---
![[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Splint Armor|clean no-title]]
