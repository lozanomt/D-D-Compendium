---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 5a7f643f-0c50-54dd-8fcc-6dd72dbd9c39
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [35]
---

# Cutting Words

![[== SRDs ==/Attachments/Artwork/phb-p069-college-of-lore.png|320]]

You learn to use your wit to supernaturally distract, confuse, and otherwise sap the confidence and competence of others. When a creature that you can see within 60 feet of yourself makes a damage roll or succeeds on an ability check or attack roll, you can take a Reaction to expend one use of your [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Bard/Bardic Inspiration|Bardic Inspiration]]; roll your Bardic Inspiration die, and subtract the number rolled from the creature’s roll, reducing the damage or potentially turning the success into a failure.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=69|Player’s Handbook (2024), PDF page 69]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=70|Player’s Handbook (2024), PDF page 70]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

You learn to use your wit to supernaturally distract, confuse, and otherwise sap the confidence and competence of others. When a creature that you can see within 60 feet of yourself makes a damage roll or succeeds on an ability check or attack roll, you can take a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Reaction|Reaction]] to expend one use of your Bardic Inspiration; roll your Bardic Inspiration die, and subtract the number rolled from the creature's roll, reducing the damage or potentially turning the success into a failure.

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=35|SRD 5.2.1, p. 35]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=35|SRD 5.2.1, p. 35]]
