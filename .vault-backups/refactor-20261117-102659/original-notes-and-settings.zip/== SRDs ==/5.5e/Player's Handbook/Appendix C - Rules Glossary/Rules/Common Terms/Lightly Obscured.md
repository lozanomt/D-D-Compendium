---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Lightly Obscured

![[Placeholder.png|320]]


You have Disadvantage on Wisdom ([[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]]) checks to see something in a Lightly Obscured space.
