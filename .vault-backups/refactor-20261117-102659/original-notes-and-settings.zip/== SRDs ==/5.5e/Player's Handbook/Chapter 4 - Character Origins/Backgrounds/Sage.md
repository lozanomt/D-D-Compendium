---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Sage

![[phb-p186-sage.png|320]]

**Ability Scores:** Constitution, Intelligence, Wisdom
**Feat:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 5 - Feats/Feats/01) Origin Feats/Magic Initiate|Magic Initiate]] (Wizard)
**Skill Proficiencies** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Arcana|Arcana]] and [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/History|History]]
**Tool Proficiency:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Artisan's Tools/Calligrapher's Supplies|Calligrapher's Supplies]]
**Equipment:** *Choose A or B:* (A) [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Simple Melee/Quarterstaff|Quarterstaff]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Artisan's Tools/Calligrapher's Supplies|Calligrapher's Supplies]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Book|Book]] (history), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Parchment|Parchment]] (8 sheets), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Robe|Robe]], 8 GP; or (B) 50 GP
