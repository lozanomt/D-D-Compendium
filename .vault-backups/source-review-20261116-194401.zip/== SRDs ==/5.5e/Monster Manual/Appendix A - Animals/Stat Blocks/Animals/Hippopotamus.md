---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Hippopotamus
> 
> *Large Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** -2 (8)  
> **HP** 82 (11d10 + 22)  
> **Speed** 30 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 21 | +5 | +7 | **Dex** | 7 | -2 | -2 | **Con** | 15 | +2 | +2 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 4 | -3 | -3 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +3  
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 13  
> **Languages** None  
> **CR** 4 (XP 1,100; PB +2)  
> 
> ### Traits
> 
> ***Hold Breath.*** The hippopotamus can hold its breath for 10 minutes.
> 
> ### Actions
> 
> ***Multiattack.*** The hippopotamus makes two Bite attacks.
> 
> ***Bite.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 16 (2d10 + 5) Piercing damage.
