---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 63feb5d9-5497-5c15-bdb8-95aa30b6ac70
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [315]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Planetar

## Monster Manual

> [!statblock]
> ### Planetar
>
> *Large Celestial (Angel), Lawful Good*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p247-planetar.png|320]]
>
> **AC** 19 &emsp; **Initiative** +10 (20)  
> **HP** 262 (21d10 + 147)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 120 ft. (hover)  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 24 | +7 | +12 | **Dex** | 20 | +5 | +5 | **Con** | 24 | +7 | +12 |
> | **Int** | 19 | +4 | +4 | **Wis** | 22 | +6 | +11 | **Cha** | 25 | +7 | +12 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +11  
> **Resistances** Radiant  
> **Immunities** [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Truesight|Truesight]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 21  
> **Languages** All; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Telepathy|Telepathy]] 120 ft.  
> **CR** 16 (XP 15,000; PB +5)  
>
> ### Traits
>
> ***Divine Awareness.*** The planetar knows if it hears a lie.
>
> ***Exalted Restoration.*** If the planetar dies outside Mount Celestia, its body disappears, and it gains a new body instantly, reviving with all its Hit Points somewhere in Mount Celestia.
>
> ***Magic Resistance.*** The planetar has Advantage on saving throws against spells and other magical effects.
>
> ### Actions
>
> ***Multiattack.*** The planetar makes three Radiant Sword attacks or uses Holy Burst twice.
>
> ***Radiant Sword.*** *Melee Attack Roll:* +12, reach 10 ft. *Hit:* 14 (2d6 + 7) Slashing damage plus 18 (4d8) Radiant damage.
>
> ***Holy Burst.*** *Dexterity Saving Throw:* DC 20, each enemy in a 20-foot-radius Sphere centered on a point the planetar can see within 120 feet. *Failure:* 24 (7d6) Radiant damage. *Success:* Half damage.
>
> ***Spellcasting.*** The planetar casts one of the following spells, requiring no Material components and using Charisma as spellcasting ability (spell save DC 20):
>
> - **At Will:** *Detect Evil and Good*
> - **1/Day Each:** *Commune*, *Control Weather*, *Dispel Evil and Good*, *Raise Dead*
>
> ### Bonus Actions
>
> ***Divine Aid (2/Day).*** The planetar casts *Cure Wounds*, *Invisibility*, *Lesser Restoration*, or *Remove Curse*, using the same spellcasting ability as Spellcasting.
> - [ ]
> - [ ]
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1

> [!statblock]
> ### Planetar
>
> *Large Celestial (Angel), Lawful Good*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p247-planetar.png|320]]
>
> **AC** 19 &emsp; **Initiative** +10 (20)  
> **HP** 262 (21d10 + 147)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 120 ft. (hover)  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 24 | +7 | +12 | **Dex** | 20 | +5 | +5 | **Con** | 24 | +7 | +12 |
> | **Int** | 19 | +4 | +4 | **Wis** | 22 | +6 | +11 | **Cha** | 25 | +7 | +12 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +11  
> **Resistances** Radiant  
> **Immunities** [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Truesight|Truesight]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 21  
> **Languages** All; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Telepathy|Telepathy]] 120 ft.  
> **CR** 16 (XP 15,000; PB +5)  
>
> ### Traits
>
> ***Divine Awareness.*** The planetar knows if it hears a lie.
>
> ***Exalted Restoration.*** If the planetar dies outside Mount Celestia, its body disappears, and it gains a new body instantly, reviving with all its Hit Points somewhere in Mount Celestia.
>
> ***Magic Resistance.*** The planetar has Advantage on saving throws against spells and other magical effects.
>
> ### Actions
>
> ***Multiattack.*** The planetar makes three Radiant Sword attacks or uses Holy Burst twice.
>
> ***Radiant Sword.*** *Melee Attack Roll:* +12, reach 10 ft. *Hit:* 14 (2d6 + 7) Slashing damage plus 18 (4d8) Radiant damage.
>
> ***Holy Burst.*** *Dexterity Saving Throw:* DC 20, each enemy in a 20-foot-radius Sphere centered on a point the planetar can see within 120 feet. *Failure:* 24 (7d6) Radiant damage. *Success:* Half damage.
>
> ***Spellcasting.*** The planetar casts one of the following spells, requiring no Material components and using Charisma as spellcasting ability (spell save DC 20):
>
> - **At Will:** *Detect Evil and Good*
> - **1/Day Each:** *Commune*, *Control Weather*, *Dispel Evil and Good*, *Raise Dead*
>
> ### Bonus Actions
>
> ***Divine Aid (2/Day).*** The planetar casts *Cure Wounds*, *Invisibility*, *Lesser Restoration*, or *Remove Curse*, using the same spellcasting ability as Spellcasting.
> - [ ]
> - [ ]
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=315|SRD 5.2.1, p. 315]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=315|SRD 5.2.1, p. 315]]
