---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 0b5772cd-1d26-55c0-ae33-73b40e514897
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Clay Golem
> 
> *Large Construct, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p074-clay-golem.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +3 (13)  
> **HP** 123 (13d10 + 52)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 20 | +5 | +5 | **Dex** | 9 | -1 | -1 | **Con** | 18 | +4 | +4 |
> | **Int** | 3 | -4 | -4 | **Wis** | 8 | -1 | -1 | **Cha** | 1 | -5 | -5 |
> 
> **Resistances** Bludgeoning, Piercing, Slashing  
> **Immunities** Acid, Poison, Psychic; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Petrified|Petrified]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** Common plus one other language  
> **CR** 9 (XP 5,000; PB +4)  
> 
> ### Traits
> 
> ***Acid Absorption.*** Whenever the golem is subjected to Acid damage, it takes no damage and instead regains a number of Hit Points equal to the Acid damage dealt.
> 
> ***Berserk.*** Whenever the golem starts its turn Bloodied, roll 1d6. On a 6, the golem goes berserk. On each of its turns while berserk, the golem attacks the nearest creature it can see. If no creature is near enough to move to and attack, the golem attacks an object. Once the golem goes berserk, it continues to be berserk until it is destroyed or it is no longer Bloodied.
> 
> ***Immutable Form.*** The golem can't shape-shift.
> 
> ***Magic Resistance.*** The golem has Advantage on saving throws against spells and other magical effects.
> 
> ### Actions
> 
> ***Multiattack.*** The golem makes two Slam attacks, or it makes three Slam attacks if it used Hasten this turn.
> 
> ***Slam.*** *Melee Attack Roll:* +9, reach 5 ft. *Hit:* 10 (1d10 + 5) Bludgeoning damage plus 6 (1d12) Acid damage, and the target's Hit Point maximum decreases by an amount equal to the Acid damage taken.
> 
> ### Bonus Actions
> 
> ***Hasten (Recharge 5-6).*** The golem takes the Dash and Disengage actions.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
