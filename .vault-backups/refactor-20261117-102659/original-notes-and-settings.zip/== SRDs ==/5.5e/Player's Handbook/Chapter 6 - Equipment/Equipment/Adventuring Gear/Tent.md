---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Tent [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Tent|(2 GP)]] 

![[Placeholder.png|320]]

A Tent sleeps up to two Small or Medium creatures.

**Weight:** 20 lb.
