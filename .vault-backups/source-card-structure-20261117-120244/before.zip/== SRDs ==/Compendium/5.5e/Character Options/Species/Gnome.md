---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 66bb7760-1af0-5907-a8db-50aab440823a
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [85]
---

# Gnome

![[== SRDs ==/Attachments/Artwork/phb-p194-gnome.png|320]]

**Creature Type:** Humanoid
**Size:** Small (about 3 - 4 feet tall)
**[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]:** 30 feet

As a Gnome, you have these special traits.

***Darkvision.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] with a range of 60 feet.

***Gnomish Cunning.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on Intelligence, Wisdom, and Charisma saving throws.

***Gnomish Lineage.*** You are part of a lineage that grants you supernatural abilities. Choose one of the following options; whichever one you choose, Intelligence, Wisdom, or Charisma is your spellcasting ability for the spells you cast with this trait (choose the ability when you select the lineage):

- **Forest Gnome.** You know the *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Minor Illusion|Minor Illusion]]* cantrip. You also always have the *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Speak with Animals|Speak with Animals]]* spell prepared. You can cast it without a spell slot a number of times equal to your Proficiency Bonus, and you regain all expended uses when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]]. You can also use any spell slots you have to cast the spell.
- **Rock Gnome.** You know the *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mending|Mending]]* and *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Prestidigitation|Prestidigitation]]* cantrips. In addition, you can spend 10 minutes casting Prestidigitation to create a Tiny clockwork device (AC 5, 1 HP), such as a toy, fire starter, or music box. When you create the device, you determine its function by choosing one effect from Prestidigitation; the device produces that effect whenever you or another creature takes a Bonus Action to activate it with a touch. If the chosen effect has options within it, you choose one of those options for the device when you create it. For example, if you choose the spell’s ignite-extinguish effect, you determine whether the device ignites or extinguishes fire; the device doesn’t do both. You can have three such devices in existence at a time, and each falls apart 8 hours after its creation or when you dismantle it with a touch as a [[== SRDs ==/Compendium/5.5e/Rules/Actions/Utilize|Utilize]] action.

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Player's Handbook — Chapter 4 - Character Origins]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=85|SRD 5.2.1, p. 85]] — matches the existing entry.
