---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 2875e50c-8a59-542f-ae78-159ebcdad1fa
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [277]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Ancient Copper Dragon

## Monster Manual


> [!statblock]
> ### Ancient Copper Dragon
>
> *Gargantuan Dragon (Metallic), Chaotic Good*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p083-ancient-copper-dragon.png|320]]
>
> **AC:** 21 &emsp;  
> **Initiative:** +15 (25)  
> **HP:** 367 (21d20 + 147)  
> **Speed:** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 80 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 27 | +8 | +8 | **Dex** | 12 | +1 | +8 | **Con** | 25 | +7 | +7 |
> | **Int** | 20 | +5 | +5 | **Wis** | 17 | +3 | +10 | **Cha** | 22 | +6 | +6 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Deception|Deception]] +13, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +17, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +8  
> **Immunities:** Acid  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 27  
> **Languages:** Common, Draconic  
> **CR:** 21 (XP 33,000, or 41,000 in lair; PB +7)  
>
> #### Traits
>
> ***Legendary Resistance (4/Day, or 5/Day in Lair).*** If the dragon fails a saving throw, it can choose to succeed instead.
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> #### Actions
>
> ***Multiattack.*** The dragon makes three Rend attacks. It can replace one attack with a use of (A) Slowing Breath or (B) Spellcasting to cast *Mind Spike* (level 5 version).
>
> ***Rend.*** *Melee Attack Roll:* +15, reach 15 ft. *Hit:* 19 (2d10 + 8) Slashing damage plus 9 (2d8) Acid damage.
>
> ***Acid Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 22, each creature in an 90-foot-long, 10-footwide Line. *Failure:* 63 (14d8) Acid damage. *Success:* Half damage.
>
> ***Slowing Breath.*** *Constitution Saving Throw:* DC 22, each creature in a 90-foot Cone. *Failure:* The target can't take Reactions; its Speed is halved; and it can take either an action or a Bonus Action on its turn, not both. This effect lasts until the end of its next turn.
>
> ***Spellcasting.*** The dragon casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 21):
>
> - **At Will:** *Detect Magic*, *Mind Spike* (level 5 version), *Minor Illusion*, *Shapechange* (Beast or Humanoid form only, no Temporary Hit Points gained from the spell, and no Concentration or Temporary Hit Points required to maintain the spell)
> - **1/Day Each:** *Greater Restoration*, *Major Image*, *Project Image*
>
> #### Legendary Actions
>
> *Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the dragon can expend a use to take one of the following actions. The dragon regains all expended uses at the start of each of its turns.*
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> ***Giggling Magic.*** *Charisma Saving Throw:* DC 21, one creature the dragon can see within 120 feet. *Failure:* 31 (9d6) Psychic damage. Until the end of its next turn, the target rolls 1d8 whenever it makes an ability check or attack roll and subtracts the number rolled from the D20 Test. *Failure or Success:* The dragon can't take this action again until the start of its next turn.
>
> ***Mind Jolt.*** The dragon uses Spellcasting to cast *Mind Spike* (level 5 version). The dragon can't take this action again until the start of its next turn.
>
> ***Pounce.*** The dragon moves up to half its Speed, and it makes one Rend attack.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Ancient Copper Dragon
>
> *Gargantuan Dragon (Metallic), Chaotic Good*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p083-ancient-copper-dragon.png|320]]
>
> **AC:** 21 &emsp;  
> **Initiative:** +15 (25)  
> **HP:** 367 (21d20 + 147)  
> **Speed:** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 80 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 27 | +8 | +8 | **Dex** | 12 | +1 | +8 | **Con** | 25 | +7 | +7 |
> | **Int** | 20 | +5 | +5 | **Wis** | 17 | +3 | +10 | **Cha** | 22 | +6 | +6 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Deception|Deception]] +13, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +17, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +8  
> **Immunities:** Acid  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 27  
> **Languages:** Common, Draconic  
> **CR:** 21 (XP 33,000, or 41,000 in lair; PB +7)  
>
> #### Traits
>
> ***Legendary Resistance (4/Day, or 5/Day in Lair).*** If the dragon fails a saving throw, it can choose to succeed instead.
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> #### Actions
>
> ***Multiattack.*** The dragon makes three Rend attacks. It can replace one attack with a use of (A) Slowing Breath or (B) Spellcasting to cast *Mind Spike* (level 5 version).
>
> ***Rend.*** *Melee Attack Roll:* +15, reach 15 ft. *Hit:* 19 (2d10 + 8) Slashing damage plus 9 (2d8) Acid damage.
>
> ***Acid Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 22, each creature in an 90-foot-long, 10-footwide Line. *Failure:* 63 (14d8) Acid damage. *Success:* Half damage.
>
> ***Slowing Breath.*** *Constitution Saving Throw:* DC 22, each creature in a 90-foot Cone. *Failure:* The target can't take Reactions; its Speed is halved; and it can take either an action or a Bonus Action on its turn, not both. This effect lasts until the end of its next turn.
>
> ***Spellcasting.*** The dragon casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 21):
>
> - **At Will:** *Detect Magic*, *Mind Spike* (level 5 version), *Minor Illusion*, *Shapechange* (Beast or Humanoid form only, no Temporary Hit Points gained from the spell, and no Concentration or Temporary Hit Points required to maintain the spell)
> - **1/Day Each:** *Greater Restoration*, *Major Image*, *Project Image*
>
> #### Legendary Actions
>
> *Legendary Action Uses: 3 (4 in Lair). Immediately after another creature's turn, the dragon can expend a use to take one of the following actions. The dragon regains all expended uses at the start of each of its turns.*
>
> - [ ]
> - [ ]
> - [ ]
> - [ ]
>
> ***Giggling Magic.*** *Charisma Saving Throw:* DC 21, one creature the dragon can see within 120 feet. *Failure:* 31 (9d6) Psychic damage. Until the end of its next turn, the target rolls 1d8 whenever it makes an ability check or attack roll and subtracts the number rolled from the D20 Test. *Failure or Success:* The dragon can't take this action again until the start of its next turn.
>
> ***Mind Jolt.*** The dragon uses Spellcasting to cast *Mind Spike* (level 5 version). The dragon can't take this action again until the start of its next turn.
>
> ***Pounce.*** The dragon moves up to half its Speed, and it makes one Rend attack.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=277|SRD 5.2.1, p. 277]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
