---
tags:
  - condition
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Unconscious

![[Placeholder.png|320]]


While you have the Unconscious condition, you experience the following effects.

***Inert.*** You have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] conditions, and you drop whatever you're holding. When this condition ends, you remain Prone.

***Speed 0.*** Your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]] is 0 and can't increase.

***Attacks Affected.*** Attack rolls against you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]].

***Saving Throws Affected.*** You automatically fail Strength and Dexterity saving throws.

***Automatic Critical Hits.*** Any attack roll that hits you is a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Critical Hit|Critical Hit]] if the attacker is within 5 feet of you.

***Unaware.*** You're unaware of your surroundings.
