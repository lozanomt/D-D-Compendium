---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Half Plate Armor, +1 [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Armor, +1, +2, or +3/Half Plate Armor, +1|(4,750 GP)]]
*Armor ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Half Plate Armor|Half Plate Armor]]), Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/phb-p221-half-plate-armor.png|320]]


**Attunement** No

You have a +1 bonus to Armor Class while wearing this armor.

---
![[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Half Plate Armor|clean no-title]]
