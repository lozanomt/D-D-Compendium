---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Ettercap
> 
> *Medium Monstrosity, Neutral Evil*
> 
> ![[mm-p117-ettercap.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +2 (12)  
> **HP** 44 (8d8 + 8)  
> **Speed** 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 15 | +2 | +2 | **Con** | 13 | +1 | +1 |
> | **Int** | 7 | -2 | -2 | **Wis** | 12 | +1 | +1 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +3, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Survival|Survival]] +3  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** None  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Spider Climb.*** The ettercap can climb difficult surfaces, including along ceilings, without needing to make an ability check.
> 
> ***Web Walker.*** The ettercap ignores movement restrictions caused by webs, and the ettercap knows the location of any other creature in contact with the same web.
> 
> ### Actions
> 
> ***Multiattack.*** The ettercap makes one Bite attack and one Claw attack.
> 
> ***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Piercing damage plus 2 (1d4) Poison damage, and the target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]] condition until the start of the ettercap's next turn.
> 
> ***Claw.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (2d4 + 2) Slashing damage.
> 
> ***Web Strand (Recharge 5-6).*** *Dexterity Saving Throw:* DC 12, one Large or smaller creature the ettercap can see within 30 feet. *Failure:* The target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] condition until the web is destroyed (AC 10; HP 5; Vulnerability to Fire damage; Immunity to Bludgeoning, Poison, and Psychic damage).
> 
> ### Bonus Actions
> 
> ***Reel.*** The ettercap pulls one creature within 30 feet of itself that is [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] by its Web Strand up to 25 feet straight toward itself.
