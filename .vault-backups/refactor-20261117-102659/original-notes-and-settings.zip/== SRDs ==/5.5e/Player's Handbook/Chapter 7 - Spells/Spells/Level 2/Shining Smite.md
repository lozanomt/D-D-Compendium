---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Shining Smite
*Level 2 Transmutation (Paladin)*

![[Placeholder.png|320]]


**Casting Time:** Bonus Action, which you take immediately after hitting a creature with a Melee weapon or an [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Unarmed Strike|Unarmed Strike]]
**Range:** Self
**Components:** V
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 minute

The target hit by the strike takes an extra 2d6 Radiant damage from the attack. Until the spell ends, the target sheds [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Bright Light|Bright Light]] in a 5-foot radius, attack rolls against it have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]], and it can't benefit from the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Invisible|Invisible]] condition.

***Using a Higher-Level Spell Slot.*** The damage increases by 1d6 for each spell slot level above 2.
