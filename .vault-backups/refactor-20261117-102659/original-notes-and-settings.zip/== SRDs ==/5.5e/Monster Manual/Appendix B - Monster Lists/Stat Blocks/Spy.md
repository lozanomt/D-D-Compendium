---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Spy
> 
> *Medium or Small Humanoid, Neutral*
> 
> ![[mm-p297-spy.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +4 (14)  
> **HP** 27 (6d8)  
> **Speed** 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 10 | +0 | +0 | **Dex** | 15 | +2 | +2 | **Con** | 10 | +0 | +0 |
> | **Int** | 12 | +1 | +1 | **Wis** | 14 | +2 | +2 | **Cha** | 16 | +3 | +3 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Deception|Deception]] +5, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Insight|Insight]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Investigation|Investigation]] +5, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +6, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Sleight of Hand|Sleight of Hand]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +6  
> **Gear** Hand Crossbow, Shortsword, Thieves' Tools  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages** Common plus one other language  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Actions
> 
> ***Shortsword.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Piercing damage plus 7 (2d6) Poison damage.
> 
> ***Hand Crossbow.*** *Ranged Attack Roll:* +4, range 30/120 ft. *Hit:* 5 (1d6 + 2) Piercing damage plus 7 (2d6) Poison damage.
> 
> ### Bonus Actions
> 
> ***Cunning Action.*** The spy takes the Dash, Disengage, or Hide action.
