---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 782c12a9-9b3f-5c73-8481-a31a13d3733b
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Young Green Dragon
> 
> *Large Dragon (Chromatic), Lawful Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p154-green-dragon-wyrmling.png|320]]
> 
> 
> **AC** 18 &emsp; **Initiative** +4 (14)  
> **HP** 136 (16d10 + 48)  
> **Speed** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 80 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 12 | +1 | +4 | **Con** | 17 | +3 | +3 |
> | **Int** | 16 | +3 | +3 | **Wis** | 13 | +1 | +4 | **Cha** | 15 | +2 | +2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Deception|Deception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +7, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +4  
> **Immunities** Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 17  
> **Languages** Common, Draconic  
> **CR** 8 (XP 3,900; PB +3)  
> 
> ### Traits
> 
> ***Amphibious.*** The dragon can breathe air and water.
> 
> ***Multiattack.*** The dragon makes three Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +7, reach 10 ft. *Hit:* 11 (2d6 + 4) Slashing damage plus 7 (2d6) Poison damage.
> 
> ***Poison Breath (Recharge 5-6).*** *Constitution Saving Throw:* DC 14, each creature in a 30-foot Cone. *Failure:* 42 (12d6) Poison damage. *Success:* Half damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
