---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Evoker

*Create Explosive Elemental Effects*

![[phb-p177-evoker.png|320]]


Your studies focus on magic that creates powerful elemental effects such as bitter cold, searing flame, rolling thunder, crackling lightning, and burning acid. Some Evokers find employment in military forces, serving as artillery to blast armies from afar. Others use their power to protect others, while some seek their own gain. 
#### Level 3: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Wizard/Evoker/Evocation Savant|Evocation Savant]]
Choose two Wizard spells from the Evocation school, each of which must be no higher than level 2, and add them to your spellbook for free. In addition, whenever you gain access to a new level of spell slots in this class, you can add one Wizard spell from the Evocation school to your spellbook for free. The chosen spell must be of a level for which you have spell slots. 
#### Level 3: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Wizard/Evoker/Potent Cantrip|Potent Cantrip]]
Your damaging cantrips affect even creatures that avoid the brunt of the effect. When you cast a cantrip at a creature and you miss with the attack roll or the target succeeds on a saving throw against the cantrip, the target takes half the cantrip’s damage (if any) but suffers no additional effect from the cantrip. 
#### Level 6: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Wizard/Evoker/Sculpt Spells|Sculpt Spells]]
You can create pockets of relative safety within the effects of your evocations. When you cast an Evocation spell that affects other creatures that you can see, you can choose a number of them equal to 1 plus the spell’s level. The chosen creatures automatically succeed on their saving throws against the spell, and they take no damage if they would normally take half damage on a successful save. 
#### Level 10: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Wizard/Evoker/Empowered Evocation|Empowered Evocation]]
Whenever you cast a Wizard spell from the Evocation school, you can add your Intelligence modifier to one damage roll of that spell. 
#### Level 14: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Wizard/Evoker/Overchannel|Overchannel]]
You can increase the power of your spells. When you cast a Wizard spell with a spell slot of levels 1-5 that deals damage, you can deal maximum damage with that spell on the turn you cast it. The first time you do so, you suffer no adverse effect. If you use this feature again before you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]], you take 2d12 Necrotic damage for each level of the spell slot immediately after you cast it. This damage ignores [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Immunity|Immunity]]. Each time you use this feature again before finishing a Long Rest, the Necrotic damage per spell level increases by 1d12.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=177|Player’s Handbook (2024), PDF page 177]]
