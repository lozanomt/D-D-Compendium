---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 0ecadcf5-6feb-54e5-97ef-c0313c60586a
entity_type: creature
source_ids: ["mm-2025", "phb-2024", "srd-5.2.1"]
source_versions: ["Monster Manual", "Player's Handbook", "SRD 5.2.1"]
srd_5_2_1_pages: [360]
---

# Reef Shark

One creature entry with separately labeled source versions. Each book’s chapter links to its own version.

## Monster Manual

> [!statblock]
> ### Reef Shark
>
> *Medium Beast, Unaligned*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 22 (4d8 + 4)  
> **Speed** 5 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 15 | +2 | +2 | **Con** | 13 | +1 | +1 |
> | **Int** | 1 | -5 | -5 | **Wis** | 10 | +0 | +0 | **Cha** | 4 | -3 | -3 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 30 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** None  
> **CR** 1/2 (XP 100; PB +2)  
>
> #### Traits
>
> ***Pack Tactics.*** The shark has Advantage on an attack roll against a creature if at least one of the shark's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
>
> ***Water Breathing.*** The shark can breathe only underwater.
>
> #### Actions
>
> ***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (2d4 + 2) Piercing damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## Player's Handbook

> [!statblock]
> ### Reef Shark
>
> *Medium Beast, Unaligned*
>
> **AC** 12 &emsp; **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]]** +2 (12)  
> **HP** 22 (4d8 + 4)  
> **[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]** 5 ft., Swim 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 15 | +2 | +2 | **Con** | 13 | +1 | +1 |
> | **Int** | 1 | -5 | -5 | **Wis** | 10 | +0 | +0 | **Cha** | 4 | -3 | -3 |
>
> **Skills** Perception +2  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 30 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** None  
> **CR** 1/2 (XP 100; PB +2)  
>
> #### Traits
>
> ***Pack Tactics.*** The shark has [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on an attack roll against a creature if at least one of the shark's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
>
> ***Water Breathing.*** The shark can breathe only underwater.
>
> #### Actions
>
> ***Bite.*** *Melee [[== SRDs ==/Compendium/5.5e/Rules/Actions/Attack|Attack]] Roll:* +4, reach 5 ft. *Hit:* 7 (2d4 + 2) Piercing damage.
>
> Source: [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=359|Player’s Handbook (2024), p. 356]].
>
> [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/Compendium/5.5e/Creatures/Reef Shark#Monster Manual|Monster Manual version]]
>
> **Source:** [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=359|Player's Handbook]]

## SRD 5.2.1

> [!statblock]
> ### Reef Shark
>
> *Medium Beast, Unaligned*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 22 (4d8 + 4)  
> **Speed** 5 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 15 | +2 | +2 | **Con** | 13 | +1 | +1 |
> | **Int** | 1 | -5 | -5 | **Wis** | 10 | +0 | +0 | **Cha** | 4 | -3 | -3 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 30 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** None  
> **CR** 1/2 (XP 100; PB +2)  
>
> #### Traits
>
> ***Pack Tactics.*** The shark has Advantage on an attack roll against a creature if at least one of the shark's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
>
> ***Water Breathing.*** The shark can breathe only underwater.
>
> #### Actions
>
> ***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (2d4 + 2) Piercing damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=360|SRD 5.2.1, p. 360]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Player's Handbook — Appendix B - Creature Stat Blocks]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=360|SRD 5.2.1, p. 360]]
