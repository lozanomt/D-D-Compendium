---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: d4a38c98-aaaf-57f8-874d-63b0a329f65e
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Pegasus
> 
> *Large Celestial, Chaotic Good*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p237-pegasus.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 59 (7d10 + 21)  
> **Speed** 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 90 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 15 | +2 | +4 | **Con** | 16 | +3 | +5 |
> | **Int** | 10 | +0 | +0 | **Wis** | 15 | +2 | +4 | **Cha** | 13 | +1 | +3 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +6  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages** Understands Celestial, Common, Elvish, and Sylvan but can't speak  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Actions
> 
> ***Hooves.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 7 (1d6 + 4) Bludgeoning damage plus 5 (2d4) Radiant damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
