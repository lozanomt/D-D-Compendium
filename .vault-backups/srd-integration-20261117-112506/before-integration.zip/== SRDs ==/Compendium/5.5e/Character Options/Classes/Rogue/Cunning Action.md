---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 8916fed6-470d-5f79-97db-152c3521d9bb
entity_type: character-option
source_ids: ["phb-2024"]
---

# Cunning Action

![[== SRDs ==/Attachments/Artwork/phb-p131-rogue.png|320]]

Your quick thinking and agility allow you to move and act quickly. On your turn, you can take one of the following actions as a Bonus Action: [[== SRDs ==/Compendium/5.5e/Rules/Actions/Dash|Dash]], [[== SRDs ==/Compendium/5.5e/Rules/Actions/Disengage|Disengage]], or [[== SRDs ==/Compendium/5.5e/Rules/Actions/Hide|Hide]].

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=132|Player’s Handbook (2024), PDF page 132]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
