---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 400b540a-3971-505f-85a3-370a9caec8f6
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Lemure
> 
> *Medium Fiend (Devil), Lawful Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p196-lemure.png|320]]
> 
> 
> **AC** 9 &emsp; **Initiative** -3 (7)  
> **HP** 9 (2d8)  
> **Speed** 20 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 10 | +0 | +0 | **Dex** | 5 | -3 | -3 | **Con** | 11 | +0 | +0 |
> | **Int** | 1 | -5 | -5 | **Wis** | 11 | +0 | +0 | **Cha** | 3 | -4 | -4 |
> 
> **Resistances** Cold  
> **Immunities** Fire, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft. (unimpeded by magical Darkness); [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Understands Infernal but can't speak  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Traits
> 
> ***Hellish Restoration.*** If the lemure dies in the Nine Hells, it revives with all its Hit Points in 1d10 days unless it is killed by a creature under the effects of a *Bless* spell or its remains are sprinkled with Holy Water.
> 
> ### Actions
> 
> ***Vile Slime.*** *Melee Attack Roll:* +2, reach 5 ft. *Hit:* 2 (1d4) Poison damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
