---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Waterskin [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Waterskin|(2 SP)]] 

![[Placeholder.png|320]]

A Waterskin holds up to 4 pints. If you don’t drink sufficient water, you risk [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Hazards/Dehydration|Dehydration]].

**Weight:** 5 lb. (full)
