---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Elk
> 
> *Huge Celestial, Neutral Good*
> 
> ![[Placeholder.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +6 (16)  
> **HP** 42 (5d12 + 10)  
> **Speed** 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +6 | **Dex** | 18 | +4 | +6 | **Con** | 14 | +2 | +2 |
> | **Int** | 7 | -2 | -2 | **Wis** | 14 | +2 | +2 | **Cha** | 10 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +4  
> **Resistances** Necrotic, Radiant  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 90 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Celestial; understands Common, Elvish, and Sylvan but can't speak them  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Actions
> 
> ***Ram.*** *Melee Attack Roll:* +6, reach 10 ft. *Hit:* 11 (2d6 + 4) Bludgeoning damage plus 5 (2d4) Radiant damage. If the target is a Huge or smaller creature and the elk moved 20+ feet straight toward it immediately before the hit, the target takes an extra 5 (2d4) Bludgeoning damage and has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.
