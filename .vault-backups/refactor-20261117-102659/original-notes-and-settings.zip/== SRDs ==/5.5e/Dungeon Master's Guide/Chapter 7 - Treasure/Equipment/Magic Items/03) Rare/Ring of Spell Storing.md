---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [298]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Ring of Spell Storing
*Ring, Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p298-ring-of-spell-storing.png|320]]

**Attunement:** Yes

The ring stores up to 5 levels of [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Spells|spells]]. When found, it contains 1d6 - 1 levels of stored spells chosen by the DM. Any creature can store a level 1-5 spell by touching the ring while casting it. The spell has no other effect. If it won't fit, the spell is expended without effect. Storage used equals the level of the spell slot used.

While wearing the ring, you can cast any stored spell. It uses the original caster's slot level, spell save DC, spell [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|attack]] bonus, and [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Spellcasting|spellcasting]] ability; otherwise you are the caster. Casting removes that spell from the ring and frees its space.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=298|p. 295 (PDF page 298)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
