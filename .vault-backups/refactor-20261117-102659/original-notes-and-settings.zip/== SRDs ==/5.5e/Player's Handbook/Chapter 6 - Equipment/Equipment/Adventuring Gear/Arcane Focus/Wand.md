---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Wand [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Arcane Focus/Wand|(10 GP)]] 
*Arcane Focus*

![[Placeholder.png|320]]


**Weight:** 1 lb.
