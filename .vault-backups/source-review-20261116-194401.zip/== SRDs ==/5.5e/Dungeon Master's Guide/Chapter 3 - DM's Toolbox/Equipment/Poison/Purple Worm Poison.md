---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Purple Worm Poison [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Equipment/Poison/Purple Worm Poison|(2,000 GP)]]
*[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Rules/Properties/Poison/Injury]] Poison*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


A creature subjected to Purple Worm Poison makes a DC 21 Constitution saving throw, taking 35 (10d6) Poison damage on a failed save or half as much damage on a successful one.
