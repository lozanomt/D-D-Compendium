---
cssclasses: [dnd-book, dnd-phb]
source_id: srd-5.2.1
source_pages: [204, 253]
---

# Magic Items

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=204|SRD 5.2.1, p. 204]].

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] items are gleaned from the hoards of felled monsters or discovered in long-lost vaults. Such items grant capabilities a character could rarely have otherwise, or they complement their owner's capabilities in wondrous ways.

### Magic Item Categories

Every magic item belongs to a category. The [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Item Categories table lists the nine categories and provides examples. Rules for the categories appear after the table.

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Item Categories Category Examples Armor +1 Leather Armor, +1 [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]] Potions Potion of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Healing#SRD 5.2.1|Healing]] Rings Ring of [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility#SRD 5.2.1|Invisibility]] Rods Immovable Rod Scrolls [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scroll Staffs Staff of Striking Wands Wand of Fireballs Weapons +1 [[== SRDs ==/Compendium/5.5e/Rules/Properties/Ammunition#SRD 5.2.1|Ammunition]], +1 Longsword Wondrous Items Bag of Holding, Boots of Elvenkind

#### Armor

An item in the Armor category is typically a magical version of armor from "Equipment." Unless an armor's description notes otherwise, the armor must be worn for its magic to function.

Some suits of magic armor specify the type of armor they are, such as Chain Mail or Plate Armor. If no type is specified, choose the type or determine it randomly.

#### Potions

An item in the Potion category might be a magical brew that must be imbibed or an oil that must be applied to a creature or an object. A typical potion consists of 1 ounce of liquid in a vial.

Using a Potion. Potions are consumable items.

Drinking a potion or administering it to another creature requires a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bonus Action#SRD 5.2.1|Bonus Action]]. Applying an oil might take longer as specified in its description.

Once used, a potion takes effect immediately, and it is used up.

Mixing Potions. A character might drink one potion while still under the effects of another or pour several potions into a single container. The strange ingredients used in creating potions can result in unpredictable interactions.

When a character mixes two potions together, roll on the Potion Miscibility table. If more than two are combined, roll again for each subsequent potion, combining the results. Unless the effects are immediately obvious, reveal them only when they become evident.

Potion Miscibility 1d100 Result 01 Both potions lose their effects, and the mixture creates a magical explosion in a 5-foot-radius [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Sphere#SRD 5.2.1|Sphere]] centered on itself.

Each creature in that area takes 4d10 Force damage. 02–08 Both potions lose their effects, and the mixture becomes an ingested poison of your choice (see "Poison" in "Gameplay Toolbox"). 09–15 Both potions lose their effects. 16–25 One potion loses its effect. 26–35 Both potions work, but with their numerical effects and durations halved. If a potion has no numerical effect and no duration, it instead loses its effect. 36–90 Both potions work normally. 91–99 Both potions work, but the numerical effects and duration of one potion are doubled. If neither potion has anything to double in this way, they work normally. 00 Only one potion works, but its effects are permanent. Choose the simplest effect to make permanent or the one that seems the most fun. For example, a Potion of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Healing#SRD 5.2.1|Healing]] might increase the drinker's Hit Point maximum by 2d4 + 2, or a Potion of [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility#SRD 5.2.1|Invisibility]]  might give the drinker the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Invisible#SRD 5.2.1|Invisible]] condition indefinitely. At your discretion, a [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic#SRD 5.2.1|Dispel Magic]]  spell or similar magic might end this lasting effect.

#### Rings

For its magic to function, an item in the Ring category must be worn on a finger or a similar digit unless its description notes otherwise.

#### Rods

An item in the Rod category is a scepter usually made of metal, wood, or bone. A typical rod weighs 2 to 5 pounds.

Unless its description notes otherwise, a rod can be used as an Arcane Focus.

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] iteM Rules Rules for identifying, attuning to, and using magic items appear in "Equipment." Additional rules are presented below.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]] Prerequisites.  If a magic item has a class prerequisite, a creature must be a member of that class to attune to the item. If a creature must be a spellcaster to attune to an item, the creature qualifies if it can cast at least one spell using its traits or features, not by using a magic item or the like.

Items Made for Specific Creatures. [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] items that are meant to be worn tend to magically adjust themselves to the wearer. However, you can decide that a magic item doesn't adjust its size to fit any wearer. For example, a particular armorer might make items usable only by folk who are sized and shaped like dwarves.

Unusual Anatomy.  Use your discretion to decide whether a creature can wear an item not made for its anatomy. A ring placed on a tentacle might work, but a yuan-ti with a snakelike tail instead of legs can't wear magic boots.

Paired Items. You can allow exceptions to the rule that paired items must both be worn. For example, a character with only one arm might be able to use a single Glove of Missile Snaring so long as the matching glove is on their person.

#### Scrolls

An item in the Scroll category is a roll of paper or parchment, sometimes attached to wooden rods and typically kept safe in a tube of ivory, jade, leather, metal, or wood. The most prevalent scroll is the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scroll, a spell stored in written form.

Using a Scroll. Scrolls are consumable items. Unleashing the magic in a scroll requires the user to read the scroll. When its magic has been invoked, the scroll can't be used again. Its words fade, or it crumbles into dust.

Any creature that can understand a written language can read a scroll and attempt to activate it unless its description notes otherwise.

#### Staffs

Items in the Staff category vary widely in appearance: some are of nearly equal diameter throughout and smooth, others are gnarled and twisted, some are made of wood, and others are composed of polished metal or crystal. A staff weighs between 2 and 7 pounds and serves well as a walking stick or cane.

Unless its description notes otherwise, a staff can be used as a nonmagical Quarterstaff and an Arcane Focus.

#### Wands

An item in the Wand category is typically 12 to 15 inches long and crafted of metal, bone, or wood. It is tipped with metal, crystal, stone, or some other material.

Unless its description notes otherwise, a wand can be used as an Arcane Focus.

#### Weapons

A magic weapon is typically a magical version of a weapon from "Equipment." Some magic weapons specify the type of weapon they are in their descriptions, such as a Longsword or Longbow. If no weapon type is specified, you may choose the type or determine it randomly.

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Ammunition#SRD 5.2.1|Ammunition]]. If a magic weapon has the [[== SRDs ==/Compendium/5.5e/Rules/Properties/Ammunition#SRD 5.2.1|Ammunition]] property, ammunition fired from it is considered magical for the purpose of any rule that cares whether a weapon is magical or not.

#### Wondrous Items

Wondrous Items include wearable items such as boots, belts, capes, amulets, brooches, and circlets. Bags, carpets, figurines, horns, musical instruments, and more also fall into this category.

### Magic Item Rarity

Every magic item has a rarity, which provides a rough measure of an item's power relative to other magic items. The rarities are shown in the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Item Rarities and Values table.

Common magic items, such as a Potion of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Healing#SRD 5.2.1|Healing]] , are the most plentiful. Artifacts, such as the Dragon Orb, are priceless, unique, and difficult to acquire.

#### Magic Item Values by Rarity

Common magic items can often be bought in a town or city. Uncommon and Rare magic items are usually found only in cities, and rarer magic items might be sold only in wondrous locations, such as a city on another plane of existence. If you allow characters to buy and sell magic items in your campaign, rarity can help you set prices for those items. Gold Piece values are provided in the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Item Rarities and Values table, though a seller might ask for a service rather than coin as payment.

If a magic item incorporates an item that has a purchase cost in "Equipment" (such as a weapon or a suit of armor), add that item's cost to the magic item's value. For example, +1 Armor (Plate Armor) has a value of 5,500 GP, which is the sum of a Rare magic item's value (4,000 GP) and the cost of Plate Armor (1,500 GP).

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Item Rarities and Values Rarity Value* Rarity Value* Common 100 GP Very Rare 40,000 GP Uncommon 400 GP Legendary 200,000 GP Rare 4,000 GP Artifact Priceless *Halve the value for a consumable item other than a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scroll .

The value of a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scroll  is double what it costs to scribe the scroll (as specified in the "Scribing [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scrolls" section of "Equipment").

### Activating a Magic Item

It usually takes a [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] action to activate a magic item. The item's user might also need to do something special. The description of each item category or individual item details how an item is activated.

Certain items use the following rules for their activation.

#### Command Word

A command word is a word or short phrase that must be spoken or signed for an item to work. Spoken command words must be audible and fail to work in areas where all sound is suppressed, as in the area of the [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Silence#SRD 5.2.1|Silence]]  spell.

#### Consumable Items

Some items are consumed—used up, in other words—when they are activated. A Potion of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Healing#SRD 5.2.1|Healing]] must be swallowed, for example, while the writing vanishes from a scroll when it is read. Once used, a consumable item loses its magic.

#### Spells Cast from Items

Some magic items allow the user to cast a spell from the item. The spell is cast at the lowest possible spell and caster level, doesn't expend any of the user's spell slots, and requires no components unless the item's description notes otherwise. The spell uses its normal casting time, range, and duration, and the user of the item must concentrate if the spell requires [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration#SRD 5.2.1|Concentration]]. Many items, such as Potions, bypass the casting of a spell and confer the spell's effects with its usual duration. Certain items make exceptions to these rules, changing the casting time, duration, or other parts of a spell.

A magic item may require the user to use their own spellcasting ability when casting a spell from the item. If the user has more than one spellcasting ability, the user chooses which one to use with the item. If the user doesn't have a spellcasting ability, their spellcasting ability modifier is +0 for the item, and the user's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus applies.

#### Charges

Some magic items have charges that must be expended to activate their properties. The number of charges an item has remaining is revealed when the [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Identify#SRD 5.2.1|Identify]] spell is cast on it. A creature attuned to an item knows how many charges the item has and how many it regains.

### "The Next Dawn"

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] items often have charges or properties that recharge at the next dawn or some other specified time. If such an item is on a world or plane of existence where the specified event doesn't occur, the GM determines when the item recharges.

### Cursed Items

A magic item's description specifies whether it bears a curse. Most methods of identifying items, including the [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Identify#SRD 5.2.1|Identify]]  spell, fail to reveal such a curse.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]] to a cursed item can't be ended voluntarily unless the curse is broken first, such as with a [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Remove Curse#SRD 5.2.1|Remove Curse]] spell.

### Magic Item Resilience

A magic item is at least as durable as a nonmagical item of its kind. Most magic items, other than Potions and Scrolls, have Resistance to all damage.

An Artifact can be destroyed only in some special way. Otherwise, it is impervious to damage. Learning how to destroy an Artifact usually requires research or the completion of a quest.

### Crafting Magic Items

"Equipment" contains rules on brewing Potions of

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Healing#SRD 5.2.1|Healing]] and scribing [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scrolls . To create other magic items, follow the rules below. In these rules, "you" refers to the character crafting the magic item.

#### Arcana Proficiency

To craft a magic item, you and any assistants must have proficiency in the Arcana skill.

#### Tools

The [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Item Tools table lists which tool is required to make a magic item of each category. You must use the required tool to make an item and have proficiency with that tool. Any assistants must also have proficiency with it. For more information on the tools, see "Equipment." [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Item Tools Item Category Required Tool Armor Leatherworker's Tools, Smith's Tools, or Weaver's Tools depending on the kind of armor as noted in the tools' descriptions Potion Alchemist's Supplies or Herbalism Kit Ring Jeweler's Tools Rod Woodcarver's Tools Scroll Calligrapher's Supplies Staff Woodcarver's Tools Wand Woodcarver's Tools [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Weapon#SRD 5.2.1|Weapon]] Leatherworker's Tools, Smith's Tools, or Woodcarver's Tools depending on the kind of weapon as noted in the tools' descriptions Wondrous Item Tinker's Tools or the tool required to make the nonmagical item on which the magic item is based

#### Spells

If a magic item allows its user to cast any spells from it, you must have all those spells prepared every day you spend crafting the item.

#### Time and Cost

Crafting a magic item takes an amount of time and money based on the item's rarity as shown in the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Item Crafting Time and Cost table.

Work per Day. For each day of crafting, you must work for 8 hours. If an item requires multiple days, those days needn't be consecutive.

Assistants.  Characters can combine their efforts to shorten the crafting time. Divide the time needed to create an item by the number of characters working on it. Normally, only one other character can assist you, but the GM might allow more assistants.

Raw Materials. The cost in the table represents the raw materials needed to make a magic item. The GM determines whether appropriate raw materials are available. In a city, there is a 75 percent chance that the materials are available, and in any other settlement, that chance is 25 percent. If materials aren't available, you must wait at least 7 days before checking on the availability again.

If a magic item incorporates an item that has a purchase cost (such as a weapon or a suit of armor), you must also pay that entire cost or craft that item using the rules in "Equipment." For example, to make +1 Armor (Plate Armor), you must pay 3,500 GP or pay 2,000 GP and craft the armor.

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Item Crafting Time and Cost Item Rarity  Time*  Cost* Common 5 days 50 GP Uncommon 10 days 200 GP Rare 50 days 2,000 GP Very Rare 125 days 20,000 GP Legendary 250 days 100,000 GP *The time and cost are halved for a consumable item other than a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scroll , whose crafting time and cost are given in "Equipment."

### Sentient Magic Items

Some magic items have sentience and personality.

Such an item might be possessed, haunted by the spirit of a previous owner, or self-aware thanks to the magic used to create it. A sentient item might be a cherished ally to its wielder or a continual thorn in the side.

Most sentient items are weapons, but other kinds of items can manifest sentience. Single-use items such as potions and scrolls are never sentient.

The GM controls sentient magic items and their activated properties. A bearer who maintains a good relationship with the item can access those properties. If the relationship is strained, a conflict can ensue (see "Conflict" below).

#### Sentient Magic Item Traits

When you make a sentient magic item, you create the item's persona much as you would create an NPC, with these exceptions.

#### Abilities

A sentient magic item has Intelligence, Wisdom, and

Charisma scores. Choose the item's abilities, or determine them randomly as follows: roll 4d6 for each one, dropping the lowest roll and totaling the rest.

#### Alignment

A sentient magic item has an alignment. Its creator or nature might suggest an alignment. Otherwise, pick an alignment or roll on the Sentient Item's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Alignment#SRD 5.2.1|Alignment]] table.

#### Communication

A sentient item communicates by sharing its emotions, broadcasting its thoughts telepathically, or speaking aloud. You can choose how it communicates or roll on the Sentient Item's Communication table.

#### Senses

A sentient item can perceive its surroundings out to a limited range. You can choose its senses or roll on the Sentient Item's Senses table.

#### Special Purpose

You can give a sentient item an objective it pursues, perhaps to the exclusion of all else. As long as the wielder's use of the item aligns with that special purpose, the item remains cooperative. Deviating from this course might cause conflict between the wielder and the item (see "Conflict" below). You can pick a special purpose or roll on the Sentient Item's Special Purpose table.

Sentient Item's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Alignment#SRD 5.2.1|Alignment]] 1d100 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Alignment#SRD 5.2.1|Alignment]] 1d100 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Alignment#SRD 5.2.1|Alignment]] 01–15 Lawful Good 74–85 Chaotic Neutral 16–35 Neutral Good 86–89 Lawful Evil 36–50 Chaotic Good 90–96 Neutral Evil 51–63 Lawful Neutral 97–00 Chaotic Evil 64–73 Neutral Sentient Item's Communication 1d10 Communication 1–6 The item communicates by transmitting emotion to the creature carrying or wielding it. 7–9 The item speaks one or more languages. 10 The item speaks one or more languages. In addition, the item can communicate telepathically with any creature that carries or wields it.

Sentient Item's Senses 1d4 Senses 1 Hearing and standard vision out to 30 feet 2 Hearing and standard vision out to 60 feet 3 Hearing and standard vision out to 120 feet 4 Hearing and Darkvision out to 120 feet Sentient Item's Special Purpose 1d10 Special Purpose 1 Aligned. The item seeks to defeat or destroy those of a diametrically opposed alignment.

Such an item is never Neutral. 2 [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bane#SRD 5.2.1|Bane]]. The item seeks to thwart or destroy creatures of a particular type, such as Constructs, Fiends, or Undead. 3 Creator Seeker. The item seeks its creator and wants to understand why it was created. 4 Destiny Seeker. The item believes it and its bearer have key roles to play in future events. 1d10 Special Purpose 5 Destroyer. The item craves destruction and goads its user to fight arbitrarily. 6 Glory Seeker. The item seeks renown as the greatest magic item in the world by winning fame or notoriety for its user. 7 Lore Seeker. The item craves knowledge or is determined to solve a mystery, learn a secret, or unravel a cryptic prophecy. 8 Protector. The item seeks to defend a particular kind of creature, such as elves or werewolves. 9 Soulmate Seeker. The item seeks another sentient magic item, perhaps one that is similar to itself. 10 Templar. The item seeks to defend the servants and interests of a particular deity.

#### Conflict

When the bearer of a sentient item acts in a manner opposed to the item's alignment or purpose, conflict can arise. When such a conflict occurs, the item's bearer makes a Charisma saving throw (DC 12 plus the item's Charisma modifier). On a failed save, the item makes one or more of the following demands:

Chase My Dreams. The item demands that its bearer pursue the item's goals to the exclusion of all other goals.

Get Rid of It. The item demands that its bearer dispose of anything the item finds repugnant.

It's Time for a Change. The item demands to be given to someone else.

Keep Me Close. The item insists on being carried or worn at all times.

If its bearer refuses to comply with the item's demands, the item can do any of the following:

• Make it impossible for its bearer to attune to it.

• Suppress one or more of its activated properties.

• Attempt to take control of its bearer, whereupon the bearer makes a Charisma saving throw (DC 12 plus the item's Charisma modifier). On a failed save, the bearer has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed#SRD 5.2.1|Charmed]] condition for 1d12 hours. While [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed#SRD 5.2.1|Charmed]] in this way, the bearer must try to follow the item's commands.

If the bearer takes damage, it repeats the save, ending the effect on a success. Whether or not the attempt to control its bearer succeeds, the item can't use this power again until the next dawn.

### Magic Items A–Z

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] items are presented in alphabetical order.

If a magic item description capitalizes a creature's name and presents it in bold  type, that's a visual cue pointing you to the creature's stat block. Unless the text states otherwise, the stat block is in "Monsters." How to read and use a stat block is explained in "Monsters."

### Adamantine Armor

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Armor#SRD 5.2.1|Adamantine Armor]]

### Ammunition, +1, +2, or +3

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Ammunition, +1, +2, or +3/Ammunition, +1, +2, or +3#SRD 5.2.1|Ammunition, +1, +2, or +3]]

### Ammunition of Slaying

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Ammunition of Slaying/Ammunition of Slaying#SRD 5.2.1|Ammunition of Slaying]]

### Amulet of Health

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Amulet of Health#SRD 5.2.1|Amulet of Health]]

### Amulet of Proof against Detection and Location

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Amulet of Proof against Detection and Location#SRD 5.2.1|Amulet of Proof against Detection and Location]]

### Amulet of the Planes

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Amulet of the Planes#SRD 5.2.1|Amulet of the Planes]]

### Animated Shield

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Animated Shield#SRD 5.2.1|Animated Shield]]

### Apparatus of the Crab

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Apparatus of the Crab#SRD 5.2.1|Apparatus of the Crab]]

### Armor, +1, +2, or +3

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Armor, +1, +2, or +3/Armor, +1, +2, or +3#SRD 5.2.1|Armor, +1, +2, or +3]]

### Armor of Invulnerability

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Armor of Invulnerability#SRD 5.2.1|Armor of Invulnerability]]

### Armor of Resistance

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Armor of Resistance/Armor of Resistance#SRD 5.2.1|Armor of Resistance]]

### Armor of Vulnerability

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Armor of Vulnerability/Armor of Vulnerability#SRD 5.2.1|Armor of Vulnerability]]

### Arrow-Catching Shield

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Arrow-Catching Shield#SRD 5.2.1|Arrow-Catching Shield]]

### Bag of Beans

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Bag of Beans#SRD 5.2.1|Bag of Beans]]

### Bag of Devouring

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Bag of Devouring#SRD 5.2.1|Bag of Devouring]]

### Bag of Holding

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Bag of Holding#SRD 5.2.1|Bag of Holding]]

### Bag of Tricks

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Bag of Tricks/Bag of Tricks#SRD 5.2.1|Bag of Tricks]]

### Bead of Force

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Bead of Force#SRD 5.2.1|Bead of Force]]

### Bead of Nourishment

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/01) Common/Bead of Nourishment#SRD 5.2.1|Bead of Nourishment]]

### Belt of Dwarvenkind

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Belt of Dwarvenkind#SRD 5.2.1|Belt of Dwarvenkind]]

### Belt of Giant Strength

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Belt of Giant Strength/Belt of Giant Strength#SRD 5.2.1|Belt of Giant Strength]]

### Berserker Axe

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Berserker Axe/Berserker Axe#SRD 5.2.1|Berserker Axe]]

### Boots of Elvenkind

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Boots of Elvenkind#SRD 5.2.1|Boots of Elvenkind]]

### Boots of Levitation

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Boots of Levitation#SRD 5.2.1|Boots of Levitation]]

### Boots of Speed

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Boots of Speed#SRD 5.2.1|Boots of Speed]]

### Boots of Striding and Springing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Boots of Striding and Springing#SRD 5.2.1|Boots of Striding and Springing]]

### Boots of the Winterlands

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Boots of the Winterlands#SRD 5.2.1|Boots of the Winterlands]]

### Bowl of Commanding Water Elementals

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Bowl of Commanding Water Elementals#SRD 5.2.1|Bowl of Commanding Water Elementals]]

### Bracers of Archery

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Bracers of Archery#SRD 5.2.1|Bracers of Archery]]

### Bracers of Defense

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Bracers of Defense#SRD 5.2.1|Bracers of Defense]]

### Brazier of Commanding Fire Elementals

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Brazier of Commanding Fire Elementals#SRD 5.2.1|Brazier of Commanding Fire Elementals]]

### Brooch of Shielding

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Brooch of Shielding#SRD 5.2.1|Brooch of Shielding]]

### Broom of Flying

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Broom of Flying#SRD 5.2.1|Broom of Flying]]

### Candle of Invocation

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Candle of Invocation#SRD 5.2.1|Candle of Invocation]]

### Cape of the Mountebank

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Cape of the Mountebank#SRD 5.2.1|Cape of the Mountebank]]

### Carpet of Flying

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Carpet of Flying#SRD 5.2.1|Carpet of Flying]]

### Censer of Controlling Air Elementals

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Censer of Controlling Air Elementals#SRD 5.2.1|Censer of Controlling Air Elementals]]

### Chime of Opening

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Chime of Opening#SRD 5.2.1|Chime of Opening]]

### Circlet of Blasting

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Circlet of Blasting#SRD 5.2.1|Circlet of Blasting]]

### Cloak of Arachnida

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Cloak of Arachnida#SRD 5.2.1|Cloak of Arachnida]]

### Cloak of Displacement

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Cloak of Displacement#SRD 5.2.1|Cloak of Displacement]]

### Cloak of Elvenkind

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Cloak of Elvenkind#SRD 5.2.1|Cloak of Elvenkind]]

### Cloak of Invisibility

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Cloak of Invisibility#SRD 5.2.1|Cloak of Invisibility]]

### Cloak of Protection

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Cloak of Protection#SRD 5.2.1|Cloak of Protection]]

### Cloak of the Bat

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Cloak of the Bat#SRD 5.2.1|Cloak of the Bat]]

### Cloak of the Manta Ray

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Cloak of the Manta Ray#SRD 5.2.1|Cloak of the Manta Ray]]

### Crystal Ball

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Crystal Ball#SRD 5.2.1|Crystal Ball]]

### Crystal Ball of Mind Reading

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Crystal Ball of Mind Reading#SRD 5.2.1|Crystal Ball of Mind Reading]]

### Crystal Ball of Telepathy

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Crystal Ball of Telepathy#SRD 5.2.1|Crystal Ball of Telepathy]]

### Crystal Ball of True Seeing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Crystal Ball of True Seeing#SRD 5.2.1|Crystal Ball of True Seeing]]

### Cube of Force

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Cube of Force#SRD 5.2.1|Cube of Force]]

### Cubic Gate

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Cubic Gate#SRD 5.2.1|Cubic Gate]]

### Dagger of Venom

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Dagger of Venom#SRD 5.2.1|Dagger of Venom]]

### Dancing Sword

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Dancing Sword/Dancing Sword#SRD 5.2.1|Dancing Sword]]

### Decanter of Endless Water

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Decanter of Endless Water#SRD 5.2.1|Decanter of Endless Water]]

### Deck of Illusions

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Deck of Illusions#SRD 5.2.1|Deck of Illusions]]

### Defender

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Defender/Defender#SRD 5.2.1|Defender]]

### Demon Armor

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Demon Armor/Demon Armor#SRD 5.2.1|Demon Armor]]

### Dimensional Shackles

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Dimensional Shackles#SRD 5.2.1|Dimensional Shackles]]

### Dragon Orb

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/06) Artifact/Dragon Orb#SRD 5.2.1|Dragon Orb]]

### Dragon Scale Mail

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Dragon Scale Mail/Dragon Scale Mail#SRD 5.2.1|Dragon Scale Mail]]

### Dragon Slayer

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Dragon Slayer/Dragon Slayer#SRD 5.2.1|Dragon Slayer]]

### Dust of Disappearance

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Dust of Disappearance#SRD 5.2.1|Dust of Disappearance]]

### Dust of Dryness

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Dust of Dryness#SRD 5.2.1|Dust of Dryness]]

### Dust of Sneezing and Choking

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Dust of Sneezing and Choking#SRD 5.2.1|Dust of Sneezing and Choking]]

### Dwarven Plate

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Dwarven Plate#SRD 5.2.1|Dwarven Plate]]

### Dwarven Thrower

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Dwarven Thrower#SRD 5.2.1|Dwarven Thrower]]

### Efficient Quiver

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Efficient Quiver#SRD 5.2.1|Efficient Quiver]]

### Efreeti Bottle

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Efreeti Bottle#SRD 5.2.1|Efreeti Bottle]]

### Elemental Gem

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Elemental Gem/Elemental Gem#SRD 5.2.1|Elemental Gem]]

### Elixir of Health

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Elixir of Health#SRD 5.2.1|Elixir of Health]]

### Elven Chain

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Elven Chain/Elven Chain#SRD 5.2.1|Elven Chain]]

### Energy Bow

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Energy Bow#SRD 5.2.1|Energy Bow]]

### Eversmoking Bottle

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Eversmoking Bottle#SRD 5.2.1|Eversmoking Bottle]]

### Eyes of Charming

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Eyes of Charming#SRD 5.2.1|Eyes of Charming]]

### Eyes of Minute Seeing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Eyes of Minute Seeing#SRD 5.2.1|Eyes of Minute Seeing]]

### Eyes of the Eagle

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Eyes of the Eagle#SRD 5.2.1|Eyes of the Eagle]]

### Feather Token

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Feather Token/Feather Token#SRD 5.2.1|Feather Token]]

### Figurine of Wondrous Power

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Figurine of Wondrous Power/Figurine of Wondrous Power#SRD 5.2.1|Figurine of Wondrous Power]]

### Giant Fly

[[== SRDs ==/Compendium/5.5e/Creatures/Giant Fly#SRD 5.2.1|Giant Fly]]

Golden Lions (Rare). These gold statuettes of lions are always created in pairs. You can use one figurine or both simultaneously. Each can become a Lion for up to 1 hour. Once a lion has been used, it can't be used again until 7 days have passed.

Ivory Goats (Rare). These ivory statuettes of goats are always created in sets of three. Each goat looks unique and functions differently from the others. Their properties are as follows:

Goat of Terror. This figurine can become a Giant

Goat for up to 3 hours. The goat can't attack, but you can (harmlessly) remove its horns and use them as weapons. One horn becomes a +1 Lance, and the other becomes a  +2 Longsword. Removing a horn requires a [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] action, and the weapons disappear and the horns return when the goat reverts to figurine form. While you ride the goat, any [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hostile#SRD 5.2.1|Hostile]] creature that starts its turn within a 30-foot [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Emanation#SRD 5.2.1|Emanation]] originating from the goat must succeed on a DC 15 Wisdom saving throw or have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened#SRD 5.2.1|Frightened]] condition for 1 minute, until you are no longer riding the goat, or until the goat reverts to figurine form. The [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened#SRD 5.2.1|Frightened]] creature repeats the save at the end of each of its turns, ending the effect on itself on a success. Once it succeeds on the save, a creature is immune to this effect for the next 24 hours. Once the figurine has been used, it can't be used again until 15 days have passed.

Goat of Traveling.  This figurine can become a Large goat with the same statistics as a Riding

Horse. It has 24 charges, and each hour or portion thereof it spends in goat form costs 1 charge.

While it has charges, you can use it as often as you wish. When it runs out of charges, it reverts to a figurine and can't be used again until 7 days have passed, when it regains all expended charges.

Goat of Travail.  This figurine can become a Giant

Goat for up to 3 hours. Once it has been used, it can't be used again until 30 days have passed.

Marble Elephant (Rare). This marble statuette resembles a trumpeting elephant. It can become an

Elephant for up to 24 hours. Once it has been used, it can't be used again until 7 days have passed.

Obsidian Steed (Very Rare). This polished obsidian horse can become a Nightmare  for up to 24 hours. The nightmare fights only to defend itself.

Once it has been used, it can't be used again until 5 days have passed.

The figurine has a 10 percent chance each time you use it to ignore your orders, including a command to revert to figurine form. If you mount the nightmare while it is ignoring your orders, you and the nightmare are instantly transported to a random location on the plane of Hades, where the nightmare reverts to figurine form.

Onyx Dog (Rare). This onyx statuette of a dog can become a Mastiff  for up to 6 hours. The mastiff has an Intelligence of 8 and can speak Common. It also has [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight#SRD 5.2.1|Blindsight]] with a range of 60 feet. Once it has been used, it can't be used again until 7 days have passed.

Serpentine Owl (Rare). This serpentine statuette of an owl can become a Giant Owl  for up to 8 hours.

The owl can communicate telepathically with you at any range if you and it are on the same plane of existence. Once it has been used, it can't be used again until 2 days have passed.

Silver Raven (Uncommon). This silver statuette of a raven can become a Raven  for up to 12 hours.

Once it has been used, it can't be used again until 2 days have passed. While in raven form, the figurine grants you the ability to cast [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Animal Messenger#SRD 5.2.1|Animal Messenger]] on it.

### Flame Tongue

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Flame Tongue/Flame Tongue#SRD 5.2.1|Flame Tongue]]

### Folding Boat

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Folding Boat#SRD 5.2.1|Folding Boat]]

### Frost Brand

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Frost Brand/Frost Brand#SRD 5.2.1|Frost Brand]]

### Gauntlets of Ogre Power

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Gauntlets of Ogre Power#SRD 5.2.1|Gauntlets of Ogre Power]]

### Gem of Brightness

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Gem of Brightness#SRD 5.2.1|Gem of Brightness]]

### Gem of Seeing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Gem of Seeing#SRD 5.2.1|Gem of Seeing]]

### Giant Slayer

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Giant Slayer/Giant Slayer#SRD 5.2.1|Giant Slayer]]

### Glamoured Studded Leather

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Glamour Studded Leather#SRD 5.2.1|Glamour Studded Leather]]

### Gloves of Missile Snaring

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Gloves of Missile Snaring#SRD 5.2.1|Gloves of Missile Snaring]]

### Gloves of Swimming and Climbing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Gloves of Swimming and Climbing#SRD 5.2.1|Gloves of Swimming and Climbing]]

### Gloves of Thievery

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Gloves of Thievery#SRD 5.2.1|Gloves of Thievery]]

### Goggles of Night

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Goggles of Night#SRD 5.2.1|Goggles of Night]]

### Hammer of Thunderbolts

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Hammer of Thunderbolts#SRD 5.2.1|Hammer of Thunderbolts]]

### Handy Haversack

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Handy Haversack#SRD 5.2.1|Handy Haversack]]

### Hat of Disguise

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Hat of Disguise#SRD 5.2.1|Hat of Disguise]]

### Hat of Many Spells

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Hat of Many Spells#SRD 5.2.1|Hat of Many Spells]]

### Headband of Intellect

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Headband of Intellect#SRD 5.2.1|Headband of Intellect]]

### Helm of Brilliance

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Helm of Brilliance#SRD 5.2.1|Helm of Brilliance]]

### Helm of Comprehending Languages

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Helm of Comprehending Languages#SRD 5.2.1|Helm of Comprehending Languages]]

### Helm of Telepathy

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Helm of Telepathy#SRD 5.2.1|Helm of Telepathy]]

### Helm of Teleportation

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Helm of Teleportation#SRD 5.2.1|Helm of Teleportation]]

### Holy Avenger

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Holy Avenger/Holy Avenger#SRD 5.2.1|Holy Avenger]]

### Horn of Blasting

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Horn of Blasting#SRD 5.2.1|Horn of Blasting]]

### Horn of Valhalla

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Horn of Valhalla/Horn of Valhalla#SRD 5.2.1|Horn of Valhalla]]

### Horseshoes of a Zephyr

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Horseshoes of a Zephyr#SRD 5.2.1|Horseshoes of a Zephyr]]

### Horseshoes of Speed

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Horseshoes of Speed#SRD 5.2.1|Horseshoes of Speed]]

### Immovable Rod

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Immovable Rod#SRD 5.2.1|Immovable Rod]]

### Instant Fortress

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Instant Fortress#SRD 5.2.1|Instant Fortress]]

### Ioun Stone

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Ioun Stone/Ioun Stone#SRD 5.2.1|Ioun Stone]]

### Iron Bands

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Iron Bands#SRD 5.2.1|Iron Bands]]

### Iron Flask

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Iron Flask#SRD 5.2.1|Iron Flask]]

### Javelin of Lightning

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Javelin of Lightning#SRD 5.2.1|Javelin of Lightning]]

### Lantern of Revealing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Lantern of Revealing#SRD 5.2.1|Lantern of Revealing]]

### Luck Blade

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Luck Blade/Luck Blade#SRD 5.2.1|Luck Blade]]

### Mace of Disruption

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Mace of Disruption#SRD 5.2.1|Mace of Disruption]]

### Mace of Smiting

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Mace of Smiting#SRD 5.2.1|Mace of Smiting]]

### Mace of Terror

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Mace of Terror#SRD 5.2.1|Mace of Terror]]

### Mantle of Spell Resistance

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Mantle of Spell Resistance#SRD 5.2.1|Mantle of Spell Resistance]]

### Manual of Bodily Health

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Manual of Bodily Health#SRD 5.2.1|Manual of Bodily Health]]

### Manual of Gainful Exercise

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Manual of Gainful Exercise#SRD 5.2.1|Manual of Gainful Exercise]]

### Manual of Golems

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Manual of Golems#SRD 5.2.1|Manual of Golems]]

### Manual of Quickness of Action

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Manual of Quickness of Action#SRD 5.2.1|Manual of Quickness of Action]]

### Marvelous Pigments

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Marvelous Pigments#SRD 5.2.1|Marvelous Pigments]]

### Medallion of Thoughts

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Medallion of Thoughts#SRD 5.2.1|Medallion of Thoughts]]

### Mirror of Life Trapping

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Mirror of Life Trapping#SRD 5.2.1|Mirror of Life Trapping]]

### Mithral Armor

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Mithral Armor/Mithral Armor#SRD 5.2.1|Mithral Armor]]

### Mysterious Deck

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Mysterious Deck#SRD 5.2.1|Mysterious Deck]]

### Avatar of Death

[[== SRDs ==/Compendium/5.5e/Creatures/Avatar of Death#SRD 5.2.1|Avatar of Death]]

### Necklace of Adaptation

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Necklace of Adaptation#SRD 5.2.1|Necklace of Adaptation]]

### Necklace of Fireballs

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Necklace of Fireballs#SRD 5.2.1|Necklace of Fireballs]]

### Necklace of Prayer Beads

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Necklace of Prayer Beads#SRD 5.2.1|Necklace of Prayer Beads]]

### Nine Lives Stealer

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Nine Lives Stealer/Nine Lives Stealer#SRD 5.2.1|Nine Lives Stealer]]

### Oathbow

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Oathbow#SRD 5.2.1|Oathbow]]

### Oil of Etherealness

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Oil of Etherealness#SRD 5.2.1|Oil of Etherealness]]

### Oil of Sharpness

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Oil of Sharpness#SRD 5.2.1|Oil of Sharpness]]

### Oil of Slipperiness

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Oil of Slipperiness#SRD 5.2.1|Oil of Slipperiness]]

### Pearl of Power

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Pearl of Power#SRD 5.2.1|Pearl of Power]]

### Periapt of Health

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Periapt of Health#SRD 5.2.1|Periapt of Health]]

### Periapt of Proof against Poison

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Periapt of Proof against Poison#SRD 5.2.1|Periapt of Proof against Poison]]

### Periapt of Wound Closure

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Periapt of Wound Closure#SRD 5.2.1|Periapt of Wound Closure]]

### Philter of Love

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Philter of Love#SRD 5.2.1|Philter of Love]]

### Pipes of Haunting

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Pipes of Haunting#SRD 5.2.1|Pipes of Haunting]]

### Pipes of the Sewers

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Pipes of the Sewers#SRD 5.2.1|Pipes of the Sewers]]

### Plate Armor of Etherealness

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Plate Armor of Etherealness#SRD 5.2.1|Plate Armor of Etherealness]]

### Portable Hole

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Portable Hole#SRD 5.2.1|Portable Hole]]

### Potion of Animal Friendship

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Potion of Animal Friendship#SRD 5.2.1|Potion of Animal Friendship]]

### Potion of Clairvoyance

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Potion of Clairvoyance#SRD 5.2.1|Potion of Clairvoyance]]

### Potion of Climbing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/01) Common/Potion of Climbing#SRD 5.2.1|Potion of Climbing]]

### Potion of Diminution

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Potion of Diminution#SRD 5.2.1|Potion of Diminution]]

### Potion of Flying

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Potion of Flying#SRD 5.2.1|Potion of Flying]]

### Potion of Gaseous Form

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Potion of Gaseous Form#SRD 5.2.1|Potion of Gaseous Form]]

### Potion of Giant Strength

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Potion of Giant Strength/Potion of Giant Strength#SRD 5.2.1|Potion of Giant Strength]]

### Potion of Growth

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Potion of Growth#SRD 5.2.1|Potion of Growth]]

### Potions of Healing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Potions of Healing/Potions of Healing#SRD 5.2.1|Potions of Healing]]

### Potion of Heroism

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Potion of Heroism#SRD 5.2.1|Potion of Heroism]]

### Potion of Invisibility

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Potion of Invisibility#SRD 5.2.1|Potion of Invisibility]]

### Potion of Invulnerability

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Potion of Invulnerability#SRD 5.2.1|Potion of Invulnerability]]

### Potion of Longevity

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Potion of Longevity#SRD 5.2.1|Potion of Longevity]]

### Potion of Mind Reading

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Potion of Mind Reading#SRD 5.2.1|Potion of Mind Reading]]

### Potion of Poison

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Potion of Poison#SRD 5.2.1|Potion of Poison]]

### Potion of Resistance

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Potion of Resistance/Potion of Resistance#SRD 5.2.1|Potion of Resistance]]

### Potion of Speed

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Potion of Speed#SRD 5.2.1|Potion of Speed]]

### Potion of Vitality

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Potion of Vitality#SRD 5.2.1|Potion of Vitality]]

### Potion of Water Breathing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Potion of Water Breathing#SRD 5.2.1|Potion of Water Breathing]]

### Quarterstaff of the Acrobat

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Quarterstaff of the Acrobat#SRD 5.2.1|Quarterstaff of the Acrobat]]

### Ring of Animal Influence

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Ring of Animal Influence#SRD 5.2.1|Ring of Animal Influence]]

### Ring of Djinni Summoning

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Ring of Djinni Summonning#SRD 5.2.1|Ring of Djinni Summonning]]

### Ring of Elemental Command

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Ring of Elemental Command/Ring of Elemental Command#SRD 5.2.1|Ring of Elemental Command]]

### Ring of Evasion

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Ring of Evasion#SRD 5.2.1|Ring of Evasion]]

### Ring of Feather Falling

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Ring of Feather Falling#SRD 5.2.1|Ring of Feather Falling]]

### Ring of Free Action

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Ring of Free Action#SRD 5.2.1|Ring of Free Action]]

### Ring of Invisibility

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Ring of Invisibility#SRD 5.2.1|Ring of Invisibility]]

### Ring of Jumping

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Ring of Jumping#SRD 5.2.1|Ring of Jumping]]

### Ring of Mind Shielding

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Ring of Mind Shielding#SRD 5.2.1|Ring of Mind Shielding]]

### Ring of Protection

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Ring of Protection#SRD 5.2.1|Ring of Protection]]

### Ring of Regeneration

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Ring of Regeneration#SRD 5.2.1|Ring of Regeneration]]

### Ring of Resistance

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Ring of Resistance/Ring of Resistance#SRD 5.2.1|Ring of Resistance]]

### Ring of Shooting Stars

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Ring of Shooting Stars#SRD 5.2.1|Ring of Shooting Stars]]

### Ring of Spell Storing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Ring of Spell Storing#SRD 5.2.1|Ring of Spell Storing]]

### Ring of Spell Turning

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Ring of Spell Turning#SRD 5.2.1|Ring of Spell Turning]]

### Ring of Swimming

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Ring of Swimming#SRD 5.2.1|Ring of Swimming]]

### Ring of Telekinesis

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Ring of Telekinesis#SRD 5.2.1|Ring of Telekinesis]]

### Ring of the Ram

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Ring of the Ram#SRD 5.2.1|Ring of the Ram]]

### Ring of Three Wishes

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Ring of Three Wishes#SRD 5.2.1|Ring of Three Wishes]]

### Ring of Warmth

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Ring of Warmth#SRD 5.2.1|Ring of Warmth]]

### Ring of Water Walking

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Ring of Water Walking#SRD 5.2.1|Ring of Water Walking]]

### Ring of X-ray Vision

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Ring of X-ray Vision#SRD 5.2.1|Ring of X-ray Vision]]

### Robe of Eyes

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Robe of Eyes#SRD 5.2.1|Robe of Eyes]]

### Robe of Scintillating Colors

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Robe of Scintillating Colors#SRD 5.2.1|Robe of Scintillating Colors]]

### Robe of Stars

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Robe of Stars#SRD 5.2.1|Robe of Stars]]

### Robe of the Archmagi

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Robe of the Archmagi#SRD 5.2.1|Robe of the Archmagi]]

### Robe of Useful Items

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Robe of Useful Items#SRD 5.2.1|Robe of Useful Items]]

### Rod of Absorption

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Rod of Absorption#SRD 5.2.1|Rod of Absorption]]

### Rod of Alertness

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Rod of Alertness#SRD 5.2.1|Rod of Alertness]]

### Rod of Lordly Might

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Rod of Lordly Might#SRD 5.2.1|Rod of Lordly Might]]

### Rod of Resurrection

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Rod of Resurrection#SRD 5.2.1|Rod of Resurrection]]

### Rod of Rulership

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Rodo f Rulership#SRD 5.2.1|Rodo f Rulership]]

### Rod of Security

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Rod of Security#SRD 5.2.1|Rod of Security]]

### Rope of Climbing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Rope of Climbing#SRD 5.2.1|Rope of Climbing]]

### Rope of Entanglement

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Rope of Entanglement#SRD 5.2.1|Rope of Entanglement]]

### Scarab of Protection

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Scarab of Protection#SRD 5.2.1|Scarab of Protection]]

### Scimitar of Speed

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Scimitar of Speed#SRD 5.2.1|Scimitar of Speed]]

### Sending Stones

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Sending Stones#SRD 5.2.1|Sending Stones]]

### Sentinel Shield

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Sentinel Shield#SRD 5.2.1|Sentinel Shield]]

### Shield, +1, +2, or +3

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Shield, +1, +2, or +3/Shield, +1, +2, or +3#SRD 5.2.1|Shield, +1, +2, or +3]]

### Shield of Missile Attraction

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Shield of Missile Attraction#SRD 5.2.1|Shield of Missile Attraction]]

### Shield of the Cavalier

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Shield of the Cavalier#SRD 5.2.1|Shield of the Cavalier]]

### Slippers of Spider Climbing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Slippers of Spider Climbing#SRD 5.2.1|Slippers of Spider Climbing]]

### Sovereign Glue

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Sovereign Glue#SRD 5.2.1|Sovereign Glue]]

### Spellguard Shield

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Spellguard Shield#SRD 5.2.1|Spellguard Shield]]

### Spell Scroll

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/Spell Scroll/Spell Scroll#SRD 5.2.1|Spell Scroll]]

### Sphere of Annihilation

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Sphere of Annihilation#SRD 5.2.1|Sphere of Annihilation]]

### Staff of Charming

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Staff of Charming#SRD 5.2.1|Staff of Charming]]

### Staff of Fire

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Staff of Fire#SRD 5.2.1|Staff of Fire]]

### Staff of Frost

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Staff of Frost#SRD 5.2.1|Staff of Frost]]

### Staff of Healing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Staff of Healing#SRD 5.2.1|Staff of Healing]]

### Staff of Power

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Staff of Power#SRD 5.2.1|Staff of Power]]

### Staff of Striking

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Staff of Striking#SRD 5.2.1|Staff of Striking]]

### Staff of Swarming Insects

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Staff of Swarming Insects#SRD 5.2.1|Staff of Swarming Insects]]

### Staff of the Magi

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Staff of the Magi#SRD 5.2.1|Staff of the Magi]]

### Staff of the Python

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Staff of the Python#SRD 5.2.1|Staff of the Python]]

### Staff of the Woodlands

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Staff of the Woodlands#SRD 5.2.1|Staff of the Woodlands]]

### Staff of Thunder and Lightning

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Staff of Thunder and Lightning#SRD 5.2.1|Staff of Thunder and Lightning]]

### Staff of Withering

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Staff of Withering#SRD 5.2.1|Staff of Withering]]

### Stone of Controlling Earth Elementals

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Stone of Controlling Earth Elementals#SRD 5.2.1|Stone of Controlling Earth Elementals]]

### Stone of Good Luck (Luckstone)

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Luckstone#SRD 5.2.1|Luckstone]]

### Sun Blade

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Sun Blade#SRD 5.2.1|Sun Blade]]

### Sword of Life Stealing

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Sword of Life Stealing/Sword of Life Stealing#SRD 5.2.1|Sword of Life Stealing]]

### Sword of Sharpness

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Sword of Sharpness/Sword of Sharpness#SRD 5.2.1|Sword of Sharpness]]

### Sword of Wounding

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Sword of Wounding/Sword of Wounding#SRD 5.2.1|Sword of Wounding]]

### Talisman of Pure Good

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Talisman of Pure Good#SRD 5.2.1|Talisman of Pure Good]]

### Talisman of the Sphere

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Talisman of the Sphere#SRD 5.2.1|Talisman of the Sphere]]

### Talisman of Ultimate Evil

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Talisman of Ultimate Evil#SRD 5.2.1|Talisman of Ultimate Evil]]

### Thunderous Greatclub

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Thunderous Greatclub#SRD 5.2.1|Thunderous Greatclub]]

### Tome of Clear Thought

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Tome of Clear Thought#SRD 5.2.1|Tome of Clear Thought]]

### Tome of Leadership and Influence

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Tome of Leadership and Influence#SRD 5.2.1|Tome of Leadership and Influence]]

### Tome of Understanding

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Tome of Understanding#SRD 5.2.1|Tome of Understanding]]

### Trident of Fish Command

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Trident of Fish Command#SRD 5.2.1|Trident of Fish Command]]

### Universal Solvent

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Universal Solvent#SRD 5.2.1|Universal Solvent]]

### Vicious Weapon

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Vicious Weapon/Vicious Weapon#SRD 5.2.1|Vicious Weapon]]

### Vorpal Sword

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Vorpal Sword/Vorpal Sword#SRD 5.2.1|Vorpal Sword]]

### Wand of Binding

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Wand of Binding#SRD 5.2.1|Wand of Binding]]

### Wand of Enemy Detection

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Wand of Enemy Detection#SRD 5.2.1|Wand of Enemy Detection]]

### Wand of Fear

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Wand of Fear#SRD 5.2.1|Wand of Fear]]

### Wand of Fireballs

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Wand of Fireballs#SRD 5.2.1|Wand of Fireballs]]

### Wand of Lightning Bolts

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Wand of Lightning Bolts#SRD 5.2.1|Wand of Lightning Bolts]]

### Wand of Magic Detection

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Wand of Magic Detection#SRD 5.2.1|Wand of Magic Detection]]

### Wand of Magic Missiles

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Wand of Magic Missiles#SRD 5.2.1|Wand of Magic Missiles]]

### Wand of Paralysis

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Wand of Paralysis#SRD 5.2.1|Wand of Paralysis]]

### Wand of Polymorph

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/04) Very Rare/Wand of Polymorph#SRD 5.2.1|Wand of Polymorph]]

### Wand of Secrets

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Wand of Secrets#SRD 5.2.1|Wand of Secrets]]

### Wand of the War Mage, +1, +2, or +3

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Wand of the War Mage, +1, +2, or +3/Wand of the War Mage, +1, +2, or +3#SRD 5.2.1|Wand of the War Mage, +1, +2, or +3]]

### Wand of Web

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Wand of Web#SRD 5.2.1|Wand of Web]]

### Wand of Wonder

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Wand of Wonder#SRD 5.2.1|Wand of Wonder]]

### Weapon, +1, +2, or +3

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Weapon, +1, +2, or +3/Weapon, +1, +2, or +3#SRD 5.2.1|Weapon, +1, +2, or +3]]

### Weapon of Warning

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Weapon of Warning/Weapon of Warning#SRD 5.2.1|Weapon of Warning]]

### Well of Many Worlds

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/05) Legendary/Well of Many Worlds#SRD 5.2.1|Well of Many Worlds]]

### Wind Fan

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Wind Fan#SRD 5.2.1|Wind Fan]]

### Winged Boots

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/02) Uncommon/Winged Boots#SRD 5.2.1|Winged Boots]]

### Wings of Flying

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/03) Rare/Wings of Flying#SRD 5.2.1|Wings of Flying]]

## Tables and Boxed Reference Material

These extracts preserve the PDF’s table layout alongside the text above.

### Page 204 — srd-p204-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p204-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=204|Open source page 204]]

### Page 206 — srd-p206-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p206-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=206|Open source page 206]]

### Page 207 — srd-p207-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p207-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=207|Open source page 207]]

### Page 208 — srd-p208-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p208-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=208|Open source page 208]]

### Page 208 — srd-p208-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p208-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=208|Open source page 208]]

### Page 208 — srd-p208-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p208-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=208|Open source page 208]]

### Page 209 — srd-p209-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p209-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=209|Open source page 209]]

### Page 210 — srd-p210-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p210-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=210|Open source page 210]]

### Page 211 — srd-p211-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p211-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=211|Open source page 211]]

### Page 212 — srd-p212-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p212-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=212|Open source page 212]]

### Page 212 — srd-p212-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p212-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=212|Open source page 212]]

### Page 212 — srd-p212-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p212-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=212|Open source page 212]]

### Page 213 — srd-p213-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p213-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=213|Open source page 213]]

### Page 215 — srd-p215-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p215-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=215|Open source page 215]]

### Page 215 — srd-p215-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p215-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=215|Open source page 215]]

### Page 216 — srd-p216-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p216-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=216|Open source page 216]]

### Page 217 — srd-p217-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p217-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=217|Open source page 217]]

### Page 218 — srd-p218-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p218-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=218|Open source page 218]]

### Page 218 — srd-p218-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p218-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=218|Open source page 218]]

### Page 219 — srd-p219-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p219-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=219|Open source page 219]]

### Page 220 — srd-p220-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p220-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=220|Open source page 220]]

### Page 221 — srd-p221-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p221-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=221|Open source page 221]]

### Page 225 — srd-p225-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p225-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=225|Open source page 225]]

### Page 226 — srd-p226-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p226-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=226|Open source page 226]]

### Page 230 — srd-p230-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p230-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=230|Open source page 230]]

### Page 231 — srd-p231-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p231-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=231|Open source page 231]]

### Page 231 — srd-p231-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p231-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=231|Open source page 231]]

### Page 233 — srd-p233-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p233-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=233|Open source page 233]]

### Page 235 — srd-p235-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p235-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=235|Open source page 235]]

### Page 236 — srd-p236-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p236-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=236|Open source page 236]]

### Page 236 — srd-p236-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p236-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=236|Open source page 236]]

### Page 238 — srd-p238-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p238-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=238|Open source page 238]]

### Page 238 — srd-p238-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p238-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=238|Open source page 238]]

### Page 240 — srd-p240-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p240-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=240|Open source page 240]]

### Page 241 — srd-p241-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p241-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=241|Open source page 241]]

### Page 244 — srd-p244-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p244-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=244|Open source page 244]]

### Page 244 — srd-p244-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p244-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=244|Open source page 244]]

### Page 245 — srd-p245-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p245-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=245|Open source page 245]]

### Page 245 — srd-p245-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p245-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=245|Open source page 245]]

### Page 245 — srd-p245-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p245-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=245|Open source page 245]]

### Page 246 — srd-p246-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p246-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=246|Open source page 246]]

### Page 246 — srd-p246-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p246-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=246|Open source page 246]]

### Page 247 — srd-p247-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p247-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=247|Open source page 247]]

### Page 252 — srd-p252-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p252-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=252|Open source page 252]]
