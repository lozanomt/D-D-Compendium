---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Foresight
*Level 9 Divination (Bard, Druid, Warlock, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** 1 minute
**Range:** Touch
**Components:** V, S, M (a hummingbird feather)
**Duration:** 8 hours

You touch a willing creature and bestow a limited ability to see into the immediate future. For the duration, the target has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/D20 Test|D20 Tests]], and other creatures have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on attack rolls against it. The spell ends early if you cast it again.
