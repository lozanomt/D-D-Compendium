---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 268cc068-c843-5107-b7e9-086e2f314dec
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [298]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Hippogriff

## Monster Manual


> [!statblock]
> ### Hippogriff
>
> *Large Monstrosity, Unaligned*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p171-hippogriff.png|320]]
>
> **AC:** 11 &emsp;  
> **Initiative:** +1 (11)  
> **HP:** 26 (4d10 + 4)  
> **Speed:** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 13 | +1 | +1 | **Con** | 13 | +1 | +1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 8 | -1 | -1 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages:** None  
> **CR:** 1 (XP 200; PB +2)  
>
> #### Traits
>
> ***Flyby.*** The hippogriff doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.
>
> #### Actions
>
> ***Multiattack.*** The hippogriff makes two Rend attacks.
>
> ***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Slashing damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Hippogriff
>
> *Large Monstrosity, Unaligned*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p171-hippogriff.png|320]]
>
> **AC:** 11 &emsp;  
> **Initiative:** +1 (11)  
> **HP:** 26 (4d10 + 4)  
> **Speed:** 40 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 13 | +1 | +1 | **Con** | 13 | +1 | +1 |
> | **Int** | 2 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 8 | -1 | -1 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages:** None  
> **CR:** 1 (XP 200; PB +2)  
>
> #### Traits
>
> ***Flyby.*** The hippogriff doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.
>
> #### Actions
>
> ***Multiattack.*** The hippogriff makes two Rend attacks.
>
> ***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Slashing damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=298|SRD 5.2.1, p. 298]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
