---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Warhorse Skeleton
> 
> *Large Undead, Lawful Evil*
> 
> ![[mm-p285-skeleton.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +1 (11)  
> **HP** 22 (3d10 + 6)  
> **Speed** 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 12 | +1 | +1 | **Con** | 15 | +2 | +2 |
> | **Int** | 2 | -4 | -4 | **Wis** | 8 | -1 | -1 | **Cha** | 5 | -3 | -3 |
> 
> **Vulnerabilities** Bludgeoning  
> **Immunities** Poison; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]]  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** None  
> **CR** 1/2 (XP 100; PB +2)  
> 
> ### Actions
> 
> ***Hooves.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 7 (1d6 + 4) Bludgeoning damage. If the target is a Large or smaller creature and the skeleton moved 20+ feet straight toward it immediately before the hit, the target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.
