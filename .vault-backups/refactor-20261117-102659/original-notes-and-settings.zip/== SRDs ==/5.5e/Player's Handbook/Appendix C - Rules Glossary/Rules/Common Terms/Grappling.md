---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Grappling

![[Placeholder.png|320]]


A creature can grapple another creature. Characters typically grapple by using an [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Unarmed Strike|Unarmed Strike]]. Many monsters have special attacks that allow them to quickly grapple prey. However a grapple is initiated, it follows these rules.

***Grappled Condition.*** Successfully grappling a creature gives it the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] condition.

***One Grapple per Hand.*** A creature must have a hand free to grapple another creature. Some stat blocks and game effects allow a creature to grapple using a tentacle, a maw, or another body part. Whatever part a grappler uses, it can grapple only one creature at a time with that part, and the grappler can’t use that part to target another creature unless it ends the grapple.

***Ending a Grapple.*** A Grappled creature can use its action to make a Strength ([[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Athletics|Athletics]]) or Dexterity ([[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Acrobatics|Acrobatics]]) check against the grapple’s escape DC, ending the condition on itself on a success. The condition also ends if the grappler has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition or if the distance between the Grappled target and the grappler exceeds the grapple’s range. In addition, the grappler can release the target at any time (no action required).
