---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: be2d6028-9c7a-5b76-a6ec-207886740c35
entity_type: character-option
source_ids: ["phb-2024"]
---

# Elusive

![[== SRDs ==/Attachments/Artwork/phb-p131-rogue.png|320]]

You’re so evasive that attackers rarely gain the upper hand against you. No attack roll can have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] against you unless you have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=132|Player’s Handbook (2024), PDF page 132]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
