---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Behir
> 
> *Huge Monstrosity, Neutral Evil*
> 
> ![[mm-p036-behir.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +3 (13)  
> **HP** 168 (16d12 + 64)  
> **Speed** 50 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 50 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 23 | +6 | +6 | **Dex** | 16 | +3 | +3 | **Con** | 18 | +4 | +4 |
> | **Int** | 7 | -2 | -2 | **Wis** | 14 | +2 | +2 | **Cha** | 12 | +1 | +1 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +6, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +7  
> **Immunities** Lightning  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 90 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages** Draconic  
> **CR** 11 (XP 7,200; PB +4)  
> 
> ### Actions
> 
> ***Multiattack.*** The behir makes one Bite attack and uses Constrict.
> 
> ***Bite.*** *Melee Attack Roll:* +10, reach 10 ft. *Hit:* 19 (2d12 + 6) Piercing damage plus 11 (2d10) Lightning damage.
> 
> ***Constrict.*** *Strength Saving Throw:* DC 18, one Large or smaller creature the behir can see within 5 feet. *Failure:* 28 (5d8 + 6) Bludgeoning damage. The target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] condition (escape DC 16), and it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] condition until the grapple ends.
> 
> ***Lightning Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 16, each creature in a 90-foot-long, 5-footwide Line. *Failure:* 66 (12d10) Lightning damage. *Success:* Half damage.
> 
> ### Bonus Actions
> 
> ***Swallow.*** *Dexterity Saving Throw:* DC 18, one Large or smaller creature [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] by the behir (the behir can have only one creature swallowed at a time). *Failure:* The behir swallows the target, which is no longer Grappled. While swallowed, a creature has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded|Blinded]] and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] conditions, has Total Cover against attacks and other effects outside the behir, and takes 21 (6d6) Acid damage at the start of each of the behir's turns.
> 
> If the behir takes 30 damage or more on a single turn from the swallowed creature, the behir must succeed on a DC 14 Constitution saving throw at the end of that turn or regurgitate the creature, which falls in a space within 10 feet of the behir and has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition. If the behir dies, a swallowed creature is no longer [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] and can escape from the corpse by using 15 feet of movement, exiting Prone.
