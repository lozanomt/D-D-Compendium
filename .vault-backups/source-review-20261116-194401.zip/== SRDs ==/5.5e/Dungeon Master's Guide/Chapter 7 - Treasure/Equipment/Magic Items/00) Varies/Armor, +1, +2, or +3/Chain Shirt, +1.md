---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Chain Shirt, +1 [[Chain Shirt, +1 |(4,050 GP)]]
*Armor ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Chain Shirt]]), Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p221-chain-shirt.png|320]]


**Attunement** No

You have a +1 bonus to Armor Class while wearing this armor.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Chain Shirt|clean no-title]]
