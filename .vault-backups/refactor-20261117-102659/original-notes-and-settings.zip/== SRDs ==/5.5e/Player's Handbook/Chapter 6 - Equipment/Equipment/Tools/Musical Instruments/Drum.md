---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Drum [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Drum|(6 GP)]]

![[Placeholder.png|320]]

**Ability:** Charisma **Weight:** 3 lb.
[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]]: Play a known tune (DC 10), or improvise a song (DC 15)
