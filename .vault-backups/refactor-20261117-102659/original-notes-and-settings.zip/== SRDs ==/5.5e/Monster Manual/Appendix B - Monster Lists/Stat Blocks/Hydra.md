---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Hydra
> 
> *Huge Monstrosity, Unaligned*
> 
> ![[mm-p177-hydra.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +4 (14)  
> **HP** 184 (16d12 + 80)  
> **Speed** 40 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 20 | +5 | +5 | **Dex** | 12 | +1 | +1 | **Con** | 20 | +5 | +5 |
> | **Int** | 2 | -4 | -4 | **Wis** | 10 | +0 | +0 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +6  
> **Immunities** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded|Blinded]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Deafened|Deafened]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Stunned|Stunned]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Unconscious|Unconscious]]  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages** None  
> **CR** 8 (XP 3,900; PB +3)  
> 
> ### Traits
> 
> ***Hold Breath.*** The hydra can hold its breath for 1 hour.
> 
> ***Multiple Heads.*** The hydra has five heads. Whenever the hydra takes 25 damage or more on a single turn, one of its heads dies. The hydra dies if all its heads are dead. At the end of each of its turns when it has at least one living head, the hydra grows two heads for each of its heads that died since its last turn, unless it has taken Fire damage since its last turn. The hydra regains 20 Hit Points when it grows new heads.
> 
> ***Reactive Heads.*** For each head the hydra has beyond one, it gets an extra Reaction that can be used only for Opportunity Attacks.
> 
> ### Actions
> 
> ***Multiattack.*** The hydra makes as many Bite attacks as it has heads.
> 
> ***Bite.*** *Melee Attack Roll:* +8, reach 10 ft. *Hit:* 10 (1d10 + 5) Piercing damage.
