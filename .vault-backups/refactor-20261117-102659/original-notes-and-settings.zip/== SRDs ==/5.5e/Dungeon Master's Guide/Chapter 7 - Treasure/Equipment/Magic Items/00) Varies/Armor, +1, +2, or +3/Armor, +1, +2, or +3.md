---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Armor, +1, +2, or +3 [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Armor, +1, +2, or +3/Armor, +1, +2, or +3|(Varies)]]
*Armor (Any Light, Medium, or Heavy), Varies*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p234-armor-1-2-or-3.png|320]]


**Attunement:** No

You have a bonus to Armor Class while wearing this armor. The bonus is determined by its rarity.

| Rarity                                   | Bonus |
| ---------------------------------------- | :---: |
| Rare  |  +1   |
| Very Rare      |  +2   |
| Legendary |  +3   |
