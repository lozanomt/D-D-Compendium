---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Nature's Veil

![[phb-p121-ranger.png|320]]

You invoke spirits of nature to magically hide yourself. As a Bonus Action, you can give yourself the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Invisible|Invisible]] condition until the end of your next turn.

You can use this feature a number of times equal to your Wisdom modifier (minimum of once), and you regain all expended uses when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=122|Player’s Handbook (2024), PDF page 122]]
