---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Club [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Simple Melee/Club|(1 SP)]]
*Simple Melee*

![[phb-p219-club.png|320]]


**Mastery:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Mastery/Slow|Slow]] **Weight:** 2 lb.
**Damage:** 1d4 Bludgeoning
**Properties:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Light|Light]]
