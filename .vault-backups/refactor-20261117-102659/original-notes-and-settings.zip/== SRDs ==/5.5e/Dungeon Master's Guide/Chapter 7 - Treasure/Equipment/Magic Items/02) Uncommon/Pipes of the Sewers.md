---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [288, 289]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Pipes of the Sewers
*Wondrous Item, Uncommon*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p288-pipes-of-the-sewers.png|320]]

**Attunement:** Yes

While the pipes are on your person, ordinary and giant rats are Indifferent toward you and won't [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|attack]] unless you threaten or [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 6/Harm|harm]] them. The pipes have 3 charges and regain 1d3 expended charges daily at dawn.

If you play the pipes as a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action, you can take a Bonus Action to expend 1-3 charges, calling one [[== SRDs ==/5.5e/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Swarm of Rats|Swarm of Rats]] per charge if the DM determines there are enough rats within half a mile. A charge is wasted if there are too few rats. Called swarms move toward the music by the shortest available route but are not otherwise under your control.

Whenever a Swarm of Rats not controlled by another creature comes within 30 feet while you play, it makes a DC 15 Wisdom saving throw. On a success, it behaves normally and can't be swayed by the music for 24 hours.

On a failed save, the swarm becomes Friendly to you and your allies while you continue playing each round as a Magic action. It obeys your commands; without commands it defends itself but otherwise takes no actions. If it starts its turn more than 30 feet from you, your control ends; it behaves normally and can't be swayed by the music for 24 hours.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=288|p. 285 (PDF page 288)]]; [[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=289|p. 286 (PDF page 289)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
