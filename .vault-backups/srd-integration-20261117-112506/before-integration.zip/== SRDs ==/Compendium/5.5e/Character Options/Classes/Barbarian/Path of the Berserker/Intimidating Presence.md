---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 89afa196-7234-5f18-a74a-9cd777f19203
entity_type: character-option
source_ids: ["phb-2024"]
---

# Intimidating Presence

![[== SRDs ==/Attachments/Artwork/phb-p057-path-of-the-berserker.png|320]]

As a Bonus Action, you can strike terror into others with your menacing presence and primal power. When you do so, each creature of your choice in a 30-foot [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Emanation|Emanation]] originating from you must make a Wisdom saving throw (DC 8 plus your Strength modifier and Proficiency Bonus). On a failed save, a creature has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]] condition for 1 minute. At the end of each of the Frightened creature’s turns, the creature repeats the save, ending the effect on itself on a success.

Once you use this feature, you can’t use it again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]] unless you expend a use of your Rage (no action required) to restore your use of it.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=57|Player’s Handbook (2024), PDF page 57]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
