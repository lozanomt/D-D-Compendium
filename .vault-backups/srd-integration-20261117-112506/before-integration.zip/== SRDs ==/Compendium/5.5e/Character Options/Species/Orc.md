---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: fe94e40a-ca7a-5cfe-88be-ffc947921ab6
entity_type: character-option
source_ids: ["phb-2024"]
---

# Orc

![[== SRDs ==/Attachments/Artwork/phb-p198-orc.png|320]]

**Creature Type:** Humanoid
**Size:** Medium (about 6 - 7 feet tall)
**[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]]:** 30 feet

As an Orc, you have these special traits.

***Adrenaline Rush.*** You can take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Dash|Dash]] action as a Bonus Action. When you do so, you gain a number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to your Proficiency Bonus. You can use this trait a number of times equal to your Proficiency Bonus, and you regain all expended uses when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

***Darkvision.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] with a range of 120 feet.

***Relentless Endurance.*** When you are reduced to 0 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] but not killed outright, you can drop to 1 Hit Point instead. Once you use this trait, you can’t do so again until you finish a Long Rest.

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Player's Handbook — Chapter 4 - Character Origins]]
