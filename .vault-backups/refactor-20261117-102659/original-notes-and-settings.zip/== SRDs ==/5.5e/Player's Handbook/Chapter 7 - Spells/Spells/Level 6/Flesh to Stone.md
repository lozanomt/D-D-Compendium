---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Flesh to Stone
*Level 6 Transmutation (Druid, Sorcerer, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a cockatrice feather)
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 minute

You attempt to turn one creature that you can see within range into stone. The target makes a Constitution saving throw. On a failed save, it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained|Restrained]] condition for the duration. On a successful save, its [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]] is 0 until the start of your next turn. Constructs automatically succeed on the save.

A Restrained target makes another Constitution saving throw at the end of each of its turns. If it successfully saves against this spell three times, the spell ends. If it fails its saves three times, it is turned to stone and has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Petrified|Petrified]] condition for the duration. The successes and failures needn't be consecutive; keep track of both until the target collects three of a kind.

If you maintain your Concentration on this spell for the entire possible duration, the target is Petrified until the condition is ended by *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Greater Restoration|Greater Restoration]]* or similar magic.
