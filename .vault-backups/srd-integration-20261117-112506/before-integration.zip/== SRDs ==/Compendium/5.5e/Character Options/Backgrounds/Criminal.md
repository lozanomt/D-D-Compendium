---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 2cc30d96-3b5e-52fb-8c37-e30be14d35c0
entity_type: character-option
source_ids: ["phb-2024"]
---

# Criminal

![[== SRDs ==/Attachments/Artwork/phb-p182-criminal.png|320]]

**Ability Scores:** Dexterity, Constitution, Intelligence
**Feat:** [[== SRDs ==/Compendium/5.5e/Character Options/Feats/01) Origin Feats/Alert|Alert]]
**Skill Proficiencies** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Sleight of Hand|Sleight of Hand]] and [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]]
**Tool Proficiency:** [[== SRDs ==/Compendium/5.5e/Items/Tools/Thieves' Tools|Thieves' Tools]]
**Equipment:** *Choose A or B:* (A) 2 [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Dagger|Daggers]], [[== SRDs ==/Compendium/5.5e/Items/Tools/Thieves' Tools|Thieves' Tools]], [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Crowbar|Crowbar]], 2 [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Pouch|Pouches]], [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Traveler's Clothes|Traveler's Clothes]], 16 GP; or (B) 50 GP

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Player's Handbook — Chapter 4 - Character Origins]]
