---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: fa932c67-4bf9-55a1-a541-20583a5b2c75
entity_type: character-option
source_ids: ["phb-2024"]
---

# Abjure Foes

![[== SRDs ==/Attachments/Artwork/phb-p111-paladin.png|320]]

As a [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action, you can expend one use of this class’s [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Paladin/Channel Oath|Channel Divinity]] to overwhelm foes with awe. As you present your [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Holy Symbol/Holy Symbol|Holy Symbol]] or weapon, you can target a number of creatures equal to your Charisma modifier (minimum of one creature) that you can see within 60 feet of yourself. Each target must succeed on a Wisdom saving throw or have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]] condition for 1 minute or until it takes any damage. While Frightened in this way, a target can do only one of the following on its turns: move, take an action, or take a Bonus Action.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=112|Player’s Handbook (2024), PDF page 112]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
