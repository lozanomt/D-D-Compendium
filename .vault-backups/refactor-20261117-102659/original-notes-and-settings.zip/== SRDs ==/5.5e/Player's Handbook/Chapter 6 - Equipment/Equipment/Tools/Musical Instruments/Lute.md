---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Lute [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Lute|(35 GP)]]

![[Placeholder.png|320]]

**Ability:** Charisma **Weight:** 2 lb.
[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]]: Play a known tune (DC 10), or improvise a song (DC 15)
