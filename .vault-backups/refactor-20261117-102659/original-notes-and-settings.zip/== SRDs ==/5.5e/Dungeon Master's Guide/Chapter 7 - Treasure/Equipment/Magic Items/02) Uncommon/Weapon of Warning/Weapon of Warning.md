---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Weapon of Warning [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Weapon of Warning/Weapon of Warning|(Varies)]]
*Weapon (Any Simple or Martial), Uncommon*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p328-weapon-of-warning.png|320]]


**Attunement:** Yes

As long as this weapon is within your reach and you are attuned to it, you and allies within 30 feet of you gain the following benefits.

***Alarm.*** The weapon magically awakens each subject who is sleeping naturally when combat begins. This benefit doesn’t wake a subject from magically induced sleep.

***Supernatural Readiness.*** Each subject has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on its [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]] rolls.
