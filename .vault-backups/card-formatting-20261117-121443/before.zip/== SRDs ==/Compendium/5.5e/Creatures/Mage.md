---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: a69d615a-3af3-584b-9953-f42be33f5f53
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [305]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Mage

## Monster Manual

> [!statblock]
> ### Mage
>
> *Medium or Small Humanoid (Wizard), Neutral*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p200-archmage.png|320]]
>
> **AC** 15 &emsp; **Initiative** +2 (12)  
> **HP** 81 (18d8)  
> **Speed** 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 9 | -1 | -1 | **Dex** | 14 | +2 | +2 | **Con** | 11 | +0 | +0 |
> | **Int** | 17 | +3 | +6 | **Wis** | 12 | +1 | +4 | **Cha** | 11 | +0 | +0 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana|Arcana]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4  
> **Gear** Wand  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Common plus three other languages  
> **CR** 6 (XP 2,300; PB +3)  
>
> ### Actions
>
> ***Multiattack.*** The mage makes three Arcane Burst attacks.
>
> ***Arcane Burst.*** *Melee or Ranged Attack Roll:* +6, reach 5 ft. or range 120 ft. *Hit:* 16 (3d8 + 3) Force damage.
>
> ***Spellcasting.*** The mage casts one of the following spells, using Intelligence as the spellcasting ability (spell save DC 14):
>
> - **At Will:** *Detect Magic*, *Light*, *Mage Armor* (included in AC), *Mage Hand*, *Prestidigitation*
> - **2/Day Each:** *Fireball* (level 4 version), *Invisibility*
> - **1/Day Each:** *Cone of Cold*, *Fly*
>
> ### Bonus Actions
>
> ***Misty Step (3/Day).*** The mage casts *Misty Step*, using the same spellcasting ability as Spellcasting.
>
> - [ ]
> - [ ]
> - [ ]
>
> ### Reactions
>
> ***Protective Magic (3/Day).*** The mage casts *Counterspell* or *Shield* in response to the spell's trigger, using the same spellcasting ability as Spellcasting.
> - [ ]
> - [ ]
> - [ ]
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1

> [!statblock]
> ### Mage
>
> *Medium or Small Humanoid (Wizard), Neutral*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p200-archmage.png|320]]
>
> **AC** 15 &emsp; **Initiative** +2 (12)  
> **HP** 81 (18d8)  
> **Speed** 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 9 | -1 | -1 | **Dex** | 14 | +2 | +2 | **Con** | 11 | +0 | +0 |
> | **Int** | 17 | +3 | +6 | **Wis** | 12 | +1 | +4 | **Cha** | 11 | +0 | +0 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana|Arcana]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/History|History]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4  
> **Gear** Wand  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Common plus three other languages  
> **CR** 6 (XP 2,300; PB +3)  
>
> ### Actions
>
> ***Multiattack.*** The mage makes three Arcane Burst attacks.
>
> ***Arcane Burst.*** *Melee or Ranged Attack Roll:* +6, reach 5 ft. or range 120 ft. *Hit:* 16 (3d8 + 3) Force damage.
>
> ***Spellcasting.*** The mage casts one of the following spells, using Intelligence as the spellcasting ability (spell save DC 14):
>
> - **At Will:** *Detect Magic*, *Light*, *Mage Armor* (included in AC), *Mage Hand*, *Prestidigitation*
> - **2/Day Each:** *Fireball* (level 4 version), *Invisibility*
> - **1/Day Each:** *Cone of Cold*, *Fly*
>
> ### Bonus Actions
>
> ***Misty Step (3/Day).*** The mage casts *Misty Step*, using the same spellcasting ability as Spellcasting.
>
> - [ ]
> - [ ]
> - [ ]
>
> ### Reactions
>
> ***Protective Magic (3/Day).*** The mage casts *Counterspell* or *Shield* in response to the spell's trigger, using the same spellcasting ability as Spellcasting.
> - [ ]
> - [ ]
> - [ ]
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=305|SRD 5.2.1, p. 305]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=305|SRD 5.2.1, p. 305]]
