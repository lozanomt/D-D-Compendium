---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Signature Spells

![[phb-p167-wizard.png|320]]

Choose two level 3 spells in your spellbook as your signature spells. You always have these spells prepared, and you can cast each of them once at level 3 without expending a spell slot. When you do so, you can’t cast them in this way again until you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]]. To cast either spell at a higher level, you must expend a spell slot.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=168|Player’s Handbook (2024), PDF page 168]]
