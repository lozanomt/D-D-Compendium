---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Musical Instruments

![[Placeholder.png|320]]


####  Musical Instrument [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Musical Instruments|(Varies)]]
**Ability:** Charisma **Weight:** Varies
[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]]: Play a known tune (DC 10), or improvise a song (DC 15)
**Variants:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Bagpipes|Bagpipes]] (30 GP, 6 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Drum|Drum]] (6 GP, 3 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Dulcimer|Dulcimer]] (25 GP, 10 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Flute|Flute]] (2 GP, 1 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Horn|Horn]] (3 GP, 2 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Lute|Lute]] (35 GP, 2 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Lyre|Lyre]] (30 GP, 2 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Pan Flute|Pan Flute]] (12 GP, 2 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Shawm|Shawm]] (2 GP, 1 lb.), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Musical Instruments/Viol|Viol]] (30 GP, 1 lb.)
