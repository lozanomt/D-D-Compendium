---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Crab
> 
> *Medium Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/Monster Manual/Artwork/mm-p358-giant-crab.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +1 (11)  
> **HP** 13 (3d8)  
> **Speed** 30 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 13 | +1 | +1 | **Con** | 11 | +0 | +0 |
> | **Int** | 1 | -5 | -5 | **Wis** | 9 | -1 | -1 | **Cha** | 3 | -4 | -4 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]] +3  
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight]] 30 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 9  
> **Languages** None  
> **CR** 1/8 (XP 25; PB +2)  
> 
> ### Traits
> 
> ***Amphibious.*** The crab can breathe air and water.
> 
> ### Actions
> 
> ***Claw.*** *Melee Attack Roll:* +3, reach 5 ft. *Hit:* 4 (1d6 + 1) Bludgeoning damage. If the target is a Medium or smaller creature, it has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled]] condition (escape DC 11) from one of two claws.
