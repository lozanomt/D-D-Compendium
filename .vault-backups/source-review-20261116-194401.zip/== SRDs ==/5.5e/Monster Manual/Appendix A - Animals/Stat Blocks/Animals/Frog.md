---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Frog
> 
> *Tiny Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/Monster Manual/Artwork/phb-p352-frog.png|320]]
> 
> 
> **AC** 11 &emsp; **Initiative** +1 (11)  
> **HP** 1 (1d4 - 1)  
> **Speed** 20 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 20 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 1 | -5 | -5 | **Dex** | 13 | +1 | +1 | **Con** | 8 | -1 | -1 |
> | **Int** | 1 | -5 | -5 | **Wis** | 8 | -1 | -1 | **Cha** | 3 | -4 | -4 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +1, [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]] +3  
> **Senses** [[Darkvision]] 30 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 11  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Traits
> 
> ***Amphibious.*** The frog can breathe air and water.
> 
> ***Standing Leap.*** The frog's Long Jump is up to 10 feet and its High Jump is up to 5 feet with or without a running start.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +3, reach 5 ft. *Hit:* 1 Piercing damage.
