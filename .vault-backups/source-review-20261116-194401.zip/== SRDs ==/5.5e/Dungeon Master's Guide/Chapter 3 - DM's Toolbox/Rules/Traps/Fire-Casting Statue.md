---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Fire-Casting Statue
*Deadly Trap (Levels 1-4)*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Trigger:** A creature moves onto a pressure plate
**Duration:** Instantaneous, and the trap resets at the start of the next turn

When a creature moves onto this trap’s pressure plate for the first time on a turn or starts its turn there, a nearby statue exhales a 15-foot Cone of magical flame. The statue can look like anything, such as a dragon or a wizard. Each creature in the Cone must succeed on a DC 15 Dexterity saving throw, taking 11 (2d10) Fire damage on a failed save or half as much damage on a successful one.

***Detect and Disarm.*** A *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Detect Magic]]* spell reveals an aura of Evocation magic around the statue. As a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Search]] action, a creature within 5 feet of the statue can examine it and make a DC 10 Wisdom ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]]) check, detecting a tiny glyph on the statue on a successful check. Once the glyph is found, a character can take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Study]] action to examine it and make a DC 15 Intelligence ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Arcana]]) check, ascertaining that the glyph means “fire” on a successful check. As an action, a character can use a sharp tool to deface the glyph, which disarms the trap. As a Search action, a creature can examine the section of floor that forms the pressure plate and make a DC 15 Wisdom (Perception) check, detecting the pressure plate on a successful check. Wedging an [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Iron Spikes|Iron Spike]] or similar object under the pressure plate prevents the trap from triggering.

***At Higher Levels.*** You can scale the trap for higher levels by increasing the damage and the area of effect, as shown in the following table.

| Levels  | Fire Damage |  Area of Effect   |
| :-----: | :---------: | :---------------: |
| 5 - 10  |  22 (4d10)  | 30-foot [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Cone]]  |
| 11 - 16 | 55 (10d10)  | 60-foot [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Cone]]  |
| 17 - 20 | 99 (18d10)  | 120-foot [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Cone]] |
