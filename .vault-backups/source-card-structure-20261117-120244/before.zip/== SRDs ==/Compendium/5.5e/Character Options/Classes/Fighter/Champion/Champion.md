---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: f5d41976-f57a-5a9a-baf1-2ea737640d3c
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [49]
---

# Champion

*Pursue Physical Excellence in Combat*

![[== SRDs ==/Attachments/Artwork/phb-p099-champion.png|320]]


A Champion focuses on the development of martial prowess in a relentless pursuit of victory. Champions combine rigorous training with physical excellence to deal devastating blows, withstand peril, and garner glory. Whether in athletic contests or bloody battle, Champions strive for the crown of the victor.

#### Level 3: [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Fighter/Champion/Improved Critical|Improved Critical]]
Your attack rolls with weapons and [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strikes]] can score a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Critical Hit|Critical Hit]] on a roll of 19 or 20 on the d20.
#### Level 3: [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Fighter/Champion/Remarkable Athlete|Remarkable Athlete]]
Thanks to your athleticism, you have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Initiative|Initiative]] rolls and Strength ([[== SRDs ==/Compendium/5.5e/Rules/Skills/Athletics|Athletics]]) checks. In addition, immediately after you score a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Critical Hit|Critical Hit]], you can move up to half your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]] without provoking [[== SRDs ==/Compendium/5.5e/Rules/Actions/Opportunity Attacks|Opportunity Attacks]].
#### Level 7: Additional Fighting Style
You gain another Fighting Style feat of your choice.
#### Level 10: [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Fighter/Champion/Heroic Warrior|Heroic Warrior]]
The thrill of battle drives you toward victory. During combat, you can give yourself [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Heroic Inspiration|Heroic Inspiration]] whenever you start your turn without it.
#### Level 15: Superior Critical
Your attack rolls with weapons and Unarmed Strikes can now score a Critical Hit on a roll of 18-20 on the d20.
#### Level 18: [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Fighter/Champion/Survivor|Survivor]]
You attain the pinnacle of resilience in battle, giving you these benefits.

***Defy Death.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Death Saving Throw|Death Saving Throws]]. Moreover, when you roll 18-20 on a Death Saving Throw, you gain the benefit of rolling a 20 on it.

***Heroic Rally.*** At the start of each of your turns, you regain [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] equal to 5 plus your Constitution modifier if you are [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bloodied|Bloodied]] and have at least 1 Hit Point.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=99|Player’s Handbook (2024), PDF page 99]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

Pursue Physical Excellence in Combat A Champion focuses on the development of martial prowess in a relentless pursuit of victory. Champions combine rigorous training with physical excellence to deal devastating blows, withstand peril, and garner glory. Whether in athletic contests or bloody battle, Champions strive for the crown of the victor.

### Level 3: Improved Critical

![[== SRDs ==/Compendium/5.5e/Character Options/Classes/Fighter/Champion/Improved Critical#SRD 5.2.1]]



### Level 3: Remarkable Athlete

![[== SRDs ==/Compendium/5.5e/Character Options/Classes/Fighter/Champion/Remarkable Athlete#SRD 5.2.1]]

#### Level 7: Additional Fighting Style

You gain another Fighting Style feat of your choice.

### Level 10: Heroic Warrior

![[== SRDs ==/Compendium/5.5e/Character Options/Classes/Fighter/Champion/Heroic Warrior#SRD 5.2.1]]

#### Level 15: Superior Critical

Your attack rolls with weapons and Unarmed Strikes can now score a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Critical Hit|Critical Hit]] on a roll of 18–20 on the d20.

### Level 18: Survivor

![[== SRDs ==/Compendium/5.5e/Character Options/Classes/Fighter/Champion/Survivor#SRD 5.2.1]]


Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=49|SRD 5.2.1, p. 49]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=49|SRD 5.2.1, p. 49]]
