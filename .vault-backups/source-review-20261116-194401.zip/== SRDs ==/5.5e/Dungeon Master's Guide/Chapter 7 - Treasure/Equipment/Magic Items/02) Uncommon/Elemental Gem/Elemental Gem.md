---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Elemental Gem [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Elemental Gem/Elemental Gem|(200 GP)]]
*Wondrous Item, Uncommon*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

This gem contains a mote of elemental energy. When you take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize]] action to break the gem, an elemental is summoned, and the gem ceases to be magical. The elemental appears in an unoccupied space as close to the broken gem as possible, understands your languages, obeys your commands, and takes its turn immediately after you on your [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative]] count. The elemental disappears after 1 hour, when it dies, or when you dismiss it as a Bonus Action. The type of gem determines the elemental, as shown in the following table.

| Gem            | Summoned Elemental  |
| -------------- | ------------------- |
| Blue sapphire  | [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Air Elemental]]   |
| Emerald        | [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Water Elemental]] |
| Red corundum   | [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Fire Elemental]]  |
| Yellow diamond | [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Earth Elemental]] |
