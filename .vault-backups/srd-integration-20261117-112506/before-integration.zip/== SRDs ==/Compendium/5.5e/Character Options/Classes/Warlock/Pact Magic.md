---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: b1734949-eb95-5200-8702-777d1538ab85
entity_type: character-option
source_ids: ["phb-2024"]
---

# Pact Magic

![[== SRDs ==/Attachments/Artwork/phb-p155-warlock.png|320]]

Through occult ceremony, you have formed a pact with a mysterious entity to gain magical powers. The entity is a voice in the shadows - its identity unclear - but its boon to you is concrete: the ability to cast spells. See [[== SRDs ==/Compendium/5.5e/Spells/Spells|Spells]] for the rules on spellcasting. The information below details how you use those rules with Warlock spells, which appear in the Warlock spell list later in the class’s description.

***Cantrips.*** You know two Warlock cantrips of your choice. Whenever you gain a Warlock level, you can replace one of your cantrips from this feature with another Warlock cantrip of your choice. When you reach Warlock levels 4 and 10, you learn another Warlock cantrip of your choice, as shown in the Cantrips column of the Warlock Features table.

***Spell Slots.*** The Warlock Features table shows how many spell slots you have to cast your Warlock spells of levels 1-5. The table also shows the level of those slots, all of which are the same level. You regain all expended Pact Magic spell slots when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

***Prepared Spells of Level 1+.*** You prepare the list of level 1+ spells that are available for you to cast with this feature. To start, choose two level 1 Warlock spells.

The number of spells on your list increases as you gain Warlock levels, as shown in the Prepared Spells column of the Warlock Features table. Whenever that number increases, choose additional Warlock spells until the number of spells on your list matches the number in the table. The chosen spells must be of a level no higher than what’s shown in the table’s Slot Level column for your level.

If another Warlock feature gives you spells that you always have prepared, those spells don’t count against the number of spells you can prepare with this feature, but those spells otherwise count as Warlock spells for you.

***Changing Your Prepared Spells.*** Whenever you gain a Warlock level, you can replace one spell on your list with another Warlock spell of an eligible level.

***Spellcasting Ability.*** Charisma is the spellcasting ability for your Warlock spells.

***Spellcasting Focus.*** You can use an [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Arcane Focus/Arcane Focus|Arcane Focus]] as a Spellcasting Focus for your Warlock spells.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=156|Player’s Handbook (2024), PDF page 156]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
