---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Potion of Healing [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Potions of Healing/Potion of Healing|(50 GP)]]
*Potion, Common*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p292-potion-of-healing.png|320]]


**Attunement:** No **Weight:** 0.5 lb

As a Bonus Action, you can drink it or administer it to another creature within 5 feet of yourself. The creature that drinks the magical red fluid in this vial regains 2d4 + 2[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]]. The potion's red liquid glimmers when agitated.
