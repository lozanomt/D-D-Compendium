---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Hobgoblin Captain
> 
> *Medium Fey (Goblinoid), Lawful Evil*
> 
> ![[mm-p172-hobgoblin-captain.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +4 (14)  
> **HP** 58 (9d8 + 18)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 14 | +2 | +2 | **Con** | 14 | +2 | +2 |
> | **Int** | 12 | +1 | +1 | **Wis** | 10 | +0 | +0 | **Cha** | 13 | +1 | +1 |
> 
> **Gear** Greatsword, Half Plate Armor, Longbow  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Common, Goblin  
> **CR** 3 (XP 700; PB +2)  
> 
> ### Traits
> 
> ***Aura of Authority.*** While in a 10-foot Emanation originating from the hobgoblin, the hobgoblin and its allies have Advantage on attack rolls and saving throws, provided the hobgoblin doesn't have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> 
> ### Actions
> 
> ***Multiattack.*** The hobgoblin makes two attacks, using Greatsword or Longbow in any combination.
> 
> ***Greatsword.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 9 (2d6 + 2) Slashing damage plus 3 (1d6) Poison damage.
> 
> ***Longbow.*** *Ranged Attack Roll:* +4, range 150/600 ft. *Hit:* 6 (1d8 + 2) Piercing damage plus 5 (2d4) Poison damage.
