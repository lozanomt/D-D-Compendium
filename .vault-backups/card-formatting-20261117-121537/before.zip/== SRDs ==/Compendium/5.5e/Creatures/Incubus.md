---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 1881c437-52ca-5045-b318-2a135b9d4d20
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [301]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Incubus

## Monster Manual


> [!statblock]
> ### Incubus
>
> *Medium Fiend, Neutral Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p180-incubus.png|320]]
>
> **AC:** 15 &emsp;  
> **Initiative:** +3 (13)  
> **HP:** 66 (12d8 + 12)  
> **Speed:** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 8 | -1 | -1 | **Dex** | 17 | +3 | +3 | **Con** | 13 | +1 | +1 |
> | **Int** | 15 | +2 | +2 | **Wis** | 12 | +1 | +1 | **Cha** | 20 | +5 | +5 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Deception|Deception]] +9, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Insight|Insight]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Persuasion|Persuasion]] +9, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +7  
> **Resistances:** Cold, Fire, Poison, Psychic  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages:** Abyssal, Common, Infernal; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Telepathy|Telepathy]] 60 ft.  
> **CR:** 4 (XP 1,100; PB +2)  
>
> #### Traits
>
> ***Succubus Form.*** When the incubus finishes a Long Rest, it can shape-shift into a **Succubus**, using that stat block instead of this one. Any equipment it is wearing or carrying isn't transformed.
>
> #### Actions
>
> ***Multiattack.*** The incubus makes two Restless Touch attacks.
>
> ***Restless Touch.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 15 (3d6 + 5) Psychic damage, and the target is cursed for 24 hours or until the incubus dies. Until the curse ends, the target gains no benefit from finishing Short Rests.
>
> ***Spellcasting.*** The incubus casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 15):
>
> - **At Will:** *Disguise Self*, *Etherealness*
> - **1/Day Each:** *Dream*, *Hypnotic Pattern*
>
> #### Bonus Actions
>
> ***Nightmare (Recharge 6).*** *Wisdom Saving Throw:* DC 15, one creature the incubus can see within 60 feet. *Failure:* If the target has 20 Hit Points or fewer, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]] condition for 1 hour, until it takes damage, or until a creature within 5 feet of it takes an action to wake it. Otherwise, the target takes 18 (4d8) Psychic damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Incubus
>
> *Medium Fiend, Neutral Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p180-incubus.png|320]]
>
> **AC:** 15 &emsp;  
> **Initiative:** +3 (13)  
> **HP:** 66 (12d8 + 12)  
> **Speed:** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 8 | -1 | -1 | **Dex** | 17 | +3 | +3 | **Con** | 13 | +1 | +1 |
> | **Int** | 15 | +2 | +2 | **Wis** | 12 | +1 | +1 | **Cha** | 20 | +5 | +5 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Deception|Deception]] +9, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Insight|Insight]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Persuasion|Persuasion]] +9, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +7  
> **Resistances:** Cold, Fire, Poison, Psychic  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages:** Abyssal, Common, Infernal; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Telepathy|Telepathy]] 60 ft.  
> **CR:** 4 (XP 1,100; PB +2)  
>
> #### Traits
>
> ***Succubus Form.*** When the incubus finishes a Long Rest, it can shape-shift into a **Succubus**, using that stat block instead of this one. Any equipment it is wearing or carrying isn't transformed.
>
> #### Actions
>
> ***Multiattack.*** The incubus makes two Restless Touch attacks.
>
> ***Restless Touch.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 15 (3d6 + 5) Psychic damage, and the target is cursed for 24 hours or until the incubus dies. Until the curse ends, the target gains no benefit from finishing Short Rests.
>
> ***Spellcasting.*** The incubus casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 15):
>
> - **At Will:** *Disguise Self*, *Etherealness*
> - **1/Day Each:** *Dream*, *Hypnotic Pattern*
>
> #### Bonus Actions
>
> ***Nightmare (Recharge 6).*** *Wisdom Saving Throw:* DC 15, one creature the incubus can see within 60 feet. *Failure:* If the target has 20 Hit Points or fewer, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]] condition for 1 hour, until it takes damage, or until a creature within 5 feet of it takes an action to wake it. Otherwise, the target takes 18 (4d8) Psychic damage.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=301|SRD 5.2.1, p. 301]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
