---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 2039ad33-332b-5c16-b2ad-d98682268fbe
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [259]
---

> [!statblock]
> ## Ankheg
> 
> *Large Monstrosity, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p020-ankheg.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +0 (10)  
> **HP** 45 (6d10 + 12)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Burrowing|Burrow]] 10 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 11 | +0 | +0 | **Con** | 14 | +2 | +2 |
> | **Int** | 1 | -5 | -5 | **Wis** | 13 | +1 | +1 | **Cha** | 6 | -2 | -2 |
> 
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Tremorsense|Tremorsense]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** None  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Tunneler.*** The ankheg can burrow through solid rock at half its Burrow Speed and leaves a 10-foot-diameter tunnel in its wake.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5 (with Advantage if the target is [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] by the ankheg), reach 5 ft. *Hit:* 10 (2d6 + 3) Slashing damage plus 3 (1d6) Acid damage. If the target is a Large or smaller creature, it has the Grappled condition (escape DC 13).
> 
> ***Acid Spray (Recharge 6).*** *Dexterity Saving Throw:* DC 12, each creature in a 30-foot-long, 5-foot-wide Line. *Failure:* 14 (4d6) Acid damage. *Success:* Half damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=259|SRD 5.2.1, p. 259]] — matches the existing entry.
