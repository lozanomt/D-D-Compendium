---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Shovel [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Shovel|(2 GP)]] 

![[Placeholder.png|320]]

Working for 1 hour, you can use a Shovel to dig a hole that is 5 feet on each side in soil or similar material.

**Weight:** 5 lb.
