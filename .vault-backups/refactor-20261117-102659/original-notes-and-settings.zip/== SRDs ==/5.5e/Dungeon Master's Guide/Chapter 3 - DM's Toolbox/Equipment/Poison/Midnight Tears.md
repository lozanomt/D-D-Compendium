---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Midnight Tears [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Equipment/Poison/Midnight Tears|(1,500 GP)]]
*[[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Rules/Properties/Poison/Ingested|Ingested]] Poison*

![[Placeholder.png|320]]


A creature that ingests Midnight Tears suffers no effect until the stroke of midnight. Any effect that ends the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]] condition neutralizes this poison. If the poison hasn’t been neutralized before midnight, the creature makes a DC 17 Constitution saving throw, taking 31 (9d6) Poison damage on a failed save or half as much damage on a successful one.
