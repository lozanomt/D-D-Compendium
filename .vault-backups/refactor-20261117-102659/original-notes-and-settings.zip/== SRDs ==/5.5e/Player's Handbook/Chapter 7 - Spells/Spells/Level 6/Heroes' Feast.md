---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Heroes' Feast
*Level 6 Conjuration (Bard, Cleric, Druid)*

![[Placeholder.png|320]]


**Casting Time:** 10 minutes
**Range:** Self
**Components:** V, S, M (a gem-encrusted bowl worth 1,000+ GP, which the spell consumes)
**Duration:** Instantaneous

You conjure a feast that appears on a surface in an unoccupied 10-foot [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Cube|Cube]] next to you. The feast takes 1 hour to consume and disappears at the end of that time, and the beneficial effects don't set in until this hour is over. Up to twelve creatures can partake of the feast.

A creature that partakes gains several benefits, which last for 24 hours. The creature has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] to Poison damage, and it has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Immunity|Immunity]] to the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Frightened|Frightened]] and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]] conditions. Its [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Point]] maximum also increases by 2d10, and it gains the same number of Hit Points.
