---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Traveler's Clothes [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Traveler's Clothes|(2 GP)]] 

![[Placeholder.png|320]]

Traveler’s Clothes are resilient garments designed for travel in various environments.

**Weight:** 4 lb.
