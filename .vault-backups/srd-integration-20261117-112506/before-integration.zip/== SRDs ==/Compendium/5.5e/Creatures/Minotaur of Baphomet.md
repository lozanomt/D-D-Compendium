---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: a1812417-0e09-51c6-9972-ca341391563e
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Minotaur of Baphomet
> 
> *Large Monstrosity, Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p217-minotaur-of-baphomet.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +0 (10)  
> **HP** 85 (10d10 + 30)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 11 | +0 | +0 | **Con** | 16 | +3 | +3 |
> | **Int** | 6 | -2 | -2 | **Wis** | 16 | +3 | +3 | **Cha** | 9 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +7, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Survival|Survival]] +7  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 17  
> **Languages** Abyssal  
> **CR** 3 (XP 700; PB +2)  
> 
> ### Actions
> 
> ***Abyssal Glaive.*** *Melee Attack Roll:* +6, reach 10 ft. *Hit:* 10 (1d12 + 4) Slashing damage plus 10 (3d6) Necrotic damage.
> 
> ***Gore (Recharge 5-6).*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 18 (4d6 + 4) Piercing damage. If the target is a Large or smaller creature and the minotaur moved 10+ feet straight toward it immediately before the hit, the target takes an extra 10 (3d6) Piercing damage and has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]] condition.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
