---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: e53ad41e-08bb-52c5-bf96-5a6930b0b761
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [352]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Giant Owl

## Monster Manual


> [!statblock]
> ### Giant Owl
>
> *Large Celestial, Neutral*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC:** 12 &emsp;  
> **Initiative:** +2 (12)  
> **HP:** 19 (3d10 + 3)  
> **Speed:** 5 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 15 | +2 | +2 | **Con** | 12 | +1 | +1 |
> | **Int** | 10 | +0 | +0 | **Wis** | 14 | +2 | +4 | **Cha** | 10 | +0 | +0 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6  
> **Resistances:** Necrotic, Radiant  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages:** Celestial; understands Common, Elvish, and Sylvan but can't speak them  
> **CR:** 1/4 (XP 50; PB +2)  
>
> #### Traits
>
> ***Flyby.*** The owl doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.
>
> #### Actions
>
> ***Talons.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (1d10 + 2) Slashing damage.
>
> ***Spellcasting.*** The owl casts one of the following spells, requiring no spell components and using Wisdom as the spellcasting ability:
>
> - **At Will:** *Detect Evil and Good*, *Detect Magic*
> - **1/Day:** *Clairvoyance*
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1


> [!statblock]
> ### Giant Owl
>
> *Large Celestial, Neutral*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **AC:** 12 &emsp;  
> **Initiative:** +2 (12)  
> **HP:** 19 (3d10 + 3)  
> **Speed:** 5 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 15 | +2 | +2 | **Con** | 12 | +1 | +1 |
> | **Int** | 10 | +0 | +0 | **Wis** | 14 | +2 | +4 | **Cha** | 10 | +0 | +0 |
>
> **Skills:** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6  
> **Resistances:** Necrotic, Radiant  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages:** Celestial; understands Common, Elvish, and Sylvan but can't speak them  
> **CR:** 1/4 (XP 50; PB +2)  
>
> #### Traits
>
> ***Flyby.*** The owl doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.
>
> #### Actions
>
> ***Talons.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (1d10 + 2) Slashing damage.
>
> ***Spellcasting.*** The owl casts one of the following spells, requiring no spell components and using Wisdom as the spellcasting ability:
>
> - **At Will:** *Detect Evil and Good*, *Detect Magic*
> - **1/Day:** *Clairvoyance*
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=352|SRD 5.2.1, p. 352]]

## Source References
- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
