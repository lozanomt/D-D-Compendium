---
tags: [creature, phb]
cssclasses: [dnd-book, dnd-mm]
source_book: "Player's Handbook (2024)"
source_page: 349
source_pdf_page: 352
review_status: checked-against-page-image
reviewed: 2026-11-17
---

> [!statblock]
> ## Elephant
>
> *Huge Beast, Unaligned*
>
> **AC** 12 &emsp; **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]]** -1 (9)  
> **HP** 76 (8d12 + 24)  
> **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]]** 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 22 | +6 | +6 | **Dex** | 9 | -1 | -1 | **Con** | 17 | +3 | +3 |
> | **Int** | 3 | -4 | -4 | **Wis** | 11 | +0 | +0 | **Cha** | 6 | -2 | -2 |
>
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** None  
> **CR** 4 (XP 1,100; PB +2)  
>
> ### Actions
>
> ***Multiattack.*** The elephant makes two Gore attacks.
>
> ***Gore.*** *Melee [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] Roll:* +8, reach 5 ft. *Hit:* 15 (2d8 + 6) Piercing damage. If the elephant moved at least 20 feet straight toward the target immediately before the hit, the target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.
>
> ### Bonus Actions
>
> ***Trample.*** *Dexterity Saving Throw:* DC 16, one creature within 5 feet that has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition. *Failure:* 17 (2d10 + 6) Bludgeoning damage. *Success:* Half damage.

Source: [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=352|Player’s Handbook (2024), p. 349]].

[[== SRDs ==/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/5.5e/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Elephant|Monster Manual version]]
