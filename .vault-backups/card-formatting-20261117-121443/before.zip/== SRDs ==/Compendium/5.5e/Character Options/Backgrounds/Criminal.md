---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 2cc30d96-3b5e-52fb-8c37-e30be14d35c0
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [83]
source_versions: ["Player's Handbook", "SRD 5.2.1"]
---

# Criminal

## Player's Handbook

> [!info]
> ### Criminal
>
> ![[== SRDs ==/Attachments/Artwork/phb-p182-criminal.png|320]]
>
> **Ability Scores:** Dexterity, Constitution, Intelligence
> **Feat:** [[== SRDs ==/Compendium/5.5e/Character Options/Feats/01) Origin Feats/Alert|Alert]]
> **Skill Proficiencies** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Sleight of Hand|Sleight of Hand]] and [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]]
> **Tool Proficiency:** [[== SRDs ==/Compendium/5.5e/Items/Tools/Thieves' Tools|Thieves' Tools]]
> **Equipment:** *Choose A or B:* (A) 2 [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Dagger|Daggers]], [[== SRDs ==/Compendium/5.5e/Items/Tools/Thieves' Tools|Thieves' Tools]], [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Crowbar|Crowbar]], 2 [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Pouch|Pouches]], [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Traveler's Clothes|Traveler's Clothes]], 16 GP; or (B) 50 GP
>
> **Source:** [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf|Player's Handbook]]

## SRD 5.2.1

> [!info]
> ### Criminal
>
> Ability Scores: Dexterity, Constitution, Intelligence Feat: Alert (see "Feats") [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Skill|Skill]] Proficiencies:  Sleight of Hand and Stealth Tool [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency|Proficiency]]: Thieves' Tools Equipment: Choose A or B: (A) 2 Daggers, Thieves' Tools, Crowbar, 2 Pouches, Traveler's Clothes, 16 GP; or (B) 50 GP
>
> Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=83|SRD 5.2.1, p. 83]].
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=83|SRD 5.2.1, p. 83]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Player's Handbook — Chapter 4 - Character Origins]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=83|SRD 5.2.1, p. 83]]
