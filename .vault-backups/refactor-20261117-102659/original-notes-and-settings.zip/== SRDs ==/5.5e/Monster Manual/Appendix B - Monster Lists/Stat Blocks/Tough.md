---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Tough
> 
> *Medium or Small Humanoid, Neutral*
> 
> ![[mm-p309-tough.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +1 (11)  
> **HP** 32 (5d8 + 10)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 12 | +1 | +1 | **Con** | 14 | +2 | +2 |
> | **Int** | 10 | +0 | +0 | **Wis** | 10 | +0 | +0 | **Cha** | 11 | +0 | +0 |
> 
> **Gear** Heavy Crossbow, Leather Armor, Mace  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Common  
> **CR** 1/2 (XP 100; PB +2)  
> 
> ### Traits
> 
> ***Pack Tactics.*** The tough has Advantage on an attack roll against a creature if at least one of the tough's allies is within 5 feet of the creature and the ally doesn't have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> 
> ### Actions
> 
> ***Mace.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Bludgeoning damage.
> 
> ***Heavy Crossbow.*** *Ranged Attack Roll:* +3, range 100/400 ft. *Hit:* 6 (1d10 + 1) Piercing damage.
