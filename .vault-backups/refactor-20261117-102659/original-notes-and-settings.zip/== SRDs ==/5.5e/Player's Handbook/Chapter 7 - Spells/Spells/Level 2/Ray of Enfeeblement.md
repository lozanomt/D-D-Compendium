---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Ray of Enfeeblement
*Level 2 Necromancy (Warlock, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 minute

A beam of enervating energy shoots from you toward a creature within range. The target must make a Constitution saving throw. On a successful save, the target has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on the next attack roll it makes until the start of your next turn.

On a failed save, the target has Disadvantage on Strength-based [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/D20 Test|D20 Tests]] for the duration. During that time, it also subtracts 1d8 from all its damage rolls. The target repeats the save at the end of each of its turns, ending the spell on a success.
