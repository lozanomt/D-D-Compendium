---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Boots of Elvenkind [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Boots of Elvenkind|(400 GP)]]
*Wondrous Item, Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p243-boots-of-elvenkind.png|320]]


**Attunement:** No

While you wear these boots, your steps make no sound, regardless of the surface you are moving across. You also have [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage]] on Dexterity ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]]) checks.
