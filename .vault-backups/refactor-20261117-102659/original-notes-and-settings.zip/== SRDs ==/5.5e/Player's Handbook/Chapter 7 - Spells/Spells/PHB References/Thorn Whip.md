---
type: spell-reference
coverage: source-reference
level: 0
school: Transmutation
rules_revision: "2024"
classes:
  - Druid
tags:
  - rules/spell-reference
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Thorn Whip

![[Placeholder.png|320]]


**Cantrip · Transmutation**

## Rules reference

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=85|Handbook class spell-list entry]]

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=242|Open the handbook’s spell descriptions]] and search for **Thorn Whip** for the complete casting time, range, components, duration, and effects. This note supplies a source reference, not a transcription of the spell.

## Class lists

[[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Druid/Druid|Druid]]
