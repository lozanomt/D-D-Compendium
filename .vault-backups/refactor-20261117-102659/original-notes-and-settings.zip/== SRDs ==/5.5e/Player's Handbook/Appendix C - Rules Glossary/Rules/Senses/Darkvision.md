---
tags:
  - sense
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Darkvision

![[Placeholder.png|320]]


If you have Darkvision, you can see in [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Dim Light|Dim Light]] within a specified range as if it were [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Bright Light|Bright Light]] and in [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Darkness|Darkness]] within that range as if it were Dim Light. You discern colors in that Darkness only as shades of gray.
