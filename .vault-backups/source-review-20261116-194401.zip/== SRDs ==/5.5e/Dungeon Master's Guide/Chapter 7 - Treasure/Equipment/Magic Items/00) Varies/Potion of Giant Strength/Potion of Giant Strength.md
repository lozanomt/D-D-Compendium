---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Potion of Giant Strength [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Potion of Giant Strength/Potion of Giant Strength|(Varies)]]
*Wondrous Item, Varies*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p292-potion-of-giant-strength.png|320]]


**Attunement:** No

When you drink this potion, your Strength score changes for 1 hour. The type of giant determines the score (see the table below). The potion has no effect on you if your Strength is equal to or greater than that score. This potion’s transparent liquid has floating in it a sliver of light resembling a giant’s fingernail.

| Potion                                                           | Str, | Rarity    |
| ---------------------------------------------------------------- | :--: | --------- |
| Potion of Hill Giant Strength                                    | 21   | Uncommon  |
| Potion of Frost Giant Strength or Potion of Stone Giant Strength | 23   | Rare      |
| Potion of Fire Giant Strength                                    | 25   | Rare      |
| Potion of Cloud Giant Strength                                   | 27   | Very Rare |
| Potion of Storm Giant Strength                                   | 29   | Legendary |
