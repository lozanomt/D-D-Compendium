---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 4fd7e046-3734-5506-a1bd-c5e90fdb0398
entity_type: character-option
source_ids: ["phb-2024"]
---

# Blessed Strikes

![[== SRDs ==/Attachments/Artwork/phb-p071-cleric.png|320]]

Divine power infuses you in battle. You gain one of the following options of your choice. If an older Cleric subclass also grants either option, use only the option you choose for this feature.

***Divine Strike.*** Once on each of your turns when you hit a creature with an attack roll using a weapon, you can cause the target to take an extra 1d8 Necrotic or Radiant damage (your choice). At Cleric level 14, the extra damage of your Divine Strike increases to 2d8.

***Potent Spellcasting.*** Add your Wisdom modifier to the damage you deal with any Cleric cantrip. At Cleric level 14, when you cast a Cleric cantrip and deal damage to a creature with it, you can give vitality to yourself or another creature within 60 feet of yourself, granting a number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to twice your Wisdom modifier.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=72|Player’s Handbook (2024), PDF page 72]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
