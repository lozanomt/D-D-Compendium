---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: d70cc2cf-06b2-5266-8b16-420167d7c1da
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Grick
> 
> *Medium Aberration, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p160-grick.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +2 (12)  
> **HP** 54 (12d8)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 14 | +2 | +2 | **Dex** | 14 | +2 | +2 | **Con** | 11 | +0 | +0 |
> | **Int** | 3 | -4 | -4 | **Wis** | 14 | +2 | +2 | **Cha** | 5 | -3 | -3 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +4  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** None  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The grick makes one Beak attack and one Tentacles attack.
> 
> ***Beak.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 9 (2d6 + 2) Piercing damage.
> 
> ***Tentacles.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (1d10 + 2) Slashing damage. If the target is a Medium or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 12) from all four tentacles.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
