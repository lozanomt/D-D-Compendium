---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: a90ded12-9587-5c33-8f60-c5b8f21a625e
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Worg
> 
> *Large Fey, Neutral Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p337-worg.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +1 (11)  
> **HP** 26 (4d10 + 4)  
> **Speed** 50 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 16 | +3 | +3 | **Dex** | 13 | +1 | +1 | **Con** | 13 | +1 | +1 |
> | **Int** | 7 | -2 | -2 | **Wis** | 11 | +0 | +0 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Goblin, Worg  
> **CR** 1/2 (XP 100; PB +2)  
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Piercing damage, and the next attack roll made against the target before the start of the worg's next turn has Advantage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
