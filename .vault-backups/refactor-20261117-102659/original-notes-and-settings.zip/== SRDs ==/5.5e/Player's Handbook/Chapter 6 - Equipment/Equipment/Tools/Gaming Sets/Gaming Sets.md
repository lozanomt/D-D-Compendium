---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Gaming Sets

![[Placeholder.png|320]]


####  Gaming Set [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Gaming Sets/Gaming Sets|(Varies)]]
**Ability:** Wisdom **Weight:** -
[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]]: Discern whether someone is cheating (DC 10), or win the game (DC 20)
**Variants:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Gaming Sets/Dice|Dice]] (1 SP), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Gaming Sets/Dragonchess|Dragonchess]] (1 GP), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Gaming Sets/Playing Cards|Playing Cards]] (5 SP), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Gaming Sets/Three-Dragon Ante|Three-Dragon Ante]] (1 GP)
