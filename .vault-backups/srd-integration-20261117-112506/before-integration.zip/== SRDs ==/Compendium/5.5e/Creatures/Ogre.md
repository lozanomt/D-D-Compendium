---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 24189446-1695-5dd7-bd16-6302aee15f17
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Ogre
> 
> *Large Giant, Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p233-ogre.png|320]]
> 
> 
> **AC** 11 &emsp; **Initiative** -1 (9)  
> **HP** 68 (8d10 + 24)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 8 | -1 | -1 | **Con** | 16 | +3 | +3 |
> | **Int** | 5 | -3 | -3 | **Wis** | 7 | -2 | -2 | **Cha** | 7 | -2 | -2 |
> 
> **Gear** Greatclub, Javelins (3)  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 8  
> **Languages** Common, Giant  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Actions
> 
> ***Greatclub.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 13 (2d8 + 4) Bludgeoning damage.
> 
> ***Javelin.*** *Melee or Ranged Attack Roll:* +6, reach 5 ft. or range 30/120 ft. *Hit:* 11 (2d6 + 4) Piercing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
