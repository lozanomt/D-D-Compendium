---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Disintegrate
*Level 6 Transmutation (Sorcerer, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** 60 feet
**Components:** V, S, M (a lodestone and dust)
**Duration:** Instantaneous

You launch a green ray at a target you can see within range. The target can be a creature, a nonmagical object, or a creation of magical force, such as the wall created by *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Wall of Force|Wall of Force]]*.

A creature targeted by this spell makes a Dexterity saving throw. On a failed save, the target takes 10d6 + 40 Force damage. If this damage reduces it to 0 [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points|Hit Points]], it and everything nonmagical it is wearing and carrying are disintegrated into gray dust. The target can be revived only by a *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 9/True Resurrection|True Resurrection]]* or a *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 9/Wish|Wish]]* spell.

This spell automatically disintegrates a Large or smaller nonmagical object or a creation of magical force. If such a target is Huge or larger, this spell disintegrates a 10-foot-[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Cube|Cube]] portion of it.

***Using a Higher-Level Spell Slot.*** The damage increases by 3d6 for each spell slot level above 6.
