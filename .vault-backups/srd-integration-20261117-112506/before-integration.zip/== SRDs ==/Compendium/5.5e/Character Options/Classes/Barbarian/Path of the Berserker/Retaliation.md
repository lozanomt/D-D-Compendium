---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 2bc3986c-10d6-5d4c-a8d0-ff729b36a274
entity_type: character-option
source_ids: ["phb-2024"]
---

# Retaliation

![[== SRDs ==/Attachments/Artwork/phb-p057-path-of-the-berserker.png|320]]

When you take damage from a creature that is within 5 feet of you, you can take a Reaction to make one melee attack against that creature, using a weapon or an [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]].

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=57|Player’s Handbook (2024), PDF page 57]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
