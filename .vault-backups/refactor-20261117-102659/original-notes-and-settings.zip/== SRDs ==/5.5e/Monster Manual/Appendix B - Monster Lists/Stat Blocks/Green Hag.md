---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Green Hag
> 
> *Medium Fey, Neutral Evil*
> 
> ![[mm-p158-green-hag.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +1 (11)  
> **HP** 82 (11d8 + 33)  
> **Speed** 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 12 | +1 | +1 | **Con** | 16 | +3 | +3 |
> | **Int** | 13 | +1 | +1 | **Wis** | 14 | +2 | +2 | **Cha** | 14 | +2 | +2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Arcana|Arcana]] +5, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Deception|Deception]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +3  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Common, Elvish, Sylvan  
> **CR** 3 (XP 700; PB +2)  
> 
> ### Traits
> 
> ***Amphibious.*** The hag can breathe air and water.
> 
> ***Coven Magic.*** While within 30 feet of at least two hag allies, the hag can cast one of the following spells, requiring no Material components, using the spell's normal casting time, and using Intelligence as the spellcasting ability (spell save DC 11): *Augury*, *Find Familiar*, *Identify*, *Locate Object*, *Scrying*, or *Unseen Servant*. The hag must finish a Long Rest before using this trait to cast that spell again.
> 
> ***Mimicry.*** The hag can mimic animal sounds and humanoid voices. A creature that hears the sounds can tell they are imitations only with a successful DC 14 Wisdom (Insight) check.
> 
> ### Actions
> 
> ***Multiattack.*** The hag makes two Claw attacks.
> 
> ***Claw.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 8 (1d8 + 4) Slashing damage plus 3 (1d6) Poison damage.
> 
> ***Spellcasting.*** The hag casts one of the following spells, requiring no Material components and using Wisdom as the spellcasting ability (spell save DC 12, +4 to hit with spell attacks):
> 
> - **At Will:** *Dancing Lights*, *Disguise Self* (24-hour duration), *Invisibility* (self only, and the hag leaves no tracks while [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Invisible|Invisible]]), *Minor Illusion*, *Ray of Sickness*  (level 3 version)
