---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Dire Wolf
> 
> *Large Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/Monster Manual/Artwork/mm-p354-dire-wolf.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +2 (12)  
> **HP** 22 (3d10 + 6)  
> **Speed** 50 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 15 | +2 | +2 | **Con** | 15 | +2 | +2 |
> | **Int** | 3 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +5, [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]] +4  
> **Senses** [[Darkvision]] 60 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 15  
> **Languages** None  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Traits
> 
> ***Pack Tactics.*** The wolf has Advantage on an attack roll against a creature if at least one of the wolf's allies is within 5 feet of the creature and the ally doesn't have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated]] condition.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 8 (1d10 + 3) Piercing damage. If the target is a Large or smaller creature, it has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone]] condition.
