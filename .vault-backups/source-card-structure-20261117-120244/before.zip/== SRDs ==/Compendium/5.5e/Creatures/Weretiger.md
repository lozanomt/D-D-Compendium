---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: d0bf1f4c-953c-5631-9fb4-8bb2a79b8a31
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [339]
---

> [!statblock]
> ## Weretiger
> 
> *Medium or Small Monstrosity (Lycanthrope), Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p328-weretiger.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 120 (16d8 + 48)  
> **Speed** 30 ft., 40 ft. (tiger form only)  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 15 | +2 | +2 | **Con** | 16 | +3 | +3 |
> | **Int** | 10 | +0 | +0 | **Wis** | 13 | +1 | +1 | **Cha** | 11 | +0 | +0 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +4  
> **Gear** Longbow  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** Common (can't speak in tiger form)  
> **CR** 4 (XP 1,100; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The weretiger makes two attacks, using Scratch or Longbow in any combination. It can replace one attack with a Bite attack.
> 
> ***Bite (Tiger or Hybrid Form Only).*** *Melee Attack Roll:*  +5, reach 5 ft. *Hit:* 12 (2d8 + 3) Piercing damage. If the target is a Humanoid, it is subjected to the following effect. *Constitution Saving Throw:* DC 13. *Failure:* The target is cursed. If the cursed target drops to 0 Hit Points, it instead becomes a **Weretiger** under the GM's control and has 10 Hit Points. *Success:* The target is immune to this weretiger's curse for 24 hours.
> 
> ***Scratch.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 10 (2d6 + 3) Slashing damage.
> 
> ***Longbow (Humanoid or Hybrid Form Only).*** *Ranged Attack Roll:* +4, range 150/600 ft. *Hit:* 11 (2d8 + 2) Piercing damage.
> 
> ### Bonus Actions
> 
> ***Prowl (Tiger or Hybrid Form Only).*** The weretiger moves up to its Speed without provoking Opportunity Attacks. At the end of this movement, the weretiger can take the Hide action.
> 
> ***Shape-Shift.*** The weretiger shape-shifts into a Large tiger-humanoid hybrid or a Large tiger, or it returns to its true humanoid form. Its game statistics, other than its size, are the same in each form. Any equipment it is wearing or carrying isn't transformed.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=339|SRD 5.2.1, p. 339]] — matches the existing entry.
