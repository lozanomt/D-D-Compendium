---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Holy Aura
*Level 8 Abjuration (Cleric)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a reliquary worth 1,000+ GP)
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 minute

For the duration, you emit an aura in a 30-foot [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Emanation|Emanation]]. While in the aura, creatures of your choice have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on all saving throws, and other creatures have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on attack rolls against them. In addition, when a Fiend or an Undead hits an affected creature with a melee attack roll, the attacker must succeed on a Constitution saving throw or have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded|Blinded]] condition until the end of its next turn.
