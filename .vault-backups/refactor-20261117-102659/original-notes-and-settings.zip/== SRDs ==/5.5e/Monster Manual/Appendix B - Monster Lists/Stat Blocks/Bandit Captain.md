---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Bandit Captain
> 
> *Medium or Small Humanoid, Neutral*
> 
> ![[mm-p029-bandit-captain.png|320]]
> 
> 
> **AC** 15 &emsp; **Initiative** +3 (13)  
> **HP** 52 (8d8 + 16)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +4 | **Dex** | 16 | +3 | +5 | **Con** | 14 | +2 | +2 |
> | **Int** | 14 | +2 | +2 | **Wis** | 11 | +0 | +2 | **Cha** | 14 | +2 | +2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Athletics|Athletics]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Deception|Deception]] +4  
> **Gear** Pistol, Scimitar, Studded Leather Armor  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Common, Thieves' Cant  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The bandit makes two attacks, using Scimitar and Pistol in any combination.
> 
> ***Scimitar.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 6 (1d6 + 3) Slashing damage.
> 
> ***Pistol.*** *Ranged Attack Roll:* +5, range 30/90 ft. *Hit:* 8 (1d10 + 3) Piercing damage.
> 
> ### Reactions
> 
> ***Parry.*** *Trigger:* The bandit is hit by a melee attack roll while holding a weapon. *Response:* The bandit adds 2 to its AC against that attack, possibly causing it to miss.
