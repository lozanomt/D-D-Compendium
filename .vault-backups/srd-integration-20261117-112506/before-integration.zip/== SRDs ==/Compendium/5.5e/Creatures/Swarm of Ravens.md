---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: a8df2eec-dbc0-5e9a-bccf-2a1366be3342
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Swarm of Ravens
> 
> *Medium Swarm of Tiny Beasts, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p373-swarm-of-ravens.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 11 (2d8 + 2)  
> **Speed** 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 50 ft. MOD SAVE MOD SAVE MOD SAVE  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 6 | -2 | -2 | **Dex** | 14 | +2 | +2 | **Con** | 12 | +1 | +1 |
> | **Int** | 5 | -3 | -3 | **Wis** | 12 | +1 | +1 | **Cha** | 6 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5  
> **Resistances** Bludgeoning, Piercing, Slashing  
> **Immunities** [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Petrified|Petrified]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Restrained|Restrained]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Stunned|Stunned]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** None  
> **CR** 1/4 (XP 50; PB +2)  
> 
> ### Traits
> 
> ***Swarm.*** The swarm can occupy another creature's space and vice versa, and the swarm can move through any opening large enough for a Tiny raven. The swarm can't regain Hit Points or gain Temporary Hit Points.
> 
> ### Actions
> 
> ***Beaks.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Piercing damage, or 2 (1d4) Piercing damage if the swarm is Bloodied.
> 
> ***Cacophony (Recharge 6).*** *Wisdom Saving Throw:* DC 10, one creature in the swarm's space. *Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Deafened|Deafened]] condition until the start of the swarm's next turn. While Deafened, the target also has Disadvantage on ability checks and attack rolls.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
