---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Ioun Stone [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Ioun Stone/Ioun Stone|(Varies)]]
*Wondrous Item, Varies*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p276-ioun-stone.png|320]]


**Attunement:** Yes

Roughly marble sized, *Ioun Stones* are named after Ioun, a god of knowledge and prophecy revered on some worlds. Many types of *Ioun Stones* exist, each type a distinct combination of shape and color. When you take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action to toss an *Ioun Stone* into the air, the stone orbits your head at a distance of 1d3 feet, conferring its benefit to you while doing so. You can have up to three *Ioun Stones* orbiting your head at the same time.

Each *Ioun Stone* orbiting your head is considered to be an object you are wearing. The orbiting stone avoids contact with other creatures and objects, adjusting its orbit to avoid collisions and thwarting all attempts by other creatures to attack or snatch it. As a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize]] action, you can seize and stow any number of *Ioun Stones* orbiting your head. If your [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Attunement]] to an *Ioun Stone* ends while it’s orbiting your head, the stone falls as though you had dropped it.

The type of stone determines its rarity and effects.

***Absorption (Very Rare).*** While this pale lavender ellipsoid orbits your head, you can take a Reaction to cancel a spell of level 4 or lower cast by a creature you can see. A canceled spell has no effect, and any resources used to cast it are wasted. Once the stone has canceled 20 levels of spells, it burns out, turns dull gray, and loses its magic.

***Agility (Very Rare).*** Your Dexterity increases by 2, to a maximum of 20, while this deep-red sphere orbits your head.

***Awareness (Rare).*** While this dark-blue rhomboid orbits your head, you have [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage]] on [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative]] rolls and Wisdom ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]]) checks.

***Fortitude (Very Rare).*** Your Constitution increases by 2, to a maximum of 20, while this pink rhomboid orbits your head.

***Greater Absorption (Legendary).*** While this marbled lavender and green ellipsoid orbits your head, you can take a Reaction to cancel a spell of level 8 or lower cast by a creature you can see. A canceled spell has no effect, and any resources used to cast it are wasted. Once the stone has canceled 20 levels of spells, it burns out, turns dull gray, and loses its magic.

***Insight (Very Rare).*** Your Wisdom increases by 2, to a maximum of 20, while this incandescent blue sphere orbits your head.

***Intellect (Very Rare).*** Your Intelligence increases by 2, to a maximum of 20, while this marbled scarlet and blue sphere orbits your head.

***Leadership (Very Rare).*** Your Charisma increases by 2, to a maximum of 20, while this marbled pink and green sphere orbits your head.

***Mastery (Legendary).*** Your Proficiency Bonus increases by 1 while this pale green prism orbits your head.

***Protection (Rare).*** You gain a +1 bonus to Armor Class while this dusty-rose prism orbits your head.

***Regeneration (Legendary).*** You regain 15 [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]] at the end of each hour this pearly white spindle orbits your head if you have at least 1 Hit Point.

***Reserve (Rare).*** This vibrant purple prism stores spells cast into it, holding them until you use them. The stone can store up to 4 levels of spells at a time. When found, it contains 1d4 levels of stored spells chosen by the DM.

Any creature can cast a spell of level 1 through 4 into the stone by touching it as the spell is cast. The spell has no effect, other than to be stored in the stone. If the stone can’t hold the spell, the spell is expended without effect. The level of the slot used to cast the spell determines how much space it uses.

While this stone orbits your head, you can cast any spell stored in it. The spell uses the slot level, spell save DC, spell attack bonus, and spellcasting ability of the original caster but is otherwise treated as if you cast the spell. The spell cast from the stone is no longer stored in it, freeing up space.

***Strength (Very Rare).*** Your Strength increases by 2, to a maximum of 20, while this pale blue rhomboid orbits your head.

***Sustenance (Rare).*** You don’t need to eat or drink while this clear spindle orbits your head.
