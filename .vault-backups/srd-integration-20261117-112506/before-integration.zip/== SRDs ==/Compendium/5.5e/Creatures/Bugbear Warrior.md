---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 9935928c-731c-5633-bd54-66ea0f529ed8
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Bugbear Warrior
> 
> *Medium Fey (Goblinoid), Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p064-bugbear-stalker.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** +2 (12)  
> **HP** 33 (6d8 + 6)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 14 | +2 | +2 | **Con** | 13 | +1 | +1 |
> | **Int** | 8 | -1 | -1 | **Wis** | 11 | +0 | +0 | **Cha** | 9 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Survival|Survival]] +2  
> **Gear** Hide Armor, Light Hammers (3)  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** Common, Goblin  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Traits
> 
> ***Abduct.*** The bugbear needn't spend extra movement to move a creature it is grappling.
> 
> ### Actions
> 
> ***Grab.*** *Melee Attack Roll:* +4, reach 10 ft. *Hit:* 9 (2d6 + 2) Bludgeoning damage. If the target is a Medium or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 12).
> 
> ***Light Hammer.*** *Melee or Ranged Attack Roll:* +4 (with Advantage if the target is [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] by the bugbear), reach 10 ft. or range 20/60 ft. *Hit:* 9 (3d4 + 2) Bludgeoning damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
