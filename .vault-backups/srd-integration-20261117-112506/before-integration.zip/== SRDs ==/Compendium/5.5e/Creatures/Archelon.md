---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: ac5d3bbf-8bfe-5a57-bf65-99f3ccf4184d
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Archelon
> 
> *Huge Beast (Dinosaur), Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p351-archelon.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +3 (13)  
> **HP** 90 (12d12 + 12)  
> **Speed** 20 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 80 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 16 | +3 | +3 | **Con** | 13 | +1 | +1 |
> | **Int** | 4 | -3 | -3 | **Wis** | 14 | +2 | +2 | **Cha** | 6 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +5  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** None  
> **CR** 4 (XP 1,100; PB +2)  
> 
> ### Traits
> 
> ***Amphibious.*** The archelon can breathe air and water.
> 
> ### Actions
> 
> ***Multiattack.*** The archelon makes two Bite attacks.
> 
> ***Bite.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 14 (3d6 + 4) Piercing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
