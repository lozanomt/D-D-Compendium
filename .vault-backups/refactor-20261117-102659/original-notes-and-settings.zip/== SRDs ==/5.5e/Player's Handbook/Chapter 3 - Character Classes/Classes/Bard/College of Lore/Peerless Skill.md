---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Peerless Skill

![[phb-p069-college-of-lore.png|320]]

When you make an ability check or attack roll and fail, you can expend one use of [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Bard/Bardic Inspiration|Bardic Inspiration]]; roll the Bardic Inspiration die, and add the number rolled to the d20, potentially turning a failure into a success. On a failure, the Bardic Inspiration isn’t expended.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=69|Player’s Handbook (2024), PDF page 69]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=70|Player’s Handbook (2024), PDF page 70]]
