---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 95f1b891-8768-5689-a36e-1fac302d0c2d
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [308, 309]
---

> [!statblock]
> ## Mimic
> 
> *Medium Monstrosity, Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p214-mimic.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +3 (13)  
> **HP** 58 (9d8 + 18)  
> **Speed** 20 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 12 | +1 | +1 | **Con** | 15 | +2 | +2 |
> | **Int** | 5 | -3 | -3 | **Wis** | 13 | +1 | +1 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +5  
> **Immunities** Acid; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** None  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Adhesive (Object Form Only).*** The mimic adheres to anything that touches it. A Huge or smaller creature adhered to the mimic has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 13). Ability checks made to escape this grapple have Disadvantage.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +5 (with Advantage if the target is [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] by the mimic), reach 5 ft. *Hit:* 7 (1d8 + 3) Piercing damage — or 12 (2d8 + 3) Piercing damage if the target is Grappled by the mimic — plus 4 (1d8) Acid damage.
> 
> ***Pseudopod.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Bludgeoning damage plus 4 (1d8) Acid damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]] condition (escape DC 13). Ability checks made to escape this grapple have Disadvantage.
> 
> ### Bonus Actions
> 
> ***Shape-Shift.*** The mimic shape-shifts to resemble a Medium or Small object while retaining its game statistics, or it returns to its true blob form. Any equipment it is wearing or carrying isn't transformed.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=308|SRD 5.2.1, p. 308–309]] — matches the existing entry.
