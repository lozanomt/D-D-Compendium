---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Adamantine Chain Shirt [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/02) Uncommon/Adamantine Armor/Adamantine Chain Shirt|(450 GP)]]
*Armor ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Chain Shirt|Chain Shirt]]), Uncommon*

![[Placeholder.png|320]]


**Attunement:** No

While you're wearing this armor, any [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Critical Hit|Critical Hit]] against you becomes a normal hit.

---
![[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Medium/Chain Shirt|clean no-title]]
