---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: c8ce1d83-3ef6-5bce-b085-64e2ee408d56
entity_type: character-option
source_ids: ["phb-2024"]
---

# Frenzy

![[== SRDs ==/Attachments/Artwork/phb-p057-path-of-the-berserker.png|320]]

If you use Reckless Attack while your Rage is active, you deal extra damage to the first target you hit on your turn with a Strength-based attack. To determine the extra damage, roll a number of d6s equal to your Rage Damage bonus, and add them together. The damage has the same type as the weapon or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]] used for the attack.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=57|Player’s Handbook (2024), PDF page 57]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
