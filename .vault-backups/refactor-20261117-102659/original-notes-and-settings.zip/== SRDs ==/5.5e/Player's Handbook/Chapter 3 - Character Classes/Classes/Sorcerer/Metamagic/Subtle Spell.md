---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Subtle Spell

![[phb-p141-sorcerer.png|320]]

*Cost:* 1 Sorcery Points

When you cast a spell, you can spend 1 Sorcery Point to cast it without any Verbal, Somatic, or Material [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Components|components]], except Material components that are consumed by the spell or that have a cost specified in the spell.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=142|Player’s Handbook (2024), PDF page 142]]
