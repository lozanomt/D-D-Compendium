---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 28253efa-956a-55ec-b0d0-5e683f20ff7b
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Pteranodon
> 
> *Medium Beast (Dinosaur), Unaligned*
> 
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +2 (12)  
> **HP** 13 (3d8)  
> **Speed** 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 12 | +1 | +1 | **Dex** | 15 | +2 | +2 | **Con** | 10 | +0 | +0 |
> | **Int** | 2 | -4 | -4 | **Wis** | 9 | -1 | -1 | **Cha** | 5 | -3 | -3 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +1  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 11  
> **Languages** None  
> **CR** 1/4 (XP 50; PB +2)  
> 
> ### Traits
> 
> ***Flyby.*** The pteranodon doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 6 (1d8 + 2) Piercing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
