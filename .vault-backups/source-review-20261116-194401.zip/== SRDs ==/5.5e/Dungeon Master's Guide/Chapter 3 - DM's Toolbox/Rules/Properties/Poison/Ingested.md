---
tags:
  - weaponproperty
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Ingested

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


A creature must swallow an entire dose of ingested poison to suffer its effects. The dose can be delivered in food or a liquid. You may decide that a partial dose has a reduced effect, such as allowing [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage]] on the saving throw or dealing only half as much damage on a failed save.
