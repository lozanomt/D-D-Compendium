# Lore

- [[== SRDs ==/Compendium/5.5e/Lore/Abyss|Abyss]]
- [[== SRDs ==/Compendium/5.5e/Lore/Far Realm|Far Realm]]
- [[== SRDs ==/Compendium/5.5e/Lore/The Ethereal Plane|The Ethereal Plane]]
