---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 4335ece4-25cd-5deb-a190-64ccdacbad8a
entity_type: character-option
source_ids: ["phb-2024"]
---

# Improved Critical

![[== SRDs ==/Attachments/Artwork/phb-p099-champion.png|320]]

Your attack rolls with weapons and [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strikes]] can score a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Critical Hit|Critical Hit]] on a roll of 19 or 20 on the d20.

***Superior Critical.*** At Fighter level 15, your attack rolls with weapons and Unarmed Strikes can now score a Critical Hit on a roll of 18-20 on the d20.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=99|Player’s Handbook (2024), PDF page 99]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
