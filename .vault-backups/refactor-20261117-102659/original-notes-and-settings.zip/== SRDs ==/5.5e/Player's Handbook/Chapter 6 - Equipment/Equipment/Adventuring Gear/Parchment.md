---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Parchment [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Parchment|(1 SP)]] 

![[Placeholder.png|320]]

One sheet of Parchment can hold about 250 handwritten words.

**Weight:** -
