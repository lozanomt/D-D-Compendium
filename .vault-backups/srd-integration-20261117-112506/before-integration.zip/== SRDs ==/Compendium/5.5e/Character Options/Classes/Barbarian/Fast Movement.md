---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 86949b48-439a-5e0f-ac29-7232732e5076
entity_type: character-option
source_ids: ["phb-2024"]
---

# Fast Movement

![[== SRDs ==/Attachments/Artwork/phb-p053-barbarian.png|320]]

Your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]] increases by 10 feet while you aren’t wearing Heavy armor.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=54|Player’s Handbook (2024), PDF page 54]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
