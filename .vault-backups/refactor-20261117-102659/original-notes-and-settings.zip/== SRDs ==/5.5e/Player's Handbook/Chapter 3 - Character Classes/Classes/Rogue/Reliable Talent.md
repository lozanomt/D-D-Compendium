---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Reliable Talent

![[phb-p131-rogue.png|320]]

Whenever you make an ability check that uses one of your skill or tool proficiencies, you can treat a d20 roll of 9 or lower as a 10.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=132|Player’s Handbook (2024), PDF page 132]]
