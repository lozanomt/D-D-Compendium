---
tags:
  - sense
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Truesight

![[Placeholder.png|320]]


If you have Truesight, your vision is enhanced within a specified range. Within that range, your vision pierces through the following:

**Darkness.** You can see in normal and magical [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Darkness|Darkness]].

**Invisibility.** You see creatures and objects that have the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Invisible|Invisible]] condition.

**Visual Illusions.** Visual illusions appear transparent to you, and you automatically succeed on saving throws against them.

**Transformations.** You discern the true form of any creature or object you see that has been transformed by magic.
