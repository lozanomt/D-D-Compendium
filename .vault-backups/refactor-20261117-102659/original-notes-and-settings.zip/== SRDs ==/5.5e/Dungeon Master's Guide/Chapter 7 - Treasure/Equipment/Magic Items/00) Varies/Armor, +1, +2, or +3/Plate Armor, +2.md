---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Plate Armor, +2 [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Armor, +1, +2, or +3/Plate Armor, +2|(41,500 GP)]]
*Armor ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Plate Armor|Plate Armor]]), Very Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/phb-p221-plate-armor.png|320]]


**Attunement** No

You have a +2 bonus to Armor Class while wearing this armor.

---
![[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Plate Armor|clean no-title]]
