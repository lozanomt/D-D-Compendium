---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Gift of the Depths
*Prerequisite: Level 5+ Warlock*

![[phb-p155-warlock.png|320]]


You can breathe underwater, and you gain a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] Speed equal to your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]].

You can also cast *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Water Breathing|Water Breathing]]* once without expending a spell slot. You regain the ability to cast it in this way again when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=156|Player’s Handbook (2024), PDF page 156]]
