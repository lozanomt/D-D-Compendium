---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Lance, +1 [[Lance, +1 |(410 GP)]]
*Weapon ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Lance]]), Uncommon*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/phb-p220-lance.png|320]]


**Attunement** No

You have a +1 bonus to attack rolls and damage rolls made with this magic weapon.

---
![[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Lance|clean no-title]]
