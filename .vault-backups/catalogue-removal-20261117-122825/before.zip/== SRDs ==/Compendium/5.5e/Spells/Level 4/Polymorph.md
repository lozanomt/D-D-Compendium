---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
entity_id: d7a8e6f9-e435-573d-8860-35628cd9a305
entity_type: spell
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [153, 154]
source_versions: ["Player's Handbook", "SRD 5.2.1"]
---

# Polymorph

## Player's Handbook

> [!info]
> ### Polymorph
> *Level 4 Transmutation (Bard, Druid, Sorcerer, Wizard)*
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> **Casting Time:** Action  
> **Range:** 60 feet  
> **Components:** V, S, M (a caterpillar cocoon)  
> **Duration:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration|Concentration]], up to 1 hour  
>
> You attempt to transform a creature that you can see within range into a Beast. The target must succeed on a Wisdom saving throw or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Shape-Shifting|shape-shift]] into a Beast form for the duration. That form can be any Beast you choose that has a Challenge Rating equal to or less than the target's (or the target's level if it doesn't have a Challenge Rating). The target's game statistics are replaced by the stat block of the chosen Beast, but the target retains its alignment, personality, creature type, [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]], and [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Point Dice|Hit Point Dice]].
>
> The target gains a number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to the Hit Points of the Beast form. These Temporary Hit Points vanish if any remain when the spell ends. The spell ends early on the target if it has no Temporary Hit Points left.
>
> The target is limited in the actions it can perform by the anatomy of its new form, and it can't speak or cast spells.
>
> The target's gear melds into the new form. The creature can't use or otherwise benefit from any of that equipment.
>
> [!columns|list 4] Polymorph Options
> - [[== SRDs ==/Compendium/5.5e/Creatures/Baboon|Baboon]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Badger#Monster Manual|Badger]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Bat#Monster Manual|Bat]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Cat#Monster Manual|Cat]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Crab#Monster Manual|Crab]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Deer|Deer]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Eagle|Eagle]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Frog#Monster Manual|Frog]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Giant Fire Beetle|Giant Fire Beetle]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Goat#Monster Manual|Goat]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Hawk#Monster Manual|Hawk]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Hyena|Hyena]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Jackal|Jackal]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Lizard#Monster Manual|Lizard]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Octopus#Monster Manual|Octopus]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Owl#Monster Manual|Owl]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Piranha|Piranha]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Rat#Monster Manual|Rat]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Raven#Monster Manual|Raven]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Scorpion#Monster Manual|Scorpion]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Seahorse|Seahorse]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Spider#Monster Manual|Spider]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Vulture|Vulture]]
> - [[== SRDs ==/Compendium/5.5e/Creatures/Weasel#Monster Manual|Weasel]]
>
> **Source:** [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf|Player's Handbook]]

## SRD 5.2.1

> [!info]
> ### Polymorph
>
> *Level 4 Transmutation (Bard, Druid, Sorcerer, Wizard)*
>
> **Casting Time:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action|Action]]  
>
> **Range:** 60 feet  
>
> **Components:** V, S, M (a caterpillar cocoon)  
>
> **Duration:** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration|Concentration]], up to 1 hour You attempt to transform a creature that you can see within range into a Beast. The target must succeed on a Wisdom saving throw or shape-shift into a Beast form for the duration. That form can be any Beast you choose that has a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating|Challenge Rating]] equal to or less than the target's (or the target's level if it doesn't have a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Challenge Rating|Challenge Rating]]). The target's game statistics are replaced by the stat block of the chosen Beast, but the target retains its alignment, personality, creature type, [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]], and Hit Point  
>
> Dice. See the "Animals" section of "Monsters" for a sample of Beast stat blocks.
>
> The target gains a number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] of the Beast form.
>
> These [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] vanish if any remain when the spell ends. The spell ends early on the target if it has no [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] left.
>
> The target is limited in the actions it can perform by the anatomy of its new form, and it can't speak or cast spells.
>
> The target's gear melds into the new form. The creature can't use or otherwise benefit from any of that equipment.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=153|SRD 5.2.1, p. 153–154]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 7 - Spells/Chapter 7 - Spells|Player's Handbook — Chapter 7 - Spells]]
