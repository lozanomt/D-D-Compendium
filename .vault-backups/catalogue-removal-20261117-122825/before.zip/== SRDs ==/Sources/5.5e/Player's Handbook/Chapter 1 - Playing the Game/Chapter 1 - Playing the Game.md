# Chapter 1 - Playing the Game

20 existing entries.

- [[== SRDs ==/Compendium/5.5e/Rules/Miscellaneous/Mounted Combat#Player's Handbook|Mounted Combat]]
- [[== SRDs ==/Compendium/5.5e/Rules/Miscellaneous/Underwater Combat#Player's Handbook|Underwater Combat]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Acrobatics#Player's Handbook|Acrobatics]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Animal Handling#Player's Handbook|Animal Handling]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana#Player's Handbook|Arcana]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Athletics#Player's Handbook|Athletics]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Deception#Player's Handbook|Deception]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/History#Player's Handbook|History]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Insight#Player's Handbook|Insight]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Intimidation#Player's Handbook|Intimidation]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Investigation#Player's Handbook|Investigation]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Medicine#Player's Handbook|Medicine]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Nature#Player's Handbook|Nature]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception#Player's Handbook|Perception]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Performance#Player's Handbook|Performance]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Persuasion#Player's Handbook|Persuasion]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Religion#Player's Handbook|Religion]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Sleight of Hand#Player's Handbook|Sleight of Hand]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth#Player's Handbook|Stealth]]
- [[== SRDs ==/Compendium/5.5e/Rules/Skills/Survival#Player's Handbook|Survival]]
