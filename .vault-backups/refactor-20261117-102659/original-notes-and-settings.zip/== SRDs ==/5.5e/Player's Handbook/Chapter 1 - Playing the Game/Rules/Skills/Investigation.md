---
tags:
  - skill
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Investigation

![[Placeholder.png|320]]


Intelligence (Investigation) allows you to find obscure information in books, or deduce how something works.
