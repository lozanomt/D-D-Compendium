---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Shield, +1 [[== SRDs ==/5.5e/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Shield, +1, +2, or +3/Shield, +1|(410 GP)]]
*Armor ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Shield|Shield]]), Uncommon*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/phb-p221-shield.png|320]]


**Attunement:** No

While holding this Shield, you have a +1 bonus to Armor Class, in addition to the Shield's normal bonus to AC.

---
![[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Shield|clean no-title]]
