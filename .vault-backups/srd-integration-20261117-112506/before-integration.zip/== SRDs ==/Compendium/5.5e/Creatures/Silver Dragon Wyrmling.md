---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: f2c6020f-2c9c-5149-930f-a3e55af52975
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Silver Dragon Wyrmling
> 
> *Medium Dragon (Metallic), Lawful Good*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p280-silver-dragon-wyrmling.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +2 (12)  
> **HP** 45 (6d8 + 18)  
> **Speed** 30 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 19 | +4 | +4 | **Dex** | 10 | +0 | +2 | **Con** | 17 | +3 | +3 |
> | **Int** | 12 | +1 | +1 | **Wis** | 11 | +0 | +2 | **Cha** | 15 | +2 | +2 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +2  
> **Immunities** Cold  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 10 ft., [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Draconic  
> **CR** 2 (450 XP; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The dragon makes two Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 9 (1d10 + 4) Piercing damage.
> 
> ***Cold Breath (Recharge 5-6).*** *Constitution Saving Throw:* DC 13, each creature in a 15-foot Cone. *Failure:* 18 (4d8) Cold damage. *Success:* Half damage.
> 
> ***Paralyzing Breath.*** *Constitution Saving Throw:* DC 13, each creature in a 15-foot Cone. *First Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition until the end of its next turn, when it repeats the save. *Second Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]] condition, and it repeats the save at the end of each of its turns, ending the effect on itself on a success. After 1 minute, it succeeds automatically.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
