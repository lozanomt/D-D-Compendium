---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: e73dad31-5e48-5d8b-9598-d2ab9c874782
entity_type: character-option
source_ids: ["phb-2024"]
---

# Rage

![[== SRDs ==/Attachments/Artwork/phb-p053-barbarian.png|320]]

You can imbue yourself with a primal power called Rage, a force that grants you extraordinary might and resilience. You can enter it as a Bonus Action if you aren’t wearing Heavy armor.

You can enter your Rage the number of times shown for your Barbarian level in the Rages column of the Barbarian Features table. You regain one expended use when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short Rest]], and you regain all expended uses when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

While active, your Rage follows the rules below.

***Damage Resistance.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Resistance|Resistance]] to Bludgeoning, Piercing, and Slashing damage.

***Rage Damage.*** When you make an attack using Strength - with either a weapon or an [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Unarmed Strike|Unarmed Strike]] - and deal damage to the target, you gain a bonus to the damage that increases as you gain levels as a Barbarian, as shown in the Rage Damage column of the Barbarian Features table.

***Strength Advantage.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on Strength checks and Strength saving throws.

***No Concentration or Spells.*** You can’t maintain [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration|Concentration]], and you can’t cast spells.

***Duration.*** The Rage lasts until the end of your next turn, and it ends early if you don Heavy armor or have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition. If your Rage is still active on your next turn, you can extend the Rage for another round by doing one of the following:
- Make an attack roll against an enemy.
- Force an enemy to make a saving throw.
- Take a Bonus Action to extend your Rage.

Each time the Rage is extended, it lasts until the end of your next turn. You can maintain a Rage for up to 10 minutes.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=54|Player’s Handbook (2024), PDF page 54]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
