---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Goat
> 
> *Medium Beast, Unaligned*
> 
> ![[Placeholder.png|320]]
> 
> 
> **AC** 10 &emsp; **Initiative** +0 (10)  
> **HP** 4 (1d8)  
> **Speed** 40 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 11 | +0 | +2 | **Dex** | 10 | +0 | +0 | **Con** | 11 | +0 | +0 |
> | **Int** | 2 | -4 | -4 | **Wis** | 10 | +0 | +0 | **Cha** | 5 | -3 | -3 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +2  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** None  
> **CR** 0 (XP 10; PB +2)  
> 
> ### Actions
> 
> ***Ram.*** *Melee Attack Roll:* +2, reach 5 ft. *Hit:* 1 Bludgeoning damage, or 2 (1d4) Bludgeoning damage if the goat moved 20+ feet straight toward the target immediately before the hit.
