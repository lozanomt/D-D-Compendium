---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Extreme Cold

![[Placeholder.png|320]]


When the temperature is 0 degrees Fahrenheit (-17 degrees Celsius) or lower, a creature exposed to the extreme cold must succeed on a DC 10 Constitution saving throw at the end of each hour or gain 1 [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]] level. Creatures that have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Resistance|Resistance]] or [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Immunity|Immunity]] to Cold damage automatically succeed on the save.
