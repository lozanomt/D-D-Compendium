# Player's Handbook

- [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf|Source PDF]]

## Chapters and Appendices

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix A - The Multiverse/Appendix A - The Multiverse|Appendix A - The Multiverse]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B - Creature Stat Blocks]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Shared-Creature-Index|Shared-Creature-Index]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Appendix C - Rules Glossary/Appendix C - Rules Glossary|Appendix C - Rules Glossary]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Chapter 1 - Playing the Game|Chapter 1 - Playing the Game]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 2 - Creating a Character/Chapter 2 - Creating a Character|Chapter 2 - Creating a Character]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Chapter 4 - Character Origins]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 5 - Feats/Chapter 5 - Feats|Chapter 5 - Feats]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 6 - Equipment/Chapter 6 - Equipment|Chapter 6 - Equipment]]
- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 7 - Spells/Chapter 7 - Spells|Chapter 7 - Spells]]
