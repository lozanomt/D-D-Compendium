---
cssclasses: [dnd-book, dnd-phb]
source_id: srd-5.2.1
source_pages: [89, 104]
---

# Equipment

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=89|SRD 5.2.1, p. 89]].

### Coins

Characters often find coins on their adventures and can spend those coins in shops, inns, and other businesses. Coins come in different denominations based on the relative worth of their material. The Coin Values table lists coins and how much they're worth relative to the Gold Piece, which is the game's main coin. For example, 100 Copper Pieces are worth 1 Gold Piece.

A coin weighs about a third of an ounce, so fifty coins weigh a pound.

Coin Values Coin Value in GP Copper Piece (CP) 1/100 Silver Piece (SP) 1/10 Electrum Piece (EP) 1/2 Gold Piece (GP) 1 Platinum Piece (PP) 10

### Weapons

The Weapons table in this section shows the game's main weapons. The table lists the cost and weight of each weapon, as well as the following details:

Category. Every weapon falls into a category: Simple or Martial. [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Weapon#SRD 5.2.1|Weapon]] proficiencies are usually tied to one of these categories. For example, you might have proficiency with Simple weapons.

Melee or Ranged. A weapon is classified as either

Melee or Ranged. A Melee weapon is used to attack a target within 5 feet, whereas a Ranged weapon is used to attack at a greater distance.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Damage#SRD 5.2.1|Damage]]. The table lists the amount of damage a weapon deals when an attacker hits with it as well as the type of that damage.

Properties.  Any properties a weapon has are listed in the Properties column. Each property is defined in the "Properties" section.

Mastery. Each weapon has a mastery property, which is defined in the "Mastery Properties" section. To use that property, you must have a feature that lets you use it.

#### Weapon Proficiency

Anyone can wield a weapon, but you must have proficiency with it to add your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus to an attack roll you make with it. A player character's features can provide weapon proficiencies. A monster is proficient with any weapon in its stat block.

#### Properties

Here are definitions of the properties in the Properties column of the Weapons table.

### Ammunition

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Ammunition#SRD 5.2.1|Ammunition]]

### Finesse

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Finesse#SRD 5.2.1|Finesse]]

### Heavy

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Heavy#SRD 5.2.1|Heavy]]

### Light

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Light#SRD 5.2.1|Light]]

### Loading

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Loading#SRD 5.2.1|Loading]]

### Range

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Range#SRD 5.2.1|Range]]

### Reach

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Reach#SRD 5.2.1|Reach]]

### Thrown

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Thrown#SRD 5.2.1|Thrown]]

### Two-Handed

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Two-Handed#SRD 5.2.1|Two-Handed]]

### Versatile

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Versatile#SRD 5.2.1|Versatile]]

#### Mastery Properties

Each weapon has a mastery property, which is usable only by a character who has a feature, such as [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Weapon#SRD 5.2.1|Weapon]] Mastery, that unlocks the property for the character. The properties are defined below.

### Cleave

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Cleave#SRD 5.2.1|Cleave]]

### Graze

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Graze#SRD 5.2.1|Graze]]

### Nick

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Nick#SRD 5.2.1|Nick]]

### Push

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Push#SRD 5.2.1|Push]]

### Sap

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Sap#SRD 5.2.1|Sap]]

### Slow

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Slow#SRD 5.2.1|Slow]]

### Topple

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Topple#SRD 5.2.1|Topple]]

### Vex

[[== SRDs ==/Compendium/5.5e/Rules/Properties/Mastery/Vex#SRD 5.2.1|Vex]]

### Weapons Table

| Name | Damage | Properties | Mastery | Weight | Cost |
| --- | --- | --- | --- | --- | --- |
| Club | 1d4 Bludgeoning | Light | Slow | 2 lb. | 1 SP |
| Dagger | 1d4 Piercing | Finesse, Light, Thrown (Range 20/60) | Nick | 1 lb. | 2 GP |
| Greatclub | 1d8 Bludgeoning | Two-Handed | Push | 10 lb. | 2 SP |
| Handaxe | 1d6 Slashing | Light, Thrown (Range 20/60) | Vex | 2 lb. | 5 GP |
| Javelin | 1d6 Piercing | Thrown (Range 30/120) | Slow | 2 lb. | 5 SP |
| Light Hammer | 1d4 Bludgeoning | Light, Thrown (Range 20/60) | Nick | 2 lb. | 2 GP |
| Mace | 1d6 Bludgeoning | — | Sap | 4 lb. | 5 GP |
| Quarterstaff | 1d6 Bludgeoning | Versatile (1d8) | Topple | 4 lb. | 2 SP |
| Sickle | 1d4 Slashing | Light | Nick | 2 lb. | 1 GP |
| Spear | 1d6 Piercing | Thrown (Range 20/60), Versatile (1d8) | Sap | 3 lb. | 1 GP |
| Dart | 1d4 Piercing | Finesse, Thrown (Range 20/60) | Vex | 1/4 lb. | 5 CP |
| Light Crossbow | 1d8 Piercing | Ammunition (Range 80/320; Bolt), Loading, Two-Handed | Slow | 5 lb. | 25 GP |
| Shortbow | 1d6 Piercing | Ammunition (Range 80/320; Arrow), Two-Handed | Vex | 2 lb. | 25 GP |
| Sling | 1d4 Bludgeoning | Ammunition (Range 30/120; Bullet) | Slow | — | 1 SP |
| Battleaxe | 1d8 Slashing | Versatile (1d10) | Topple | 4 lb. | 10 GP |
| Flail | 1d8 Bludgeoning | — | Sap | 2 lb. | 10 GP |
| Glaive | 1d10 Slashing | Heavy, Reach, Two-Handed | Graze | 6 lb. | 20 GP |
| Greataxe | 1d12 Slashing | Heavy, Two-Handed | Cleave | 7 lb. | 30 GP |
| Greatsword | 2d6 Slashing | Heavy, Two-Handed | Graze | 6 lb. | 50 GP |
| Halberd | 1d10 Slashing | Heavy, Reach, Two-Handed | Cleave | 6 lb. | 20 GP |
| Lance | 1d10 Piercing | Heavy, Reach, Two-Handed (unless mounted) | Topple | 6 lb. | 10 GP |
| Longsword | 1d8 Slashing | Versatile (1d10) | Sap | 3 lb. | 15 GP |
| Maul | 2d6 Bludgeoning | Heavy, Two-Handed | Topple | 10 lb. | 10 GP |
| Morningstar | 1d8 Piercing | — | Sap | 4 lb. | 15 GP |
| Pike | 1d10 Piercing | Heavy, Reach, Two-Handed | Push | 18 lb. | 5 GP |
| Rapier | 1d8 Piercing | Finesse | Vex | 2 lb. | 25 GP |
| Scimitar | 1d6 Slashing | Finesse, Light | Nick | 3 lb. | 25 GP |
| Shortsword | 1d6 Piercing | Finesse, Light | Vex | 2 lb. | 10 GP |
| Trident | 1d8 Piercing | Thrown (Range 20/60), Versatile (1d10) | Topple | 4 lb. | 5 GP |
| Warhammer | 1d8 Bludgeoning | Versatile (1d10) | Push | 5 lb. | 15 GP |
| War Pick | 1d8 Piercing | Versatile (1d10) | Sap | 2 lb. | 5 GP |
| Whip | 1d4 Slashing | Finesse, Reach | Slow | 3 lb. | 2 GP |
| Blowgun | 1 Piercing | Ammunition (Range 25/100; Needle), Loading | Vex | 1 lb. | 10 GP |
| Hand Crossbow | 1d6 Piercing | Ammunition (Range 30/120; Bolt), Light, Loading | Vex | 3 lb. | 75 GP |
| Heavy Crossbow | 1d10 Piercing | Ammunition (Range 100/400; Bolt), Heavy, Loading, Two-Handed | Push | 18 lb. | 50 GP |
| Longbow | 1d8 Piercing | Ammunition (Range 150/600; Arrow), Heavy, Two-Handed | Slow | 2 lb. | 50 GP |
| Musket | 1d12 Piercing | Ammunition (Range 40/120; Bullet), Loading, Two-Handed | Slow | 10 lb. | 500 GP |
| Pistol | 1d10 Piercing | Ammunition (Range 30/90; Bullet), Loading | Vex | 3 lb. | 250 GP |

### Armor

The Armor table lists the game's main armor. The table includes the cost and weight of armor, as well as the following details:

Category. Every type of armor falls into a category:

Light, Medium, or [[== SRDs ==/Compendium/5.5e/Rules/Properties/Heavy#SRD 5.2.1|Heavy]]. The category determines how long it takes to don or doff the armor (as shown in the table).

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Class#SRD 5.2.1|Armor Class]] (AC). The table's [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Class#SRD 5.2.1|Armor Class]] column tells you what your base AC is when you wear a type of armor. For example, if you wear Leather Armor, your base AC is 11 plus your Dexterity modifier, whereas your AC is 16 in Chain Mail.

Strength.  If the table shows a Strength score in the Strength column for an armor type, that armor reduces the wearer's speed by 10 feet unless the wearer has a Strength score equal to or higher than the listed score.

Stealth.  If the table shows "[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]]" in the Stealth column for an armor type, the wearer has [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]] on Dexterity (Stealth) checks.

#### Armor Training

Anyone can don armor or hold a [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]], but only those with training can use them effectively, as explained below. A character's class and other features determine the character's armor training.

A monster has training with any armor in its stat block.

#### Light, Medium, or Heavy Armor

If you wear Light, Medium, or [[== SRDs ==/Compendium/5.5e/Rules/Properties/Heavy#SRD 5.2.1|Heavy]] armor and lack training with it, you have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]] on any [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/D20 Test#SRD 5.2.1|D20 Test]] that involves Strength or Dexterity, and you can't cast spells.

#### Shield

You gain the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Class#SRD 5.2.1|Armor Class]] benefit of a [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]] only if you have training with it.

#### One at a Time

A creature can wear only one suit of armor at a time and wield only one [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]] at a time.

Armor Armor [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Armor Class#SRD 5.2.1|Armor Class]] (AC) Strength Stealth Weight Cost Light Armor (1 Minute to Don or Doff) Padded Armor 11 + Dex modifier — [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]] 8 lb. 5 GP Leather Armor 11 + Dex modifier — — 10 lb. 10 GP Studded Leather Armor 12 + Dex modifier — — 13 lb. 45 GP Medium Armor (5 Minutes to Don and 1 Minute to Doff) [[== SRDs ==/Compendium/5.5e/Rules/Actions/Hide#SRD 5.2.1|Hide]] Armor 12 + Dex modifier (max 2) — — 12 lb. 10 GP Chain Shirt 13 + Dex modifier (max 2) — — 20 lb. 50 GP Scale Mail 14 + Dex modifier (max 2) — [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]] 45 lb. 50 GP Breastplate 14 + Dex modifier (max 2) — — 20 lb. 400 GP Half Plate Armor 15 + Dex modifier (max 2) — [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]] 40 lb. 750 GP [[== SRDs ==/Compendium/5.5e/Rules/Properties/Heavy#SRD 5.2.1|Heavy]] Armor (10 Minutes to Don and 5 Minutes to Doff) Ring Mail 14 — [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]] 40 lb. 30 GP

Chain Mail 16 Str 13 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]] 55 lb. 75 GP

Splint Armor 17 Str 15 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]] 60 lb. 200 GP

Plate Armor 18 Str 15 [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage#SRD 5.2.1|Disadvantage]] 65 lb. 1,500 GP [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]] ([[== SRDs ==/Compendium/5.5e/Rules/Actions/Utilize#SRD 5.2.1|Utilize]] [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Action#SRD 5.2.1|Action]] to Don or Doff) [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]] +2 — — 6 lb. 10 GP

### Tools

A tool helps you make specialized ability checks, craft certain items, or both. A tool's description includes the tool's cost and weight, as well as the following entries:

Ability. This entry lists the ability to use when making an ability check with the tool.

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Utilize#SRD 5.2.1|Utilize]].  This entry lists things you can do with the tool when you take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Utilize#SRD 5.2.1|Utilize]] action. You can do one of those things each time you take the action.

This entry also provides the DC for the action.

Craft.  This entry lists what, if anything, you can craft with the tool. For crafting rules, see "Crafting Nonmagical Items," "Brewing Potions of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Healing#SRD 5.2.1|Healing]]," and "Scribing [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scrolls" later in "Equipment."

Variants.  This entry appears if the tool has variants, which are listed. Each requires a separate proficiency.

#### Tool Proficiency

If you have proficiency with a tool, add your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency#SRD 5.2.1|Proficiency]] Bonus to any ability check you make that uses the tool. If you have proficiency in a skill that's used with that check, you have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage#SRD 5.2.1|Advantage]] on the check too.

Your features might give you proficiency with a tool. A monster has proficiency with any tool in its stat block.

#### Artisan's Tools

Artisan's Tools are each focused on crafting items and pursuing a trade. Each of these tools requires a separate proficiency.

### Alchemist's Supplies (50 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Alchemist's Supplies#SRD 5.2.1|Alchemist's Supplies]]

### Brewer's Supplies (20 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Brewer's Supplies#SRD 5.2.1|Brewer's Supplies]]

### Calligrapher's Supplies (10 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Calligrapher's Supplies#SRD 5.2.1|Calligrapher's Supplies]]

### Carpenter's Tools (8 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Carpenter's Tools#SRD 5.2.1|Carpenter's Tools]]

### Cartographer's Tools (15 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Cartographer's Tools#SRD 5.2.1|Cartographer's Tools]]

### Cobbler's Tools (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Cobbler's Tools#SRD 5.2.1|Cobbler's Tools]]

### Cook's Utensils (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Cook's Utensils#SRD 5.2.1|Cook's Utensils]]

### Glassblower's Tools (30 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Glassblower's Tools#SRD 5.2.1|Glassblower's Tools]]

### Jeweler's Tools (25 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Jeweler's Tools#SRD 5.2.1|Jeweler's Tools]]

### Leatherworker's Tools (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Leatherworker's Tools#SRD 5.2.1|Leatherworker's Tools]]

### Mason's Tools (10 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Mason's Tools#SRD 5.2.1|Mason's Tools]]

### Painter's Supplies (10 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Painter's Supplies#SRD 5.2.1|Painter's Supplies]]

### Potter's Tools (10 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Potter's Tools#SRD 5.2.1|Potter's Tools]]

### Smith's Tools (20 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Smith's Tools#SRD 5.2.1|Smith's Tools]]

### Tinker's Tools (50 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Tinker's Tools#SRD 5.2.1|Tinker's Tools]]

### Weaver's Tools (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Weaver's Tools#SRD 5.2.1|Weaver's Tools]]

### Woodcarver's Tools (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Woodcarver's Tools#SRD 5.2.1|Woodcarver's Tools]]

#### Other Tools

### Disguise Kit (25 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Disguise Kit#SRD 5.2.1|Disguise Kit]]

### Forgery Kit (15 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Forgery Kit#SRD 5.2.1|Forgery Kit]]

### Gaming Set (Varies)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Gaming Set#SRD 5.2.1|Gaming Set]]

### Herbalism Kit (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Herbalism Kit#SRD 5.2.1|Herbalism Kit]]

### Musical Instrument (Varies)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Musical Instrument#SRD 5.2.1|Musical Instrument]]

### Navigator's Tools (25 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Navigator's Tools#SRD 5.2.1|Navigator's Tools]]

### Poisoner's Kit (50 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Poisoner's Kit#SRD 5.2.1|Poisoner's Kit]]

### Thieves' Tools (25 GP)

[[== SRDs ==/Compendium/5.5e/Items/Tools/Thieves' Tools#SRD 5.2.1|Thieves' Tools]]

### Adventuring Gear

The Adventuring Gear table in this section includes gear that adventurers often find useful. These items are described here in alphabetical order, with an item's price appearing after its name.

### Acid (25 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Acid#SRD 5.2.1|Acid]]

### Alchemist's Fire (50 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Alchemist's Fire#SRD 5.2.1|Alchemist's Fire]]

### Ammunition (Varies)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Ammunition#SRD 5.2.1|Ammunition]]

### Antitoxin (50 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Antitoxin#SRD 5.2.1|Antitoxin]]

### Arcane Focus (Varies)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Arcane Focus/Arcane Focus#SRD 5.2.1|Arcane Focus]]

### Backpack (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Backpack#SRD 5.2.1|Backpack]]

### Ball Bearings (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Ball Bearings#SRD 5.2.1|Ball Bearings]]

### Barrel (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Barrel#SRD 5.2.1|Barrel]]

### Basket (4 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Basket#SRD 5.2.1|Basket]]

### Bedroll (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Bedroll#SRD 5.2.1|Bedroll]]

### Bell (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Bell#SRD 5.2.1|Bell]]

### Blanket (5 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Blanket#SRD 5.2.1|Blanket]]

### Block and Tackle (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Block and Tackle#SRD 5.2.1|Block and Tackle]]

### Book (25 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Book#SRD 5.2.1|Book]]

### Bottle, Glass (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Glass Bottle#SRD 5.2.1|Glass Bottle]]

### Bucket (5 CP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Bucket#SRD 5.2.1|Bucket]]

### Burglar's Pack (16 GP)

[[== SRDs ==/Compendium/5.5e/Items/Gear Packs/Burglar's Pack#SRD 5.2.1|Burglar's Pack]]

### Caltrops (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Caltrops#SRD 5.2.1|Caltrops]]

### Candle (1 CP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Candle#SRD 5.2.1|Candle]]

### Case, Crossbow Bolt (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Crossbow Bolt Case#SRD 5.2.1|Crossbow Bolt Case]]

### Case, Map or Scroll (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Map or Scroll Case#SRD 5.2.1|Map or Scroll Case]]

### Chain (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Chain#SRD 5.2.1|Chain]]

### Chest (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Chest#SRD 5.2.1|Chest]]

### Climber's Kit (25 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Climber's Kit#SRD 5.2.1|Climber's Kit]]

### Clothes, Fine (15 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Fine Clothes#SRD 5.2.1|Fine Clothes]]

### Clothes, Traveler's (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Traveler's Clothes#SRD 5.2.1|Traveler's Clothes]]

### Component Pouch (25 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Component Pouch#SRD 5.2.1|Component Pouch]]

### Costume (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Costume#SRD 5.2.1|Costume]]

### Crowbar (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Crowbar#SRD 5.2.1|Crowbar]]

### Diplomat's Pack (39 GP)

[[== SRDs ==/Compendium/5.5e/Items/Gear Packs/Diplomat's Pack#SRD 5.2.1|Diplomat's Pack]]

### Druidic Focus (Varies)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Druidic Focus/Druidic Focus#SRD 5.2.1|Druidic Focus]]

### Dungeoneer's Pack (12 GP)

[[== SRDs ==/Compendium/5.5e/Items/Gear Packs/Dungeoneer's Pack#SRD 5.2.1|Dungeoneer's Pack]]

### Entertainer's Pack (40 GP)

[[== SRDs ==/Compendium/5.5e/Items/Gear Packs/Entertainer's Pack#SRD 5.2.1|Entertainer's Pack]]

### Explorer's Pack (10 GP)

[[== SRDs ==/Compendium/5.5e/Items/Gear Packs/Explorer's Pack#SRD 5.2.1|Explorer's Pack]]

### Flask (2 CP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Flask#SRD 5.2.1|Flask]]

### Grappling Hook (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Grappling Hook#SRD 5.2.1|Grappling Hook]]

### Healer's Kit (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Healer's Kit#SRD 5.2.1|Healer's Kit]]

### Holy Symbol (Varies)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Holy Symbol/Holy Symbol#SRD 5.2.1|Holy Symbol]]

### Holy Water (25 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Holy Water#SRD 5.2.1|Holy Water]]

### Hunting Trap (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Hunting Trap#SRD 5.2.1|Hunting Trap]]

### Ink (10 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Ink#SRD 5.2.1|Ink]]

### Ink Pen (2 CP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Ink Pen#SRD 5.2.1|Ink Pen]]

### Jug (2 CP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Jug#SRD 5.2.1|Jug]]

### Ladder (1 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Ladder#SRD 5.2.1|Ladder]]

### Lamp (5 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Lamp#SRD 5.2.1|Lamp]]

### Lantern, Bullseye (10 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Bullseye Lantern#SRD 5.2.1|Bullseye Lantern]]

### Lantern, Hooded (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Hooded Lantern#SRD 5.2.1|Hooded Lantern]]

### Lock (10 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Lock#SRD 5.2.1|Lock]]

### Magnifying Glass (100 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Magnifying Glass#SRD 5.2.1|Magnifying Glass]]

### Manacles (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Manacles#SRD 5.2.1|Manacles]]

### Map (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Map#SRD 5.2.1|Map]]

### Mirror (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Mirror#SRD 5.2.1|Mirror]]

### Net (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Net#SRD 5.2.1|Net]]

### Oil (1 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Oil#SRD 5.2.1|Oil]]

### Paper (2 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Paper#SRD 5.2.1|Paper]]

### Parchment (1 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Parchment#SRD 5.2.1|Parchment]]

### Perfume (5 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Perfume#SRD 5.2.1|Perfume]]

### Poison, Basic (100 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Basic Poison#SRD 5.2.1|Basic Poison]]

### Pole (5 CP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Pole#SRD 5.2.1|Pole]]

### Pot, Iron (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Iron Pot#SRD 5.2.1|Iron Pot]]

### Potion of Healing (50 GP)

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/00) Varies/Potions of Healing/Potion of Healing#SRD 5.2.1|Potion of Healing]]

### Pouch (5 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Pouch#SRD 5.2.1|Pouch]]

### Priest's Pack (33 GP)

[[== SRDs ==/Compendium/5.5e/Items/Gear Packs/Priest's Pack#SRD 5.2.1|Priest's Pack]]

### Quiver (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Quiver#SRD 5.2.1|Quiver]]

### Ram, Portable (4 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Portable Ram#SRD 5.2.1|Portable Ram]]

### Rations (5 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Rations#SRD 5.2.1|Rations]]

### Robe (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Robe#SRD 5.2.1|Robe]]

### Rope (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Rope#SRD 5.2.1|Rope]]

### Sack (1 CP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Sack#SRD 5.2.1|Sack]]

### Scholar's Pack (40 GP)

[[== SRDs ==/Compendium/5.5e/Items/Gear Packs/Scholar's Pack#SRD 5.2.1|Scholar's Pack]]

### Shovel (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Shovel#SRD 5.2.1|Shovel]]

### Signal Whistle (5 CP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Signal Whistle#SRD 5.2.1|Signal Whistle]]

### Spell Scroll (Cantrip, 30 GP; Level 1, 50 GP)

[[== SRDs ==/Compendium/5.5e/Items/Magic Items/Spell Scroll/Spell Scroll#SRD 5.2.1|Spell Scroll]]

### Spikes, Iron (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Iron Spikes#SRD 5.2.1|Iron Spikes]]

### Spyglass (1,000 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Spyglass#SRD 5.2.1|Spyglass]]

### String (1 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/String#SRD 5.2.1|String]]

### Tent (2 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Tent#SRD 5.2.1|Tent]]

### Tinderbox (5 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Tinderbox#SRD 5.2.1|Tinderbox]]

### Torch (1 CP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Torch#SRD 5.2.1|Torch]]

### Vial (1 GP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Vial#SRD 5.2.1|Vial]]

### Waterskin (2 SP)

[[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Waterskin#SRD 5.2.1|Waterskin]]

### Mounts and Vehicles

A mount can help you move more quickly through the wilderness, but its primary purpose is to carry gear that would otherwise slow you down. The Mounts and Other Animals table shows each animal's carrying capacity. See "Monsters" for the animals' stat blocks.

#### Mounts and Cargo

An animal pulling a carriage, cart, chariot, sled, or wagon can move weight up to five times its base carrying capacity, including the weight of the vehicle. If multiple animals pull the same vehicle, add their carrying capacities together.

#### Barding

Barding is armor designed for a mount. Any type of armor on the Armor table in "Equipment" can be purchased as barding. The cost is four times the normal cost, and it weighs twice as much.

#### Saddles

A saddle comes with a bit, a bridle, reins, and any other equipment needed to use the saddle. A Military Saddle gives [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage#SRD 5.2.1|Advantage]] on any ability check you make to remain mounted. An Exotic Saddle is required for riding an aquatic or a flying mount.

Mounts and Other Animals Item [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Carrying Capacity#SRD 5.2.1|Carrying Capacity]] Cost

Camel 450 lb. 50 GP

Elephant 1,320 lb. 200 GP

Horse, Draft 540 lb. 50 GP

Horse, Riding 480 lb. 75 GP

Mastiff 195 lb. 25 GP

Mule 420 lb. 8 GP

Pony 225 lb. 30 GP

Warhorse 540 lb. 400 GP Tack, Harness, and Drawn Vehicles Item Weight Cost

Carriage 600 lb. 100 GP

Cart 200 lb. 15 GP

Chariot 100 lb. 250 GP

Feed per day 10 lb. 5 CP Saddle

Exotic 40 lb. 60 GP

Military 30 lb. 20 GP

Riding 25 lb. 10 GP

Sled 300 lb. 20 GP Stabling per day — 5 SP

Wagon 400 lb. 35 GP

#### Large Vehicles

The Airborne and Waterborne Vehicles table provides statistics for various types of large vehicles.

The following notes apply.

#### Speed

A ship sailing against a strong wind moves at half speed. In a dead calm (no wind), waterborne ships can't move under sail and must be rowed. Keelboats and Rowboats are used on lakes and rivers. If going downstream, add the speed of the current (typically 3 miles per hour) to the speed of the vehicle. These vehicles can't be rowed against any significant current, but they can be pulled upstream by draft animals on the shores. A Rowboat can be carried and weighs 100 pounds.

#### Crew

A ship larger than a Keelboat or Rowboat needs a crew of skilled hirelings (see "Hirelings" later in "Equipment") to function. The minimum number of skilled hirelings needed to crew a ship depends on the type of ship, as shown in the table.

#### Passengers

The table lists the number of Small and Medium passengers the ship can accommodate using hammocks. A ship outfitted with private accommodations can carry one-fifth as many passengers. A passenger usually pays 5 SP per day for a hammock, but prices can vary from ship to ship. A small private cabin usually costs 2 GP per day.

#### Damage Threshold

If a vehicle has a damage threshold (see "Rules Glossary"), it's noted in the table.

#### Ship Repair

Repairs to a damaged ship can be made while the vessel is berthed. Repairing 1 Hit Point of damage requires 1 day and costs 20 GP for materials and labor. If the repairs are made in a location where supplies and skilled labor are abundant, such as a city shipyard, the repair time and cost are halved.

### Lifestyle Expenses

Lifestyle expenses summarize the cost of living in a fantasy world. They cover lodging, food, equipment maintenance, and other necessities.

At the start of each week or month (GM's choice), choose a lifestyle below—Wretched, Squalid, Poor, Modest, Comfortable, Wealthy, or Aristocratic—and pay the price to sustain that lifestyle.

Lifestyles have no inherent consequences, but the GM might take them into account when determining risks or how others perceive your character.

#### Wretched (Free)

You survive via chance and charity. You're often exposed to natural dangers as a result of sleeping outside.

#### Squalid (1 SP per Day)

You spend the bare minimum for your necessities.

You might be exposed to unhealthy conditions and opportunistic criminals.

#### Poor (2 SP per Day)

You spend frugally for your necessities.

#### Modest (1 GP per Day)

You support yourself at an average level.

#### Comfortable (2 GP per Day)

You spend modestly for your necessities and enjoy a few luxuries.

#### Wealthy (4 GP per Day)

You're accustomed to the finer things in life and might have servants.

#### Aristocratic (10 GP per Day)

You pay for the best and might have a staff that supports your lifestyle. Others notice your wealth and might encourage you to share it, either legally or otherwise.

### Food, Drink, and Lodging

The Food, Drink, and Lodging table gives prices for food and a single night's lodging. Prices for daily lodging and meals are included in your lifestyle's expenses.

Food, Drink, and Lodging Item Cost Ale (mug) 4 CP Bread (loaf) 2 CP Cheese (wedge) 1 SP Inn Stay per Day Squalid 7 CP Poor 1 SP Modest 5 SP Item Cost Comfortable 8 SP Wealthy 2 GP Aristocratic 4 GP Meal Squalid 1 CP Poor 2 CP Modest 1 SP Airborne and Waterborne Vehicles Ship [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed#SRD 5.2.1|Speed]] Crew Passengers Cargo (Tons) AC HP [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Damage Threshold#SRD 5.2.1|Damage Threshold]] Cost Airship 8 mph 10 20 1 13 300 — 40,000 GP Galley 4 mph 80 — 150 15 500 20 30,000 GP Keelboat 1 mph 1 6 1/2 15 100 10 3,000 GP Longship 3 mph 40 150 10 15 300 15 10,000 GP Rowboat 11⁄2 mph 1 3 — 11 50 — 50 GP Sailing Ship 2 mph 20 20 100 15 300 15 10,000 GP Warship 21⁄2 mph 60 60 200 15 500 20 25,000 GP Item Cost Comfortable 2 SP Wealthy 3 SP Aristocratic 6 SP Item Cost Wine (bottle) Common 2 SP Fine 10 GP

### Hirelings

Skilled hirelings include anyone hired to perform a service that involves a proficiency (including weapon, tool, or skill): a mercenary, an artisan, a scribe, or the like. The pay shown on the Hirelings table is a minimum; some expert hirelings require more pay. Untrained hirelings are hired for work that requires no particular proficiencies; they include laborers and porters.

Hirelings Service Cost Skilled hireling 2 GP per day Untrained hireling 2 SP per day Messenger 2 CP per mile

### Spellcasting

Most settlements contain individuals who are willing to cast spells in exchange for payment. If a spell has expensive components, add the cost of those components to the cost listed in the Spellcasting

Services table. The higher the level of a desired spell, the harder it is to find someone to cast it.

Spellcasting Services [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Level Availability Cost [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Cantrip#SRD 5.2.1|Cantrip]] Village, town, or city 30 GP 1 Village, town, or city 50 GP 2 Village, town, or city 200 GP 3 Town or city only 300 GP 4–5 Town or city only 2,000 GP 6–8 City only 20,000 GP 9 City only 100,000 GP

### Magic Items

Adventures hold the promise—but not a guarantee—of finding magic items. Hundreds of magic items are detailed in "[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] Items" later in this document. Here's what you need to know about using magic items.

#### Identifying a Magic Item

Some magic items are indistinguishable from their nonmagical counterparts, while others are conspicuously magical. Handling a magic item is enough to give you a sense that it is extraordinary, but learning a magic item's properties isn't automatic.

The [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Identify#SRD 5.2.1|Identify]] spell is the fastest way to reveal an item's properties. Alternatively, you can focus on one magic item during a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest#SRD 5.2.1|Short Rest]] while being in physical contact with the item. At the end of the rest, you learn its properties and how to use them (but not any curse the item might bear).

Sometimes a magic item carries a clue to its properties. The command word to activate a ring might be etched inside the band, or a feathered design might hint that it's a Ring of Feather [[== SRDs ==/Compendium/5.5e/Rules/Hazards/Falling#SRD 5.2.1|Falling]].

Wearing or experimenting with an item can also offer hints about its properties. In the specific case of Potions, a little taste is enough to tell the taster what a potion does. Other items might require more experimentation. For example, if your character puts on a Ring of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming#SRD 5.2.1|Swimming]], the GM might say, "Your movement feels strangely fluid." Perhaps you then dive into a river to see what happens. The GM would then say you swim unexpectedly well.

#### Attunement

Some magic items require a creature to form a bond—called [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]]—with them before the creature can use an item's magical properties. Without becoming attuned to an item that requires [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]], you gain only its nonmagical benefits unless its description states otherwise. For example, a magic [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]] that requires [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]] provides the benefits of a normal [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]] if you aren't attuned to it, but none of its magical properties.

#### Attune during a Short Rest

Attuning to an item requires you to spend a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest#SRD 5.2.1|Short Rest]] focused on only that item while being in physical contact with it (this can't be the same [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest#SRD 5.2.1|Short Rest]] used to learn the item's properties). This focus can take the form of weapon practice (for a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Weapon#SRD 5.2.1|Weapon]]), meditation (for a Wand), or some other appropriate activity. If the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest#SRD 5.2.1|Short Rest]] is interrupted, the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]] attempt fails. Otherwise, at the end of the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest#SRD 5.2.1|Short Rest]], you're attuned to the magic item and can access its full magical capabilities.

#### No More Than Three Items

You can be attuned to no more than three magic items at a time. Any attempt to attune to a fourth item fails; you must end your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]] to an item first. Additionally, you can't attune to more than one copy of an item. For example, you can't attune to more than one Ring of Protection  at a time.

#### Ending Attunement

Your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]] to an item ends if you no longer satisfy the prerequisites for [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]], if the item has been more than 100 feet away for at least 24 hours, if you die, or if another creature attunes to the item. You can also voluntarily end [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attunement#SRD 5.2.1|Attunement]] by spending another [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest#SRD 5.2.1|Short Rest]] focused on the item unless the item is cursed.

#### Wearing and Wielding Items

Using a magic item's properties might mean wearing or wielding it. A magic item meant to be worn must be donned in the intended fashion: boots go on feet, gloves on hands, hats and helmets on a head, and rings on a finger. [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] armor must be donned, a [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield#SRD 5.2.1|Shield]] strapped to the arm, a cloak fastened about the shoulders. A weapon must be held.

In most cases, a magic item that's meant to be worn can fit a creature regardless of size or build.

[[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic#SRD 5.2.1|Magic]] garments are made to be easily adjustable, or they magically adjust themselves to the wearer.

#### Multiple Items of the Same Kind

You can't wear more than one of certain magic items. You can't normally wear more than one pair of footwear, one pair of gloves or gauntlets, one pair of bracers, one suit of armor, one item of headwear, or one cloak. The GM might make exceptions.

#### Paired Items

Items that come in pairs—such as boots, bracers, gauntlets, and gloves—impart their benefits only if both items of the pair are worn. For example, a character wearing a Boot of Striding and Springing on one foot and a Boot of Elvenkind on the other foot gains no benefit from either.

### Crafting Nonmagical Items

To craft a nonmagical item, you need tools, raw materials, and time, each of which is detailed below. If you meet the requirements, you make the item, and you can use it or sell it at its normal price.

#### Tools

The "Tools" section of "Equipment" lists which tools are required to make certain items. The GM assigns required tools for items not listed there.

You must use the required tool to make an item and have proficiency with that tool. Anyone who helps you must also have proficiency with it.

#### Raw Materials

To make an item, you need raw materials worth half its purchase cost (round down). For example, you need 750 GP of raw materials to make Plate

Armor, which sells for 1,500 GP. The GM determines whether appropriate raw materials are available.

#### Time

To determine how many days (working 8 hours a day) it takes to make an item, divide its purchase cost in GP by 10 (round a fraction up to a day). For example, you need 5 days to make a [[== SRDs ==/Compendium/5.5e/Rules/Properties/Heavy#SRD 5.2.1|Heavy]] Crossbow, which sells for 50 GP.

If an item requires multiple days, the days needn't be consecutive.

Characters can combine their efforts to shorten the crafting time. Divide the time needed to create an item by the number of characters working on it.

Normally, only one other character can assist you, but the GM might allow more assistants.

### Brewing Potions of Healing

A character who has proficiency with the Herbalism

Kit can create a Potion of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Healing#SRD 5.2.1|Healing]] . Doing so requires using that kit and 25 GP of raw material over the course of 1 day (8 hours of work).

### Scribing Spell Scrolls

A spellcaster can transfer a spell to a scroll and create a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scroll, using the rules below.

#### Time and Cost

Scribing a scroll takes an amount of time and money based on the level of the spell, as shown in the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]]

Scroll Costs table. For each day of inscription, you must work for 8 hours. If a scroll requires multiple days, those days needn't be consecutive.

#### Prerequisites for the Scribe

To scribe a scroll, you must have proficiency in the Arcana skill or with Calligrapher's Supplies and have the spell prepared on each day of the inscription. You must also have at hand any Material components required by the spell; if the spell consumes its Material components, they are consumed only when you complete the scroll. The scroll's spell uses your spell save DC and spell attack bonus.

#### Cantrips

If the scribed spell is a cantrip, the version on the scroll works as if the caster were your level.

[[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Scroll Costs [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Spell#SRD 5.2.1|Spell]] Level  Time  Cost [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Cantrip#SRD 5.2.1|Cantrip]] 1 day 15 GP 1 1 day 25 GP 2 3 days 100 GP 3 5 days 150 GP 4 10 days 1,000 GP 5 25 days 1,500 GP 6 40 days 10,000 GP 7 50 days 12,500 GP 8 60 days 15,000 GP 9 120 days 50,000 GP castinG in arMor You must have training with any armor you are wearing to cast spells while wearing it. You are otherwise too hampered by the armor for spellcasting.

## Equipment Table Entries

- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Club#SRD 5.2.1|Club]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Dagger#SRD 5.2.1|Dagger]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Greatclub#SRD 5.2.1|Greatclub]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Handaxe#SRD 5.2.1|Handaxe]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Javelin#SRD 5.2.1|Javelin]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Light Hammer#SRD 5.2.1|Light Hammer]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Mace#SRD 5.2.1|Mace]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Quarterstaff#SRD 5.2.1|Quarterstaff]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Sickle#SRD 5.2.1|Sickle]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Melee/Spear#SRD 5.2.1|Spear]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Ranged/Dart#SRD 5.2.1|Dart]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Ranged/Light Crossbow#SRD 5.2.1|Light Crossbow]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Ranged/Shortbow#SRD 5.2.1|Shortbow]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Simple Ranged/Sling#SRD 5.2.1|Sling]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Battleaxe#SRD 5.2.1|Battleaxe]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Flail#SRD 5.2.1|Flail]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Glaive#SRD 5.2.1|Glaive]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Greataxe#SRD 5.2.1|Greataxe]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Greatsword#SRD 5.2.1|Greatsword]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Halberd#SRD 5.2.1|Halberd]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Lance#SRD 5.2.1|Lance]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Longsword#SRD 5.2.1|Longsword]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Maul#SRD 5.2.1|Maul]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Morningstar#SRD 5.2.1|Morningstar]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Pike#SRD 5.2.1|Pike]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Rapier#SRD 5.2.1|Rapier]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Scimitar#SRD 5.2.1|Scimitar]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Shortsword#SRD 5.2.1|Shortsword]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Trident#SRD 5.2.1|Trident]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Warhammer#SRD 5.2.1|Warhammer]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/War Pick#SRD 5.2.1|War Pick]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Melee/Whip#SRD 5.2.1|Whip]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Ranged/Blowgun#SRD 5.2.1|Blowgun]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Ranged/Hand Crossbow#SRD 5.2.1|Hand Crossbow]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Ranged/Heavy Crossbow#SRD 5.2.1|Heavy Crossbow]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Ranged/Longbow#SRD 5.2.1|Longbow]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Ranged/Musket#SRD 5.2.1|Musket]]
- [[== SRDs ==/Compendium/5.5e/Items/Weapons/Martial Ranged/Pistol#SRD 5.2.1|Pistol]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Light/Padded Armor#SRD 5.2.1|Padded Armor]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Light/Leather Armor#SRD 5.2.1|Leather Armor]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Light/Studded Leather Armor#SRD 5.2.1|Studded Leather Armor]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Medium/Hide Armor#SRD 5.2.1|Hide Armor]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Medium/Chain Shirt#SRD 5.2.1|Chain Shirt]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Medium/Scale Mail#SRD 5.2.1|Scale Mail]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Medium/Breastplate#SRD 5.2.1|Breastplate]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Medium/Half Plate Armor#SRD 5.2.1|Half Plate Armor]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Heavy/Ring Mail#SRD 5.2.1|Ring Mail]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Heavy/Chain Mail#SRD 5.2.1|Chain Mail]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Heavy/Splint Armor#SRD 5.2.1|Splint Armor]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Heavy/Plate Armor#SRD 5.2.1|Plate Armor]]
- [[== SRDs ==/Compendium/5.5e/Items/Armor/Shield#SRD 5.2.1|Shield]]

## Tables and Boxed Reference Material

These extracts preserve the PDF’s table layout alongside the text above.

### Page 89 — srd-p089-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p089-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=89|Open source page 89]]

### Page 91 — srd-p091-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p091-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=91|Open source page 91]]

### Page 92 — srd-p092-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p092-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=92|Open source page 92]]

### Page 93 — srd-p093-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p093-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=93|Open source page 93]]

### Page 93 — srd-p093-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p093-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=93|Open source page 93]]

### Page 93 — srd-p093-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p093-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=93|Open source page 93]]

### Page 93 — srd-p093-table-4.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p093-table-4.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=93|Open source page 93]]

### Page 93 — srd-p093-table-5.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p093-table-5.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=93|Open source page 93]]

### Page 93 — srd-p093-table-6.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p093-table-6.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=93|Open source page 93]]

### Page 93 — srd-p093-table-7.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p093-table-7.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=93|Open source page 93]]

### Page 94 — srd-p094-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p094-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=94|Open source page 94]]

### Page 94 — srd-p094-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p094-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=94|Open source page 94]]

### Page 94 — srd-p094-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p094-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=94|Open source page 94]]

### Page 94 — srd-p094-table-4.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p094-table-4.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=94|Open source page 94]]

### Page 94 — srd-p094-table-5.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p094-table-5.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=94|Open source page 94]]

### Page 94 — srd-p094-table-6.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p094-table-6.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=94|Open source page 94]]

### Page 95 — srd-p095-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p095-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=95|Open source page 95]]

### Page 96 — srd-p096-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p096-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=96|Open source page 96]]

### Page 96 — srd-p096-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p096-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=96|Open source page 96]]

### Page 97 — srd-p097-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p097-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=97|Open source page 97]]

### Page 97 — srd-p097-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p097-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=97|Open source page 97]]

### Page 100 — srd-p100-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p100-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=100|Open source page 100]]

### Page 100 — srd-p100-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p100-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=100|Open source page 100]]

### Page 101 — srd-p101-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p101-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=101|Open source page 101]]

### Page 101 — srd-p101-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p101-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=101|Open source page 101]]

### Page 102 — srd-p102-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p102-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=102|Open source page 102]]

### Page 102 — srd-p102-table-2.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p102-table-2.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=102|Open source page 102]]

### Page 102 — srd-p102-table-3.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p102-table-3.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=102|Open source page 102]]

### Page 103 — srd-p103-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p103-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=103|Open source page 103]]

### Page 104 — srd-p104-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p104-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=104|Open source page 104]]
