---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: a5fd70e4-6535-5b88-a8d6-6dbf55d379e6
entity_type: character-option
source_ids: ["phb-2024"]
---

# Sneak Attack

![[== SRDs ==/Attachments/Artwork/phb-p131-rogue.png|320]]

You know how to strike subtly and exploit a foe’s distraction. Once per turn, you can deal an extra 1d6 damage to one creature you hit with an attack roll if you have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on the roll and the attack uses a [[== SRDs ==/Compendium/5.5e/Rules/Properties/Finesse|Finesse]] or a Ranged weapon. The extra damage’s type is the same as the weapon’s type.

You don’t need Advantage on the attack roll if at least one of your allies is within 5 feet of the target, the ally doesn’t have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition, and you don’t have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Disadvantage|Disadvantage]] on the attack roll.

The extra damage increases as you gain Rogue levels, as shown in the Sneak Attack column of the Rogue Features table.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=132|Player’s Handbook (2024), PDF page 132]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
