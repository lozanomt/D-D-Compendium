---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Owl
> 
> *Large Celestial, Neutral*
> 
> ![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 19 (3d10 + 3)  
> **Speed** 5 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 15 | +2 | +2 | **Con** | 12 | +1 | +1 |
> | **Int** | 10 | +0 | +0 | **Wis** | 14 | +2 | +4 | **Cha** | 10 | +0 | +0 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]] +6, [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]] +6  
> **Resistances** Necrotic, Radiant  
> **Senses** [[Darkvision]] 120 ft.; [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 16  
> **Languages** Celestial; understands Common, Elvish, and Sylvan but can't speak them  
> **CR** 1/4 (XP 50; PB +2)  
> 
> ### Traits
> 
> ***Flyby.*** The owl doesn't provoke an Opportunity Attack when it flies out of an enemy's reach.
> 
> ### Actions
> 
> ***Talons.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 7 (1d10 + 2) Slashing damage.
> 
> ***Spellcasting.*** The owl casts one of the following spells, requiring no spell components and using Wisdom as the spellcasting ability:
> 
> - **At Will:** *Detect Evil and Good*, *Detect Magic*
> - **1/Day:** *Clairvoyance*
