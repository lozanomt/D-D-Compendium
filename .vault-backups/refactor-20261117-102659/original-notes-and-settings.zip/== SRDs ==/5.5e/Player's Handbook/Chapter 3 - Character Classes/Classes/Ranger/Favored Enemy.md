---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Favored Enemy

![[phb-p121-ranger.png|320]]

You always have the *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Hunter's Mark|Hunter's Mark]]* spell prepared. You can cast it twice without expending a spell slot, and you regain all expended uses of this ability when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

The number of times you can cast the spell without a spell slot increases when you reach certain Ranger levels.

***Relentless Hunter.*** At Ranger level 13, taking damage can't break your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]] on *Hunter's Mark*.

***Precise Hunter.*** At Ranger level 17, you have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on attack rolls against the creature currently marked by your *Hunter's Mark*.

***Foe Slayer.*** At Ranger level 20, the damage die of your *Hunter's Mark* is a d10 rather than a d6

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=122|Player’s Handbook (2024), PDF page 122]]
