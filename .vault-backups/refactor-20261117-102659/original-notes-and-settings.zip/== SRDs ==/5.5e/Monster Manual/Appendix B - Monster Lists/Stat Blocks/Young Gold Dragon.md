---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Young Gold Dragon
> 
> *Large Dragon (Metallic), Lawful Good*
> 
> ![[mm-p146-gold-dragon-wyrmling.png|320]]
> 
> 
> **AC** 18 &emsp; **Initiative** +6 (16)  
> **HP** 178 (17d10 + 85)  
> **Speed** 40 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 80 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 23 | +6 | +6 | **Dex** | 14 | +2 | +6 | **Con** | 21 | +5 | +5 |
> | **Int** | 16 | +3 | +3 | **Wis** | 13 | +1 | +5 | **Cha** | 20 | +5 | +5 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Insight|Insight]] +5, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +9, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Persuasion|Persuasion]] +9, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +6  
> **Immunities** Fire  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight|Blindsight]] 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 19  
> **Languages** Common, Draconic  
> **CR** 10 (XP 5,900; PB +4)  
> 
> ### Traits
> 
> ***Amphibious.*** The dragon can breathe air and water.
> 
> ### Actions
> 
> ***Multiattack.*** The dragon makes three Rend attacks. It can replace one attack with a use of Weakening Breath.
> 
> ***Rend.*** *Melee Attack Roll:* +10, reach 10 ft. *Hit:* 17 (2d10 + 6) Slashing damage.
> 
> ***Fire Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 17, each creature in a 30-foot Cone. *Failure:* 55 (10d10) Fire damage. *Success:* Half damage.
> 
> ***Weakening Breath.*** *Strength Saving Throw:* DC 17, each creature that isn't currently affected by this breath in a 30-foot Cone. *Failure:* The target has Disadvantage on Strength-based D20 Tests and subtracts 3 (1d6) from its damage rolls. It repeats the save at the end of each of its turns, ending the effect on itself on a success. After 1 minute, it succeeds automatically.
