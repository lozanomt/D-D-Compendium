---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 00a0fc45-f2fc-5e2c-a731-9bd0f169b525
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Guard Captain
> 
> *Medium or Small Humanoid, Neutral*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p164-guard-captain.png|320]]
> 
> 
> **AC** 18 &emsp; **Initiative** +4 (14)  
> **HP** 75 (10d8 + 30)  
> **Speed** 30 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 14 | +2 | +2 | **Con** | 16 | +3 | +3 |
> | **Int** | 12 | +1 | +1 | **Wis** | 14 | +2 | +2 | **Cha** | 13 | +1 | +1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Athletics|Athletics]] +6, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +4  
> **Gear** Breastplate, Javelins (6), Longsword, Shield  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Common  
> **CR** 4 (XP 1,100; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The guard makes two attacks, using Javelin or Longsword in any combination.
> 
> ***Javelin.*** *Melee or Ranged Attack Roll:* +6, reach 5 ft. or range 30/120 ft. *Hit:* 14 (3d6 + 4) Piercing damage.
> 
> ***Longsword.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 15 (2d10 + 4) Slashing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
