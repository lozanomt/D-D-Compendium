---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Giant Crocodile
> 
> *Huge Beast, Unaligned*
> 
> ![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]
> 
> 
> **AC** 14 &emsp; **Initiative** -1 (9)  
> **HP** 85 (9d12 + 27)  
> **Speed** 30 ft., [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] 50 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 21 | +5 | +5 | **Dex** | 9 | -1 | -1 | **Con** | 17 | +3 | +3 |
> | **Int** | 2 | -4 | -4 | **Wis** | 10 | +0 | +0 | **Cha** | 7 | -2 | -2 |
> 
> **Skills** [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth]] +5  
> **Senses** [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception]] 10  
> **Languages** None  
> **CR** 5 (XP 1,800; PB +3)  
> 
> ### Traits
> 
> ***Hold Breath.*** The crocodile can hold its breath for 1 hour.
> 
> ### Actions
> 
> ***Multiattack.*** The crocodile makes one Bite attack and one Tail attack.
> 
> ***Bite.*** *Melee Attack Roll:* +8, reach 5 ft. *Hit:* 21 (3d10 + 5) Piercing damage. If the target is a Large or smaller creature, it has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled]] condition (escape DC 15). While Grappled, the target has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Restrained]] condition and can't be targeted by the crocodile's Tail.
> 
> ***Tail.*** *Melee Attack Roll:* +8, reach 10 ft. *Hit:* 18 (3d8 + 5) Bludgeoning damage. If the target is a Large or smaller creature, it has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone]] condition.
