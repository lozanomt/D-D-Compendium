---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Feather Token [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Feather Token/Feather Token|(Varies)]]
*Wondrous Item, Varies*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p293-feather-token.png|320]]


**Attunement:** No

This object looks like a feather. Different types of feather tokens exist, each with a different single-use effect. The DM chooses the kind of token or determines it randomly by rolling on the Quaal’s Feather Tokens table. The type of token determines its rarity.
###### Feather Tokens
| 1d100   | Token                          | Rarity   |
| ------- | ------------------------------ | -------- |
| 01 - 20 | [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Feather Token/Anchor Token|Anchor]]       | Uncommon |
| 21 - 35 | [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Feather Token/Bird Token|Bird]]           | Rare     |
| 36 - 50 | [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Feather Token/Fan Token|Fan]]             | Uncommon |
| 51 - 65 | [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Feather Token/Swan Boat Token|Swan boat]] | Rare     |
| 66 - 90 | [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Feather Token/Tree Token|Tree]]           | Uncommon |
| 91 - 00 | [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Feather Token/Whip Token|Whip]]           | Rare     |
