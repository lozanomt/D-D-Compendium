---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Saber-Toothed Tiger
> 
> *Large Beast, Unaligned*
> 
> ![[Placeholder.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +3 (13)  
> **HP** 52 (7d10 + 14)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +6 | **Dex** | 17 | +3 | +5 | **Con** | 15 | +2 | +2 |
> | **Int** | 3 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +7  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** None  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Running Leap.*** With a 10-foot running start, the tiger can Long Jump up to 25 feet.
> 
> ### Actions
> 
> ***Multiattack.*** The tiger makes two Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +6, reach 5 ft. *Hit:* 11 (2d6 + 4) Slashing damage.
> 
> ### Bonus Actions
> 
> ***Nimble Escape.*** The tiger takes the Disengage or Hide action.
