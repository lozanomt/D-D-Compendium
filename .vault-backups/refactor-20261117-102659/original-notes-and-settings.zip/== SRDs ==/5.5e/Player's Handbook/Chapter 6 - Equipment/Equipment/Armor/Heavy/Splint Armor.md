---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Splint Armor [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Heavy/Splint Armor|(200 GP)]]
*Heavy Armor (10 Minutes to Don and 5 Minutes to Doff)*

![[== SRDs ==/Attachments/Artwork/phb-p221-splint-armor.png|320]]


**Stealth:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] **Weight:** 60 lb.
**Armor Class (AC):** 17
**Strength:** Str 15
