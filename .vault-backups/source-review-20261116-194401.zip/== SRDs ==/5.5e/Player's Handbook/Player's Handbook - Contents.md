# Player's Handbook — Contents

Existing vault entries grouped by the source’s chapters and appendices. Empty sections are ready for future additions; no missing book text was imported.

- [[D&D 5e 2024 Rules/Player's Handbook/Introduction - Welcome to Adventure/Introduction - Welcome to Adventure|Introduction - Welcome to Adventure]] — 0 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Chapter 1 - Playing the Game|Chapter 1 - Playing the Game]] — 20 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Chapter 2 - Creating a Character/Chapter 2 - Creating a Character|Chapter 2 - Creating a Character]] — 1 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Chapter 3 - Character Classes]] — 229 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Chapter 4 - Character Origins]] — 13 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Chapter 5 - Feats/Chapter 5 - Feats|Chapter 5 - Feats]] — 19 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Chapter 6 - Equipment|Chapter 6 - Equipment]] — 205 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Chapter 7 - Spells|Chapter 7 - Spells]] — 395 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Appendix A - The Multiverse/Appendix A - The Multiverse|Appendix A - The Multiverse]] — 0 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B - Creature Stat Blocks]] — 1 entries
- [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Appendix C - Rules Glossary|Appendix C - Rules Glossary]] — 94 entries

See [[D&D 5e 2024 Rules/Audits/Source-Reorganization-2026-11-16|source assignment and overlap report]] before removing a source.
