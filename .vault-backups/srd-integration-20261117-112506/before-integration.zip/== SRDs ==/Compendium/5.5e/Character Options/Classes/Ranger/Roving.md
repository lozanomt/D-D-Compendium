---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 0231fbdb-2bb7-5570-a3ac-a50dfe1faf60
entity_type: character-option
source_ids: ["phb-2024"]
---

# Roving

![[== SRDs ==/Attachments/Artwork/phb-p121-ranger.png|320]]

Your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Speed|Speed]] increases by 10 feet while you aren’t wearing Heavy armor. You also have a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Climbing|Climb]] Speed and a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] Speed equal to your Speed.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=122|Player’s Handbook (2024), PDF page 122]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
