---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 3a8d80ff-4d0e-5f52-a12f-76f3f1667905
entity_type: character-option
source_ids: ["phb-2024"]
---

# Acolyte

![[== SRDs ==/Attachments/Artwork/phb-p181-acolyte.png|320]]

**Ability Scores:** Intelligence, Wisdom, Charisma
**Feat:** [[== SRDs ==/Compendium/5.5e/Character Options/Feats/01) Origin Feats/Magic Initiate|Magic Initiate]] (Cleric)
**Skill Proficiencies** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Insight|Insight]] and [[== SRDs ==/Compendium/5.5e/Rules/Skills/Religion|Religion]]
**Tool Proficiency:** [[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Calligrapher's Supplies|Calligrapher's Supplies]]
**Equipment:** *Choose A or B:* (A) [[== SRDs ==/Compendium/5.5e/Items/Tools/Artisan's Tools/Calligrapher's Supplies|Calligrapher's Supplies]], [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Book|Book]] (prayers), [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Holy Symbol/Holy Symbol|Holy Symbol]], [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Parchment|Parchment]] (10 sheets), [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Robe|Robe]], 8 GP; or (B) 50 GP

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 4 - Character Origins/Chapter 4 - Character Origins|Player's Handbook — Chapter 4 - Character Origins]]
