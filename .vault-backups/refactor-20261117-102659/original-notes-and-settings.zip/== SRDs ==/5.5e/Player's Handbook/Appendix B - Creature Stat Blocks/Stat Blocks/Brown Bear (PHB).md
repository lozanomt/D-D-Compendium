---
tags: [creature, phb]
cssclasses: [dnd-book, dnd-mm]
source_book: "Player's Handbook (2024)"
source_page: 347
source_pdf_page: 350
review_status: checked-against-page-image
reviewed: 2026-11-17
---

> [!statblock]
> ## Brown Bear
>
> *Large Beast, Unaligned*
>
> **AC** 11 &emsp; **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]]** +1 (11)  
> **HP** 22 (3d10 + 6)  
> **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]]** 40 ft., Climb 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 12 | +1 | +1 | **Con** | 15 | +2 | +2 |
> | **Int** | 2 | -4 | -4 | **Wis** | 13 | +1 | +1 | **Cha** | 7 | -2 | -2 |
>
> **Skills** Perception +3  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** None  
> **CR** 1 (XP 200; PB +2)  
>
> ### Actions
>
> ***Multiattack.*** The bear makes one Bite attack and one Claw attack.
>
> ***Bite.*** *Melee [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] Roll:* +5, reach 5 ft. *Hit:* 7 (1d8 + 3) Piercing damage.
>
> ***Claw.*** *Melee [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] Roll:* +5, reach 5 ft. *Hit:* 5 (1d4 + 3) Slashing damage. If the target is a Huge or smaller creature, it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.

Source: [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=350|Player’s Handbook (2024), p. 347]].

[[== SRDs ==/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/5.5e/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Brown Bear|Monster Manual version]]
