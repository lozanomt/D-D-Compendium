---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Ranger

![[phb-p121-ranger.png|320]]


###### Core Ranger Traits
|                                |                                                                                                                                                                                                 |
| ------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Primary Ability**            | Dexterity and Wisdom                                                                                                                                                                            |
| **Hit Point Die**              | D10 per Ranger level                                                                                                                                                                            |
| **Saving Throw Proficiencies** | Strength and Dexterity                                                                                                                                                                          |
| **Skill Proficiencies**        | *Choose 3:* [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Animal Handling\|Animal Handling]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Athletics\|Athletics]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Insight\|Insight]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Investigation\|Investigation]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Nature\|Nature]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception\|Perception]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth\|Stealth]], or [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Survival\|Survival]]                                                        |
| **Weapon Proficiencies**       | Simple and Martial weapons                                                                                                                                                                      |
| **Armor Training**             | Light and Medium armor and Shields                                                                                                                                                              |
| **Starting Equipment**         | *Choose A or B:* (A) [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Armor/Light/Studded Leather Armor\|Studded Leather Armor]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Scimitar\|Scimitar]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Shortsword\|Shortsword]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Ranged/Longbow\|Longbow]], 20 [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Ammunition/Arrows\|Arrows]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Quiver\|Quiver]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Druidic Focus/Druidic Focus\|Druidic Focus]] ([[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Druidic Focus/Sprig of Mistletoe\|Sprig of Mistletoe]]), [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Gear Packs/Explorer's Pack\|Explorer's Pack]], and 7 GP; or (B) 150 GP |
### Becoming a Ranger...
#### As a Level 1 Character
- Gain all the traits Core Ranger Traits table
- Gain the Ranger's level 1 features, which are listed in the Ranger Features table
#### As a Multiclass Character
- Gain the following traits from the Core Ranger Traits table: Hit Point Die, proficiency with Martial weapons, proficiency in one skill of your choice from the Ranger skill list, and training with Light and Medium armor and Shields
- Gain the Ranger's level 1 features, which are listed in the Ranger Features table. See the [[== SRDs ==/5.5e/Player's Handbook/Chapter 2 - Creating a Character/Rules/Miscellaneous/Multiclassing|Multiclassing]] rules to determine your available spell slots.
## Ranger Class Features
As a Ranger, you gain the following class features when you reach the specified Ranger levels. These features are listed in the Ranger Features table.
###### Ranger Features
| Level | Proficiency<br>Bonus | Class Features                                          | Favored Enemy | Prepared<br>Spells |  1  |  2  |  3  |  4  |  5  |
| :---: | :------------------: | ------------------------------------------------------- | :-----------: | :----------------: | :-: | :-: | :-: | :-: | :-: |
|   1   |          +2          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Spellcasting\|Spellcasting]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Favored Enemy\|Favored Enemy]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Weapon Mastery\|Weapon Mastery]] |       2       |         2          |  2  |  -  |  -  |  -  |  -  |
|   2   |          +2          | Deft Explorer, Fighting Style                           |       2       |         3          |  2  |  -  |  -  |  -  |  -  |
|   3   |          +2          | Ranger Subclass                                         |       2       |         4          |  3  |  -  |  -  |  -  |  -  |
|   4   |          +2          | Ability Score Improvement                               |       2       |         5          |  3  |  -  |  -  |  -  |  -  |
|   5   |          +3          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Extra Attack\|Extra Attack]]                                        |       3       |         6          |  4  |  2  |  -  |  -  |  -  |
|   6   |          +3          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Roving\|Roving]]                                              |       3       |         6          |  4  |  2  |  -  |  -  |  -  |
|   7   |          +3          | Subclass feature                                        |       3       |         7          |  4  |  3  |  -  |  -  |  -  |
|   8   |          +3          | Ability Score Improvement                               |       3       |         7          |  4  |  3  |  -  |  -  |  -  |
|   9   |          +4          | Expertise                                               |       4       |         9          |  4  |  3  |  2  |  -  |  -  |
|  10   |          +4          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Tireless\|Tireless]]                                            |       4       |         9          |  4  |  3  |  2  |  -  |  -  |
|  11   |          +4          | Subclass feature                                        |       4       |         10         |  4  |  3  |  3  |  -  |  -  |
|  12   |          +4          | Ability Score Improvement                               |       4       |         10         |  4  |  3  |  3  |  -  |  -  |
|  13   |          +5          | Relentless Hunter                                       |       5       |         11         |  4  |  3  |  3  |  1  |  -  |
|  14   |          +5          | [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Nature's Veil\|Nature's Veil]]                                       |       5       |         11         |  4  |  3  |  3  |  1  |  -  |
|  15   |          +5          | Subclass feature                                        |       5       |         12         |  4  |  3  |  3  |  2  |  -  |
|  16   |          +5          | Ability Score Improvement                               |       5       |         12         |  4  |  3  |  3  |  2  |  -  |
|  17   |          +6          | Precise Hunter                                          |       6       |         14         |  4  |  3  |  3  |  3  |  1  |
|  18   |          +6          | Feral Senses                                            |       6       |         14         |  4  |  3  |  3  |  3  |  1  |
|  19   |          +6          | Epic Boon                                               |       6       |         15         |  4  |  3  |  3  |  3  |  2  |
|  20   |          +6          | Foe Slayer                                              |       6       |         15         |  4  |  3  |  3  |  3  |  2  |
#### Level 1: Spellcasting
You have learned to channel the magical essence of nature to cast spells. See [[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Spells|Spells]] for the rules on spellcasting.. The information below details how you use those rules with Ramger spells, which appear in the Ranger spell list later in the class’s description.

***Spell Slots.*** The Ranger Features table shows how many spell slots you have to cast your level 1+ spells. You regain all expended slots when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

***Prepared Spells of Level 1+.*** You prepare the list of level 1+ spells that are available for you to cast with this feature. To start, choose two level 1 Ranger spells.

The number of spells on your list increases as you gain Ranger levels, as shown in the Prepared Spells column of the Ranger Features table. Whenever that number increases, choose additional Ranger spells until the number of spells on your list matches the number in the Ranger Features table. The chosen spells must be of a level for which you have spell slots. For example, if you’re a level 5 Ranger, your list of prepared spells can include six Ranger spells of level 1 or 2 in any combination.

If another Ranger feature gives you spells that you always have prepared, those spells don’t count against the number of spells you can prepare with this feature, but those spells otherwise count as Ranger spells for you.

***Changing Your Prepared Spells.*** Whenever you finish a Long Rest, you can replace one spell on your list with another Ranger spell for which you have spell slots.

***Spellcasting Ability.*** Wisdom is your spellcasting ability for your Ranger spells.

***Spellcasting Focus.*** You can use a [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Druidic Focus/Druidic Focus|Druidic Focus]] as a Spellcasting Focus for your Ranger spells.
#### Level 1: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Favored Enemy|Favored Enemy]]
You always have the *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Hunter's Mark|Hunter's Mark]]* spell prepared. You can cast it twice without expending a spell slot, and you regain all expended uses of this ability when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

The number of times you can cast the spell without a spell slot increases when you reach certain Ranger levels.
#### Level 1: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Weapon Mastery|Weapon Mastery]]
Your training with weapons allows you to use the mastery properties of two kinds of weapons of your choice with which you have proficiency, such as [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Ranged/Longbow|Longbows]] and [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Shortsword|Shortswords]]

Whenever you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]], you can change the kinds of weapons you chose. For example, you could switch to using the mastery properties of [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Scimitar|Scimitars]] and [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Longsword|Longswords]].
#### Level 2: Deft Explorer
Thanks to your travels, you gain the following benefits.

***Expertise.*** Choose one of your skill proficiencies with which you lack Expertise. You gain [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Expertise|Expertise]] in that skill.

***Languages.*** You know two languages of your choice.
#### Level 2: Fighting Style
You gain a Fighting Style feat of your choice.

Alternatively, choose **Druidic Warrior**: learn two Druid cantrips of your choice. They count as Ranger spells for you and use Wisdom. Whenever you gain a Ranger level, you can replace one of these cantrips with another Druid cantrip.
#### Level 3: Ranger Subclass
You gain a Ranger subclass of your choice. A subclass is a specialization that grants you features at certain Ranger levels. For the rest of your career, you gain each of your subclass’s features that are of your Ranger level or lower. The following subclasses are available for you to choose from:
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Beast Master/Beast Master|Beast Master]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Fey Wanderer/Fey Wanderer|Fey Wanderer]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Gloom Stalker/Gloom Stalker|Gloom Stalker]]
- [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Hunter/Hunter|Hunter]]
#### Level 4: Ability Score Improvement
You gain the [[== SRDs ==/5.5e/Player's Handbook/Chapter 5 - Feats/Feats/02) General Feats/Ability Score Improvement|Ability Score Improvement]] feat or another feat of your choice for which you qualify. You gain this feature again at Ranger levels 8, 12, and 16.
#### Level 5: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Any Class Features/Extra Attack|Extra Attack]]
You can attack twice instead of once whenever you take the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] action on your turn.
#### Level 6: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Roving|Roving]]
Your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]] increases by 10 feet while you aren’t wearing Heavy armor. You also have a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] Speed and a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] Speed equal to your Speed.
#### Level 9: Expertise
Choose two of your skill proficiencies with which you lack Expertise. You gain [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Expertise|Expertise]] in those skills.
#### Level 10: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Tireless|Tireless]]
Primal forces now help fuel you on your journeys, granting you the following benefits.

***Temporary Hit Points.*** As a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action, you can give yourself a number of [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Temporary Hit Points|Temporary Hit Points]] equal to 1d8 plus your Wisdom modifier (minimum of 1). You can use this action a number of times equal to your Wisdom modifier (minimum of once), and you regain all expended uses when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].

***Decrease Exhaustion.*** Whenever you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Short Rest|Short Rest]], your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]] level, if any, decreases by 1.
#### Level 13: Relentless Hunter
Taking damage can’t break your [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]] on *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Hunter's Mark|Hunter's Mark]]*.
#### Level 14: [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Ranger/Nature's Veil|Nature's Veil]]
You invoke spirits of nature to magically hide yourself. As a Bonus Action, you can give yourself the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Invisible|Invisible]] condition until the end of your next turn.

You can use this feature a number of times equal to your Wisdom modifier (minimum of once), and you regain all expended uses when you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]].
#### Level 17: Precise Hunter
You have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on attack rolls against the creature currently marked by your *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Hunter's Mark|Hunter's Mark]]*.
#### Level 18: Feral Senses
Your connection to the forces of nature grants you [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight|Blindsight]] with a range of 30 feet.
#### Level 19: Epic Boon
You gain an Epic Boon feat or another feat of your choice for which you qualify.
#### Level 20: Foe Slayer
The damage die of your *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Hunter's Mark|Hunter's Mark]]* is a d10 rather than a d6.
### Ranger Spell List

Shared handbook spell choices; spells always prepared through a subclass are listed with that subclass. **C** = Concentration, **R** = Ritual, **M** = specified Material component.

| Level | Spell | School | Special |
| :---: | --- | --- | :---: |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Alarm\|Alarm]]* | Abjuration | R |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Animal Friendship\|Animal Friendship]]* | Enchantment | - |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Cure Wounds\|Cure Wounds]]* | Abjuration | - |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Detect Magic\|Detect Magic]]* | Divination | C, R |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Detect Poison and Disease\|Detect Poison and Disease]]* | Divination | C, R |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Ensnaring Strike\|Ensnaring Strike]]* | Conjuration | C |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Entangle\|Entangle]]* | Conjuration | C |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Fog Cloud\|Fog Cloud]]* | Conjuration | C |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Goodberry\|Goodberry]]* | Conjuration | - |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Hail of Thorns\|Hail of Thorns]]* | Conjuration | - |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Hunter's Mark\|Hunter's Mark]]* | Divination | C |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Jump\|Jump]]* | Transmutation | - |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Longstrider\|Longstrider]]* | Transmutation | - |
| 1 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 1/Speak with Animals\|Speak with Animals]]* | Divination | R |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Aid\|Aid]]* | Abjuration | - |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Animal Messenger\|Animal Messenger]]* | Enchantment | R |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Barkskin\|Barkskin]]* | Transmutation | - |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Beast Sense\|Beast Sense]]* | Divination | C, R |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Cordon of Arrows\|Cordon of Arrows]]* | Transmutation | - |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Darkvision\|Darkvision]]* | Transmutation | - |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Enhance Ability\|Enhance Ability]]* | Transmutation | C |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Find Traps\|Find Traps]]* | Divination | - |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Gust of Wind\|Gust of Wind]]* | Evocation | C |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Lesser Restoration\|Lesser Restoration]]* | Abjuration | - |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Locate Animals or Plants\|Locate Animals or Plants]]* | Divination | R |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Locate Object\|Locate Object]]* | Divination | C |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Magic Weapon\|Magic Weapon]]* | Transmutation | - |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Pass without Trace\|Pass without Trace]]* | Abjuration | C |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Protection from Poison\|Protection from Poison]]* | Abjuration | - |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Silence\|Silence]]* | Illusion | C, R |
| 2 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Spike Growth\|Spike Growth]]* | Transmutation | C |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Conjure Animals\|Conjure Animals]]* | Conjuration | C |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Conjure Barrage\|Conjure Barrage]]* | Conjuration | - |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Daylight\|Daylight]]* | Evocation | - |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Dispel Magic\|Dispel Magic]]* | Abjuration | - |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Elemental Weapon\|Elemental Weapon]]* | Transmutation | C |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Lightning Arrow\|Lightning Arrow]]* | Transmutation | - |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Meld into Stone\|Meld into Stone]]* | Transmutation | R |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Nondetection\|Nondetection]]* | Abjuration | M |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Plant Growth\|Plant Growth]]* | Transmutation | - |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Protection from Energy\|Protection from Energy]]* | Abjuration | C |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Revivify\|Revivify]]* | Necromancy | M |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Speak with Plants\|Speak with Plants]]* | Transmutation | - |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Summon Fey\|Summon Fey]]* | Conjuration | C, M |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Water Breathing\|Water Breathing]]* | Transmutation | R |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Water Walk\|Water Walk]]* | Transmutation | R |
| 3 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 3/Wind Wall\|Wind Wall]]* | Evocation | C |
| 4 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Conjure Woodland Beings\|Conjure Woodland Beings]]* | Conjuration | C |
| 4 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Dominate Beast\|Dominate Beast]]* | Enchantment | C |
| 4 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Freedom of Movement\|Freedom of Movement]]* | Abjuration | - |
| 4 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Locate Creature\|Locate Creature]]* | Divination | C |
| 4 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 4/Stoneskin\|Stoneskin]]* | Transmutation | C, M |
| 5 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Commune with Nature\|Commune with Nature]]* | Divination | R |
| 5 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Conjure Volley\|Conjure Volley]]* | Conjuration | - |
| 5 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Greater Restoration\|Greater Restoration]]* | Abjuration | M |
| 5 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Steel Wind Strike\|Steel Wind Strike]]* | Conjuration | M |
| 5 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/PHB References/Swift Quiver\|Swift Quiver]]* | Transmutation | C, M |
| 5 | *[[== SRDs ==/5.5e/Player's Handbook/Chapter 7 - Spells/Spells/Level 5/Tree Stride\|Tree Stride]]* | Conjuration | C |

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=122|Player’s Handbook (2024), PDF page 122]]
