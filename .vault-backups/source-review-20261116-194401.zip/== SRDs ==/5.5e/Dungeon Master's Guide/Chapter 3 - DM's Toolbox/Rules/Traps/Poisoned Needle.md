---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Poisoned Needle

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


#### Poison Needle
*Nuisance Trap (Levels 1 - 4)*

**Trigger:** A creature opens the trap's lock improperly or fails to disarm the trap
**Duration:** Instantaneous

A poisoned needle is hidden in a lock. When a creature opens the lock with any object other than the proper key, the needle springs out and stabs the creature. The creature makes a DC 11 Constitution saving throw. On a failed save, the creature takes 5 (1d10) Poison damage and has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned]] condition for 1 hour. On a successful save, the creature takes half as much damage only.

***Avoid.*** The trap doesn’t trigger if the lock is opened using a *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Knock]]* spell or similar magic.

***Detect and Disarm.*** As a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Search]] action, a creature can examine the trapped lock and make a DC 15 Wisdom ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception]]) check, detecting the needle on
a successful check. Once the trap is detected, a character can take an action to try to disarm the trap, doing so with a successful DC 15 Dexterity ([[D&D 5e 2024 Rules/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Sleight of Hand]]) check. On a failed check, the creature triggers the trap.

***At Higher Levels.*** You can scale the trap for higher levels by increasing the damage and the save DC, as shown in the following table.

| Levels  | Poison Damage | Save DC |
| :-----: | :-----------: | :-----: |
| 5 - 10  |   11 (2d10)   |   13    |
| 11 - 16 |   22 (4d10)   |   15    |
| 17 - 20 |  55 (10d10)   |   17    |
