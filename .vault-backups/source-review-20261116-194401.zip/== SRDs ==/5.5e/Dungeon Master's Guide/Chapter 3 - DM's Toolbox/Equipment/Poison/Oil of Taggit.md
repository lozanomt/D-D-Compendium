---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Oil of Taggit [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Equipment/Poison/Oil of Taggit|400 GP]]
*[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Rules/Properties/Poison/Contact]] Poison*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


A creature subjected to Oil of Taggit must succeed on a DC 13 Constitution saving throw or have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned]] condition for 24 hours. The creature also has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Unconscious]] condition while Poisoned in this way. It wakes up if it takes damage.
