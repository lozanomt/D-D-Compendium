# Vault Guide

- [[== SRDs ==/Compendium/5.5e/Compendium|Compendium — browse entities]]
- [[== SRDs ==/Sources/Sources|Sources — browse books and chapters]]

Each entity has one permanent note in the Compendium. Distinct source versions share that note under labeled headings. Chapter pages link to or embed the relevant source section.

Items, spells, creatures, rules, lore, and character options are organized by kind. Identical names can represent different entities: Shield the spell and Shield the item remain separate, as do the Druid class and Druid NPC stat block.

Source PDFs and artwork remain with their book. Existing campaign and Homebrew locations are unchanged. Source IDs and entity IDs are included for future maintenance; each book has a source-manifest.json inventory. These inventories do not automate adding or removing content yet.

When adding material manually, search for an existing entity first, add its source reference or distinct version there, and link the book chapter to it. Keep personal annotations outside source-version sections. Do not delete a shared entity merely because a book is removed.
