---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Potions of Healing [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Potions of Healing/Potions of Healing|(Varies)]]
*Potion, Rarity Varies*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p292-potion-of-healing.png|320]]


**Attunement:** No **Weight:** 0.5 lb

As a Bonus Action, you can drink it or administer it to another creature within 5 feet of yourself. The creature that drinks the magical red fluid in this vial regains [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]]. The number of Hit Points depends on the potion's rarity, as shown in the table below.

Whatever the potency, the potion's red liquid glimmers when agitated.

| Potion                             | HP Regained | Rarity    |
| ---------------------------------- | :---------: | --------- |
| *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Potions of Healing/Potion of Healing]]*            |   2d4 + 2   | Common    |
| *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Potions of Healing/Potion of Healing (Greater)]]*  |   4d4 + 4   | Uncommon  |
| *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Potions of Healing/Potion of Healing (Superior)]]* |   8d4 +8    | Rare      |
| *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Potions of Healing/Potion of Healing (Supreme)]]*  |  10d4 + 20  | Very Rare |
