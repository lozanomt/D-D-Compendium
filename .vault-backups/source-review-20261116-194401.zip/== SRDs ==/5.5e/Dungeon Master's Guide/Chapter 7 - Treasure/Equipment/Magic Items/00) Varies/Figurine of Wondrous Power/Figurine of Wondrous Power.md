---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Figurine of Wondrous Power [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Figurine of Wondrous Power/Figurine of Wondrous Power|(Varies)]]
*Wondrous Item, Varies*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

A *Figurine of Wondrous Power* is a statuette small enough to fit in a pocket. If you take a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action to throw the figurine to a point on the ground within 60 feet of yourself, the figurine becomes a living creature specified in the figurine’s description below. If the space where the creature would appear is occupied by other creatures or objects, or if there isn’t enough space for the creature, the figurine doesn’t become a creature.

The creature is Friendly to you and your allies. It understands your languages, obeys your commands, and takes its turn immediately after you on your [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative]] count. If you issue no commands, the creature defends itself but takes no other actions.

The creature exists for a duration specific to each figurine. At the end of the duration, the creature reverts to its figurine form. It reverts to a figurine early if its creature form drops to 0 [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Hit Points]] or if you take a Magic action while touching the creature to make it revert to figurine form. When the creature becomes a figurine again, its property can’t be used again until a certain amount of time has passed, as specified in the figurine’s description.

***Bronze Griffon (Rare).*** This bronze statuette is of a griffon rampant. It can become a [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Griffon]] for up to 6 hours. Once it has been used, it can’t be used again until 5 days have passed.

***Ebony Fly (Rare).*** This ebony statuette, carved in the likeness of a horsefly, can become a [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Stat Blocks/Item Summons/Giant Fly]] for up to 12 hours and can be ridden as a mount. Once it has been used, it can’t be used again until 2 days have passed.

***Golden Lions (Rare).*** These gold statuettes of lions are always created in pairs. You can use one figurine or both simultaneously. Each can become a [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Lion]] for up to 1 hour. Once a lion has been used, it can’t be used again until 7 days have passed.

***Ivory Goats (Rare).*** These ivory statuettes of goats are always created in sets of three. Each goat looks unique and functions differently from the others. Their properties are as follows:

**Goat of Terror.** This figurine can become a [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Giant Goat]] for up to 3 hours. The goat can’t attack, but you can (harmlessly) remove its horns and use them as weapons. One horn becomes a *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Weapon, +1, +2, or +3/Lance, +1|+1 Lance]]*, and the other becomes a *[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Weapon, +1, +2, or +3/Longsword, +2|+2 Longsword]]*. Removing a horn requires a [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic]] action, and the weapons disappear and the horns return when the goat reverts to figurine form. While you ride the goat, any Hostile creature that starts its turn within a 30-foot [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Emanation]] originating from the goat must succeed on a DC 15 Wisdom saving throw or have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Frightened]] condition for 1 minute, until you are no longer riding the goat, or until the goat reverts to figurine form. The Frightened creature repeats the save at the end of each of its turns, ending the effect on itself on a success. Once it succeeds on the save, a creature is immune to this effect for the next 24 hours. Once the figurine has been used, it can’t be used again until 15 days have passed.

**Goat of Traveling.** This figurine can become a Large goat with the same statistics as a [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Riding Horse]]. It has 24 charges, and each hour or portion thereof it spends in goat form costs 1 charge. While it has charges, you can use it as often as you wish. When it runs out of charges, it reverts to a figurine and can’t be used again until 7 days have passed, when it regains all expended charges.

**Goat of Travail.** This figurine can become a Giant Goat for up to 3 hours. Once it has been used, it can’t be used again until 30 days have passed.

***Marble Elephant (Rare).*** This marble statuette resembles a trumpeting elephant. It can become an [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Elephant]] for up to 24 hours. Once it has been used, it can’t be used again until 7 days have passed.

***Obsidian Steed (Very Rare).*** This polished obsidian horse can become a [[D&D 5e 2024 Rules/Monster Manual/Monsters A to Z/Stat Blocks/Nightmare]] for up to 24 hours. The nightmare fights only to defend itself. Once it has been used, it can’t be used again until 5 days have passed.

The figurine has a 10 percent chance each time you use it to ignore your orders, including a command to revert to figurine form. If you mount the nightmare while it is ignoring your orders, you and the nightmare are instantly transported to a random location on the plane of Hades, where the nightmare reverts to figurine form.

***Onyx Dog (Rare).*** This onyx statuette of a dog can become a [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Mastiff]] for up to 6 hours. The mastiff has an Intelligence of 8 and can speak Common. It also has [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight]] with a range of 60 feet. Once it has been used, it can’t be used again until 7 days have passed.

***Serpentine Owl (Rare).*** This serpentine statuette of an owl can become a [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Giant Owl]] for up to 8 hours. The owl can communicate telepathically with you at any range if you and it are on the same plane of existence. Once it has been used, it can’t be used again until 2 days have passed.

***Silver Raven (Uncommon).*** This silver statuette of a raven can become a [[D&D 5e 2024 Rules/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Raven]] for up to 12 hours. Once it has been used, it can’t be used again until 2 days have passed. While in raven form, the figurine grants you the ability to cast *[[D&D 5e 2024 Rules/Player's Handbook/Chapter 7 - Spells/Spells/Level 2/Animal Messenger]]* on it.
