---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Ammunition, +1, +2, or +3 [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Ammunition, +1, +2, or +3/Ammunition, +1, +2, or +3|(Varies)]]
*Weapon (Any Ammunition), Varies*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

You have a bonus to attack rolls and damage rolls made with this piece of magic ammunition. The bonus is determined by the rarity of the ammunition. Once it hits a target, the ammunition is no longer magical.

This ammunition is typically found or sold in quantities of ten or twenty pieces. Ten pieces of this ammunition are equivalent in value to a potion of the same rarity.

| Rarity                                   | Bonus |
| ---------------------------------------- | :---: |
| Uncommon  |  +1   |
| Rare      |  +2   |
| Very Rare |  +3   |
