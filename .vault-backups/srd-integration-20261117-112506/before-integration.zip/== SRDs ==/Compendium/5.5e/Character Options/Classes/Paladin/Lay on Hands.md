---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 723304bb-b142-551c-9790-18bb0001fee2
entity_type: character-option
source_ids: ["phb-2024"]
---

# Lay On Hands

![[== SRDs ==/Attachments/Artwork/phb-p111-paladin.png|320]]

Your blessed touch can heal wounds. You have a pool of healing power that replenishes when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]]. With that pool, you can restore a total number of [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Hit Points|Hit Points]] equal to five times your Paladin level. As a Bonus Action, you can touch a creature (which could be yourself) and draw power from the pool of healing to restore a number of Hit Points to that creature, up to the maximum amount remaining in the pool. You can also expend 5 Hit Points from the pool of healing power to remove the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]] conditions from the creature; those points don’t also restore Hit Points to the creature.

***Restoring Touch.*** At Paladin level 14, when you use Lay on Hands on a creature, you can also remove one or more of the following conditions from the creature: [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Blinded|Blinded]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Deafened|Deafened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], or [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Stunned|Stunned]]. You must expend 5 Hit Points from the healing pool of Lay On Hands for each of these conditions you remove; those points don’t also restore Hit Points to the creature.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=112|Player’s Handbook (2024), PDF page 112]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
