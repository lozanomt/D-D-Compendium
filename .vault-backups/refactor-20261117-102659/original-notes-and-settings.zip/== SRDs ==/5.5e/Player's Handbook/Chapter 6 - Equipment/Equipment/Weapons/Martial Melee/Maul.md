---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Maul [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Weapons/Martial Melee/Maul|(10 GP)]]
*Martial Melee*

![[phb-p220-maul.png|320]]


**Mastery:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Mastery/Topple|Topple]] **Weight:** 10 lb.
**Damage:** 2d6 Bludgeoning
**Properties:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Heavy|Heavy]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Rules/Properties/Two-Handed|Two-Handed]]
