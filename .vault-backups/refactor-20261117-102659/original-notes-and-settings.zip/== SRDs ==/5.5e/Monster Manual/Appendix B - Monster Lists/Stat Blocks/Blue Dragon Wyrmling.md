---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Blue Dragon Wyrmling
> 
> *Medium Dragon (Chromatic), Lawful Evil*
> 
> ![[mm-p050-blue-dragon-wyrmling.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +2 (12)  
> **HP** 65 (10d8 + 20)  
> **Speed** 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Burrowing|Burrow]] 15 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 60 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 10 | +0 | +2 | **Con** | 15 | +2 | +2 |
> | **Int** | 12 | +1 | +1 | **Wis** | 11 | +0 | +2 | **Cha** | 15 | +2 | +2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +4, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +2  
> **Immunities** Lightning  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Blindsight|Blindsight]] 10 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 14  
> **Languages** Draconic  
> **CR** 3 (XP 700; PB +2)  
> 
> ### Actions
> 
> ***Multiattack.*** The dragon makes two Rend attacks.
> 
> ***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 8 (1d10 + 3) Slashing damage plus 3 (1d6) Lightning damage.
> 
> ***Lightning Breath (Recharge 5-6).*** *Dexterity Saving Throw:* DC 12, each creature in a 30-foot-long, 5-footwide Line. *Failure:* 21 (6d6) Lightning damage. *Success:* Half damage.
