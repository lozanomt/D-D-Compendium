---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 4c27221e-f174-597d-86d0-76259651ea32
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Hunter Shark
> 
> *Large Beast, Unaligned*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p365-hunter-shark.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 45 (6d10 + 12)  
> **Speed** 5 ft., [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Swimming|Swim]] 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 14 | +2 | +2 | **Con** | 15 | +2 | +2 |
> | **Int** | 1 | -5 | -5 | **Wis** | 10 | +0 | +0 | **Cha** | 4 | -3 | -3 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +2  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Blindsight|Blindsight]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 12  
> **Languages** None  
> **CR** 2 (XP 450; PB +2)  
> 
> ### Traits
> 
> ***Water Breathing.*** The shark can breathe only underwater.
> 
> ### Actions
> 
> ***Bite.*** *Melee Attack Roll:* +6 (with Advantage if the target doesn't have all its Hit Points), reach 5 ft. *Hit:* 14 (3d6 + 4) Piercing damage.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix A - Animals/Appendix A - Animals|Monster Manual — Appendix A - Animals]]
