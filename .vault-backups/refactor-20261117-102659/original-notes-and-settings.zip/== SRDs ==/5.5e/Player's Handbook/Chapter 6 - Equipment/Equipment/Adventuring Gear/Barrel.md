---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Barrel [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Barrel|(2 GP)]] 

![[Placeholder.png|320]]

A Barrel holds up to 40 gallons of liquid or up to 4 cubic feet of dry goods.

**Weight:** 70 lb.
