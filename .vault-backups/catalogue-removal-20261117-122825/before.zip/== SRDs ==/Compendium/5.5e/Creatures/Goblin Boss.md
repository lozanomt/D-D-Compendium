---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 76045a63-82cc-5ad8-8355-5ab77d3fb052
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [290]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Goblin Boss

## Monster Manual

> [!statblock]
> ### Goblin Boss
>
> *Small Fey (Goblinoid), Chaotic Neutral*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p145-goblin-boss.png|320]]
>
> **AC:** 17  
> **HP:** 21 (6d6)  
> **Speed:** 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 10 | +0 | +0 | **Dex** | 15 | +2 | +2 | **Con** | 10 | +0 | +0 |
> | **Int** | 10 | +0 | +0 | **Wis** | 8 | -1 | -1 | **Cha** | 10 | +0 | +0 |
>
> **Skills:**  
> **Stealth:** +6  
> **Gear:** Chain Shirt, Scimitar, Shield, Shortbow  
> **Senses:** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages:** Common, Goblin  
> **CR:** 1 (XP 200; PB +2)  
>
> #### Actions
>
> ***Multiattack.*** The goblin makes two attacks, using Scimitar or Shortbow in any combination.
>
> ***Scimitar.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Slashing damage, plus 2 (1d4) Slashing damage if the attack roll had Advantage.
>
> ***Shortbow.*** *Ranged Attack Roll:* +4, range 80/320 ft. *Hit:* 5 (1d6 + 2) Piercing damage, plus 2 (1d4) Piercing damage if the attack roll had Advantage.
>
> #### Bonus Actions
>
> ***Nimble Escape.*** The goblin takes the Disengage or Hide action.
>
> #### Reactions
>
> ***Redirect Attack.*** *Trigger:* A creature the goblin can see makes an attack roll against it. *Response:* The goblin chooses a Small or Medium ally within 5 feet of itself. The goblin and that ally swap places, and the ally becomes the target of the attack instead.
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1

> [!statblock]
> ### Goblin Boss
>
> *Small Fey (Goblinoid), Chaotic Neutral*
>
> **AC:** 17  
> **Initiative:** +2 (12)  
>
> **HP:** 21 (6d6)  
>
> **Speed:** 30 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 10 | +0 | +0 | **Dex** | 15 | +2 | +2 | **Con** | 10 | +0 | +0 |
> | **Int** | 10 | +0 | +0 | **Wis** | 8 | -1 | -1 | **Cha** | 10 | +0 | +0 |
>
> **Skills:**  
> **Stealth:** +6  
>
> **Gear:** Chain Shirt, Scimitar, [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield|Shield]], Shortbow  
>
> **Senses:** Darkvision 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
>
> **Languages:** Common, Goblin  
>
> **CR:** 1 (XP 200; PB +2)  
>
> #### Actions
>
> ***Multiattack.*** The goblin makes two attacks, using Scimitar or Shortbow in any combination.
>
> ***Scimitar.*** Melee [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attack Roll|Attack Roll]]: +4, reach 5 ft. Hit: 5 (1d6 + 2) Slashing damage, plus 2 (1d4) Slashing damage if the attack roll had [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]].
>
> ***Shortbow.*** Ranged [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Attack Roll|Attack Roll]]: +4, range 80/320 ft.
>
> Hit: 5 (1d6 + 2) Piercing damage, plus 2 (1d4) Piercing damage if the attack roll had [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]].
>
> #### Bonus Actions
>
> ***Nimble Escape.*** The goblin takes the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Disengage|Disengage]] or [[== SRDs ==/Compendium/5.5e/Rules/Actions/Hide|Hide]] action.
>
> #### Reactions
>
> ***Redirect Attack.*** Trigger: A creature the goblin can see makes an attack roll against it. Response: The goblin chooses a Small or Medium ally within 5 feet of itself.
>
> The goblin and that ally swap places, and the ally becomes the target of the attack instead.
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=290|SRD 5.2.1, p. 290]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
