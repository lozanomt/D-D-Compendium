---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
entity_id: eb345a47-ad1b-5755-b94c-8ddd796cb468
entity_type: rule
source_ids: ["phb-2024"]
source_versions: ["Player's Handbook"]
---

# Spells

## Player's Handbook

> [!info]
> ### Spells
>
> ![[== SRDs ==/Sources/5.5e/Placeholder.png|320]]
>
> #### Gaining Spells
> Before you can cast a spell, you must have the spell prepared in your mind or have access to the spell from a magic item, such as a *[[== SRDs ==/Compendium/5.5e/Items/Magic Items/Spell Scroll/Spell Scroll|Spell Scroll]]*. Your features specify which spells you have access to, if any; whether you always have certain spells prepared; and whether you can change the list of spells you have prepared.
> #### Preparing Spells
> If you have a list of level 1+ spells you prepare, your spellcasting feature specifies when you can change the list and the number of spells you can change, as summarized in the Spell Preparation by Class table.
> [!tip|right ws-med] Casting in Armor
> You must have training with any armor you are wearing to cast spells while wearing it. You are otherwise too hampered by the armor for spellcasting.
> #### Spell Preparation by Class
> | Class                          | Change When You... | Number of Spells |
> | ------------------------------ | ------------------ | :----------------: |
> | [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Bard/Bard\|Bard]]                       | Gain a level       | One              |
> | [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Cleric/Cleric\|Cleric]]                     | Finish a Long Rest | Any              |
> | [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Druid/Druid\|Druid]] | Finish a Long Rest | Any              |
> | [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Paladin/Paladin\|Paladin]]                    | Finish a Long Rest | One              |
> | [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Ranger/Ranger\|Ranger]]                     | Finish a Long Rest | One              |
> | [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Sorcerer/Sorcerer\|Sorcerer]]                   | Gain a level       | One              |
> | [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Warlock/Warlock\|Warlock]]                    | Gain a level       | One              |
> | [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Wizard/Wizard\|Wizard]]                     | Finish a Long Rest | Any              |
> Most spellcasting monsters don’t change their lists of prepared spells, but the DM is free to alter them.
> #### Always-Prepared Spells
> Certain features might give you a spell that you always have prepared. If you also have a list of prepared spells that you can change, a spell that you always have prepared doesn’t count against the number of spells on that list.
> #### Casting Spells
> Each spell description has a series of entries that provide the details needed to cast the spell. The following sections explain each of those entries, which follow a spell’s name.
> #### Spell Level
> Every spell has a level from 0 to 9, which is indicated in a spell’s description. A spell’s level is an indicator of how powerful it is. Cantrips - simple spells that can be cast almost by rote - are level 0. The rules for each spellcasting class say when its members gain access to spells of certain levels.
> #### Spell Slots
> Spellcasting is taxing, so a spellcaster can cast only a limited number of level 1+ spells before resting. Spell slots are the main way a spellcaster’s magical potential is represented. Each spellcasting class gives its members a limited number of spell slots of certain spell levels. When you cast a spell, you expend a slot of that spell’s level or higher, effectively “filling” a slot with the spell. Imagine a spell slot is a groove of a certain size - small for a level 1 slot and larger for a higher-level spell. A level 1 spell fits into a slot of any size, but a level 2 spell fits only into a slot that’s at least level 2. Finishing a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]] restores any expended spell slots.
> #### Casting without Slots
> There are several ways to cast a spell without expending a spell slot:
>
> **Cantrips.** A cantrip is cast without a spell slot.
>
> **Rituals.** Certain spells have the [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual|Ritual]] tag in the Casting Time entry. Such a spell can be cast following the normal rules for spellcasting, or it can be cast as a Ritual. The Ritual version of a spell takes 10 minutes longer to cast than normal, but it doesn’t expend a spell slot. To cast a spell as a Ritual, a spellcaster must have it prepared.
>
> **Special Abilities.** Some characters and monsters have special abilities that allow them to cast specific spells without a spell slot. This casting is usually limited in another way, such as being able to cast the spell a limited number of times per day.
>
> **Magic Items.** *[[== SRDs ==/Compendium/5.5e/Items/Magic Items/Spell Scroll/Spell Scroll|Spell Scrolls]]* and some other magic items contain spells that can be cast without a spell slot. The description of such an item specifies how many times a spell can be cast from it.
> #### Using a Higher-Level Spell Slot
> When a spellcaster casts a spell using a slot that is of a higher level than the spell, the spell takes on the higher level for that casting. Effectively, the spell expands to fill the slot it is put into. Some spells, such as *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Magic Missile|Magic Missile]]* and *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Cure Wounds|Cure Wounds]]*, have more powerful effects when cast at a higher level, as detailed in a spell’s description.
> #### School of Magic
> Each spell belongs to a school of magic. The schools are listed in the Schools of Magic table. These categories help describe spells but have no rules of their own, although some other rules refer to them.
> #### Schools of Magic
> | School        | Typical Effects                                              |
> | ------------- | ------------------------------------------------------------ |
> | Abjuration    | Prevents or reverses harmful effects                         |
> | Conjuration   | Transports creatures or objects                              |
> | Divination    | Reveals information                                          |
> | Enchantment   | Influences minds                                             |
> | Evocation     | Channels energy to create effects that are often destructive |
> | Illusion      | Deceives the mind or senses                                  |
> | Necromancy    | Manipulates life and death                                   |
> | Transmutation | Transforms creatures or objects                              |
> #### Class Spell Lists
> This section presents the spell lists for each class. The spells are organized by spell level and then alphabetized, and each spell's school of magic is listed. In the Special column, *C* means the spell requires [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration|Concentration]], *R* means it's a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual|Ritual]], and *M* means it requires a specific Material [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Components|component]].
> #### Bard Spell List
> | Level | Spell                          | School        | Special |
> | :---: | ------------------------------ | ------------- | :-----: |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Dancing Lights\|Dancing Lights]]*           | Illusion      |    C    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Light\|Light]]*                    | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mage Hand\|Mage Hand]]*                | Conjuration   |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mending\|Mending]]*                  | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Message\|Message]]*                  | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Minor Illusion\|Minor Illusion]]*           | Illusion      |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Prestidigitation\|Prestidigitation]]*         | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Starry Wisp\|Starry Wisp]]*              | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/True Strike\|True Strike]]*              | Divination    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Vicious Mockery\|Vicious Mockery]]*          | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Animal Friendship\|Animal Friendship]]*        | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bane\|Bane]]*                     | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Charm Person\|Charm Person]]*             | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Color Spray\|Color Spray]]*              | Illusion      |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Command\|Command]]*                  | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Comprehend Languages\|Comprehend Languages]]*     | Divination    |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Cure Wounds\|Cure Wounds]]*              | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic\|Detect Magic]]*             | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Disguise Self\|Disguise Self]]*            | Illusion      |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Dissonant Whispers\|Dissonant Whispers]]*       | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Faerie Fire\|Faerie Fire]]*              | Evocation     |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Feather Fall\|Feather Fall]]*             | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Healing Word\|Healing Word]]*             | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Heroism\|Heroism]]*                  | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hideous Laughter\|Hideous Laughter]]*         | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Identify\|Identify]]*                 | Divination    |  R, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Illusory Script\|Illusory Script]]*          | Illusion      |  R, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Longstrider\|Longstrider]]*              | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Silent Image\|Silent Image]]*             | Illusion      |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Sleep\|Sleep]]*                    | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Speak with Animals\|Speak with Animals]]*       | Divination    |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Thunderwave\|Thunderwave]]*              | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Unseen Servant\|Unseen Servant]]*           | Conjuration   |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Aid\|Aid]]*                      | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Animal Messenger\|Animal Messenger]]*         | Enchantment   |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blindness + Deafness\|Blindness + Deafness]]*     | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Calm Emotions\|Calm Emotions]]*            | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Detect Thoughts\|Detect Thoughts]]*          | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enhance Ability\|Enhance Ability]]*          | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enlarge + Reduce\|Enlarge + Reduce]]*         | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enthrall\|Enthrall]]*                 | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Heat Metal\|Heat Metal]]*               | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Hold Person\|Hold Person]]*              | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility\|Invisibility]]*             | Illusion      |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Knock\|Knock]]*                    | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Lesser Restoration\|Lesser Restoration]]*       | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Animals or Plants\|Locate Animals or Plants]]* | Divination    |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Object\|Locate Object]]*            | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Mouth\|Magic Mouth]]*              | Illusion      |  R, M   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mirror Image\|Mirror Image]]*             | Illusion      |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Phantasmal Force\|Phantasmal Force]]*         | Illusion      |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/See Invisibility\|See Invisibility]]*         | Divination    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Shatter\|Shatter]]*                  | Evocation     |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Silence\|Silence]]*                  | Illusion      |  C, R   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Suggestion\|Suggestion]]*               | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Zone of Truth\|Zone of Truth]]*            | Enchantment   |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Bestow Curse\|Bestow Curse]]*             | Necromancy    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Clairvoyance\|Clairvoyance]]*             | Divination    |  C, M   |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic\|Dispel Magic]]*             | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fear\|Fear]]*                     | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Glyph of Warding\|Glyph of Warding]]*         | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Hypnotic Pattern\|Hypnotic Pattern]]*         | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Major Image\|Major Image]]*              | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Mass Healing Word\|Mass Healing Word]]*        | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Nondetection\|Nondetection]]*             | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Plant Growth\|Plant Growth]]*             | Transmutation |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sending\|Sending]]*                  | Divination    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Slow\|Slow]]*                     | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Dead\|Speak with Dead]]*          | Necromancy    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Plants\|Speak with Plants]]*        | Transmutation |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Stinking Cloud\|Stinking Cloud]]*           | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tiny Hut\|Tiny Hut]]*                 | Evocation     |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tongues\|Tongues]]*                  | Divination    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Charm Monster\|Charm Monster]]*            | Enchantment   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Compulsion\|Compulsion]]*               | Enchantment   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Confusion\|Confusion]]*                | Enchantment   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dimension Door\|Dimension Door]]*           | Conjuration   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Freedom of Movement\|Freedom of Movement]]*      | Abjuration    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Greater Invisibility\|Greater Invisibility]]*     | Illusion      |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Hallucinatory Terrain\|Hallucinatory Terrain]]*    | Illusion      |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Locate Creature\|Locate Creature]]*          | Divination    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Phantasmal Killer\|Phantasmal Killer]]*        | Illusion      |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Polymorph\|Polymorph]]*                | Transmutation |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Animate Objects\|Animate Objects]]*          | Transmutation |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Awaken\|Awaken]]*                   | Transmutation |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dominate Person\|Dominate Person]]*          | Enchantment   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dream\|Dream]]*                    | Illusion      |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Geas\|Geas]]*                     | Enchantment   |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Greater Restoration\|Greater Restoration]]*      | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Hold Monster\|Hold Monster]]*             | Enchantment   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Legend Lore\|Legend Lore]]*              | Divination    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mass Cure Wounds\|Mass Cure Wounds]]*         | Abjuration    |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mislead\|Mislead]]*                  | Illusion      |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Modify Memory\|Modify Memory]]*            | Enchantment   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Planar Binding\|Planar Binding]]*           | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Raise Dead\|Raise Dead]]*               | Necromancy    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Scrying\|Scrying]]*                  | Divination    |  C, M   |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Seeming\|Seeming]]*                  | Illusion      |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Telepathic Bond\|Telepathic Bond]]*          | Divination    |    R    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Teleportation Circle\|Teleportation Circle]]*     | Conjuration   |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Eyebite\|Eyebite]]*                  | Necromancy    |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Find the Path\|Find the Path]]*            | Divination    |  C, M   |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Guards and Wards\|Guards and Wards]]*         | Abjuration    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Heroes' Feast\|Heroes' Feast]]*            | Conjuration   |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Irresistible Dance\|Irresistible Dance]]*       | Enchantment   |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Mass Suggestion\|Mass Suggestion]]*          | Enchantment   |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Programmed Illusion\|Programmed Illusion]]*      | Illusion      |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/True Seeing\|True Seeing]]*              | Divination    |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Arcane Sword\|Arcane Sword]]*             | Evocation     |  C, M   |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Etherealness\|Etherealness]]*             | Conjuration   |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Forcecage\|Forcecage]]*                | Evocation     |  C, M   |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Magnificent Mansion\|Magnificent Mansion]]*      | Conjuration   |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Mirage Arcane\|Mirage Arcane]]*            | Illusion      |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Prismatic Spray\|Prismatic Spray]]*          | Evocation     |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Project Image\|Project Image]]*            | Illusion      |  C, M   |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Regenerate\|Regenerate]]*               | Transmutation |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Resurrection\|Resurrection]]*             | Necromancy    |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Symbol\|Symbol]]*                   | Abjuration    |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Teleport\|Teleport]]*                 | Conjuration   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Antipathy + Sympathy\|Antipathy + Sympathy]]*     | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Befuddlement\|Befuddlement]]*             | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Dominate Monster\|Dominate Monster]]*         | Enchantment   |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Glibness\|Glibness]]*                 | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Mind Blank\|Mind Blank]]*               | Abjuration    |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Power Word Stun\|Power Word Stun]]*          | Enchantment   |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Foresight\|Foresight]]*                | Divination    |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Heal\|Power Word Heal]]*          | Enchantment   |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Kill\|Power Word Kill]]*          | Enchantment   |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Prismatic Wall\|Prismatic Wall]]*           | Abjuration    |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/True Polymorph\|True Polymorph]]*           | Transmutation |    C    |
> #### Cleric Spell List
> | Level | Spell                                       | School        | Special |
> | :---: | ------------------------------------------- | ------------- | :-----: |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Guidance\|Guidance]]*                              | Divination    |    C    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Light\|Light]]*                                 | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mending\|Mending]]*                               | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Resistance\|Resistance]]* | Abjuration    |    C    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Sacred Flame\|Sacred Flame]]*                          | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Spare the Dying\|Spare the Dying]]*                       | Necromancy    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Thaumaturgy\|Thaumaturgy]]*                           | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bane\|Bane]]*                                  | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bless\|Bless]]*                                 | Enchantment   |  C, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Command\|Command]]*                               | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Create or Destroy Water\|Create or Destroy Water]]*               | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Cure Wounds\|Cure Wounds]]*                           | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Evil and Good\|Detect Evil and Good]]*                  | Divination    |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic\|Detect Magic]]*                          | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Poison and Disease\|Detect Poison and Disease]]*             | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Guiding Bolt\|Guiding Bolt]]*                          | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Healing Word\|Healing Word]]*                          | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Inflict Wounds\|Inflict Wounds]]*                        | Necromancy    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Protection from Evil and Good\|Protection from Evil and Good]]*         | Abjuration    |  C, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Purify Food and Drink\|Purify Food and Drink]]*                 | Transmutation |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Sanctuary\|Sanctuary]]*                             | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield of Faith\|Shield of Faith]]*                       | Abjuration    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Aid\|Aid]]*                                   | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Augury\|Augury]]*                                | Divination    |  R, M   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blindness + Deafness\|Blindness + Deafness]]*                  | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Calm Emotions\|Calm Emotions]]*                         | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Continual Flame\|Continual Flame]]*                       | Evocation     |    M    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enhance Ability\|Enhance Ability]]*                       | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Find Traps\|Find Traps]]*                            | Divination    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gentle Repose\|Gentle Repose]]*                         | Necromancy    |  R, M   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Hold Person\|Hold Person]]*                           | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Lesser Restoration\|Lesser Restoration]]*                    | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Object\|Locate Object]]*                         | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Prayer of Healing\|Prayer of Healing]]*                     | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Protection from Poison\|Protection from Poison]]*                | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Silence\|Silence]]*                               | Illusion      |  C, R   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spiritual Weapon\|Spiritual Weapon]]*                      | Evocation     |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Warding Bond\|Warding Bond]]*                          | Abjuration    |    M    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Zone of Truth\|Zone of Truth]]*                         | Enchantment   |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Animate Dead\|Animate Dead]]*                          | Necromancy    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Beacon of Hope\|Beacon of Hope]]*                        | Abjuration    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Bestow Curse\|Bestow Curse]]*                          | Necromancy    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Clairvoyance\|Clairvoyance]]*                          | Divination    |  C, M   |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Create Food and Water\|Create Food and Water]]*                 | Conjuration   |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Daylight\|Daylight]]*                              | Evocation     |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic\|Dispel Magic]]*                          | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Glyph of Warding\|Glyph of Warding]]*                      | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Magic Circle\|Magic Circle]]*                          | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Mass Healing Word\|Mass Healing Word]]*                     | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Meld into Stone\|Meld into Stone]]*                       | Transmutation |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Protection from Energy\|Protection from Energy]]*                | Abjuration    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Remove Curse\|Remove Curse]]*                          | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Revivify\|Revivify]]*                              | Necromancy    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sending\|Sending]]*                               | Divination    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Dead\|Speak with Dead]]*                       | Necromancy    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Spirit Guardians\|Spirit Guardians]]*                      | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tongues\|Tongues]]*                               | Divination    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Walk\|Water Walk]]*                            | Transmutation |    R    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Aura of Life\|Aura of Life]]*                          | Abjuration    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Banishment\|Banishment]]*                            | Abjuration    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Control Water\|Control Water]]*                         | Transmutation |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Death Ward\|Death Ward]]*                            | Abjuration    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Divination\|Divination]]*                            | Divination    |  R, M   |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Freedom of Movement\|Freedom of Movement]]*                   | Abjuration    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Guardian of Faith\|Guardian of Faith]]*                     | Conjuration   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Locate Creature\|Locate Creature]]*                       | Divination    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stone Shape\|Stone Shape]]*                           | Transmutation |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Commune\|Commune]]*                               | Divination    |    R    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Contagion\|Contagion]]*                             | Necromancy    |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dispel Evil and Good\|Dispel Evil and Good]]*                  | Abjuration    |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Flame Strike\|Flame Strike]]*                          | Evocation     |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Geas\|Geas]]*                                  | Enchantment   |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Greater Restoration\|Greater Restoration]]*                   | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Hallow\|Hallow]]*                                | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Insect Plague\|Insect Plague]]*                         | Conjuration   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Legend Lore\|Legend Lore]]*                           | Divination    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mass Cure Wounds\|Mass Cure Wounds]]*                      | Abjuration    |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Planar Binding\|Planar Binding]]*                        | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Raise Dead\|Raise Dead]]*                            | Necromancy    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Scrying\|Scrying]]*                               | Divination    |  C, M   |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Blade Barrier\|Blade Barrier]]*                         | Evocation     |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Create Undead\|Create Undead]]*                         | Necromancy    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Find the Path\|Find the Path]]*                         | Divination    |  C, M   |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Forbiddance\|Forbiddance]]*                           | Abjuration    |  R, M   |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Harm\|Harm]]*                                  | Necromancy    |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Heal\|Heal]]*                                  | Abjuration    |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Heroes' Feast\|Heroes' Feast]]*                         | Conjuration   |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Planar Ally\|Planar Ally]]*                           | Conjuration   |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Sunbeam\|Sunbeam]]*                               | Evocation     |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/True Seeing\|True Seeing]]*                           | Divination    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Word of Recall\|Word of Recall]]*                        | Conjuration   |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Conjure Celestial\|Conjure Celestial]]*                     | Conjuration   |    C    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Divine Word\|Divine Word]]*                           | Evocation     |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Etherealness\|Etherealness]]*                          | Conjuration   |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Fire Storm\|Fire Storm]]*                            | Evocation     |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Plane Shift\|Plane Shift]]*                           | Conjuration   |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Regenerate\|Regenerate]]*                            | Transmutation |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Resurrection\|Resurrection]]*                          | Necromancy    |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Symbol\|Symbol]]*                                | Abjuration    |    M    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Antimagic Field\|Antimagic Field]]*                       | Abjuration    |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Control Weather\|Control Weather]]*                       | Transmutation |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Earthquake\|Earthquake]]*                            | Transmutation |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Holy Aura\|Holy Aura]]*                             | Abjuration    |  C, M   |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Sunburst\|Sunburst]]*                              | Evocation     |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Astral Projection\|Astral Projection]]*                     | Necromancy    |    M    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Gate\|Gate]]*                                  | Conjuration   |  C, M   |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Mass Heal\|Mass Heal]]*                             | Abjuration    |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Heal\|Power Word Heal]]*                       | Enchantment   |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/True Resurrection\|True Resurrection]]*                     | Necromancy    |    M    |
> #### Druid Spell List
> | Level | Spell                                           | School        | Special |
> | :---: | ----------------------------------------------- | ------------- | :-----: |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Druidcraft\|Druidcraft]]*                                | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Elementalism\|Elementalism]]*                              | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Guidance\|Guidance]]*                                  | Divination    |    C    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mending\|Mending]]*                                   | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Message\|Message]]*                                   | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Poison Spray\|Poison Spray]]*                              | Necromancy    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Produce Flame\|Produce Flame]]*                             | Conjuration   |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Resistance\|Resistance]]*     | Abjuration    |    C    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Shillelagh\|Shillelagh]]*                                | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Spare the Dying\|Spare the Dying]]*                           | Necromancy    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Starry Wisp\|Starry Wisp]]*                               | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Animal Friendship\|Animal Friendship]]*                         | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Charm Person\|Charm Person]]*                              | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Create or Destroy Water\|Create or Destroy Water]]*                   | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Cure Wounds\|Cure Wounds]]*                               | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic\|Detect Magic]]*                              | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Poison and Disease\|Detect Poison and Disease]]*                 | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Entangle\|Entangle]]*                                  | Conjuration   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Faerie Fire\|Faerie Fire]]*                               | Evocation     |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Fog Cloud\|Fog Cloud]]*                                 | Conjuration   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Goodberry\|Goodberry]]*                                 | Conjuration   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Healing Word\|Healing Word]]*                              | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ice Knife\|Ice Knife]]*                                 | Conjuration   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Jump\|Jump]]*                                      | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Longstrider\|Longstrider]]*                               | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Protection from Evil and Good\|Protection from Evil and Good]]*             | Abjuration    |  C, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Purify Food and Drink\|Purify Food and Drink]]*                     | Transmutation |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Speak with Animals\|Speak with Animals]]*                        | Divination    |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Thunderwave\|Thunderwave]]*                               | Evocation     |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Aid\|Aid]]*                                       | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Animal Messenger\|Animal Messenger]]*                          | Enchantment   |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Augury\|Augury]]*                                    | Divination    |  R, M   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Barkskin\|Barkskin]]*                                  | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Continual Flame\|Continual Flame]]*                           | Evocation     |    M    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkvision\|Darkvision]]*     | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enhance Ability\|Enhance Ability]]*                           | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enlarge + Reduce\|Enlarge + Reduce]]*                          | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Find Traps\|Find Traps]]*                                | Divination    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Flame Blade\|Flame Blade]]*                               | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Flaming Sphere\|Flaming Sphere]]*                            | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gust of Wind\|Gust of Wind]]*                              | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Heat Metal\|Heat Metal]]*                                | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Hold Person\|Hold Person]]*                               | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Lesser Restoration\|Lesser Restoration]]*                        | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Animals or Plants\|Locate Animals or Plants]]*                  | Divination    |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Object\|Locate Object]]*                             | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Moonbeam\|Moonbeam]]*                                  | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Pass without Trace\|Pass without Trace]]*                        | Abjuration    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Protection from Poison\|Protection from Poison]]*                    | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spike Growth\|Spike Growth]]*                              | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Call Lightning\|Call Lightning]]*                            | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Conjure Animals\|Conjure Animals]]*                           | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Daylight\|Daylight]]*                                  | Evocation     |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic\|Dispel Magic]]*                              | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Meld into Stone\|Meld into Stone]]*                           | Transmutation |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Plant Growth\|Plant Growth]]*                              | Transmutation |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Protection from Energy\|Protection from Energy]]*                    | Abjuration    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Revivify\|Revivify]]*                                  | Necromancy    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sleet Storm\|Sleet Storm]]*                               | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Plants\|Speak with Plants]]*                         | Transmutation |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Breathing\|Water Breathing]]*                           | Transmutation |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Walk\|Water Walk]]*                                | Transmutation |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Wind Wall\|Wind Wall]]*                                 | Evocation     |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Blight\|Blight]]*                                    | Necromancy    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Charm Monster\|Charm Monster]]*                             | Enchantment   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Confusion\|Confusion]]*                                 | Enchantment   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Conjure Minor Elementals\|Conjure Minor Elementals]]*                  | Conjuration   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Conjure Woodland Beings\|Conjure Woodland Beings]]*                   | Conjuration   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Control Water\|Control Water]]*                             | Transmutation |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Divination\|Divination]]*                                | Divination    |  R, M   |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dominate Beast\|Dominate Beast]]*                            | Enchantment   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Fire Shield\|Fire Shield]]*                               | Evocation     |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Freedom of Movement\|Freedom of Movement]]*                       | Abjuration    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Giant Insect\|Giant Insect]]* | Conjuration   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Hallucinatory Terrain\|Hallucinatory Terrain]]*                     | Illusion      |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Ice Storm\|Ice Storm]]*                                 | Evocation     |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Locate Creature\|Locate Creature]]*                           | Divination    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Polymorph\|Polymorph]]*                                 | Transmutation |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stone Shape\|Stone Shape]]*                               | Transmutation |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stoneskin\|Stoneskin]]*                                 | Transmutation |  C, M   |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Wall of Fire\|Wall of Fire]]*                              | Evocation     |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Antilife Shell\|Antilife Shell]]*                            | Abjuration    |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Awaken\|Awaken]]*                                    | Transmutation |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Commune with Nature\|Commune with Nature]]*                       | Divination    |    R    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Cone of Cold\|Cone of Cold]]*                              | Evocation     |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Conjure Elemental\|Conjure Elemental]]*                         | Conjuration   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Contagion\|Contagion]]*                                 | Necromancy    |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Geas\|Geas]]*                                      | Enchantment   |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Greater Restoration\|Greater Restoration]]*                       | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Insect Plague\|Insect Plague]]*                             | Conjuration   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mass Cure Wounds\|Mass Cure Wounds]]*                          | Abjuration    |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Planar Binding\|Planar Binding]]*                            | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Reincarnate\|Reincarnate]]*                               | Necromancy    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Scrying\|Scrying]]*                                   | Divination    |  C, M   |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Tree Stride\|Tree Stride]]*                               | Conjuration   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Wall of Stone\|Wall of Stone]]*                             | Evocation     |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Conjure Fey\|Conjure Fey]]*                               | Conjuration   |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Find the Path\|Find the Path]]*                             | Divination    |  C, M   |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Flesh to Stone\|Flesh to Stone]]*                            | Transmutation |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Heal\|Heal]]*                                      | Abjuration    |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Heroes' Feast\|Heroes' Feast]]*                             | Conjuration   |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Move Earth\|Move Earth]]*                                | Transmutation |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Sunbeam\|Sunbeam]]*                                   | Evocation     |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Transport via Plants\|Transport via Plants]]*                      | Conjuration   |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Wall of Thorns\|Wall of Thorns]]*                            | Conjuration   |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Wind Walk\|Wind Walk]]*                                 | Transmutation |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Fire Storm\|Fire Storm]]*                                | Evocation     |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Mirage Arcane\|Mirage Arcane]]*                             | Illusion      |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Plane Shift\|Plane Shift]]*                               | Conjuration   |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Regenerate\|Regenerate]]*                                | Transmutation |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Reverse Gravity\|Reverse Gravity]]*                           | Transmutation |    C    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Symbol\|Symbol]]*                                    | Abjuration    |    M    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Animal Shapes\|Animal Shapes]]*                             | Transmutation |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Antipathy + Sympathy\|Antipathy + Sympathy]]*                      | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Befuddlement\|Befuddlement]]*                              | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Control Weather\|Control Weather]]*                           | Transmutation |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Earthquake\|Earthquake]]*                                | Transmutation |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Incendiary Cloud\|Incendiary Cloud]]*                          | Conjuration   |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Sunburst\|Sunburst]]*                                  | Evocation     |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Tsunami\|Tsunami]]*                                   | Conjuration   |    C    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Foresight\|Foresight]]*                                 | Divination    |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Shapechange\|Shapechange]]*                               | Transmutation |  C, M   |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Storm of Vengeance\|Storm of Vengeance]]*                        | Conjuration   |    C    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/True Resurrection\|True Resurrection]]*                         | Necromancy    |    M    |
> #### Paladin Spell List
> | Level | Spell                               | School        | Special |
> | :---: | ----------------------------------- | ------------- | :-----: |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bless\|Bless]]*                         | Enchantment   |  C, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Command\|Command]]*                       | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Cure Wounds\|Cure Wounds]]*                   | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Evil and Good\|Detect Evil and Good]]*          | Divination    |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic\|Detect Magic]]*                  | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Poison and Disease\|Detect Poison and Disease]]*     | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Divine Favor\|Divine Favor]]*                  | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Heroism\|Heroism]]*                       | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Protection from Evil and Good\|Protection from Evil and Good]]* | Abjuration    |  C, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Purify Food and Drink\|Purify Food and Drink]]*         | Transmutation |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Searing Smite\|Searing Smite]]*                 | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield of Faith\|Shield of Faith]]*               | Abjuration    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Aid\|Aid]]*                           | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Find Steed\|Find Steed]]*                    | Conjuration   |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gentle Repose\|Gentle Repose]]*                 | Necromancy    |  R, M   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Lesser Restoration\|Lesser Restoration]]*            | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Object\|Locate Object]]*                 | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Weapon\|Magic Weapon]]*                  | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Prayer of Healing\|Prayer of Healing]]*             | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Protection from Poison\|Protection from Poison]]*        | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Shining Smite\|Shining Smite]]*                 | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Warding Bond\|Warding Bond]]*                  | Abjuration    |    M    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Zone of Truth\|Zone of Truth]]*                 | Enchantment   |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Create Food and Water\|Create Food and Water]]*         | Conjuration   |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Daylight\|Daylight]]*                      | Evocation     |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic\|Dispel Magic]]*                  | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Magic Circle\|Magic Circle]]*                  | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Remove Curse\|Remove Curse]]*                  | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Revivify\|Revivify]]*                      | Necromancy    |    M    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Aura of Life\|Aura of Life]]*                  | Abjuration    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Banishment\|Banishment]]*                    | Abjuration    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Death Ward\|Death Ward]]*                    | Abjuration    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Locate Creature\|Locate Creature]]*               | Divination    |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dispel Evil and Good\|Dispel Evil and Good]]*          | Abjuration    |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Geas\|Geas]]*                          | Enchantment   |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Greater Restoration\|Greater Restoration]]*           | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Raise Dead\|Raise Dead]]*                    | Necromancy    |    M    |
> #### Ranger Spell List
> | Level | Spell                                       | School        | Special |
> | :---: | ------------------------------------------- | ------------- | :-----: |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Alarm\|Alarm]]*                                 | Abjuration    |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Animal Friendship\|Animal Friendship]]*                     | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Cure Wounds\|Cure Wounds]]*                           | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic\|Detect Magic]]*                          | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Poison and Disease\|Detect Poison and Disease]]*             | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ensnaring Strike\|Ensnaring Strike]]*                      | Conjuration   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Entangle\|Entangle]]*                              | Conjuration   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Fog Cloud\|Fog Cloud]]*                             | Conjuration   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Goodberry\|Goodberry]]*                             | Conjuration   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hunter's Mark\|Hunter's Mark]]*                         | Divination    |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Jump\|Jump]]*                                  | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Longstrider\|Longstrider]]*                           | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Speak with Animals\|Speak with Animals]]*                    | Divination    |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Aid\|Aid]]*                                   | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Animal Messenger\|Animal Messenger]]*                      | Enchantment   |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Barkskin\|Barkskin]]*                              | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkvision\|Darkvision]]* | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enhance Ability\|Enhance Ability]]*                       | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Find Traps\|Find Traps]]*                            | Divination    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gust of Wind\|Gust of Wind]]*                          | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Lesser Restoration\|Lesser Restoration]]*                    | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Animals or Plants\|Locate Animals or Plants]]*              | Divination    |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Object\|Locate Object]]*                         | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Weapon\|Magic Weapon]]*                          | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Pass without Trace\|Pass without Trace]]*                    | Abjuration    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Protection from Poison\|Protection from Poison]]*                | Abjuration    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Silence\|Silence]]*                               | Illusion      |  C, R   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spike Growth\|Spike Growth]]*                          | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Conjure Animals\|Conjure Animals]]*                       | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Daylight\|Daylight]]*                              | Evocation     |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic\|Dispel Magic]]*                          | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Meld into Stone\|Meld into Stone]]*                       | Transmutation |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Nondetection\|Nondetection]]*                          | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Plant Growth\|Plant Growth]]*                          | Transmutation |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Protection from Energy\|Protection from Energy]]*                | Abjuration    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Revivify\|Revivify]]*                              | Necromancy    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Plants\|Speak with Plants]]*                     | Transmutation |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Breathing\|Water Breathing]]*                       | Transmutation |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Walk\|Water Walk]]*                            | Transmutation |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Wind Wall\|Wind Wall]]*                             | Evocation     |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Conjure Woodland Beings\|Conjure Woodland Beings]]*               | Conjuration   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dominate Beast\|Dominate Beast]]*                        | Enchantment   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Freedom of Movement\|Freedom of Movement]]*                   | Abjuration    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Locate Creature\|Locate Creature]]*                       | Divination    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stoneskin\|Stoneskin]]*                             | Transmutation |  C, M   |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Commune with Nature\|Commune with Nature]]*                   | Divination    |    R    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Greater Restoration\|Greater Restoration]]*                   | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Tree Stride\|Tree Stride]]*                           | Conjuration   |    C    |
> #### Sorcerer Spell List
> | Level | Spell                                       | School        | Special |
> | :---: | ------------------------------------------- | ------------- | :-----: |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Acid Splash\|Acid Splash]]*                           | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Chill Touch\|Chill Touch]]*                           | Necromancy    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Dancing Lights\|Dancing Lights]]*                        | Illusion      |    C    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Elementalism\|Elementalism]]*                          | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Fire Bolt\|Fire Bolt]]*                             | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Light\|Light]]*           | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mage Hand\|Mage Hand]]*                             | Conjuration   |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mending\|Mending]]*                               | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Message\|Message]]*                               | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Minor Illusion\|Minor Illusion]]*                        | Illusion      |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Poison Spray\|Poison Spray]]*                          | Necromancy    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Prestidigitation\|Prestidigitation]]*                      | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Ray of Frost\|Ray of Frost]]*                          | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Shocking Grasp\|Shocking Grasp]]*                        | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Sorcerous Burst\|Sorcerous Burst]]*                       | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/True Strike\|True Strike]]*                           | Divination    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Burning Hands\|Burning Hands]]*                         | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Charm Person\|Charm Person]]*                          | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Chromatic Orb\|Chromatic Orb]]*                         | Evocation     |    M    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Color Spray\|Color Spray]]*                           | Illusion      |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Comprehend Languages\|Comprehend Languages]]*                  | Divination    |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic\|Detect Magic]]*                          | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Disguise Self\|Disguise Self]]*                         | Illusion      |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Expeditious Retreat\|Expeditious Retreat]]*                   | Transmutation |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/False Life\|False Life]]*                            | Necromancy    |    –    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Feather Fall\|Feather Fall]]*                          | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Fog Cloud\|Fog Cloud]]*                             | Conjuration   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Grease\|Grease]]*                                | Conjuration   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ice Knife\|Ice Knife]]*                             | Conjuration   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Jump\|Jump]]*                                  | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Mage Armor\|Mage Armor]]*                            | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Magic Missile\|Magic Missile]]*                         | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ray of Sickness\|Ray of Sickness]]*                       | Necromancy    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield\|Shield]]*         | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Silent Image\|Silent Image]]*                          | Illusion      |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Sleep\|Sleep]]*                                 | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Thunderwave\|Thunderwave]]*                           | Evocation     |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Alter Self\|Alter Self]]*                            | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blindness + Deafness\|Blindness + Deafness]]*                  | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blur\|Blur]]*                                  | Illusion      |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkness\|Darkness]]*     | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkvision\|Darkvision]]* | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Detect Thoughts\|Detect Thoughts]]*                       | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Dragon's Breath\|Dragon's Breath]]*                       | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enhance Ability\|Enhance Ability]]*                       | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enlarge + Reduce\|Enlarge + Reduce]]*                      | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Flame Blade\|Flame Blade]]*                           | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Flaming Sphere\|Flaming Sphere]]*                        | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gust of Wind\|Gust of Wind]]*                          | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Hold Person\|Hold Person]]*                           | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility\|Invisibility]]*                          | Illusion      |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Knock\|Knock]]*                                 | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Levitate\|Levitate]]*                              | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Weapon\|Magic Weapon]]*                          | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mind Spike\|Mind Spike]]*                            | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mirror Image\|Mirror Image]]*                          | Illusion      |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Misty Step\|Misty Step]]*                            | Conjuration   |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Phantasmal Force\|Phantasmal Force]]*                      | Illusion      |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Scorching Ray\|Scorching Ray]]*                         | Evocation     |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/See Invisibility\|See Invisibility]]*                      | Divination    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Shatter\|Shatter]]*                               | Evocation     |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spider Climb\|Spider Climb]]*                          | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Suggestion\|Suggestion]]*                            | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Web\|Web]]*                                   | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Blink\|Blink]]*                                 | Transmutation |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Clairvoyance\|Clairvoyance]]*                          | Divination    |  C, M   |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Counterspell\|Counterspell]]*                          | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Daylight\|Daylight]]*                              | Evocation     |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic\|Dispel Magic]]*                          | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fear\|Fear]]*                                  | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fireball\|Fireball]]*                              | Evocation     |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fly\|Fly]]*                                   | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Gaseous Form\|Gaseous Form]]*                          | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Haste\|Haste]]*                                 | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Hypnotic Pattern\|Hypnotic Pattern]]*                      | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Lightning Bolt\|Lightning Bolt]]*                        | Evocation     |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Major Image\|Major Image]]*                           | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Protection from Energy\|Protection from Energy]]*                | Abjuration    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sleet Storm\|Sleet Storm]]*                           | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Slow\|Slow]]*             | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Stinking Cloud\|Stinking Cloud]]*                        | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tongues\|Tongues]]*                               | Divination    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Vampiric Touch\|Vampiric Touch]]*                        | Necromancy    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Breathing\|Water Breathing]]*                       | Transmutation |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Walk\|Water Walk]]*                            | Transmutation |    R    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Banishment\|Banishment]]*                            | Abjuration    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Blight\|Blight]]*                                | Necromancy    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Charm Monster\|Charm Monster]]*                         | Enchantment   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Confusion\|Confusion]]*                             | Enchantment   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dimension Door\|Dimension Door]]*                        | Conjuration   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dominate Beast\|Dominate Beast]]*                        | Enchantment   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Fire Shield\|Fire Shield]]*                           | Evocation     |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Greater Invisibility\|Greater Invisibility]]*                  | Illusion      |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Ice Storm\|Ice Storm]]*                             | Evocation     |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Polymorph\|Polymorph]]*                             | Transmutation |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stoneskin\|Stoneskin]]*                             | Transmutation |  C, M   |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Vitriolic Sphere\|Vitriolic Sphere]]*                      | Evocation     |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Wall of Fire\|Wall of Fire]]*                          | Evocation     |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Animate Objects\|Animate Objects]]*                       | Transmutation |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Arcane Hand\|Arcane Hand]]*                           | Evocation     |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Cloudkill\|Cloudkill]]*                             | Conjuration   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Cone of Cold\|Cone of Cold]]*                          | Evocation     |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Creation\|Creation]]*                              | Illusion      |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dominate Person\|Dominate Person]]*                       | Enchantment   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Hold Monster\|Hold Monster]]*                          | Enchantment   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Insect Plague\|Insect Plague]]*                         | Conjuration   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Seeming\|Seeming]]*                               | Illusion      |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Telekinesis\|Telekinesis]]*                           | Transmutation |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Teleportation Circle\|Teleportation Circle]]*                  | Conjuration   |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Wall of Stone\|Wall of Stone]]*                         | Evocation     |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Chain Lightning\|Chain Lightning]]*                       | Evocation     |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Circle of Death\|Circle of Death]]*                       | Necromancy    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Disintegrate\|Disintegrate]]*                          | Transmutation |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Eyebite\|Eyebite]]*                               | Necromancy    |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Flesh to Stone\|Flesh to Stone]]*                        | Transmutation |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Freezing Sphere\|Freezing Sphere]]*                       | Evocation     |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Globe of Invulnerability\|Globe of Invulnerability]]*              | Abjuration    |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Mass Suggestion\|Mass Suggestion]]*                       | Enchantment   |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Move Earth\|Move Earth]]*                            | Transmutation |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Sunbeam\|Sunbeam]]*                               | Evocation     |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/True Seeing\|True Seeing]]*                           | Divination    |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Delayed Blast Fireball\|Delayed Blast Fireball]]*                | Evocation     |    C    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Etherealness\|Etherealness]]*                          | Conjuration   |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Finger of Death\|Finger of Death]]*                       | Necromancy    |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Fire Storm\|Fire Storm]]*                            | Evocation     |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Plane Shift\|Plane Shift]]*                           | Conjuration   |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Prismatic Spray\|Prismatic Spray]]*                       | Evocation     |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Reverse Gravity\|Reverse Gravity]]*                       | Transmutation |    C    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Teleport\|Teleport]]*                              | Conjuration   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Demiplane\|Demiplane]]*                             | Conjuration   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Dominate Monster\|Dominate Monster]]*                      | Enchantment   |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Earthquake\|Earthquake]]*                            | Transmutation |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Incendiary Cloud\|Incendiary Cloud]]*                      | Conjuration   |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Power Word Stun\|Power Word Stun]]*                       | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Sunburst\|Sunburst]]*                              | Evocation     |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Gate\|Gate]]*                                  | Conjuration   |  C, M   |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Meteor Swarm\|Meteor Swarm]]*                          | Evocation     |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Kill\|Power Word Kill]]*                       | Enchantment   |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Time Stop\|Time Stop]]*                             | Transmutation |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Wish\|Wish]]*                                  | Conjuration   |    -    |
> #### Warlock Spell List
> | Level | Spell                                   | School        | Special |
> | :---: | --------------------------------------- | ------------- | :-----: |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Chill Touch\|Chill Touch]]*                       | Necromancy    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Eldritch Blast\|Eldritch Blast]]*                    | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mage Hand\|Mage Hand]]*                         | Conjuration   |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Minor Illusion\|Minor Illusion]]*                    | Illusion      |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Poison Spray\|Poison Spray]]*                      | Necromancy    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Prestidigitation\|Prestidigitation]]*                  | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/True Strike\|True Strike]]*                       | Divination    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bane\|Bane]]*                              | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Charm Person\|Charm Person]]*                      | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Comprehend Languages\|Comprehend Languages]]*              | Divination    |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic\|Detect Magic]]*                      | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Expeditious Retreat\|Expeditious Retreat]]*               | Transmutation |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hellish Rebuke\|Hellish Rebuke]]*                    | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hex\|Hex]]*                               | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hideous Laughter\|Hideous Laughter]]*                  | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Illusory Script\|Illusory Script]]*                   | Illusion      |  R, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Protection from Evil and Good\|Protection from Evil and Good]]*     | Abjuration    |  C, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Speak with Animals\|Speak with Animals]]*                | Divination    |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Unseen Servant\|Unseen Servant]]*                    | Conjuration   |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkness\|Darkness]]* | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enthrall\|Enthrall]]*                          | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Hold Person\|Hold Person]]*                       | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility\|Invisibility]]*                      | Illusion      |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mind Spike\|Mind Spike]]*                        | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mirror Image\|Mirror Image]]*                      | Illusion      |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Misty Step\|Misty Step]]*                        | Conjuration   |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Ray of Enfeeblement\|Ray of Enfeeblement]]*               | Necromancy    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spider Climb\|Spider Climb]]*                      | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Suggestion\|Suggestion]]*                        | Enchantment   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Counterspell\|Counterspell]]*                      | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic\|Dispel Magic]]*                      | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fear\|Fear]]*                              | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fly\|Fly]]*                               | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Gaseous Form\|Gaseous Form]]*                      | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Hypnotic Pattern\|Hypnotic Pattern]]*                  | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Magic Circle\|Magic Circle]]*                      | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Major Image\|Major Image]]*                       | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Remove Curse\|Remove Curse]]*                      | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tongues\|Tongues]]*                           | Divination    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Vampiric Touch\|Vampiric Touch]]*                    | Necromancy    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Banishment\|Banishment]]*                        | Abjuration    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Blight\|Blight]]*                            | Necromancy    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Charm Monster\|Charm Monster]]*                     | Enchantment   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dimension Door\|Dimension Door]]*                    | Conjuration   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Hallucinatory Terrain\|Hallucinatory Terrain]]*             | Illusion      |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Contact Other Plane\|Contact Other Plane]]*               | Divination    |    R    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dream\|Dream]]*                             | Illusion      |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Hold Monster\|Hold Monster]]*                      | Enchantment   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mislead\|Mislead]]*                           | Illusion      |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Planar Binding\|Planar Binding]]*                    | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Scrying\|Scrying]]*                           | Divination    |  C, M   |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Teleportation Circle\|Teleportation Circle]]*              | Conjuration   |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Circle of Death\|Circle of Death]]*                   | Necromancy    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Create Undead\|Create Undead]]*                     | Necromancy    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Eyebite\|Eyebite]]*                           | Necromancy    |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/True Seeing\|True Seeing]]*                       | Divination    |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Etherealness\|Etherealness]]*                      | Conjuration   |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Finger of Death\|Finger of Death]]*                   | Necromancy    |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Forcecage\|Forcecage]]*                         | Evocation     |  C, M   |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Plane Shift\|Plane Shift]]*                       | Conjuration   |    M    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Befuddlement\|Befuddlement]]*                      | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Demiplane\|Demiplane]]*                         | Conjuration   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Dominate Monster\|Dominate Monster]]*                  | Enchantment   |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Glibness\|Glibness]]*                          | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Power Word Stun\|Power Word Stun]]*                   | Enchantment   |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Astral Projection\|Astral Projection]]*                 | Necromancy    |    M    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Foresight\|Foresight]]*                         | Divination    |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Gate\|Gate]]*                              | Conjuration   |  C, M   |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Imprisonment\|Imprisonment]]*                      | Abjuration    |    M    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Kill\|Power Word Kill]]*                   | Enchantment   |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/True Polymorph\|True Polymorph]]*                    | Transmutation |    C    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Weird\|Weird]]*                             | Illusion      |    C    |
> #### Wizard Spell List
> | Level | Spell                                       | School        | Special |
> | :---: | ------------------------------------------- | ------------- | :-----: |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Acid Splash\|Acid Splash]]*                           | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Chill Touch\|Chill Touch]]*                           | Necromancy    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Dancing Lights\|Dancing Lights]]*                        | Illusion      |    C    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Elementalism\|Elementalism]]*                          | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Fire Bolt\|Fire Bolt]]*                             | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Light\|Light]]*           | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mage Hand\|Mage Hand]]*                             | Conjuration   |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mending\|Mending]]*                               | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Message\|Message]]*                               | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Minor Illusion\|Minor Illusion]]*                        | Illusion      |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Poison Spray\|Poison Spray]]*                          | Necromancy    |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Prestidigitation\|Prestidigitation]]*                      | Transmutation |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Ray of Frost\|Ray of Frost]]*                          | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Shocking Grasp\|Shocking Grasp]]*                        | Evocation     |    -    |
> |   0   | *[[== SRDs ==/Compendium/5.5e/Spells/Cantrip/True Strike\|True Strike]]*                           | Divination    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Alarm\|Alarm]]*                                 | Abjuration    |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Burning Hands\|Burning Hands]]*                         | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Charm Person\|Charm Person]]*                          | Enchantment   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Chromatic Orb\|Chromatic Orb]]*                         | Evocation     |    M    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Color Spray\|Color Spray]]*                           | Illusion      |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Comprehend Languages\|Comprehend Languages]]*                  | Divination    |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic\|Detect Magic]]*                          | Divination    |  C, R   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Disguise Self\|Disguise Self]]*                         | Illusion      |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Expeditious Retreat\|Expeditious Retreat]]*                   | Transmutation |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/False Life\|False Life]]*                            | Necromancy    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Feather Fall\|Feather Fall]]*                          | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Find Familiar\|Find Familiar]]*                         | Conjuration   |  R, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Floating Disk\|Floating Disk]]*                         | Conjuration   |    R    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Fog Cloud\|Fog Cloud]]*                             | Conjuration   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Grease\|Grease]]*                                | Conjuration   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hideous Laughter\|Hideous Laughter]]*                      | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ice Knife\|Ice Knife]]*                             | Conjuration   |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Identify\|Identify]]*                              | Divination    |  R, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Illusory Script\|Illusory Script]]*                       | Illusion      |  R, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Jump\|Jump]]*                                  | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Longstrider\|Longstrider]]*                           | Transmutation |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Mage Armor\|Mage Armor]]*                            | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Magic Missile\|Magic Missile]]*                         | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Protection from Evil and Good\|Protection from Evil and Good]]*         | Abjuration    |  C, M   |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ray of Sickness\|Ray of Sickness]]*                       | Necromancy    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield\|Shield]]*         | Abjuration    |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Silent Image\|Silent Image]]*                          | Illusion      |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Sleep\|Sleep]]*                                 | Enchantment   |    C    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Thunderwave\|Thunderwave]]*                           | Evocation     |    -    |
> |   1   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Unseen Servant\|Unseen Servant]]*                        | Conjuration   |    R    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Acid Arrow\|Acid Arrow]]*                            | Evocation     |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Alter Self\|Alter Self]]*                            | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Arcane Lock\|Arcane Lock]]*                           | Abjuration    |    M    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Arcanist's Magic Aura\|Arcanist's Magic Aura]]*                 | Illusion      |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Augury\|Augury]]*                                | Divination    |  R, M   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blindness + Deafness\|Blindness + Deafness]]*                  | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blur\|Blur]]*                                  | Illusion      |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Continual Flame\|Continual Flame]]*                       | Evocation     |    M    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkness\|Darkness]]*     | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkvision\|Darkvision]]* | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Detect Thoughts\|Detect Thoughts]]*                       | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Dragon's Breath\|Dragon's Breath]]*                       | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enhance Ability\|Enhance Ability]]*                       | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enlarge + Reduce\|Enlarge + Reduce]]*                      | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Flaming Sphere\|Flaming Sphere]]*                        | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gentle Repose\|Gentle Repose]]*                         | Necromancy    |  R, M   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gust of Wind\|Gust of Wind]]*                          | Evocation     |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Hold Person\|Hold Person]]*                           | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility\|Invisibility]]*                          | Illusion      |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Knock\|Knock]]*                                 | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Levitate\|Levitate]]*                              | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Object\|Locate Object]]*                         | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Mouth\|Magic Mouth]]*                           | Illusion      |  R, M   |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Weapon\|Magic Weapon]]*                          | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mind Spike\|Mind Spike]]*                            | Divination    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mirror Image\|Mirror Image]]*                          | Illusion      |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Misty Step\|Misty Step]]*                            | Conjuration   |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Phantasmal Force\|Phantasmal Force]]*                      | Illusion      |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Ray of Enfeeblement\|Ray of Enfeeblement]]*                   | Necromancy    |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Rope Trick\|Rope Trick]]*                            | Transmutation |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Scorching Ray\|Scorching Ray]]*                         | Evocation     |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/See Invisibility\|See Invisibility]]*                      | Divination    |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Shatter\|Shatter]]*                               | Evocation     |    -    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spider Climb\|Spider Climb]]*                          | Transmutation |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Suggestion\|Suggestion]]*                            | Enchantment   |    C    |
> |   2   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 2/Web\|Web]]*                                   | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Animate Dead\|Animate Dead]]*                          | Necromancy    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Bestow Curse\|Bestow Curse]]*                          | Necromancy    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Blink\|Blink]]*                                 | Transmutation |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Clairvoyance\|Clairvoyance]]*                          | Divination    |  C, M   |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Counterspell\|Counterspell]]*                          | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic\|Dispel Magic]]*                          | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fear\|Fear]]*                                  | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fireball\|Fireball]]*                              | Evocation     |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fly\|Fly]]*                                   | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Gaseous Form\|Gaseous Form]]*                          | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Glyph of Warding\|Glyph of Warding]]*                      | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Haste\|Haste]]*                                 | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Hypnotic Pattern\|Hypnotic Pattern]]*                      | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Lightning Bolt\|Lightning Bolt]]*                        | Evocation     |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Magic Circle\|Magic Circle]]*                          | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Major Image\|Major Image]]*                           | Illusion      |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Nondetection\|Nondetection]]*                          | Abjuration    |    M    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Phantom Steed\|Phantom Steed]]*                         | Illusion      |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Protection from Energy\|Protection from Energy]]*                | Abjuration    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Remove Curse\|Remove Curse]]*                          | Abjuration    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sending\|Sending]]*                               | Divination    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sleet Storm\|Sleet Storm]]*                           | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Slow\|Slow]]*             | Transmutation |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Dead\|Speak with Dead]]*                       | Necromancy    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Stinking Cloud\|Stinking Cloud]]*                        | Conjuration   |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tiny Hut\|Tiny Hut]]*                              | Evocation     |    R    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tongues\|Tongues]]*                               | Divination    |    -    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Vampiric Touch\|Vampiric Touch]]*                        | Necromancy    |    C    |
> |   3   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Breathing\|Water Breathing]]*                       | Transmutation |    R    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Arcane Eye\|Arcane Eye]]*                            | Divination    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Banishment\|Banishment]]*                            | Abjuration    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Black Tentacles\|Black Tentacles]]*                       | Conjuration   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Blight\|Blight]]*                                | Necromancy    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Charm Monster\|Charm Monster]]*                         | Enchantment   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Confusion\|Confusion]]*                             | Enchantment   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Conjure Minor Elementals\|Conjure Minor Elementals]]*              | Conjuration   |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Control Water\|Control Water]]*                         | Transmutation |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dimension Door\|Dimension Door]]*                        | Conjuration   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Divination\|Divination]]*                            | Divination    |  R, M   |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Fabricate\|Fabricate]]*                             | Transmutation |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Faithful Hound\|Faithful Hound]]*                        | Conjuration   |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Fire Shield\|Fire Shield]]*                           | Evocation     |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Greater Invisibility\|Greater Invisibility]]*                  | Illusion      |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Hallucinatory Terrain\|Hallucinatory Terrain]]*                 | Illusion      |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Ice Storm\|Ice Storm]]*                             | Evocation     |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Locate Creature\|Locate Creature]]*                       | Divination    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Phantasmal Killer\|Phantasmal Killer]]*                     | Illusion      |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Polymorph\|Polymorph]]*                             | Transmutation |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Private Sanctum\|Private Sanctum]]*                       | Abjuration    |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Resilient Sphere\|Resilient Sphere]]*                      | Abjuration    |    C    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Secret Chest\|Secret Chest]]*                          | Conjuration   |    M    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stone Shape\|Stone Shape]]*                           | Transmutation |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stoneskin\|Stoneskin]]*                             | Transmutation |  C, M   |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Vitriolic Sphere\|Vitriolic Sphere]]*                      | Evocation     |    -    |
> |   4   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 4/Wall of Fire\|Wall of Fire]]*                          | Evocation     |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Animate Objects\|Animate Objects]]*                       | Transmutation |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Arcane Hand\|Arcane Hand]]*                           | Evocation     |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Cloudkill\|Cloudkill]]*                             | Conjuration   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Cone of Cold\|Cone of Cold]]*                          | Evocation     |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Conjure Elemental\|Conjure Elemental]]*                     | Conjuration   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Contact Other Plane\|Contact Other Plane]]*                   | Divination    |    R    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Creation\|Creation]]*                              | Illusion      |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dominate Person\|Dominate Person]]*                       | Enchantment   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dream\|Dream]]*                                 | Illusion      |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Geas\|Geas]]*                                  | Enchantment   |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Hold Monster\|Hold Monster]]*                          | Enchantment   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Legend Lore\|Legend Lore]]*                           | Divination    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mislead\|Mislead]]*                               | Illusion      |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Modify Memory\|Modify Memory]]*                         | Enchantment   |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Passwall\|Passwall]]*                              | Transmutation |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Planar Binding\|Planar Binding]]*                        | Abjuration    |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Scrying\|Scrying]]*                               | Divination    |  C, M   |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Seeming\|Seeming]]*                               | Illusion      |    -    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Summon Dragon\|Summon Dragon]]*                         | Conjuration   |  C, M   |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Telekinesis\|Telekinesis]]*                           | Transmutation |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Telepathic Bond\|Telepathic Bond]]*                       | Divination    |    R    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Teleportation Circle\|Teleportation Circle]]*                  | Conjuration   |    M    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Wall of Force\|Wall of Force]]*                         | Evocation     |    C    |
> |   5   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 5/Wall of Stone\|Wall of Stone]]*                         | Evocation     |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Chain Lightning\|Chain Lightning]]*                       | Evocation     |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Circle of Death\|Circle of Death]]*                       | Necromancy    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Contingency\|Contingency]]*                           | Abjuration    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Create Undead\|Create Undead]]*                         | Necromancy    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Disintegrate\|Disintegrate]]*                          | Transmutation |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Eyebite\|Eyebite]]*                               | Necromancy    |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Flesh to Stone\|Flesh to Stone]]*                        | Transmutation |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Freezing Sphere\|Freezing Sphere]]*                       | Evocation     |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Globe of Invulnerability\|Globe of Invulnerability]]*              | Abjuration    |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Guards and Wards\|Guards and Wards]]*                      | Abjuration    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Instant Summons\|Instant Summons]]*                       | Conjuration   |  R, M   |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Irresistible Dance\|Irresistible Dance]]*                    | Enchantment   |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Magic Jar\|Magic Jar]]*                             | Necromancy    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Mass Suggestion\|Mass Suggestion]]*                       | Enchantment   |    -    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Move Earth\|Move Earth]]*                            | Transmutation |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Programmed Illusion\|Programmed Illusion]]*                   | Illusion      |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Sunbeam\|Sunbeam]]*                               | Evocation     |    C    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/True Seeing\|True Seeing]]*                           | Divination    |    M    |
> |   6   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 6/Wall of Ice\|Wall of Ice]]*                           | Evocation     |    C    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Arcane Sword\|Arcane Sword]]*                          | Evocation     |  C, M   |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Delayed Blast Fireball\|Delayed Blast Fireball]]*                | Evocation     |    C    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Etherealness\|Etherealness]]*                          | Conjuration   |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Finger of Death\|Finger of Death]]*                       | Necromancy    |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Forcecage\|Forcecage]]*                             | Evocation     |  C, M   |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Magnificent Mansion\|Magnificent Mansion]]*                   | Conjuration   |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Mirage Arcane\|Mirage Arcane]]*                         | Illusion      |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Plane Shift\|Plane Shift]]*                           | Conjuration   |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Prismatic Spray\|Prismatic Spray]]*                       | Evocation     |    -    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Project Image\|Project Image]]*                         | Illusion      |  C, M   |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Reverse Gravity\|Reverse Gravity]]*                       | Transmutation |    C    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Sequester\|Sequester]]*                             | Transmutation |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Simulacrum\|Simulacrum]]*                            | Illusion      |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Symbol\|Symbol]]*                                | Abjuration    |    M    |
> |   7   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 7/Teleport\|Teleport]]*                              | Conjuration   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Antimagic Field\|Antimagic Field]]*                       | Abjuration    |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Antipathy + Sympathy\|Antipathy + Sympathy]]*                  | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Befuddlement\|Befuddlement]]*                          | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Clone\|Clone]]*                                 | Necromancy    |    M    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Control Weather\|Control Weather]]*                       | Transmutation |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Demiplane\|Demiplane]]*                             | Conjuration   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Dominate Monster\|Dominate Monster]]*                      | Enchantment   |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Incendiary Cloud\|Incendiary Cloud]]*                      | Conjuration   |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Maze\|Maze]]*                                  | Conjuration   |    C    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Mind Blank\|Mind Blank]]*                            | Abjuration    |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Power Word Stun\|Power Word Stun]]*                       | Enchantment   |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Sunburst\|Sunburst]]*                              | Evocation     |    -    |
> |   8   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 8/Telepathy\|Telepathy]]*   | Divination    |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Astral Projection\|Astral Projection]]*                     | Necromancy    |    M    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Foresight\|Foresight]]*                             | Divination    |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Gate\|Gate]]*                                  | Conjuration   |  C, M   |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Imprisonment\|Imprisonment]]*                          | Abjuration    |    M    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Meteor Swarm\|Meteor Swarm]]*                          | Evocation     |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Kill\|Power Word Kill]]*                       | Enchantment   |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Prismatic Wall\|Prismatic Wall]]*                        | Abjuration    |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Shapechange\|Shapechange]]*                           | Transmutation |  C, M   |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Time Stop\|Time Stop]]*                             | Transmutation |    -    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/True Polymorph\|True Polymorph]]*                        | Transmutation |    C    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Weird\|Weird]]*                                 | Illusion      |    C    |
> |   9   | *[[== SRDs ==/Compendium/5.5e/Spells/Level 9/Wish\|Wish]]*                                  | Conjuration   |    -    |
> #### Casting Time
> Most spells require the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action to cast, but some spells require a Bonus Action, a Reaction, or 1 minute or more. A spell’s Casting Time entry specifies which of those is required.
> #### One Spell with a Spell Slot per Turn
> On a turn, you can expend only one spell slot to cast a spell. This rule means you can’t, for example, cast a spell with a spell slot using the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action and another one using a Bonus Action on the same turn.
> #### Reaction and Bonus Action Triggers
> A spell that has a casting time of a Reaction is cast in response to a trigger that is defined in the spell’s Casting Time entry. Some spells that have a casting time of a Bonus Action are also cast in response to a trigger defined in the spell.
> #### Longer Casting Times
> Certain spells - including a spell cast as a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Ritual|Ritual]] - require more time to cast: minutes or even hours. While you cast a spell with a casting time of 1 minute or more, you must take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action on each of your turns, and you must maintain [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration|Concentration]] while you do so. If your Concentration is broken, the spell fails, but you don’t expend a spell slot. To cast the spell again, you must start over.
> #### Range
> A spell’s range indicates how far from the spellcaster the spell’s effect can originate, and the spell’s description specifies which part of the effect is limited by the range. A range usually takes one of the following forms:
>
> **Distance.** The range is expressed in feet.
>
> **Touch.** The spell’s effect originates on something, as defined by the spell, that the spellcaster must touch within their reach.
>
> **Self.** The spell is cast on the spellcaster or emanates from them, as specified in the spell.
>
> If a spell has movable effects, they aren’t restricted by its range unless the spell’s description says otherwise.
> #### Components
> A spell’s components are physical requirements the spellcaster must meet to cast the spell. Each spell’s description indicates whether it requires Verbal (V), Somatic (S), or Material (M) components. If the spellcaster can’t provide one or more of a spell’s components, the spellcaster can’t cast the spell.
>
> ***Verbal (V).*** A Verbal component is the chanting of esoteric words that sound like nonsense to the uninitiated. The words must be uttered in a normal speaking voice. The words themselves aren’t the source of the spell’s power; rather, the particular combination of sounds, with specific pitch and resonance, sets the threads of magic in motion. Thus, a creature who is gagged or in an area of magical silence can’t cast a spell with a Verbal component.
>
> ***Somatic (S).*** A Somatic component is a forceful gesticulation or an intricate set of gestures. A spellcaster must use at least one of their hands to perform these movements.
>
> ***Material (M).*** A Material component is a particular material used in a spell’s casting, as specified in parentheses in the Components entry. These materials aren’t consumed by the spell unless the spell’s description states otherwise. The spellcaster must have a hand free to access them, but it can be the same hand used to perform Somatic components, if any.
>
> If a spell doesn’t consume its materials and doesn’t specify a cost for them, a spellcaster can use a [[== SRDs ==/Compendium/5.5e/Items/Adventuring Gear/Component Pouch|Component Pouch]] instead of providing the materials specified in the spell, or the spellcaster can substitute a Spellcasting Focus if the caster has a feature that allows that substitution. To use a Component Pouch, you must have a hand free to reach into it, and to use a Spellcasting Focus, you must hold it unless its description says otherwise.
> #### Duration
> A spell’s duration is the length of time the spell persists after it is cast. A duration typically takes one of the following forms:
>
> **Concentration.** A duration that requires [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Concentration|Concentration]] follows the Concentration rules.
>
> **Instantaneous.** An instantaneous duration means the spell’s magic appears only for a moment and then disappears.
>
> **Time Span.** A duration that provides a time span specifies how long the spell lasts in rounds, minutes, hours, or the like. For example, a Duration entry might say “1 minute,” meaning the spell ends after 1 minute has passed. While a time-span spell that you cast is ongoing, you can dismiss it (no action required) if you don’t have the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Incapacitated|Incapacitated]] condition.
> #### Effects
> The effects of a spell are detailed after its duration entry. Those details present exactly what the spell does, which ignores mundane physical laws; any outcomes beyond those effects are under the DM’s purview. Whatever the effects, they typically deal with targets, saving throws, attack rolls, or all three, each of which is detailed below.
> #### Targets
> A typical spell requires the caster to pick one or more targets to be affected by the spell’s magic. A spell’s description says whether the spell targets creatures, objects, or something else.
>
> ***A Clear Path to the Target.*** To target something with a spell, a caster must have a clear path to it, so it can’t be behind [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Total Cover|Total Cover]].
>
> ***Targeting Yourself.*** If a spell targets a creature of your choice, you can choose yourself unless the creature must be Hostile or specifically a creature other than you.
>
> ***Areas of Effect.*** Some spells, such as *[[== SRDs ==/Compendium/5.5e/Spells/Level 1/Thunderwave|Thunderwave]]*, cover an area called an [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Areas of Effect|area of effect]]. The area determines what the spell targets. The description of a spell specifies whether it has an area of effect, which is typically one of these shapes: [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cone|Cone]], [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cube|Cube]], [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Cylinder|Cylinder]], [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Emanation|Emanation]], [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Line|Line]], or [[== SRDs ==/Compendium/5.5e/Rules/Areas of Effect/Sphere|Sphere]].
>
> ***Awareness of Being Targeted.*** Unless a spell has a perceptible effect, a creature doesn’t know it was targeted by the spell. An effect like lightning is obvious, but a more subtle effect, such as an attempt to read thoughts, goes unnoticed unless a spell’s description says otherwise.
>
> ***Invalid Targets.*** If you cast a spell on someone or something that can’t be affected by it, nothing happens to that target, but if you used a spell slot to cast the spell, the slot is still expended. If the spell normally has no effect on a target that succeeds on a saving throw, the invalid target appears to have succeeded on its saving throw, even though it didn’t attempt one (giving no hint that the creature is an invalid target). Otherwise, you perceive that the spell did nothing to the target.
> #### Saving Throws
> Many spells specify that a target makes a saving throw to avoid some or all of a spell’s effects. The spell specifies the ability that the target uses for the save and what happens on a success or failure. Here’s how to calculate the DC for your spells:
> **Spell save DC** = 8 + your spellcasting ability modifier + your Proficiency Bonus
> #### Attack Rolls
> Some spells require the caster to make an attack roll to determine whether the spell hits a target. Here’s how to calculate the attack modifier for your spells:
> **Spell attack modifier** = your spellcasting ability modifier + your Proficiency Bonus
> #### Combining Spell Effects
> The effects of different spells add together while their durations overlap. In contrast, the effects of the same spell cast multiple times don’t combine. Instead, the most potent effect - such as the highest bonus - from those castings applies while their durations overlap. The most recent effect applies if the castings are equally potent and their durations overlap.
> #### Identifying an Ongoing Spell
> You can try to identify a non-instantaneous spell by its observable effects if its duration is ongoing. To identify it, you must take the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Study|Study]] action and succeed on a DC 15 Intelligence ([[== SRDs ==/Compendium/5.5e/Rules/Skills/Arcana|Arcana]]) check.
>
> #### Spell Index
>
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Acid Arrow|Acid Arrow]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Acid Splash|Acid Splash]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Aid|Aid]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Alarm|Alarm]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Alter Self|Alter Self]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Animal Friendship|Animal Friendship]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Animal Messenger|Animal Messenger]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Animal Shapes|Animal Shapes]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Animate Dead|Animate Dead]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Animate Objects|Animate Objects]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Antilife Shell|Antilife Shell]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Antimagic Field|Antimagic Field]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Antipathy + Sympathy|Antipathy + Sympathy]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Arcane Eye|Arcane Eye]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Arcane Gate|Arcane Gate]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Arcane Hand|Arcane Hand]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Arcane Lock|Arcane Lock]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Arcane Sword|Arcane Sword]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Arcane Vigor|Arcane Vigor]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Arcanist's Magic Aura|Arcanist's Magic Aura]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Armor of Agathys|Armor of Agathys]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Arms of Hadar|Arms of Hadar]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Astral Projection|Astral Projection]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Augury|Augury]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Aura of Life|Aura of Life]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Aura of Purity|Aura of Purity]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Aura of Vitality|Aura of Vitality]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Awaken|Awaken]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bane|Bane]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Banishing Smite|Banishing Smite]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Banishment|Banishment]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Barkskin|Barkskin]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Beacon of Hope|Beacon of Hope]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Beast Sense|Beast Sense]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Befuddlement|Befuddlement]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Bestow Curse|Bestow Curse]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Black Tentacles|Black Tentacles]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Blade Barrier|Blade Barrier]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Blade Ward|Blade Ward]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Bless|Bless]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Blight|Blight]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Blinding Smite|Blinding Smite]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blindness + Deafness|Blindness + Deafness]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Blink|Blink]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Blur|Blur]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Burning Hands|Burning Hands]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Call Lightning|Call Lightning]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Calm Emotions|Calm Emotions]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Chain Lightning|Chain Lightning]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Charm Monster|Charm Monster]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Charm Person|Charm Person]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Chill Touch|Chill Touch]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Chromatic Orb|Chromatic Orb]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Circle of Death|Circle of Death]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Circle of Power|Circle of Power]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Clairvoyance|Clairvoyance]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Clone|Clone]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Cloud of Daggers|Cloud of Daggers]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Cloudkill|Cloudkill]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Color Spray|Color Spray]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Command|Command]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Commune|Commune]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Commune with Nature|Commune with Nature]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Compelled Duel|Compelled Duel]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Comprehend Languages|Comprehend Languages]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Compulsion|Compulsion]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Cone of Cold|Cone of Cold]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Confusion|Confusion]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Conjure Animals|Conjure Animals]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Conjure Barrage|Conjure Barrage]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Conjure Celestial|Conjure Celestial]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Conjure Elemental|Conjure Elemental]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Conjure Fey|Conjure Fey]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Conjure Minor Elementals|Conjure Minor Elementals]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Conjure Volley|Conjure Volley]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Conjure Woodland Beings|Conjure Woodland Beings]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Contact Other Plane|Contact Other Plane]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Contagion|Contagion]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Contingency|Contingency]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Continual Flame|Continual Flame]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Control Water|Control Water]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Control Weather|Control Weather]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Cordon of Arrows|Cordon of Arrows]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Counterspell|Counterspell]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Create Food and Water|Create Food and Water]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Create or Destroy Water|Create or Destroy Water]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Create Undead|Create Undead]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Creation|Creation]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Crown of Madness|Crown of Madness]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Crusader’s Mantle|Crusader’s Mantle]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Cure Wounds|Cure Wounds]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Dancing Lights|Dancing Lights]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkness|Darkness]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Darkvision|Darkvision]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Daylight|Daylight]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Death Ward|Death Ward]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Delayed Blast Fireball|Delayed Blast Fireball]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Demiplane|Demiplane]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Destructive Wave|Destructive Wave]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Evil and Good|Detect Evil and Good]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Magic|Detect Magic]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Detect Poison and Disease|Detect Poison and Disease]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Detect Thoughts|Detect Thoughts]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dimension Door|Dimension Door]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Disguise Self|Disguise Self]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Disintegrate|Disintegrate]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dispel Evil and Good|Dispel Evil and Good]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Dispel Magic|Dispel Magic]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Dissonant Whispers|Dissonant Whispers]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Divination|Divination]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Divine Favor|Divine Favor]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Divine Smite|Divine Smite]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Divine Word|Divine Word]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Dominate Beast|Dominate Beast]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Dominate Monster|Dominate Monster]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dominate Person|Dominate Person]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Dragon's Breath|Dragon's Breath]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Dream|Dream]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Druidcraft|Druidcraft]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Earthquake|Earthquake]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Eldritch Blast|Eldritch Blast]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Elemental Weapon|Elemental Weapon]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Elementalism|Elementalism]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enhance Ability|Enhance Ability]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enlarge + Reduce|Enlarge + Reduce]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ensnaring Strike|Ensnaring Strike]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Entangle|Entangle]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Enthrall|Enthrall]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Etherealness|Etherealness]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Expeditious Retreat|Expeditious Retreat]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Eyebite|Eyebite]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Fabricate|Fabricate]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Faerie Fire|Faerie Fire]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Faithful Hound|Faithful Hound]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/False Life|False Life]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fear|Fear]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Feather Fall|Feather Fall]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Feign Death|Feign Death]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Find Familiar|Find Familiar]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Find Steed|Find Steed]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Find the Path|Find the Path]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Find Traps|Find Traps]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Finger of Death|Finger of Death]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Fire Bolt|Fire Bolt]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Fire Shield|Fire Shield]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Fire Storm|Fire Storm]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fireball|Fireball]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Flame Blade|Flame Blade]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Flame Strike|Flame Strike]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Flaming Sphere|Flaming Sphere]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Flesh to Stone|Flesh to Stone]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Floating Disk|Floating Disk]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Fly|Fly]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Fog Cloud|Fog Cloud]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Forbiddance|Forbiddance]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Forcecage|Forcecage]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Foresight|Foresight]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Fount of Moonlight|Fount of Moonlight]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Freedom of Movement|Freedom of Movement]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Freezing Sphere|Freezing Sphere]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Friends|Friends]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Gaseous Form|Gaseous Form]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Gate|Gate]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Geas|Geas]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gentle Repose|Gentle Repose]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Giant Insect|Giant Insect]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Glibness|Glibness]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Globe of Invulnerability|Globe of Invulnerability]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Glyph of Warding|Glyph of Warding]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Goodberry|Goodberry]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Grasping Vine|Grasping Vine]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Grease|Grease]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Greater Invisibility|Greater Invisibility]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Greater Restoration|Greater Restoration]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Guardian of Faith|Guardian of Faith]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Guards and Wards|Guards and Wards]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Guidance|Guidance]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Guiding Bolt|Guiding Bolt]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Gust of Wind|Gust of Wind]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Hail of Thorns|Hail of Thorns]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Hallow|Hallow]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Hallucinatory Terrain|Hallucinatory Terrain]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Harm|Harm]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Haste|Haste]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Heal|Heal]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Healing Word|Healing Word]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Heat Metal|Heat Metal]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hellish Rebuke|Hellish Rebuke]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Heroes' Feast|Heroes' Feast]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Heroism|Heroism]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hex|Hex]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hideous Laughter|Hideous Laughter]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Hold Monster|Hold Monster]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Hold Person|Hold Person]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Holy Aura|Holy Aura]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Hunger of Hadar|Hunger of Hadar]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Hunter's Mark|Hunter's Mark]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Hypnotic Pattern|Hypnotic Pattern]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ice Knife|Ice Knife]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Ice Storm|Ice Storm]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Identify|Identify]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Illusory Script|Illusory Script]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Imprisonment|Imprisonment]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Incendiary Cloud|Incendiary Cloud]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Inflict Wounds|Inflict Wounds]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Insect Plague|Insect Plague]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Instant Summons|Instant Summons]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Invisibility|Invisibility]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Irresistible Dance|Irresistible Dance]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Jallarzi’s Storm of Radiance|Jallarzi’s Storm of Radiance]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Jump|Jump]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Knock|Knock]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Legend Lore|Legend Lore]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Lesser Restoration|Lesser Restoration]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Levitate|Levitate]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Light|Light]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Lightning Arrow|Lightning Arrow]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Lightning Bolt|Lightning Bolt]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Animals or Plants|Locate Animals or Plants]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Locate Creature|Locate Creature]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Locate Object|Locate Object]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Longstrider|Longstrider]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Mage Armor|Mage Armor]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mage Hand|Mage Hand]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Magic Circle|Magic Circle]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Magic Jar|Magic Jar]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Magic Missile|Magic Missile]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Mouth|Magic Mouth]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Magic Weapon|Magic Weapon]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Magnificent Mansion|Magnificent Mansion]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Major Image|Major Image]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mass Cure Wounds|Mass Cure Wounds]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Mass Heal|Mass Heal]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Mass Healing Word|Mass Healing Word]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Mass Suggestion|Mass Suggestion]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Maze|Maze]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Meld into Stone|Meld into Stone]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Mending|Mending]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Message|Message]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Meteor Swarm|Meteor Swarm]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Mind Blank|Mind Blank]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Mind Sliver|Mind Sliver]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mind Spike|Mind Spike]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Minor Illusion|Minor Illusion]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Mirage Arcane|Mirage Arcane]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Mirror Image|Mirror Image]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Mislead|Mislead]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Misty Step|Misty Step]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Modify Memory|Modify Memory]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Moonbeam|Moonbeam]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Move Earth|Move Earth]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Nondetection|Nondetection]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Pass without Trace|Pass without Trace]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Passwall|Passwall]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Phantasmal Force|Phantasmal Force]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Phantasmal Killer|Phantasmal Killer]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Phantom Steed|Phantom Steed]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Planar Ally|Planar Ally]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Planar Binding|Planar Binding]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Plane Shift|Plane Shift]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Plant Growth|Plant Growth]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Poison Spray|Poison Spray]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Polymorph|Polymorph]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Power Word Fortify|Power Word Fortify]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Heal|Power Word Heal]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Power Word Kill|Power Word Kill]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Power Word Stun|Power Word Stun]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Prayer of Healing|Prayer of Healing]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Prestidigitation|Prestidigitation]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Prismatic Spray|Prismatic Spray]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Prismatic Wall|Prismatic Wall]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Private Sanctum|Private Sanctum]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Produce Flame|Produce Flame]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Programmed Illusion|Programmed Illusion]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Project Image|Project Image]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Protection from Energy|Protection from Energy]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Protection from Evil and Good|Protection from Evil and Good]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Protection from Poison|Protection from Poison]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Purify Food and Drink|Purify Food and Drink]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Raise Dead|Raise Dead]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Ray of Enfeeblement|Ray of Enfeeblement]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Ray of Frost|Ray of Frost]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Ray of Sickness|Ray of Sickness]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Regenerate|Regenerate]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Reincarnate|Reincarnate]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Remove Curse|Remove Curse]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Resilient Sphere|Resilient Sphere]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Resistance|Resistance]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Resurrection|Resurrection]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Reverse Gravity|Reverse Gravity]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Revivify|Revivify]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Rope Trick|Rope Trick]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Sacred Flame|Sacred Flame]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Sanctuary|Sanctuary]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Scorching Ray|Scorching Ray]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Scrying|Scrying]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Searing Smite|Searing Smite]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Secret Chest|Secret Chest]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/See Invisibility|See Invisibility]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Seeming|Seeming]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sending|Sending]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Sequester|Sequester]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Shapechange|Shapechange]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Shatter|Shatter]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield|Shield]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Shield of Faith|Shield of Faith]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Shillelagh|Shillelagh]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Shining Smite|Shining Smite]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Shocking Grasp|Shocking Grasp]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Silence|Silence]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Silent Image|Silent Image]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Simulacrum|Simulacrum]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Sleep|Sleep]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Sleet Storm|Sleet Storm]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Slow|Slow]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Sorcerous Burst|Sorcerous Burst]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Spare the Dying|Spare the Dying]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Speak with Animals|Speak with Animals]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Dead|Speak with Dead]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Speak with Plants|Speak with Plants]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Spells|Spells]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spider Climb|Spider Climb]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spike Growth|Spike Growth]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Spirit Guardians|Spirit Guardians]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Spiritual Weapon|Spiritual Weapon]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Staggering Smite|Staggering Smite]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Starry Wisp|Starry Wisp]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Steel Wind Strike|Steel Wind Strike]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Stinking Cloud|Stinking Cloud]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stone Shape|Stone Shape]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Stoneskin|Stoneskin]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Storm of Vengeance|Storm of Vengeance]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Suggestion|Suggestion]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Summon Aberration|Summon Aberration]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Summon Celestial|Summon Celestial]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Summon Construct|Summon Construct]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Summon Dragon|Summon Dragon]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Summon Elemental|Summon Elemental]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Summon Fey|Summon Fey]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Summon Fiend|Summon Fiend]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Summon Undead|Summon Undead]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Sunbeam|Sunbeam]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Sunburst|Sunburst]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Swift Quiver|Swift Quiver]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Symbol|Symbol]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Synaptic Static|Synaptic Static]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Tasha’s Bubbling Cauldron|Tasha’s Bubbling Cauldron]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Telekinesis|Telekinesis]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Telepathic Bond|Telepathic Bond]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Telepathy|Telepathy]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 7/Teleport|Teleport]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Teleportation Circle|Teleportation Circle]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Thaumaturgy|Thaumaturgy]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Thorn Whip|Thorn Whip]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Thunderclap|Thunderclap]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Thunderous Smite|Thunderous Smite]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Thunderwave|Thunderwave]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Time Stop|Time Stop]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tiny Hut|Tiny Hut]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Toll the Dead|Toll the Dead]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Tongues|Tongues]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Transport via Plants|Transport via Plants]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Tree Stride|Tree Stride]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/True Polymorph|True Polymorph]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/True Resurrection|True Resurrection]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/True Seeing|True Seeing]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/True Strike|True Strike]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 8/Tsunami|Tsunami]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 1/Unseen Servant|Unseen Servant]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Vampiric Touch|Vampiric Touch]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Cantrip/Vicious Mockery|Vicious Mockery]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Vitriolic Sphere|Vitriolic Sphere]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 4/Wall of Fire|Wall of Fire]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Wall of Force|Wall of Force]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Wall of Ice|Wall of Ice]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 5/Wall of Stone|Wall of Stone]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Wall of Thorns|Wall of Thorns]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Warding Bond|Warding Bond]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Breathing|Water Breathing]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Water Walk|Water Walk]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Web|Web]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Weird|Weird]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Wind Walk|Wind Walk]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 3/Wind Wall|Wind Wall]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 9/Wish|Wish]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Witch Bolt|Witch Bolt]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Word of Radiance|Word of Radiance]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 6/Word of Recall|Word of Recall]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Wrathful Smite|Wrathful Smite]]
> - [[== SRDs ==/Compendium/5.5e/Spells/PHB References/Yolande’s Regal Presence|Yolande’s Regal Presence]]
> - [[== SRDs ==/Compendium/5.5e/Spells/Level 2/Zone of Truth|Zone of Truth]]
>
> **Source:** [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf|Player's Handbook]]

## Source References

[[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 7 - Spells/Chapter 7 - Spells|Player's Handbook — Chapter 7: Spells]]
