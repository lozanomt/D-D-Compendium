---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Deep Water

![[Placeholder.png|320]]


Swimming through deep water (more than 100 feet deep) presents additional challenges because of the water’s pressure and cold temperature. After each hour of swimming in deep water, a creature that lacks a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Swimming|Swim]] Speed must succeed on a DC 10 Constitution saving throw or gain 1 [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]] level.
