---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: 16b7e928-f4f5-58de-943a-07283e021d84
entity_type: creature
source_ids: ["mm-2025", "srd-5.2.1"]
srd_5_2_1_pages: [279]
source_versions: ["Monster Manual", "SRD 5.2.1"]
---

# Death Dog

## Monster Manual

> [!statblock]
> ### Death Dog
>
> *Medium Monstrosity, Neutral Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p093-death-dog.png|320]]
>
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 39 (6d8 + 12)  
> **Speed** 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 14 | +2 | +2 | **Con** | 14 | +2 | +2 |
> | **Int** | 3 | -4 | -4 | **Wis** | 13 | +1 | +1 | **Cha** | 6 | -2 | -2 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +4  
> **Immunities** [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Blinded|Blinded]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Deafened|Deafened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Stunned|Stunned]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** None  
> **CR** 1 (XP 200; PB +2)  
>
> ### Actions
>
> ***Multiattack.*** The death dog makes two Bite attacks.
>
> ***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 4 (1d4 + 2) Piercing damage. If the target is a creature, it is subjected to the following effect. *Constitution Saving Throw:* DC 12. *First Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]] condition. While Poisoned, the target's Hit Point maximum doesn't return to normal when finishing a Long Rest, and it repeats the save every 24 hours that elapse, ending the effect on itself on a success. *Subsequent Failures:* The Poisoned target's Hit Point maximum decreases by 5 (1d10).
>
> **Source:** [[== SRDs ==/Sources/5.5e/Monster Manual/D&D 5.5E - Monster Manual.pdf|Monster Manual]]

## SRD 5.2.1

> [!statblock]
> ### Death Dog
>
> *Medium Monstrosity, Neutral Evil*
>
> ![[== SRDs ==/Attachments/Artwork/mm-p093-death-dog.png|320]]
>
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 39 (6d8 + 12)  
> **Speed** 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 15 | +2 | +2 | **Dex** | 14 | +2 | +2 | **Con** | 14 | +2 | +2 |
> | **Int** | 3 | -4 | -4 | **Wis** | 13 | +1 | +1 | **Cha** | 6 | -2 | -2 |
>
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Perception|Perception]] +5, [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +4  
> **Immunities** [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Blinded|Blinded]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Deafened|Deafened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Stunned|Stunned]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 15  
> **Languages** None  
> **CR** 1 (XP 200; PB +2)  
>
> ### Actions
>
> ***Multiattack.*** The death dog makes two Bite attacks.
>
> ***Bite.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 4 (1d4 + 2) Piercing damage. If the target is a creature, it is subjected to the following effect. *Constitution Saving Throw:* DC 12. *First Failure:* The target has the [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]] condition. While Poisoned, the target's Hit Point maximum doesn't return to normal when finishing a Long Rest, and it repeats the save every 24 hours that elapse, ending the effect on itself on a success. *Subsequent Failures:* The Poisoned target's Hit Point maximum decreases by 5 (1d10).
>
> **Source:** [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=279|SRD 5.2.1, p. 279]]

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=279|SRD 5.2.1, p. 279]]
