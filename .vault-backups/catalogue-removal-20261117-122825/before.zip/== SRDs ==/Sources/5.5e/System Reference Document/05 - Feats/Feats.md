---
cssclasses: [dnd-book, dnd-phb]
source_id: srd-5.2.1
source_pages: [87, 89]
---

# Feats

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=87|SRD 5.2.1, p. 87]].

### Feat Descriptions

The feats that follow are organized by category— Origin, General, Fighting Style, or Epic Boon—and alphabetized in each category.

#### Parts of a Feat

The description of a feat contains the following parts, which are presented after the feat's name.

Category.  A feat is a member of a category, which is noted in the feat. If you're instructed to choose a feat from a specific category, such as the Origin category, that category must appear under the feat's name. If you're instructed to choose a feat and no category is specified, you can choose from any category.

Prerequisite.  To take a feat, you must meet any prerequisite in its description unless a feature allows you to take the feat without the prerequisite.

If a prerequisite includes a class, you must have at least 1 level in that class to take the feat.

Benefit. The benefits of a feat are detailed after any prerequisites are listed. If you have a feat, you gain its benefits.

Repeatable. A feat can be taken only once unless its description states otherwise in a "Repeatable" subsection.

#### Origin Feats

### Alert

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/01) Origin Feats/Alert#SRD 5.2.1|Alert]]

### Magic Initiate

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/01) Origin Feats/Magic Initiate#SRD 5.2.1|Magic Initiate]]

### Savage Attacker

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/01) Origin Feats/Savage Attacker#SRD 5.2.1|Savage Attacker]]

### Skilled

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/01) Origin Feats/Skilled#SRD 5.2.1|Skilled]]

#### General Feats

### Ability Score Improvement

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/02) General Feats/Ability Score Improvement#SRD 5.2.1|Ability Score Improvement]]

### Grappler

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/02) General Feats/Grappler#SRD 5.2.1|Grappler]]

#### Fighting Style Feats

### Archery

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/03) Fighting Style Feats/Archery#SRD 5.2.1|Archery]]

### Defense

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/03) Fighting Style Feats/Defense#SRD 5.2.1|Defense]]

### Great Weapon Fighting

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/03) Fighting Style Feats/Great Weapon Fighting#SRD 5.2.1|Great Weapon Fighting]]

### Two-Weapon Fighting

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/03) Fighting Style Feats/Two-Weapon Fighting#SRD 5.2.1|Two-Weapon Fighting]]

#### Epic Boon Feats

### Boon of Combat Prowess

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/04) Epic Boon Feats/Boon of Combat Prowess#SRD 5.2.1|Boon of Combat Prowess]]

### Boon of Dimensional Travel

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/04) Epic Boon Feats/Boon of Dimensional Travel#SRD 5.2.1|Boon of Dimensional Travel]]

### Boon of Fate

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/04) Epic Boon Feats/Boon of Fate#SRD 5.2.1|Boon of Fate]]

### Boon of Irresistible Offense

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/04) Epic Boon Feats/Boon of Irresistible Offense#SRD 5.2.1|Boon of Irresistible Offense]]

### Boon of Spell Recall

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/04) Epic Boon Feats/Boon of Spell Recall#SRD 5.2.1|Boon of Spell Recall]]

### Boon of the Night Spirit

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/04) Epic Boon Feats/Boon of the Night Spirit#SRD 5.2.1|Boon of the Night Spirit]]

### Boon of Truesight

[[== SRDs ==/Compendium/5.5e/Character Options/Feats/04) Epic Boon Feats/Boon of Truesight#SRD 5.2.1|Boon of Truesight]]

## Tables and Boxed Reference Material

These extracts preserve the PDF’s table layout alongside the text above.

### Page 89 — srd-p089-table-1.png

![[== SRDs ==/Sources/5.5e/System Reference Document/Tables/srd-p089-table-1.png]]

[[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=89|Open source page 89]]
