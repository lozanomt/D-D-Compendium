---
tags: [creature, phb]
cssclasses: [dnd-book, dnd-mm]
source_book: "Player's Handbook (2024)"
source_page: 347
source_pdf_page: 350
review_status: checked-against-page-image
reviewed: 2026-11-17
---

> [!statblock]
> ## Boar
>
> *Medium Beast, Unaligned*
>
> **AC** 11 &emsp; **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Initiative|Initiative]]** +0 (10)  
> **HP** 13 (2d8 + 4)  
> **[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Speed|Speed]]** 40 ft.  
>
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 13 | +1 | +1 | **Dex** | 11 | +0 | +0 | **Con** | 14 | +2 | +2 |
> | **Int** | 2 | -4 | -4 | **Wis** | 9 | -1 | -1 | **Cha** | 5 | -3 | -3 |
>
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 9  
> **Languages** None  
> **CR** 1/4 (XP 50; PB +2)  
>
> ### Traits
>
> ***Bloodied Fury.*** While [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Bloodied|Bloodied]], the boar has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Advantage|Advantage]] on attack rolls.
>
> ### Actions
>
> ***Gore.*** *Melee [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|Attack]] Roll:* +3, reach 5 ft. *Hit:* 4 (1d6 + 1) Piercing damage. If the boar moved at least 20 feet straight toward the target immediately before the hit, the target takes an extra 3 (1d6) Piercing damage and, if it is Large or smaller, has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.

Source: [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=350|Player’s Handbook (2024), p. 347]].

[[== SRDs ==/5.5e/Player's Handbook/Appendix B - Creature Stat Blocks/Appendix B - Creature Stat Blocks|Appendix B — Creature Stat Blocks]] · [[== SRDs ==/5.5e/Monster Manual/Appendix A - Animals/Stat Blocks/Animals/Boar|Monster Manual version]]
