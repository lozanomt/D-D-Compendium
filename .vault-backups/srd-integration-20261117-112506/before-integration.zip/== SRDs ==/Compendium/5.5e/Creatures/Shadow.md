---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
entity_id: b9aa1ba9-09b4-509a-9bea-4f3da0a5ddfc
entity_type: creature
source_ids: ["mm-2025"]
---

> [!statblock]
> ## Shadow
> 
> *Medium Undead, Chaotic Evil*
> 
> ![[== SRDs ==/Attachments/Artwork/mm-p274-shadow.png|320]]
> 
> 
> **AC** 12 &emsp; **Initiative** +2 (12)  
> **HP** 27 (5d8 + 5)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 6 | -2 | -2 | **Dex** | 14 | +2 | +2 | **Con** | 13 | +1 | +1 |
> | **Int** | 6 | -2 | -2 | **Wis** | 10 | +0 | +0 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/Compendium/5.5e/Rules/Skills/Stealth|Stealth]] +6  
> **Vulnerabilities** Radiant  
> **Resistances** Acid, Cold, Fire, Lightning, Thunder  
> **Immunities** Necrotic, Poison; [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Frightened|Frightened]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Grappled|Grappled]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Paralyzed|Paralyzed]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Petrified|Petrified]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Poisoned|Poisoned]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Prone|Prone]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Restrained|Restrained]], [[== SRDs ==/Compendium/5.5e/Rules/Conditions/Unconscious|Unconscious]]  
> **Senses** [[== SRDs ==/Compendium/5.5e/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Passive Perception|Passive Perception]] 10  
> **Languages** None  
> **CR** 1/2 (XP 100; PB +2)  
> 
> ### Traits
> 
> ***Amorphous.*** The shadow can move through a space as narrow as 1 inch without expending extra movement to do so.
> 
> ***Sunlight Weakness.*** While in sunlight, the shadow has Disadvantage on D20 Tests.
> 
> ### Actions
> 
> ***Draining Swipe.*** *Melee Attack Roll:* +4, reach 5 ft. *Hit:* 5 (1d6 + 2) Necrotic damage, and the target's Strength score decreases by 1d4. The target dies if this reduces that score to 0. If a Humanoid is slain by this attack, a **Shadow** rises from the corpse 1d4 hours later.
> 
> ### Bonus Actions
> 
> ***Shadow Stealth.*** While in Dim Light or Darkness, the shadow takes the Hide action.

## Source References

- [[== SRDs ==/Sources/5.5e/Monster Manual/Appendix B - Monster Lists/Appendix B - Monsters|Monster Manual — Appendix B - Monster Lists]]
