---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 586f9786-3575-59ab-b125-5227e47d39d5
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [35]
---

# Peerless Skill

![[== SRDs ==/Attachments/Artwork/phb-p069-college-of-lore.png|320]]

When you make an ability check or attack roll and fail, you can expend one use of [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Bard/Bardic Inspiration|Bardic Inspiration]]; roll the Bardic Inspiration die, and add the number rolled to the d20, potentially turning a failure into a success. On a failure, the Bardic Inspiration isn’t expended.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=69|Player’s Handbook (2024), PDF page 69]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=70|Player’s Handbook (2024), PDF page 70]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

When you make an ability check or attack roll and fail, you can expend one use of Bardic Inspiration; roll the Bardic Inspiration die, and add the number rolled to the d20, potentially turning a failure into a success. On a failure, the Bardic Inspiration isn't expended.

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=35|SRD 5.2.1, p. 35]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=35|SRD 5.2.1, p. 35]]
