---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Hurl Through Hell

![[phb-p165-fiend-patron.png|320]]

Once per turn when you hit a creature with an attack roll, you can try to instantly transport the target through the Lower Planes. The target must succeed on a Charisma saving throw against your spell save DC, or the target disappears and hurtles through a nightmare landscape. The target takes 8d10 Psychic damage if it isn’t a Fiend, and it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Incapacitated|Incapacitated]] condition until the end of your next turn, when it returns to the space it previously occupied or the nearest unoccupied space.

Once you use this feature, you can’t use it again until you finish a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Long Rest|Long Rest]] unless you expend a [[== SRDs ==/5.5e/Player's Handbook/Chapter 3 - Character Classes/Classes/Warlock/Pact Magic|Pact Magic]] spell slot (no action required) to restore your use of it.

## Handbook source

[[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=164|Player’s Handbook (2024), PDF page 164]] · [[== SRDs ==/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=165|Player’s Handbook (2024), PDF page 165]]
