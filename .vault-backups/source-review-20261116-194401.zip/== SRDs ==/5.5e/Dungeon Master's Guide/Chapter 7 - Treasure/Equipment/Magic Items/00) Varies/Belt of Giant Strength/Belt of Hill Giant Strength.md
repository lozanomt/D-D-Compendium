---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Belt of Hill Giant Strength [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Belt of Giant Strength/Belt of Hill Giant Strength|(4,000 GP)]]
*Wondrous Item, Rare*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p239-belt-of-giant-strength.png|320]]


**Attunement:** Yes

While wearing this belt, your Strength score changes to 21. The item has no effect on you if your Strength without the belt is equal to or greater than the belt’s score.
