---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Alchemist's Supplies [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Artisan's Tools/Alchemist's Supplies|(50 GP)]]

![[Placeholder.png|320]]

**Ability:** Intelligence **Weight:** 8 lb.
[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]]: Identify a substance (DC 15), or start a fire (DC 15)
**Craft:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Acid|Acid]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Alchemist's Fire|Alchemist's Fire]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Component Pouch|Component Pouch]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Oil|Oil]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Paper|Paper]], [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Perfume|Perfume]]
