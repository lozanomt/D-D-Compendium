---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Spider's Sting

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


#### Spider’s Sting [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Equipment/Poison/Spider's Sting|(200 GP)]]
*[[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 3 - DM's Toolbox/Rules/Properties/Poison/Injury]] Poison*

A creature subjected to Spider’s Sting must succeed on a DC 13 Constitution saving throw or have the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned]] condition for 1 hour. If the creature fails the save by 5 or more, the creature also has the [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Unconscious]] condition while Poisoned in this way. The creature wakes up if it takes damage or if another creature takes an action to shake it awake.
