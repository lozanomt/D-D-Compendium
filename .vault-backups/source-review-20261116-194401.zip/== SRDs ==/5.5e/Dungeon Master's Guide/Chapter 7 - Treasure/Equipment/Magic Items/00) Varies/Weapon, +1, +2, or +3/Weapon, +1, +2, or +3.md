---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Weapon, +1, +2, or +3 [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Weapon, +1, +2, or +3/Weapon, +1, +2, or +3|(Varies)]]
*Armor (Any Simple or Martial), Varies*

![[D&D 5e 2024 Rules/z. Load Bearing Folders/Attachments/Placeholder.png|320]]


**Attunement:** No

You have a bonus to attack rolls and damage rolls made with this magic weapon. The bonus is determined by its rarity.

| Rarity                                   | Bonus |
| ---------------------------------------- | :---: |
| Uncommon  |  +1   |
| Rare      |  +2   |
| Very Rare |  +3   |
