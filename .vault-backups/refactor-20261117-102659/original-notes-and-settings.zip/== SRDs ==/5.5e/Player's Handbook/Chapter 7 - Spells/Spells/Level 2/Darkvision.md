---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Darkvision
*Level 2 Transmutation (Druid, Ranger, Sorcerer, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Touch
**Components:** V, S, M (a dried carrot)
**Duration:** 8 hours

For the duration, a willing creature you touch has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] with a range of 150 feet.
