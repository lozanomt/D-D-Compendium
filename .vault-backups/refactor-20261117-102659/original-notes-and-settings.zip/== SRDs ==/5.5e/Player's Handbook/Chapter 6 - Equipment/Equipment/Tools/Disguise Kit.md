---
tags:
  - equipment
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Disguise Kit [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Tools/Disguise Kit|(25 GP)]]

![[Placeholder.png|320]]

**Ability:** Charisma **Weight:** 3 lb.
[[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Utilize|Utilize]]: Apply makeup (DC 10)
**Craft:** [[== SRDs ==/5.5e/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Costume|Costume]]
