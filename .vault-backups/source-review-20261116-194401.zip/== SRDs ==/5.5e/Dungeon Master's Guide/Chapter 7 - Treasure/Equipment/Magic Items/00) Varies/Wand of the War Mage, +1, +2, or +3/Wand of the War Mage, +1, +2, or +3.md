---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Wand of the War Mage, +1, +2, or +3 [[D&D 5e 2024 Rules/Dungeon Master's Guide/Chapter 7 - Treasure/Equipment/Magic Items/00) Varies/Wand of the War Mage, +1, +2, or +3/Wand of the War Mage, +1, +2, or +3|(Varies)]]
*[[D&D 5e 2024 Rules/Player's Handbook/Chapter 6 - Equipment/Equipment/Adventuring Gear/Arcane Focus/Wand]], Varies*

![[D&D 5e 2024 Rules/Dungeon Master's Guide/Artwork/dmg-p325-wand-of-secrets.png|320]]


**Attunement:** By a Spellcaster

While holding this wand, you gain a bonus to spell attack rolls determined by the wand’s rarity. In addition, you ignore [[D&D 5e 2024 Rules/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Half Cover]] when making a spell attack roll.

| Rarity                                   | Bonus |
| ---------------------------------------- | :---: |
| Uncommon  |  +1   |
| Rare      |  +2   |
| Very Rare |  +3   |
