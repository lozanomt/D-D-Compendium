---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Tiger
> 
> *Large Beast, Unaligned*
> 
> ![[Placeholder.png|320]]
> 
> 
> **AC** 13 &emsp; **Initiative** +3 (13)  
> **HP** 30 (4d10 + 8)  
> **Speed** 40 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 17 | +3 | +3 | **Dex** | 16 | +3 | +3 | **Con** | 14 | +2 | +2 |
> | **Int** | 3 | -4 | -4 | **Wis** | 12 | +1 | +1 | **Cha** | 8 | -1 | -1 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +3, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +7  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 13  
> **Languages** None  
> **CR** 1 (XP 200; PB +2)  
> 
> ### Actions
> 
> ***Rend.*** *Melee Attack Roll:* +5, reach 5 ft. *Hit:* 10 (2d6 + 3) Slashing damage. If the target is a Large or smaller creature, it has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Prone|Prone]] condition.
> 
> ### Bonus Actions
> 
> ***Nimble Escape.*** The tiger takes the Disengage or Hide action.
