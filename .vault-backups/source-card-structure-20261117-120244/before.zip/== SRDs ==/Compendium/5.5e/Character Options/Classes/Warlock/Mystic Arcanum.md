---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: f4404618-05aa-5446-a4f4-953840644c44
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [72]
---

# Mystic Arcanum

![[== SRDs ==/Attachments/Artwork/phb-p155-warlock.png|320]]

Your patron grants you a magical secret called an arcanum. Choose one level 6 Warlock spell as this arcanum. You can cast your arcanum spell once without expending a spell slot, and you must finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]] before you can cast it in this way again.

As shown in the Warlock Features table, you gain another Warlock spell of your choice that can be cast in this way when you reach Warlock levels 13 (level 7 spell), 15 (level 8 spell), and 17 (level 9 spell). You regain all uses of your Mystic Arcanum when you finish a Long Rest. Whenever you gain a Warlock level, you can replace one of your arcanum spells with another Warlock spell of the same level.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=156|Player’s Handbook (2024), PDF page 156]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

Your patron grants you a magical secret called an arcanum. Choose one level 6 Warlock spell as this arcanum.

You can cast your arcanum spell once without expending a spell slot, and you must finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]] before you can cast it in this way again.

As shown in the Warlock Features table, you gain another Warlock spell of your choice that can be cast in this way when you reach Warlock levels 13 (level 7 spell), 15 (level 8 spell), and 17 (level 9 spell). You regain all uses of your Mystic Arcanum when you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]].

Whenever you gain a Warlock level, you can replace one of your arcanum spells with another Warlock spell of the same level.

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=72|SRD 5.2.1, p. 72]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=72|SRD 5.2.1, p. 72]]
