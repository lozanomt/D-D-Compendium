---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 68f3864c-22e6-5aca-87ee-f945ca81ae9c
entity_type: character-option
source_ids: ["phb-2024"]
---

# Action Surge

![[== SRDs ==/Attachments/Artwork/phb-p093-fighter.png|320]]

You can push yourself beyond your normal limits for a moment. On your turn, you can take one additional action, except the [[== SRDs ==/Compendium/5.5e/Rules/Actions/Magic|Magic]] action. Once you use this feature, you can’t do so again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Short Rest|Short]] or [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]]. Starting at level 17, you can use it twice before a rest but only once on a turn.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=94|Player’s Handbook (2024), PDF page 94]]

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
