---
tags:
  - condition
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Frightened

![[Placeholder.png|320]]


While you have the Frightened condition, you experience the following effects.

***Ability Checks and Attacks Affected.*** You have [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Disadvantage|Disadvantage]] on ability checks and attack rolls while the source of fear is within line of sight.

***Can't Approach.*** You can't willingly move closer to the source of fear.
