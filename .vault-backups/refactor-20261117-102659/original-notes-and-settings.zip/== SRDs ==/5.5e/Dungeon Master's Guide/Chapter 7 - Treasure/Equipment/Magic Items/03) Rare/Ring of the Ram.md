---
tags:
  - magicitem
cssclasses:
  - "dnd-book"
  - "dnd-dmg"
source_book: "Dungeon Master's Guide (2024)"
source_pdf_pages: [299]
review_status: "rules-summary-checked-against-page-image"
reviewed: 2026-11-16
---
# Ring of the Ram
*Ring, Rare*

![[== SRDs ==/5.5e/Dungeon Master's Guide/Artwork/dmg-p299-ring-of-the-ram.png|320]]

**Attunement:** Yes

The ring has 3 charges and regains 1d3 expended charges daily at dawn. While wearing it, take a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action and expend 1-3 charges to make a ranged spell [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Attack|attack]] against a creature you can see within 60 feet. The spectral ram attacks with a +7 bonus. On a hit, each expended charge deals 2d10 Force damage and pushes the target 5 feet away.

Alternatively, expend 1-3 charges as a Magic action to try to break a nonmagical object you can see within 60 feet that isn't worn or carried. The ring makes a Strength check with a +5 bonus for each expended charge.

## Source

[[== SRDs ==/5.5e/Dungeon Master's Guide/D&D 5.5E - Dungeon Master's Guide.pdf#page=299|p. 296 (PDF page 299)]]

*Rules summary checked against the supplied book page image; see the source for the original wording and illustration.*
