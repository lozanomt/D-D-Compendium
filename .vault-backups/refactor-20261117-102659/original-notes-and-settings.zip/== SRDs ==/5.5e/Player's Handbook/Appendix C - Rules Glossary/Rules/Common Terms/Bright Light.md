---
tags:
  - rule
cssclasses:
  - "dnd-book"
  - "dnd-phb"
---
# Bright Light

![[Placeholder.png|320]]


Bright Light is normal illumination.
