---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Roper
> 
> *Large Aberration, Neutral Evil*
> 
> ![[mm-p264-roper.png|320]]
> 
> 
> **AC** 20 &emsp; **Initiative** +5 (15)  
> **HP** 93 (11d10 + 33)  
> **Speed** 10 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Climbing|Climb]] 20 ft.  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 8 | -1 | -1 | **Con** | 17 | +3 | +3 |
> | **Int** | 7 | -2 | -2 | **Wis** | 16 | +3 | +3 | **Cha** | 6 | -2 | -2 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +6, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Stealth|Stealth]] +5  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 60 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 16  
> **Languages** None  
> **CR** 5 (XP 1,800; PB +3)  
> 
> ### Traits
> 
> ***Spider Climb.*** The roper can climb difficult surfaces, including along ceilings, without needing to make an ability check.
> 
> ### Actions
> 
> ***Multiattack.*** The roper makes two Tentacle attacks, uses Reel, and makes two Bite attacks.
> 
> ***Bite.*** *Melee Attack Roll:* +7, reach 5 ft. *Hit:* 17 (3d8 + 4) Piercing damage.
> 
> ***Tentacle.*** *Melee Attack Roll:* +7, reach 60 ft. *Hit:* The target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] condition (escape DC 14) from one of six tentacles, and the target has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Poisoned|Poisoned]] condition until the grapple ends.
> 
> The tentacle can be damaged, freeing a creature it has [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] when destroyed (AC 20, HP 10, Immunity to Poison and Psychic damage). Damaging the tentacle deals no damage to the roper, and a destroyed tentacle regrows at the start of the roper's next turn.
> 
> ***Reel.*** The roper pulls each creature [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Grappled|Grappled]] by it up to 30 feet straight toward it.
