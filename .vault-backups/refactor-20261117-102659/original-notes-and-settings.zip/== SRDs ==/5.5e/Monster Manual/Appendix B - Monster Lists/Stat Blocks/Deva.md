---
tags:
  - creature
cssclasses:
  - "dnd-book"
  - "dnd-mm"
---
> [!statblock]
> ## Deva
> 
> *Medium Celestial (Angel), Lawful Good*
> 
> ![[mm-p099-deva.png|320]]
> 
> 
> **AC** 17 &emsp; **Initiative** +4 (14)  
> **HP** 229 (27d8 + 108)  
> **Speed** 30 ft., [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Flying|Fly]] 90 ft. (hover)  
> 
> | | | MOD | SAVE | | | MOD | SAVE | | | MOD | SAVE |
> |:--|--:|--:|--:|:--|--:|--:|--:|:--|--:|--:|--:|
> | **Str** | 18 | +4 | +4 | **Dex** | 18 | +4 | +4 | **Con** | 18 | +4 | +4 |
> | **Int** | 17 | +3 | +3 | **Wis** | 20 | +5 | +9 | **Cha** | 20 | +5 | +9 |
> 
> **Skills** [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Insight|Insight]] +9, [[== SRDs ==/5.5e/Player's Handbook/Chapter 1 - Playing the Game/Rules/Skills/Perception|Perception]] +9  
> **Resistances** Radiant  
> **Immunities** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Charmed|Charmed]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Exhaustion|Exhaustion]], [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Frightened|Frightened]]  
> **Senses** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Senses/Darkvision|Darkvision]] 120 ft.; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Passive Perception|Passive Perception]] 19  
> **Languages** All; [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Telepathy|Telepathy]] 120 ft.  
> **CR** 10 (XP 5,900; PB +4)  
> 
> ### Traits
> 
> ***Exalted Restoration.*** If the deva dies outside Mount Celestia, its body disappears, and it gains a new body instantly, reviving with all its Hit Points somewhere in Mount Celestia.
> 
> ***Magic Resistance.*** The deva has Advantage on saving throws against spells and other magical effects.
> 
> ### Actions
> 
> ***Multiattack.*** The deva makes two Holy Mace attacks.
> 
> ***Holy Mace.*** *Melee Attack Roll:* +8, reach 5 ft. *Hit:*  7 (1d6 + 4) Bludgeoning damage plus 18 (4d8) Radiant damage.
> 
> ***Spellcasting.*** The deva casts one of the following spells, requiring no Material components and using Charisma as the spellcasting ability (spell save DC 17):
> 
> - **At Will:** *Detect Evil and Good*, *Shapechange* (Beast or Humanoid form only, no Temporary Hit Points gained from the spell, and no Concentration or Temporary Hit Points required to maintain the spell)
> - **1/Day Each:** *Commune*, *Raise Dead*
> 
> ### Bonus Actions
> 
> ***Divine Aid (2/Day).*** The deva casts *Cure Wounds*, *Lesser Restoration*, or *Remove Curse*, using the same spellcasting ability as Spellcasting.
> - [ ]
> - [ ]
