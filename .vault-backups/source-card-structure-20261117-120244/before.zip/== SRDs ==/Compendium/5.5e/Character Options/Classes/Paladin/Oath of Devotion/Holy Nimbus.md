---
cssclasses:
  - "dnd-book"
  - "dnd-phb"
entity_id: 04b66296-661d-5b56-b027-18c6ce5ae41c
entity_type: character-option
source_ids: ["phb-2024", "srd-5.2.1"]
srd_5_2_1_pages: [57]
---

# Holy Nimbus

![[== SRDs ==/Attachments/Artwork/phb-p116-oath-of-devotion.png|320]]

As a Bonus Action, you can imbue your [[== SRDs ==/Compendium/5.5e/Character Options/Classes/Paladin/Aura of Protection|Aura of Protection]] with holy power, granting the benefits below for 10 minutes or until you end them (no action required). Once you use this feature, you can’t use it again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]]. You can also restore your use of it by expending a level 5 spell slot (no action required).

***Holy Ward.*** You have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on any saving throw you are forced to make by a Fiend or an Undead.

***Radiant Damage***. Whenever an enemy starts its turn in the aura, that creature takes Radiant damage equal to your Charisma modifier plus your Proficiency Bonus.

***Sunlight.*** The aura is filled with [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bright Light|Bright Light]] that is sunlight.

## Handbook source

[[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=116|Player’s Handbook (2024), PDF page 116]] · [[== SRDs ==/Sources/5.5e/Player's Handbook/D&D 5.5E - Player's Handbook.pdf#page=117|Player’s Handbook (2024), PDF page 117]]

## SRD 5.2.1

<!-- source:srd-5.2.1:start -->

As a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bonus Action|Bonus Action]], you can imbue your Aura of Protection with holy power, granting the benefits below for 10 minutes or until you end them (no action required). Once you use this feature, you can't use it again until you finish a [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Long Rest|Long Rest]]. You can also restore your use of it by expending a level 5 spell slot (no action required).

Holy Ward. You have [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Advantage|Advantage]] on any saving throw you are forced to make by a Fiend or an Undead.

Radiant [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Damage|Damage]]. Whenever an enemy starts its turn in the aura, that creature takes Radiant damage equal to your Charisma modifier plus your [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Proficiency|Proficiency]] Bonus.

Sunlight.  The aura is filled with [[== SRDs ==/Compendium/5.5e/Rules/Common Terms/Bright Light|Bright Light]] that is sunlight.

Source: [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=57|SRD 5.2.1, p. 57]].

<!-- source:srd-5.2.1:end -->

## Source References

- [[== SRDs ==/Sources/5.5e/Player's Handbook/Chapter 3 - Character Classes/Chapter 3 - Character Classes|Player's Handbook — Chapter 3 - Character Classes]]
- [[== SRDs ==/Sources/5.5e/System Reference Document/SRD_CC_v5.2.1.pdf#page=57|SRD 5.2.1, p. 57]]
