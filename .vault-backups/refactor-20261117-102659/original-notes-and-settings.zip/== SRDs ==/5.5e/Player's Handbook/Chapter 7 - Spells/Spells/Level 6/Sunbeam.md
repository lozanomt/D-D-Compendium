---
tags:
  - spell
cssclasses:
  - "dnd-book"
  - "dnd-phb"
  - "dnd-spell"
---
# Sunbeam
*Level 6 Evocation (Cleric, Druid, Sorcerer, Wizard)*

![[Placeholder.png|320]]


**Casting Time:** Action
**Range:** Self
**Components:** V, S, M (a magnifying glass)
**Duration:** [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Concentration|Concentration]], up to 1 minute

You launch a sunbeam in a 5-foot-wide, 60-foot-long [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Areas of Effect/Line|Line]]. Each creature in the Line makes a Constitution saving throw. On a failed save, a creature takes 6d8 Radiant damage and has the [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Conditions/Blinded|Blinded]] condition until the start of your next turn. On a successful save, it takes half as much damage only.

Until the spell ends, you can take a [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Actions/Magic|Magic]] action to create a new Line of radiance.

For the duration, a mote of brilliant radiance shines above you. It sheds [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Bright Light|Bright Light]] in a 30-foot radius and [[== SRDs ==/5.5e/Player's Handbook/Appendix C - Rules Glossary/Rules/Common Terms/Dim Light|Dim Light]] for an additional 30 feet. This light is sunlight.
